@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo.
echo  ==============================================
echo    闲鱼自动化 · 安装器
echo  ==============================================
echo.
if not exist "xianyu-achun\install.ps1" (
  echo  [x] 找不到 xianyu-achun\install.ps1。
  echo      你可能只解压了一个文件夹 —— 要把三个文件夹一起解开，
  echo      让它们并排放在一起，然后再双击本文件。
  pause & exit /b 1
)
if not exist "xianyu-playwright-service\server.js" (
  echo  [x] 找不到 xianyu-playwright-service\server.js。
  echo      把整个安装包重新解压一遍，三个文件夹并排，再试。
  pause & exit /b 1
)
if not exist "xianyu-monitor\publish.js" (
  echo  [x] 找不到 xianyu-monitor\publish.js。
  echo      把整个安装包重新解压一遍，三个文件夹并排，再试。
  pause & exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo  [x] 这台电脑还没装 Node.js。
  echo      去 https://nodejs.org 下 LTS 版本装上，
  echo      装完【关掉这个窗口】，重新开一个，再双击本文件。
  pause & exit /b 1
)
if not exist "xianyu-playwright-service\service.local.json" (
  echo  [!] 还没填你自己的账号配置。
  echo      按下面三步做一次，做完回来再双击本文件：
  echo      1）把 xianyu-achun\service.local.json.example 复制成
  echo         xianyu-playwright-service\service.local.json
  echo      2）用记事本打开它，填 id 和 name（见 install-guide.html 第 2 节）
  echo      3）双击 xianyu-playwright-service\start.bat，然后回来运行本文件
  pause & exit /b 1
)
cd xianyu-achun
echo.
echo  ---- 第 1/2 步：预演（什么都不改）----
powershell -ExecutionPolicy Bypass -File install.ps1 -DryRun
echo.
echo  上面这两行应该指向：
echo    xianyu-playwright-service  和  xianyu-monitor
echo  不对的话就停下来 —— 说明三个文件夹没并排放。
echo.
pause
echo  ---- 第 2/2 步：正式安装 ----
powershell -ExecutionPolicy Bypass -File install.ps1
echo.
echo  ---- 装完了。下一步：扫码登录 ----
echo    node tools\store-ready.js "你的店铺名"
echo    node tools\store-login.js "你的店铺名" --wait=15
pause
