xianyu-playwright-service 代码包 20261117-924c0d9
由 tools/make-release.js 生成；只含被 git 跟踪的代码文件，不含 .git、配置、素材、台账。
安装：解压到目标目录后跑 install.cmd（详见 给学员的一页说明.md）。
