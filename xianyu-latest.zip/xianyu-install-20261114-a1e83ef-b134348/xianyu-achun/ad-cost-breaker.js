/**
 * ad-cost-breaker.js — 广告花费熔断器（每 30 分钟跑一次）
 *
 * 阈值（老板 2026-09-27 批准）：
 *   A 累计花费门槛      ¥50
 *   B 单次咨询成本上限  ¥10
 *   C 当日花费/预算占比 80%
 *   E 单日花费上限      ¥100
 *
 * 规则：
 *   1. 累计花费 ≥ ¥50 且 单次咨询成本 > ¥10   → 【自动暂停】+ 企微告警
 *   2. 当日花费 ≥ 预算×80% 且 咨询 = 0        → 企微告警（不自动停）
 *   3. 单日花费 ≥ ¥100                        → 企微告警
 *   4. 订单量计划：累计 ≥ ¥150 且 下单 = 0    → 暂不启用（平台已禁用订单量目标）
 *
 * ⚠️ 护栏：名字以「擦亮宝贝」开头的【主/副集合】计划**一律不自动暂停**，
 *    改为高声告警。依据老板的长期约束「保证主集合和副集合不动」。
 *    但今天花钱最多的 6 条恰恰都是集合计划 —— 所以告警必须够醒目。
 *
 * 用法: node ad-cost-breaker.js [--dry]
 *   退出码 0=正常 1=出错 2=登录态失效
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const { execFileSync } = require('child_process');
const { SVC, ROOT, STORE } = require('./lib/env');

const D = ROOT + '/';
const KEY = SVC.apiKey;
const DRY = process.argv.indexOf('--dry') >= 0;
const SELFTEST = process.argv.indexOf('--selftest') >= 0;

const TH = { A_CUM_COST: 50, B_COST_PER_CHAT: 10, C_BUDGET_PCT: 0.8, E_DAY_COST: 100, B_TARGET_COST: 4, D_ORDER_CUM: 150 };
const COLLECTION = /^擦亮宝贝/;   // 护栏：绝不自动暂停

const LOG = D + 'ad-cost-breaker.log';
const STATE = D + 'ad-cost-breaker-state.json';
const MSG = D + 'ad-cost-breaker-msg.md';

function log(line) {
  const s = new Date().toLocaleString('zh-CN') + '  ' + line;
  console.log(s);
  try { fs.appendFileSync(LOG, s + '\n', 'utf8'); } catch (e) { }
}
function post(p, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 300))); } }); });
    req.on('error', reject); req.setTimeout(timeoutMs || 300000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}
async function evalStore(code) {
  const r = await post('/api/agent/eval-on-store', { store: STORE, code });
  if (!r.ok) throw new Error(r.error || 'eval 失败');
  return r.result;
}
function loadState() { try { return JSON.parse(fs.readFileSync(STATE, 'utf8')); } catch (e) { return {}; } }
function saveState(s) { fs.writeFileSync(STATE, JSON.stringify(s, null, 2), 'utf8'); }

const ymd = d => d.getFullYear().toString() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');

/**
 * hitRules(p) — 单条计划命中哪些规则，返回说明数组（空数组 = 正常）
 * 抽成函数是为了能跑 --selftest：改完误报之后必须证明"该报的还会报"。
 */
function hitRules(p) {
  const hit = [];
  const cpc = p.累计咨询 > 0 ? p.累计花费 / p.累计咨询 : (p.累计花费 >= TH.A_CUM_COST ? Infinity : 0);

  // 规则1：累计花费门槛 + 单次咨询成本
  if (p.累计花费 >= TH.A_CUM_COST && cpc > TH.B_COST_PER_CHAT) {
    hit.push('R1 累计¥' + p.累计花费.toFixed(2) + ' / ' + p.累计咨询 + '咨询 = 单次¥' +
      (cpc === Infinity ? '∞' : cpc.toFixed(2)) + ' > ¥' + TH.B_COST_PER_CHAT);
  }
  // 规则2：当日花费 ≥ 预算×C 且 咨询=0
  if (p.预算 > 0 && p.今日花费 >= p.预算 * TH.C_BUDGET_PCT && p.今日咨询 === 0) {
    hit.push('R2 今日¥' + p.今日花费.toFixed(2) + ' 已达预算¥' + p.预算 + ' 的 ' +
      Math.round(p.今日花费 / p.预算 * 100) + '% 且 0 咨询');
  }
  // 规则3：单日花费上限 —— 【成本感知版】
  // 2026-09-27 首跑教训：原版只看"花了多少"，结果每天都对两条花得多但单次咨询成本
  // 只有 ¥2.92 / ¥3.62（都优于 ¥4 目标）的集合计划告警 → 告警疲劳，与熔断初衷相反。
  // 故追加成本条件：花得多 **且** 花得不值（今日单次咨询成本 > ¥4 目标）才告警。
  if (p.今日花费 >= TH.E_DAY_COST) {
    const tcpc = p.今日咨询 > 0 ? p.今日花费 / p.今日咨询 : Infinity;
    if (tcpc > TH.B_TARGET_COST) {
      hit.push('R3 今日¥' + p.今日花费.toFixed(2) + ' ≥ ¥' + TH.E_DAY_COST +
        '，且今日单次咨询成本 ' + (tcpc === Infinity ? '∞（0 咨询）' : '¥' + tcpc.toFixed(2)) + ' > ¥' + TH.B_TARGET_COST);
    }
  }
  return hit;
}

// ── 浏览器侧：拉「近7日累计」+「今日」两份，按 campaignId 合并 ──
function pullJs(startYmd, endYmd) {
  return `(async () => {
  const mtop = window.lib.mtop;
  const TGT = { exposure:'曝光量', click:'浏览量', follow_collect:'关注收藏量', chat:'咨询量', order:'订单量' };
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const out = { 时刻: new Date().toLocaleString('zh-CN') };
  async function q(extra) {
    const req = Object.assign({ pageNum:1, pageSize:100, campaignStatus:[], statusGroup:[] }, extra||{});
    const r = await mtop.request({ api:'mtop.taobao.idle.ad.campaign.search', v:'1.0', type:'GET',
      data:{ requestJson: JSON.stringify(req) } });
    if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS')===0)) throw { ret: r && r.ret };
    return ((r.data||{}).result)||[];
  }
  const range = await q({ startDate: '${startYmd}', endDate: '${endYmd}', includeEndDate: true });
  const today = await q({});
  const tmap = {}; today.forEach(c => tmap[String(c.campaignId)] = c);
  out.计划 = range.map(c => {
    const d = c.adDataDetailVO || {};
    const t = tmap[String(c.campaignId)] || {};
    const it = t.infoTab || {};
    const td = t.todayAdDataDetail || {};
    return {
      id: String(c.campaignId), name: c.title,
      target: TGT[c.bidTarget] || c.bidTarget,
      pause: String(c.pauseStatus||''),
      累计花费: n(d.cost)/100, 累计咨询: n(d.chatPv), 累计下单: n(d.payPv),
      累计支付额: n(d.payAmount)/100,
      今日花费: n(it.todayCost)/100,
      今日咨询: n(td.chatPv),
      预算: n(t.maxDayBudget)/100,
    };
  });
  // 有些计划（如已暂停的）只在 today 里出现
  today.forEach(c => {
    if (out.计划.some(x => x.id === String(c.campaignId))) return;
    const it = c.infoTab || {}, td = c.todayAdDataDetail || {};
    out.计划.push({ id:String(c.campaignId), name:c.title, target:TGT[c.bidTarget]||c.bidTarget,
      pause:String(c.pauseStatus||''), 累计花费:0, 累计咨询:0, 累计下单:0, 累计支付额:0,
      今日花费:n(it.todayCost)/100, 今日咨询:n(td.chatPv), 预算:n(c.maxDayBudget)/100 });
  });
  return JSON.stringify(out);
})()`;
}

/**
 * 空闲门槛：你在用电脑就跳过本轮巡检。
 *
 * 存在的理由（2026-09-30 老板反馈「一直有弹出窗口」）：
 *   广告接口只在 dayu 域可用，所以巡检一开始必须
 *   `location.href=dayu...` 把那个【可见的】Chrome 窗口导航到广告后台 ——
 *   于是每 30 分钟就弹一次，人在电脑前时很烦。
 *   你离开后照跑，熔断保护不丢。
 *   （发布链那边【没有】这个门槛 —— 老板要求「守在电脑前也要发」。两处刻意不同。）
 *
 * 2026-10-01：不再自己实现，统一走 lib/idle.js。
 *   原来这里抄了一份 GetLastInputInfo，**忘了 /1000** —— dwTime 是毫秒，
 *   300 秒的阈值被当成 300 毫秒，空闲 30 秒算出「30000 >= 300」判为不忙，
 *   门槛实际上从来没生效过。lib/ps/Idle.ps1 里那份犯了同样的错。
 *   抄第二份正是这次踩坑的原因，所以只留一处。
 */
const idleLib = require('./lib/idle');

(async () => {
  const now = new Date();
  const start = new Date(now.getTime() - 6 * 86400000);

  // 广告只在 8:00-23:00 投放，其余时段不必巡检（省掉无意义的页面导航）
  const h = now.getHours();
  if (h < 7 || h >= 24) { console.log(new Date().toLocaleString('zh-CN') + '  非投放时段(' + h + '点)，跳过'); process.exit(0); }

  // 用户在用电脑就跳过本轮：巡检必须导航那个【可见】窗口，会弹出来打扰人。
  // 检测失败(-1)时按「不跳过」处理（fail-open）—— 宁可弹一次窗，也不丢掉烧钱熔断。
  // 【--selftest 不受此限】：自检是纯规则运算（跑合成计划），不碰浏览器、不会弹窗，
  //   任何时候都该能跑 —— 它是改规则后的回归测试，被门槛拦住就失去意义了。
  if (idleLib.skipIfBusy('熔断巡检', { force: SELFTEST })) process.exit(0);

  // ── 放假/停投期间，熔断器【没有存在意义】，直接跳过 ──
  // 2026-10-03 追查「一直弹窗」的真凶就是这里：
  //   ① 当初只给 ad-retry-order.ps1 / ad-watch-stuck.ps1 加了 PAUSE-ADS 门，**漏了这个**；
  //   ② 它每 30 分钟无条件导航那个【可见的】浏览器；
  //   ③ 浏览器被「空闲 20 分钟回收」后，这次导航会把它【重新拉起】= 弹出一个新窗口。
  //      所以只要人在电脑前但没碰键盘（空闲 > 5 分钟），门槛放行 → 每半小时弹一次。
  // 停投期间没有在投的广告，熔断什么？整个跳过，一次浏览器都不碰。
  if (!SELFTEST && require('fs').existsSync(require('path').join(__dirname, 'PAUSE-ADS'))) {
    console.log(new Date().toLocaleString('zh-CN') + '  PAUSE-ADS 存在：停投中，跳过本轮巡检（不导航浏览器）');
    process.exit(0);
  }

  log('=== 熔断巡检开始 (dry=' + DRY + ' selftest=' + SELFTEST + ') 阈值 ' + JSON.stringify(TH) + ' ===');

  // ── 自检模式：用合成计划跑【同一段规则代码】，验证规则该报的会报、不该报的不报 ──
  // 存在的意义：修好一个"误报"之后，很容易把它改成"永不触发"的废规则。这个模式防的就是这个。
  let plans;
  if (SELFTEST) {
    plans = [
      { id: 'T1', name: '自检-花得多但效果好', pause: '0', 累计花费: 311.33, 累计咨询: 86, 今日花费: 324.90, 今日咨询: 86, 预算: 500, target: '咨询量' },
      { id: 'T2', name: '自检-花得多且效果差', pause: '0', 累计花费: 150.00, 累计咨询: 20, 今日花费: 150.00, 今日咨询: 20, 预算: 150, target: '咨询量' },
      { id: 'T3', name: '自检-花得多且零咨询', pause: '0', 累计花费: 120.00, 累计咨询: 0, 今日花费: 120.00, 今日咨询: 0, 预算: 500, target: '咨询量' },
      { id: 'T4', name: '自检-累计¥50单次¥12', pause: '0', 累计花费: 60.00, 累计咨询: 5, 今日花费: 10.00, 今日咨询: 1, 预算: 150, target: '咨询量' },
      { id: 'T5', name: '自检-集合计划触发', pause: '0', 累计花费: 60.00, 累计咨询: 5, 今日花费: 10.00, 今日咨询: 1, 预算: 150, target: '咨询量' },
    ];
    plans[4].name = '擦亮宝贝自检-集合计划触发';
    log('[自检] 用 5 条合成计划跑规则');
    const VERDICT = {
      T1: '不应告警（¥3.77/咨询 优于 ¥4）',
      T2: 'R3 应告警（¥7.50/咨询）',
      T3: 'R3 应告警（0 咨询 → ∞）',
      T4: 'R1 应告警（累计¥60 / 5咨询 = ¥12 > ¥10）',
      T5: 'R1 应告警但归入"集合计划只告警不停"',
    };
    for (const p of plans) {
      const hit = hitRules(p);
      const isColl = COLLECTION.test(p.name);
      console.log('  ' + p.id + ' ' + p.name + '  →  ' + (hit.length ? hit.join('；') : '（无）') +
        '   [预期: ' + VERDICT[p.id] + ']' + (isColl ? '  【集合】' : ''));
    }
    process.exit(0);
  }

  // 进入广告控制台页（接口只在该域可用）
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage"; "ok"' }, 60000);
  await new Promise(r => setTimeout(r, 16000));

  let raw;
  try { raw = await evalStore(pullJs(ymd(start), ymd(now))); }
  catch (e) { log('❌ 拉取失败: ' + e.message); process.exit(e.message.indexOf('SESSION') >= 0 ? 2 : 1); }
  let data; try { data = typeof raw === 'string' ? JSON.parse(raw) : raw; } catch (e) { log('❌ 解析失败: ' + String(raw).slice(0, 300)); process.exit(1); }
  plans = data.计划 || [];
  log('拉到 ' + plans.length + ' 条计划');

  // ── 评估规则 ──
  const today = now.toISOString().slice(0, 10);
  const st = loadState();
  const alerts = [];      // 告警（含集合计划）
  const toPause = [];     // 待自动暂停
  const skipped = [];     // 触发了但因为是集合计划而没停

  for (const p of plans) {
    if (p.pause === '1') continue;                       // 已停的不管
    const hit = hitRules(p);
    if (!hit.length) continue;

    const isColl = COLLECTION.test(p.name);
    if (isColl) {
      if (!st[p.id + '|' + today]) { skipped.push({ p, hit }); }
    } else if (hit.some(h => h.indexOf('R1') === 0)) {
      if (!st[p.id + '|' + today]) toPause.push({ p, hit });
    } else {
      if (!st[p.id + '|' + today]) alerts.push({ p, hit });
    }
  }

  // ── 执行自动暂停（只针对非集合计划）──
  const pausedOk = [];
  if (toPause.length && !DRY) {
    const ids = toPause.map(x => x.p.id);
    try {
      const r = await evalStore(`(async () => {
        const r = await window.lib.mtop.request({ api:'mtop.taobao.idle.ad.campaign.pause', v:'1.0', type:'POST',
          data:{ requestJson: JSON.stringify({ campaignIds: ${JSON.stringify(ids)}, pauseStatus: 1 }) } });
        return JSON.stringify({ ret: r && r.ret });
      })()`);
      log('暂停返回: ' + String(r).slice(0, 200));
      pausedOk.push(...toPause);
      toPause.forEach(x => { st[x.p.id + '|' + today] = 'paused'; });
    } catch (e) { log('❌ 暂停失败: ' + e.message); }
  }

  // ── 告警 ──
  const needAlert = alerts.concat(skipped);
  if (needAlert.length || pausedOk.length) {
    const L = ['## ' + (pausedOk.length ? '🛑 广告熔断触发' : '⚠️ 广告花费异常'), '',
      '**' + new Date().toLocaleString('zh-CN') + '**   阈值：累计¥' + TH.A_CUM_COST + ' / 单次¥' + TH.B_COST_PER_CHAT + ' / 预算' + (TH.C_BUDGET_PCT * 100) + '% / 单日¥' + TH.E_DAY_COST, ''];
    if (pausedOk.length) {
      L.push('### 已自动暂停（单链接）');
      L.push('| 计划 | 累计花费 | 咨询 | 单次成本 | 触发 |', '|---|---|---|---|---|');
      pausedOk.forEach(x => L.push('| ' + x.p.name + ' | ¥' + x.p.累计花费.toFixed(2) + ' | ' + x.p.累计咨询 + ' | ' + (x.p.累计咨询 ? '¥' + (x.p.累计花费 / x.p.累计咨询).toFixed(2) : '∞') + ' | ' + x.hit.join('；') + ' |'));
      L.push('');
    }
    if (skipped.length) {
      L.push('### ⚠️ 集合计划触发但**未自动停**（按你的规矩不动主/副集合）');
      L.push('| 计划 | 累计花费 | 咨询 | 单次成本 | 触发 |', '|---|---|---|---|---|');
      skipped.forEach(x => L.push('| ' + x.p.name + ' | ¥' + x.p.累计花费.toFixed(2) + ' | ' + x.p.累计咨询 + ' | ' + (x.p.累计咨询 ? '¥' + (x.p.累计花费 / x.p.累计咨询).toFixed(2) : '∞') + ' | ' + x.hit.join('；') + ' |'));
      L.push('', '**这些要你决定：继续投、降出价、还是停。**');
      L.push('');
    }
    if (alerts.length) {
      L.push('### 仅告警（未达自动暂停条件或非 R1）');
      alerts.forEach(x => L.push('- `' + x.p.name + '` — ' + x.hit.join('；')));
      L.push('');
    }
    fs.writeFileSync(MSG, L.join('\n'), 'utf8');
    // 【2026-11-13 加】先看 wecom-send.ps1 在不在。
    //   它是【内部企微发送器】，学员包里没有（make-release 排掉了）。
    //   原来直接 execFileSync，失败就 log「❌ 告警发送失败」——
    //   学员看到红叉会以为熔断器坏了，其实只是"没装企微，告警留在本地文件里"。
    //   学员的正确预期是：熔断【照常暂停计划】，告警内容写进 ad-cost-breaker-msg.md 自己看。
    const WECOM = D + 'wecom-send.ps1';
    if (DRY) {
      // 【2026-11-13 修】原来 --dry 只挡住了【暂停计划】(L253 的 !DRY)，
      //   没挡【发企微告警】—— 实测 2026-11-13 跑 `node ad-cost-breaker.js --dry`
      //   真的去调了企微，还因为授权过期打了一屏红字。
      //   演习不该有任何外部副作用：不发企微、不改平台、只打印会做什么。
      log('ℹ️ --dry 演习：告警内容已写入 ' + MSG + '（不发企微）');
      [...pausedOk, ...needAlert].forEach(x => { st[x.p.id + '|' + today] = st[x.p.id + '|' + today] || 'alerted'; });
    } else if (!fs.existsSync(WECOM)) {
      log('ℹ️ 这台机器没装企微发送器（wecom-send.ps1），告警内容已写入 ' + MSG);
      log('   → 熔断照常生效（超阈值的计划已经暂停）;想发到企微找管理员配。');
      [...pausedOk, ...needAlert].forEach(x => { st[x.p.id + '|' + today] = st[x.p.id + '|' + today] || 'alerted'; });
    } else {
      try {
        execFileSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', WECOM, '-File', MSG], { stdio: 'inherit' });
        [...pausedOk, ...needAlert].forEach(x => { st[x.p.id + '|' + today] = st[x.p.id + '|' + today] || 'alerted'; });
      } catch (e) { log('❌ 告警发送失败（内容留在 ' + MSG + '）: ' + e.message); }
    }
  } else {
    log('无异常');
  }

  // ── 告警明细落日志 ──
  // 2026-09-28 补：原来日志只写「集合计划告警 1」，不写是哪条计划、命中哪条规则、什么数值，
  // 事后完全没法追溯（当天为了查 96296935 到底命中 R1/R2/R3，只能另外写脚本拉实时数据算）。
  // 企微消息里本来就有明细表格，这里只是把同样的信息也落一份到日志。
  if (needAlert.length) {
    needAlert.forEach(x => log('  ⚠ 明细 ' + x.p.name + ' (id=' + x.p.id + ' 目标' + (x.p.target || '?') + ')' +
      '  累计 ¥' + x.p.累计花费.toFixed(2) + '/' + x.p.累计咨询 + '咨询' +
      '  今日 ¥' + (x.p.今日花费 || 0).toFixed(2) + '/' + (x.p.今日咨询 || 0) + '咨询' +
      '  预算 ¥' + (x.p.预算 || 0) +
      '  →  ' + x.hit.join('；')));
  }
  if (pausedOk.length) {
    pausedOk.forEach(x => log('  🛑 已暂停 ' + x.p.name + ' (id=' + x.p.id + ')  →  ' + x.hit.join('；')));
  }

  saveState(st);
  log('巡检结束：自动暂停 ' + pausedOk.length + '，集合计划告警 ' + skipped.length + '，仅告警 ' + alerts.length);
  process.exit(0);
})().catch(e => require('./lib/crash').crash(e, 1));
