@echo off
rem ===== Version-independent node launcher (ASCII only on purpose) =====
rem WHY: CodeBuddy auto-update renames versions\<ver> to .<ver>.deleting.* overnight.
rem On 2026-10-02 that silently killed scheduled tasks (LastTaskResult 2147942402
rem = file not found). Never hardcode a node version in a scheduled task.
rem
rem Resolution order:
rem   1) %XY_NODE%                      - explicit override, must exist
rem   2) %XY_NODE_VERSIONS%\current     - a text file holding the version name
rem   3) newest non-dot dir under versions (skips .deleting.* and locks)
rem   4) node.exe on PATH
rem
rem %XY_NODE_VERSIONS% defaults to %USERPROFILE%\.workbuddy\binaries\node\versions,
rem so a machine that has no WorkBuddy simply falls through to 4). Nothing here is
rem specific to one user account any more.
setlocal
set "VD=%XY_NODE_VERSIONS%"
if "%VD%"=="" set "VD=%USERPROFILE%\.workbuddy\binaries\node\versions"
set "N="

if defined XY_NODE if exist "%XY_NODE%" set "N=%XY_NODE%"
if not defined N if exist "%VD%\current" for /f "usebackq delims=" %%v in ("%VD%\current") do if exist "%VD%\%%v\node.exe" set "N=%VD%\%%v\node.exe"
if not defined N if exist "%VD%" for /f "delims=" %%d in ('dir /b /ad /o-d "%VD%" 2^>nul ^| findstr /v /b /l /c:"." ^| findstr /v /i /l /c:"locks"') do if not defined N if exist "%VD%\%%d\node.exe" set "N=%VD%\%%d\node.exe"

if not defined N goto trypath
"%N%" %*
exit /b %ERRORLEVEL%

:trypath
where node >nul 2>nul
if errorlevel 1 goto nonode
node %*
exit /b %ERRORLEVEL%

:nonode
echo [run-node] �Ҳ��� node���� XY_NODE / XY_NODE_VERSIONS ������������� node �ӽ� PATH�� 1>&2
exit /b 1