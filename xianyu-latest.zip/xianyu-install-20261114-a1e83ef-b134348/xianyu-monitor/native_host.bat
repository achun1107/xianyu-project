@echo off
set PYTHONDONTWRITEBYTECODE=1
python "C:\Users\43462\Desktop\xianyu-monitor\native_host.py" %*
