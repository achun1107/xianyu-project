@echo off
chcp 65001 >nul
cd /d "%~dp0\..\.."
title 闲鱼上架助手

echo.
echo   正在启动，稍后浏览器会自动打开…
echo   用完了关掉这个黑窗口就行。
echo.

rem 3 秒后自动打开浏览器（等 node 把端口起来）
start "" /min cmd /c "timeout /t 3 >nul & start http://127.0.0.1:8099"

node tools\staff-ui\server.js

pause
