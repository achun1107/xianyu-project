# xianyu-monitor 代码审查报告

审查标准（沿用 hym-admin AGENTS.md 固化纪律 + think-before-act 原则）：单文件 ≤400 行、分层清晰、SSOT 单一真源、禁止静默吞错、命名统一、无死代码、无店铺/机器专属硬编码、安全红线（密钥/XSS/权限最小化）。

---

## 一、P0 阻断项（先修这些，其余都排后面）

### 1. background.js 语法级错误，Service Worker 可能整体加载失败
- **L530**：非 async 的 `onMessage` 监听器里使用 `await` —— 语法错误，会导致整个 SW 解析失败。
- **L80**：`SAVE_COOKIE` 分支引用未定义变量 `profile`，保存登录恒报失败。

### 2. API Key 已泄漏，需立即轮换
- `xy_78****` 硬编码出现在 **4 处前端源码**：publish.js L893/L1403、publish_dashboard.js L6、dashboard.js L357、api.js L5、bridge_direct.js L9。
- 仓库由 `一键安装.bat` 从**公开 GitLab** clone，Key 已事实泄漏。该 Key 可调本地 8093 服务（读写磁盘 + `eval-on-store` 任意页面执行代码 = 本机 RCE 面）。
- **修复**：轮换 Key；改为 native host 下发 / 会话令牌，绝不再进前端源码。

### 3. XSS（多处确认，外部数据进 innerHTML 未转义）
| 位置 | 问题 |
|---|---|
| publish_ui.js L1141–1143 | renderLog 的 `l.m` 未 escHtml 直插，日志含抓取的商品标题/URL |
| dashboard.js L131 | 商品名 `r.name` 直插 innerHTML（全文件无转义函数） |
| dashboard.js L216–217 | `JSON.stringify(fields)` 进 innerHTML，不转义 `<` |
| dashboard.js L378–388 | 配置 value 未转义破属性 |
| publish_dashboard.js L782–789 等 | 剪贴板 URL 以 `indexOf('http')===0` 判断后直拼 `<img src="...">`，可注入 `onerror` |
| publish_dashboard.js L304 | 服务端模板 name/ratio 未转义 |
| monitor.js | 商品名 innerHTML 未转义 |

### 4. 确认的逻辑 bug（不只是风格）
- **publish.js L1113 / L1563**：`storeCfg` 在 `var storeCfg = loadStoreConfig()`（L1131/L1585）**之前**使用——var 提升使其恒为 `undefined`，**店铺级副图开关从未生效**。
- **dashboard.js L226/L252**：`ALERT_KEY` 从未定义。`loadAlertConfig` 读它抛 ReferenceError 被吞、恒返默认值；`saveAlertConfig` 抛未捕获异常——**告警配置功能整体失效**。
- **dashboard.js L355–359**：`saveConfigs` 用相对路径 fetch `/api/agent/native-host`，扩展页 origin 下必然失败且被吞——配置永远同步不到磁盘权威源。
- **publish_dashboard.js L2049/L2130（多店发布只写当前店任务盘）**：`runStoreBatch`/`startPublish` 只在 `store === state.currentStore` 时写盘，却对所有勾选店铺执行 `syncTasksFromDisk()`——**非当前店铺发布的是旧磁盘任务**，正确性硬伤。
- **publish.js L1660–1662**：`runBatchPublish` 用过滤后的子集整体写回，已完成任务的 itemId 历史被从任务列表剔除，破坏"itemId 已存在永不重发"防线的数据前提。

### 5. Native host 安装链路断裂
- `native_host_manifest.json` L4：`C:\\\\Users\\\\43462\\\\...` 双反斜杠转义错误 + 写死个人用户目录 + description GBK 乱码；换机即不可用。应由 install_host.ps1 按实际路径生成。
- `install_host.ps1` L55：path 直接指向 `.py`，绕过 `native_host.bat` 里设置的 `PYTHONDONTWRITEBYTECODE=1` —— 正是 `__pycache__` 残留导致扩展加载失败的根源（操作记录里踩过）。应指向 `.bat`。

---

## 二、安全（除 Key/XSS 外）

1. **任意本地文件读取**：bridge.js L142 NATIVE_HOST 透传 + 页面广播 postMessage 不校验 origin ⇒ goofish 页面上任意第三方脚本可经 native host `readImage` 读任意本地文件（base64 回传）。message 监听普遍无 origin/source 校验（publish.js L1832 的 `PD_PREPARE_PUBLISH` 可被页面脚本伪造驱动发布+擦亮=花钱）。
2. **eval-on-store**：本地服务提供"任意店铺页面执行任意代码"，与已泄漏 Key 组合即本机 RCE。
3. **凭据过度收集**：SAVE_COOKIE 明文存储 goofish + taobao + **alipay** 全量 Cookie；publish.js L816 把整包 `document.cookie` 外传 Python 代理。建议移除 alipay，收敛域名列表（该列表散落 3 份）。
4. **manifest.json 权限**：`web_accessible_resources` matches `<all_urls>` 应收敛到 goofish + manager.hympro.cn；`browsingData` 未使用应删；`*.taobao.com`/`*.alipay.com` 过宽按实际收窄。
5. background.js L9 硬编码飞书 Webhook。

---

## 三、SSOT（结构性根源，重复上架/数据回滚都来自这里）

- **任务数据 4 条双向同步路径**（publish.js）：启动磁盘→LS（L231–238）、2 分钟定时 LS→磁盘（L336）、beforeunload 推送（L479）、发布前拉取（L1286/1649）。发布间隙旧数据回写会覆盖刚写盘的 status/itemId；L1653 的 `!t.itemId` 过滤是补丁非根治。
- **publish_dashboard.js L1662–1734**：localStorage 与磁盘双写无版本仲裁，写盘失败仅 console.log（L1683），下次 load 用磁盘**无条件覆盖**（L1717）——写失败后新任务被静默回滚。
- **dashboard.js / publish_ui.js** 绕过封装直写 `localStorage['kun_project_configs']`/`kun_tpl_global`，第二套读写路径。
- **修复方向**：磁盘为唯一权威源，页面持工作副本，所有变更走单一 write-through（内存→盘→LS 缓存），删除 2 分钟盲推定时器，读盘做版本/时间戳仲裁，写失败必须 UI 上报。

---

## 四、静默吞错（抽查即 40+ 处，最危险清单）

| 文件 | 行号 | 影响 |
|---|---|---|
| publish.js | 238 / 255 | **任务/模板写盘失败 `.catch(function(){})`，数据无声丢失** |
| publish.js | 1632 | 自动擦亮失败静默——投放（花钱）失败无感知 |
| publish.js | 1123 / 1552–1578 | 上传失败与"文件不存在"混为一谈 |
| publish_dashboard.js | 1655–1656 | 唤醒计划没设上，用户以为定时生效（涉及钱） |
| publish_dashboard.js | 1683 / 1730 / 2103 | SSOT 写失败不报告；轮询一次抖动即放弃跟踪（发布仍在跑） |
| dashboard.js | 多处 | 告警/配置失败全吞 |
| background.js | L124/207/343/351/478/503/505/524/532/625 | 空吞 |
| bridge.js / monitor.js | L176/478；L36/42/192/211/292 | 空吞 |

**规则**：`catch(e){}` 一律消灭；写盘类失败必须 UI 提示；`api()` 统一检查 `res.ok`（当前从不检查，是吞错的根因）。

---

## 五、死代码（确认不可达，直接删）

- **publish_ui.js L218 `return;` 之后 L220–618 约 400 行**：引用的 DOM id（kp-casa-*、kp-poster-*、kp-start 等）在精简后的面板里不存在。
- publish.js：`runDailyPublish`(L283)、`runRotateAll`(L1426)、旧队列体系 `startAuto/stopAuto/runOne/readQueue/writeQueue/getStats` 等无调用方；`startPublishLegacy`（操作记录已知）。
- **bridge_direct.js 整个文件**：未注册进 manifest，与 bridge.js 职责重复且路径不一致。
- dashboard.js：`feeIncrease` 告警配置 UI 可配但逻辑未实现（死配置）；`kun_trend_db` 本文件只读不写。
- publish_dashboard.js L958 `IMAGES_ROOT`（写死 `C:/Users/43462/...` 且无引用）。

---

## 六、硬编码 / 店铺与机器专属逻辑

- `'casa家居'` 字符量判断 **4 处**（publish.js L1074/1113/1512/1563）+ publish_ui.js 死代码区 + publish_dashboard.js L1973–1979（天猫搬运文案"工厂代工"、分类"装饰灯"写死）→ 应改为店铺配置字段。
- `C:/Users/43462/Desktop/闲鱼上架图片/`（publish.js L225）写死个人机器路径。
- 城市表重复定义 **5 次**且内容有出入；擦亮出价 13.6/日预算 50/时段 [8..22]/类目 ID 201456914 回退、POI 写死苏州经纬度、预览城市写死"广州"。
- API BASE `localhost:8093` / 旧域名 `hym-admin.webkubor.online`（已下线域名！AGENTS.md 明确警示）散落多处；Cookie 域名列表 3 份；20+ 消息类型字符串散落多文件 → 建统一常量表。
- 三份近乎相同的发布编排（doDailyTask / publishOneTask / publishOneExternalTask）细节漂移，改一漏二 → 合并为一条。

---

## 七、竞态

- 发布循环运行中切店触发 `loadStoreData()` 重载 state.tasks，`runStoreBatch` 的 total/写盘读易变 state，跨店写错数据风险。
- 两个标签页各开一份发布台：`state.publishing` 是各自内存变量，同一店铺会被下发两次。
- `pollStoreBatch` 被 await 在循环内，单店最长阻塞 10 分钟，"多店并发"实为串行。
- publish_ui.js：每次切店/每次渲染都 addEventListener message 监听（不设超时），泄漏堆积；renderTaskRows 全量 innerHTML 重建丢输入焦点，用户输入与后台发布互相覆盖。
- publish_dashboard.js `ensureStoreEngine`：无失败快速路径、`move` 会杀正在发布的循环（与注释矛盾）、无并发保护。

---

## 八、文件规模（≤400 行标准）

| 文件 | 行数 | 方案 |
|---|---|---|
| publish_dashboard.js | 2397 | 拆 13 模块：core/{api,store-sync,publish}、views/{gallery,tasks,templates,store-panel}、workshop/{workshop,canvas,poster,scrape}、main；内联样式抽 publish_dashboard.css |
| publish.js | 2003 | 拆 7 模块：core/{config,storage,store,image,publisher,scheduler,external}；先删死代码 |
| publish_ui.js | 1609（活代码约 1200） | 删 L220–618 后拆 4 模块：ui/{panel,taskTable,dialogs,events} |
| background.js | 628 | 入口路由 + bg/{cookies,publish,sync,notify} |
| monitor.js | 525 | 入口 + fetch + panel + copy_export + sync + trend |
| dashboard.js | 429 | 拆 data/table/trend/config，先修 ALERT_KEY |

其他小问题：dashboard.js 表头 7 列表体 8 列（L118–140）；monitor.js toISOString 取日期 UTC+8 凌晨拿到前一天；一键安装.bat clone 无 exit code 检查失败仍报"安装完成"；publish_dashboard 三个发布按钮（🚀/📦/📤）语义重叠文案区分不出"节奏 vs 立即"。

---

## 九、修复优先级

1. **当天**：轮换 API Key；修 background.js L530/L80；修 storeCfg 声明顺序、ALERT_KEY、saveConfigs 相对路径；manifest path/ps1 指向 .bat。
2. **本周**：XSS 全部补转义；message 监听加 origin 校验；多店发布全店写盘；写盘失败上报 + 版本仲裁；删 ~800 行确认死代码（publish_ui 400 行 + bridge_direct.js + publish.js 旧体系）。
3. **迭代内**：文件拆分到 ≤400 行；合并三份发布编排；casa/路径/城市表等硬编码进配置；吞错清零；manifest 权限收敛。

## 十、值得肯定

- 发布从"发布台直发"演进到"写盘 + 店铺页自循环"的方向正确，店铺互不干扰的隔离设计合理。
- publish_dashboard.js 的 esc() 覆盖率较高；任务表/店铺面板有空态占位；`_pdTweakTitle` 用确定性种子利于复现。
- 操作记录（踩坑→修复→遗留）习惯好，本次多处结论可直接对照其遗留清单。
