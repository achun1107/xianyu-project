const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let win;
function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 880,
    webPreferences: { nodeIntegration: true, contextIsolation: false }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(createWindow);
app.on('window-all-closed', function(){ if (process.platform !== 'darwin') app.quit(); });

// 占位：P1 后续接入 IPC（中台出图 / 扫码登录 / 发商品）
ipcMain.handle('ping', (e, args) => { return 'pong ' + (args || ''); });
