#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""擦亮广告成本台账 — 把「100元出3单」变成一个可核算的目标。

设计原则抄自 voxflow/core/obs.py（好易美的上游项目），四条：
  1. **写入时定格**：落库的数值就是当时看到的数值；平台事后修正时不静默覆盖，
     而是把旧值写进 ad_changes 留痕（改一次价/回填一次历史，不应改写过去的结论）。
  2. **失败照样记账**：拉取失败的日期写一行 status='fail'，账本上有「空洞」比数字错更危险。
  3. **数据源要标注**：日汇总接口对最近 1~2 天有滞后（实测：查 9/10 返回 0，但前一日小时
     累计到 23:00 是 ¥653.44）。所以 source 区分 'daily' / 'hourly'（小时累计补齐）。
  4. **未证实就留空**：拿不到就是 NULL，不填 0 —— 0 是「真的没花」，NULL 是「不知道」。

数据源（已验证可用）：
  mtop.taobao.idle.ad.member.data.query —— 账户级，任意日期区间
  返回：cost(分) showPv clickPv inquiries payPv payAmount(分) returnOnInvestment
  plus dataDetailVOList（逐日）与 previousDataDetailVOList（前一窗口逐日/逐时）

用法:
  python ad_ledger.py pull  [--store 好易美代拍] [--days 30] [--no-restore]
  python ad_ledger.py report [--days 7] [--target 100:3]
  python ad_ledger.py today  [--store 好易美代拍]     # 拉今天并直接出达标判断
"""
import argparse
import json
import os
import sqlite3
import sys
import time
import urllib.request
from datetime import date, datetime, timedelta

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

SVC = os.environ.get("XY_SVC", "http://127.0.0.1:8093")
KEY = os.environ.get("XY_KEY", "")
DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ad_ledger.sqlite")

# 擦亮数据接口的页面表达式（复用发布台里已验证的那条）
AD_EXPR = (
    "(function(){try{var rj=JSON.stringify({startDate:'%s',endDate:'%s',includeEndDate:true});"
    "return window.lib.mtop.request({api:'mtop.taobao.idle.ad.member.data.query',v:'1.0',"
    "data:{requestJson:rj},type:'POST'}).then(function(r){"
    "if(r&&r.ret&&r.ret[0]&&r.ret[0].startsWith('SUCCESS'))return JSON.stringify({ok:1,data:r.data});"
    "return JSON.stringify({err:(r&&r.ret?r.ret[0]:'fail')});});}"
    "catch(e){return Promise.resolve(JSON.stringify({err:e.message}));}})()"
)


def api(path, body=None, timeout=60):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(SVC + path, data=data,
                                 headers={"Content-Type": "application/json", "X-API-Key": KEY},
                                 method="POST" if body is not None else "GET")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def init_db():
    con = sqlite3.connect(DB)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS ad_daily (
      store      TEXT NOT NULL,
      date       TEXT NOT NULL,
      cost       REAL,       -- 元（接口给分，落库换算）
      show_pv    INTEGER,
      click_pv   INTEGER,
      inquiries  INTEGER,
      pay_pv     INTEGER,    -- 下单数
      pay_amount REAL,       -- 交易额（元）
      roi        REAL,
      source     TEXT,       -- daily | hourly | fail
      note       TEXT,
      pulled_at  TEXT,
      PRIMARY KEY (store, date)
    );
    CREATE TABLE IF NOT EXISTS ad_changes (
      store TEXT, date TEXT, field TEXT, old_value TEXT, new_value TEXT, changed_at TEXT
    );
    """)
    con.commit()
    return con


def zh(s):
    return datetime.fromtimestamp(s).strftime("%Y-%m-%d %H:%M:%S")


def pull_range(store, start, end):
    """拉一个日期区间的账户级数据。返回 (daily dict, hourly-fallback dict)。"""
    expr = AD_EXPR % (start.replace("-", ""), end.replace("-", ""))
    r = api("/api/agent/eval-on-store", {"store": store, "code": expr}, timeout=90)
    if not r.get("ok"):
        raise RuntimeError(r.get("error") or "eval 失败")
    raw = r.get("result")
    d = json.loads(raw) if isinstance(raw, str) else raw
    if d.get("err"):
        raise RuntimeError("mtop 返回 " + str(d["err"]))
    payload = d["data"]

    def conv(x):
        if not x:
            return None
        return {
            "cost": (x.get("cost") or 0) / 100.0,
            "show_pv": x.get("showPv"),
            "click_pv": x.get("clickPv"),
            "inquiries": x.get("inquiries"),
            "pay_pv": x.get("payPv"),
            "pay_amount": (x.get("payAmount") or 0) / 100.0,
            "roi": x.get("returnOnInvestment"),
        }

    daily = {}
    for row in payload.get("dataDetailVOList") or []:
        t = (row.get("time") or "")[:10]
        if t:
            daily[t] = conv(row)

    # 日汇总对最近 1~2 天有滞后：用「前一日小时累计」的最后一格补齐
    hourly = {}
    prev = payload.get("previousDataDetailVOList") or []
    if prev:
        last_by_day = {}
        for row in prev:
            t = (row.get("time") or "")
            if len(t) >= 13 and row.get("unit") == "HOUR":
                last_by_day[t[:10]] = row
            elif row.get("unit") == "DAY":
                last_by_day[(t or "")[:10]] = row
        for day, row in last_by_day.items():
            hourly[day] = conv(row)
    return daily, hourly


def upsert(con, store, day, vals, source, note=""):
    """写入时定格：值变了就留痕，不静默覆盖。"""
    cur = con.execute("SELECT cost,pay_pv,pay_amount,show_pv,click_pv,inquiries,source,note FROM ad_daily WHERE store=? AND date=?",
                      (store, day)).fetchone()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if cur:
        keys = ["cost", "pay_pv", "pay_amount", "show_pv", "click_pv", "inquiries"]
        for i, k in enumerate(keys):
            old, new = cur[i], vals.get(k)
            if old is None or new is None:
                continue
            if abs(float(old) - float(new)) > 1e-6:
                con.execute("INSERT INTO ad_changes VALUES (?,?,?,?,?,?)",
                            (store, day, k, str(old), str(new), now))
    v = vals
    con.execute("""INSERT INTO ad_daily
        (store,date,cost,show_pv,click_pv,inquiries,pay_pv,pay_amount,roi,source,note,pulled_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(store,date) DO UPDATE SET
          cost=excluded.cost, show_pv=excluded.show_pv, click_pv=excluded.click_pv,
          inquiries=excluded.inquiries, pay_pv=excluded.pay_pv, pay_amount=excluded.pay_amount,
          roi=excluded.roi, source=excluded.source, note=excluded.note, pulled_at=excluded.pulled_at""",
        (store, day, v.get("cost"), v.get("show_pv"), v.get("click_pv"), v.get("inquiries"),
         v.get("pay_pv"), v.get("pay_amount"), v.get("roi"), source, note, now))
    con.commit()


def cmd_pull(args):
    con = init_db()
    store = args.store
    end = date.today()
    start = end - timedelta(days=args.days)
    print(f"[pull] {store}  {start} ~ {end}")

    moved = False
    try:
        api("/api/agent/move", {"store": store, "url": "https://dayu.goofish.com/?site=FISHAD#/ad/home"}, timeout=60)
        moved = True
        time.sleep(6)
        daily, hourly = pull_range(store, start.isoformat(), end.isoformat())
    except Exception as e:
        # 原则 2：失败照样记账 —— 记一行 fail，别让账本出现无法解释的空洞
        upsert(con, store, end.isoformat(), {"cost": None}, "fail", f"拉取失败: {e}")
        print(f"[fail] {e}")
        return 1
    finally:
        if moved and not args.no_restore:
            try:
                api("/api/agent/move", {"store": store, "url": "https://www.goofish.com/"}, timeout=60)
            except Exception:
                pass

    n = n_hourly = 0
    for day, v in sorted(daily.items()):
        if v["cost"] and v["cost"] > 0:
            upsert(con, store, day, v, "daily")
            n += 1
        elif day in hourly and hourly[day]["cost"]:
            # 日汇总为 0 但小时累计有数 → 日汇总滞后，先用小时累计顶上并标注来源
            upsert(con, store, day, hourly[day], "hourly", "日汇总滞后，取前一日小时累计末格")
            n += 1
            n_hourly += 1
        else:
            upsert(con, store, day, v, "daily")
            n += 1
    hint = f"（其中 {n_hourly} 天用小时累计补齐）" if n_hourly else ""
    print(f"[pull] 写入/更新 {n} 天{hint}；来源已标注（daily=日汇总 / hourly=小时累计补齐）")
    return 0


def summarize(con, store, start_iso, end_iso=None):
    end_iso = end_iso or date.today().isoformat()   # 不传 end 时默认到今天（不能默认=start，否则只算一天）
    rows = con.execute("""SELECT date,cost,pay_pv,pay_amount,show_pv,click_pv,inquiries,source
                          FROM ad_daily WHERE store=? AND date>=? AND date<=? ORDER BY date""",
                       (store, start_iso, end_iso)).fetchall()
    known = [r for r in rows if r[1] is not None and r[7] != "fail"]
    cost = sum(r[1] for r in known if r[1])
    pay = sum(r[2] for r in known if r[2])
    amt = sum(r[3] for r in known if r[3])
    return {"rows": rows, "cost": cost, "pay": pay, "amount": amt,
            "cpp": (cost / pay) if pay else None,
            "roi": (amt / cost) if cost else None,
            "days": len(known)}


def cmd_report(args):
    con = init_db()
    store = args.store
    print(f"\n===== 擦亮台账 · {store} · 近 {args.days} 天 =====")
    print(f"{'日期':<12}{'花费¥':>9}{'曝光':>8}{'点击':>7}{'询单':>6}{'下单':>6}{'交易额¥':>10}{'单均¥':>8}  来源")
    for r in con.execute("""SELECT date,cost,show_pv,click_pv,inquiries,pay_pv,pay_amount,source
                            FROM ad_daily WHERE store=? AND date>=? ORDER BY date DESC""",
                         (store, (date.today() - timedelta(days=args.days)).isoformat())):
        d, c, sh, ck, iq, py, am, src = r
        cpp = f"{c/py:.2f}" if (c and py) else "—"
        srcs = {"daily": "日汇总", "hourly": "小时补齐", "fail": "❌失败"}.get(src, src or "?")
        if src == "fail":
            print(f"{d:<12}{'—':>9}{'—':>8}{'—':>7}{'—':>6}{'—':>6}{'—':>10}{'—':>8}  {srcs}")
        else:
            print(f"{d:<12}{(c or 0):>9.2f}{(sh or 0):>8}{(ck or 0):>7}{(iq or 0):>6}{(py or 0):>6}{(am or 0):>10.2f}{cpp:>8}  {srcs}")
    s = summarize(con, store, (date.today() - timedelta(days=args.days)).isoformat())
    print(f"\n合计：花费 ¥{s['cost']:.2f} / 下单 {s['pay']} / 交易额 ¥{s['amount']:.2f}")
    if s["cpp"]:
        print(f"单均成本 ¥{s['cpp']:.2f}　投产比 {s['roi']:.2f}" if s["roi"] else f"单均成本 ¥{s['cpp']:.2f}")
    return 0


def cmd_today(args):
    con = init_db()
    store = args.store
    tr = args.target.split(":")
    goal_cost, goal_pay = float(tr[0]), int(tr[1])
    goal_cpp = goal_cost / goal_pay

    print(f"[today] 拉取 {store} 今天的数据 ...")
    if cmd_pull(argparse.Namespace(store=store, days=0, no_restore=False)) != 0:
        return 1
    today_iso = date.today().isoformat()
    s = summarize(con, store, today_iso)          # 只看今天，不把昨天的算进来
    hist = summarize(con, store, (date.today() - timedelta(days=7)).isoformat(),
                     (date.today() - timedelta(days=1)).isoformat())
    c, p = s["cost"], s["pay"]
    print(f"\n===== 达标判断（目标：¥{goal_cost:.0f} 出 {goal_pay} 单 → 单均 ≤ ¥{goal_cpp:.2f}）=====")
    if hist["cpp"]:
        print(f"（参考：近 7 天实际单均 ¥{hist['cpp']:.2f}，共花 ¥{hist['cost']:.2f} / {hist['pay']} 单）")
    print(f"今日花费 ¥{c:.2f}　下单 {p}　单均 {'¥%.2f' % (c/p) if p else '—（还没出单）'}")
    if p == 0:
        print(f"→ 还没出单：按历史效率，出 1 单约需 ¥{goal_cpp*1:.2f}（目标线）。"
              f"花费超过 ¥{goal_cpp:.0f} 仍 0 单，就该盯计划了。")
    elif c / p <= goal_cpp:
        need = goal_cpp * goal_pay - c
        if p >= goal_pay:
            print(f"→ ✅ 已达标（{p} 单 ≥ {goal_pay}，单均 ¥{c/p:.2f} ≤ ¥{goal_cpp:.2f}）")
        else:
            print(f"→ ✅ 效率达标（单均 ¥{c/p:.2f}）；按此效率再花 ¥{max(need,0):.2f} 左右可到 {goal_pay} 单")
    else:
        print(f"→ ❌ 效率不达标（单均 ¥{c/p:.2f} > ¥{goal_cpp:.2f}）；"
              f"按当前效率出 {goal_pay} 单要花 ¥{c/p*goal_pay:.2f}，比目标多 ¥{c/p*goal_pay-goal_cost:.2f}")
        print("   动作：单均 >¥40 的计划降出价 10%；连续 2 天 >¥50 的暂停")
    return 0


def main():
    ap = argparse.ArgumentParser(description="擦亮广告成本台账")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("pull"); p.add_argument("--store", default="好易美代拍")
    p.add_argument("--days", type=int, default=30); p.add_argument("--no-restore", action="store_true")
    p.set_defaults(func=cmd_pull)
    p = sub.add_parser("report"); p.add_argument("--store", default="好易美代拍")
    p.add_argument("--days", type=int, default=7); p.set_defaults(func=cmd_report)
    p = sub.add_parser("today"); p.add_argument("--store", default="好易美代拍")
    p.add_argument("--target", default="100:3", help="目标 花费:单数，默认 100:3")
    p.set_defaults(func=cmd_today)
    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
