#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""闲鱼上架素材合规检查器 — 按「发布链路真实行为」逐项判定。

设计依据（不是猜的平台规则，全部来自本仓库实测）：
  * native_host.py readImage()：所有图上传前一律「最长边缩到 1920 → 转 RGB → JPEG q85」。
    所以闲鱼真正收到的是压缩后的版本；本工具**模拟同一条链路**并报出「实际上传尺寸/体积」。
  * 现有素材库 233 个文件实测：全部 3:4；中位 1.4MB，最大 11.6MB；PNG/JPEG 混用；201 个文件无扩展名。

判定分三级：FAIL(必须改) / WARN(人工确认) / OK。**退出码 = FAIL 条数**（便于接 CI）。
零第三方依赖，除 Pillow。

用法:
    python check_assets.py <素材目录> [--spec xianyu-asset-spec.json] [--tasks <daily-tasks.json>] [--json]
"""
import argparse
import hashlib
import io
import json
import os
import sys

try:
    from PIL import Image
except ImportError:
    print("需要 Pillow：pip install Pillow", file=sys.stderr)
    sys.exit(2)

# Windows 控制台默认 GBK，打印 ✅/❌ 会 UnicodeEncodeError 直接崩 —— 显式切 UTF-8
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}

# ---- 发布链路常量：必须与 native_host.py readImage() 保持一致 ----
UPLOAD_MAX_DIM = 1920
UPLOAD_JPEG_QUALITY = 85

# ---- 默认规格（来自现有素材库实测；可用 --spec 覆盖）----
DEFAULT_SPEC = {
    "_note": "阈值来源：素材库 233 文件实测 + native_host.py 上传行为。改这里即可调整，不必改代码。",
    "ratio": [3, 4],                 # 现有素材 100% 为 3:4
    "ratio_tolerance": 0.02,         # 允许 2% 偏差
    "min_short_edge": 700,           # 短边下限（525x700 是现有最小，再小清晰度不足）
    "upload_max_kb": 5000,          # 闲鱼侧未知；这是保守上限，超了告警人工确认
    "source_max_kb": 20000,          # 源文件体积上限（纯本地浪费，不影响上传）
    "min_bytes": 20 * 1024,          # 小于此视为可疑（空白/坏图）
    "dup_fail_distance": 6,          # dhash 距离 < 6 判几乎同图
    "dup_warn_distance": 11,         # < 11 判构图接近
    "blank_stddev": 6.0,             # 灰度标准差低于此视为接近纯色
}


class Report:
    def __init__(self):
        self.rows = []

    def add(self, level, target, msg):
        self.rows.append({"level": level, "target": target, "msg": msg})

    def fail(self, t, m): self.add("FAIL", t, m)
    def warn(self, t, m): self.add("WARN", t, m)
    def ok(self, t, m): self.add("OK", t, m)

    @property
    def fails(self):
        return sum(1 for r in self.rows if r["level"] == "FAIL")

    @property
    def warns(self):
        return sum(1 for r in self.rows if r["level"] == "WARN")

    def has_fail(self, target):
        return any(r["target"] == target and r["level"] == "FAIL" for r in self.rows)


def simulate_upload(im):
    """复刻 native_host.py readImage()：缩到 1920 内 → 去 alpha → JPEG q85。
    返回 (宽, 高, 字节数)。这是闲鱼真正收到的东西。"""
    w, h = im.size
    if w > UPLOAD_MAX_DIM or h > UPLOAD_MAX_DIM:
        s = UPLOAD_MAX_DIM / max(w, h)
        im = im.resize((int(w * s), int(h * s)), Image.LANCZOS)
    if im.mode in ("RGBA", "P", "LA"):
        im = im.convert("RGB")
    buf = io.BytesIO()
    im.save(buf, format="JPEG", quality=UPLOAD_JPEG_QUALITY, optimize=True)
    return im.size[0], im.size[1], buf.tell()


def has_alpha(im):
    """有真实透明度才算（全不透明的 RGBA 不算）。"""
    if im.mode not in ("RGBA", "LA", "P"):
        return False, 0.0
    a = im.convert("RGBA").getchannel("A")
    px = a.tobytes()
    trans = sum(1 for v in px if v < 250)
    return trans > 0, trans / len(px)


def dhash(im):
    """差分哈希：先裁到主体再算，避免大片白底把两张不同的图算成一样。"""
    g = im.convert("L")
    box = g.point(lambda v: 255 if v < 245 else 0).getbbox()
    if box:
        g = g.crop(box)
    g = g.resize((9, 8), Image.LANCZOS)
    px = g.tobytes()
    bits = 0
    for y in range(8):
        for x in range(8):
            if px[y * 9 + x] > px[y * 9 + x + 1]:
                bits |= 1 << (y * 8 + x)
    return bits


def classify(name):
    """素材分类 —— 不同类的规格不同，混在一起判会刷出大量误报。
    main  = 主图（城市 明星 版式-时间戳 出图产物）：必须 3:4
    sub   = 副图（副图1..8 / 自定义副图）：自有规格，只做解码/体积/重复检查
    other = 其它（旧海报、临时图）：比例只告警不判失败
    """
    stem = name
    for ext in IMAGE_EXT:
        if stem.lower().endswith(ext):
            stem = stem[: -len(ext)]
            break
    if stem.startswith("副图") or stem.startswith("自定义副图"):
        return "sub"
    # 出图产物：末段是 13 位毫秒时间戳
    if len(stem) >= 14 and stem[-13:].isdigit():
        return "main"
    return "other"


def check_one(path, name, spec, rep):
    """返回 (哈希, 元信息) 或 None。"""
    try:
        im = Image.open(path)
        im.load()
    except Exception as e:
        rep.fail(name, f"无法解码：{e}")
        return None

    kind = classify(name)
    fmt, size = im.format, im.size
    w, h = size
    src_kb = os.path.getsize(path) / 1024
    up_w, up_h, up_bytes = simulate_upload(im)
    up_kb = up_bytes / 1024

    # 1) 比例：只对主图判失败；副图自有规格，其它类只告警
    rw, rh = spec["ratio"]
    want = rw / rh
    tol = spec.get("ratio_tolerance", 0.02)
    if abs((w / h) - want) > tol:
        msg = f"比例 {w}×{h} = {w/h:.3f}，不是 {rw}:{rh}（{want:.3f}）"
        if kind == "main":
            rep.fail(name, msg + " — 主图按 3:4 出图，比例不符会被平台裁切")
        elif kind == "other":
            rep.warn(name, msg + " — 非出图产物；若当主图用会被裁切")
        # kind == "sub"：副图自有规格，不判比例

    # 2) 清晰度下限
    if min(w, h) < spec["min_short_edge"]:
        rep.warn(name, f"短边仅 {min(w,h)}px（建议 ≥{spec['min_short_edge']}）— 文字细节会糊")

    # 3) 透明通道：上传必被 JPEG 化 → 透明区变黑/白，视觉失真
    ta, ta_ratio = has_alpha(im)
    if ta:
        rep.fail(name, f"含 {ta_ratio:.0%} 透明像素 — 上传链路会 JPEG 化并丢掉 alpha（透明区变黑底），主图须不透明")

    # 4) 源体积（本地浪费）
    if src_kb > spec["source_max_kb"]:
        rep.warn(name, f"源文件 {src_kb/1024:.1f}MB 偏大（本地读取/传输慢，且上传后仅 {up_kb:.0f}KB，属白占磁盘）")
    if os.path.getsize(path) < spec["min_bytes"]:
        rep.fail(name, f"仅 {src_kb:.0f}KB — 疑似空白或坏图")

    # 5) 上传后体积
    if up_kb > spec["upload_max_kb"]:
        rep.warn(name, f"上传后 {up_kb/1024:.1f}MB 超保守上限 {spec['upload_max_kb']/1024:.1f}MB — 请确认闲鱼侧限制")

    # 6) 空白/纯色
    g = im.convert("L")
    hist = g.histogram()
    n = sum(hist) or 1
    mean = sum(i * c for i, c in enumerate(hist)) / n
    var = sum(c * (i - mean) ** 2 for i, c in enumerate(hist)) / n
    if var ** 0.5 < spec["blank_stddev"]:
        rep.fail(name, f"灰度标准差 {var**0.5:.1f} — 接近纯色/空白，可能出图失败")

    # 7) 占位符残留
    for token in ("{城市}", "{明星}", "{city}", "{star}", "undefined", "NaN"):
        if token in name:
            rep.fail(name, f"文件名含未替换占位符「{token}」")
            break

    if not rep.has_fail(name):
        tag = {"main": "主图", "sub": "副图", "other": "其它"}[kind]
        rep.ok(name, f"[{tag}] {fmt} {w}×{h} 源{src_kb:.0f}KB → 上传 {up_w}×{up_h} {up_kb:.0f}KB")
    # 像素级指纹：同样一张图重出多次 → 像素完全一致（换 PNG/JPEG 压缩也不影响）
    pix = hashlib.md5(im.convert("RGB").resize((64, 64), Image.LANCZOS).tobytes()).hexdigest()
    return {"hash": dhash(im), "pix": pix, "kind": kind, "w": w, "h": h,
            "up_w": up_w, "up_h": up_h, "up_kb": up_kb, "src_kb": src_kb, "fmt": fmt}


def _cluster(names, dist_fn, thr):
    """把「彼此接近」的成员聚成组（并查集）。dist_fn(a,b) -> 距离。"""
    parent = {n: n for n in names}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for i, a in enumerate(names):
        for b in names[i + 1:]:
            if dist_fn(a, b) < thr:
                ra, rb = find(a), find(b)
                if ra != rb:
                    parent[rb] = ra
    groups = {}
    for n in names:
        groups.setdefault(find(n), []).append(n)
    return [g for g in groups.values() if len(g) > 1]


def check_duplicates(items, spec, rep):
    """两级重复判定（这是本工具最值钱的一项 —— 历史重复上架就是重复出图造成的）：
      ① 像素级完全相同 → FAIL。同一张图被重出多次，是纯浪费积分，且必然导致重复上架。
      ② 布局相似（dhash 接近但像素不同）→ WARN。可能只是同版式换了文字（如不同城市），
         9×8 的 dhash 分不出这种差异，所以**不能当重复判失败** —— 实测会把
         「大连 于适 一紫块+红字」和「西安 于适 紫红」误并成一组。
    只在**同类之间**比对（主图和副图本来就不该像）。"""
    fail_thr = spec["dup_fail_distance"]
    warn_thr = spec["dup_warn_distance"]
    by_kind = {}
    for name, meta in items.items():
        by_kind.setdefault(meta["kind"], []).append(name)

    near_clusters = 0
    for kind, names in by_kind.items():
        names = sorted(names)
        tag = {"main": "主图", "sub": "副图", "other": "其它"}[kind]

        # ① 像素级完全相同
        by_pix = {}
        for n in names:
            by_pix.setdefault(items[n]["pix"], []).append(n)
        for members in sorted(by_pix.values(), key=lambda g: -len(g)):
            if len(members) < 2:
                continue
            head = "；".join(members[:3])
            more = f" …等 {len(members)} 个" if len(members) > 3 else ""
            rep.fail(f"[{tag}] {members[0]}",
                     f"— 共 {len(members)} 张**像素完全相同**（同一张图重复出了 {len(members)} 次）：{head}{more}"
                     f"　→ 只保留 1 张；其余既浪费出图积分，又会被重复上架")

        # ② 布局相似（排除已判像素相同的）
        seen = set()
        for n in names:
            seen.add(items[n]["pix"])
        uniq = [n for n in names if list(by_pix[items[n]["pix"]]).index(n) == 0]
        near = _cluster(uniq, lambda a, b: bin(items[a]["hash"] ^ items[b]["hash"]).count("1"), warn_thr)
        if near:
            near_clusters += len(near)

    if near_clusters:
        rep.warn("布局相似", f"{near_clusters} 组图的版式布局接近（差分哈希 {fail_thr}~{warn_thr}/64）"
                            f"— 很可能只是换了城市/明星文字，属正常；若同款商品要求差异化可人工确认")


def check_against_tasks(items, tasks_path, rep):
    """与任务表交叉核对：文件名里的「城市 明星」必须与任务记录一致。
    —— 这条直接防住已发生过的真实事故：图是「新加坡」但任务城市写「广州」。"""
    try:
        with open(tasks_path, encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        rep.warn("任务表", f"无法读取 {tasks_path}：{e}")
        return
    tasks = data.get("tasks", []) if isinstance(data, dict) else data
    # 任务 → 期望的图片名后缀
    pending = [t for t in tasks if t.get("imageName")]
    by_img = {}
    for t in pending:
        by_img[t["imageName"]] = t
    checked = 0
    for name, meta in items.items():
        stem = name
        for ext in IMAGE_EXT:
            if stem.lower().endswith(ext):
                stem = stem[: -len(ext)]
                break
        t = by_img.get(stem)
        if not t:
            continue
        checked += 1
        city, star = (t.get("city") or "").strip(), (t.get("star") or "").strip()
        if city and star and city not in stem:
            rep.fail(name, f"图文不符：任务写的是「{star}·{city}」，但图片名是「{stem}」— 会发出图文不符的商品")
        elif city and star and star not in stem:
            rep.fail(name, f"图文不符：任务明星是「{star}」，图片名是「{stem}」")
    rep.ok("任务表", f"已交叉核对 {checked} 条任务与图片的归属" if checked else "任务表里没有匹配的图片名")


def main():
    ap = argparse.ArgumentParser(description="闲鱼上架素材合规检查器")
    ap.add_argument("dir", help="素材目录（如 C:/Users/43462/Desktop/闲鱼上架图片/好易美代拍）")
    ap.add_argument("--spec", help="规格 JSON（默认用内置）")
    ap.add_argument("--tasks", help="任务表 JSON（可选；用于图文归属交叉核对）")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    ap.add_argument("--limit", type=int, default=0, help="只检查前 N 个文件（调试用）")
    args = ap.parse_args()

    spec = dict(DEFAULT_SPEC)
    if args.spec:
        try:
            with open(args.spec, encoding="utf-8") as f:
                spec.update(json.load(f))
        except Exception as e:
            print(f"规格文件读取失败，改用内置默认：{e}", file=sys.stderr)

    d = args.dir
    if not os.path.isdir(d):
        print(f"目录不存在：{d}", file=sys.stderr)
        return 2

    # 按内容嗅探：素材库里 201/233 个文件没有扩展名
    files = sorted(f for f in os.listdir(d) if os.path.isfile(os.path.join(d, f)) and not f.startswith("."))
    if args.limit:
        files = files[: args.limit]
    if not files:
        print(f"目录里没有文件：{d}", file=sys.stderr)
        return 2

    rep = Report()
    items = {}
    for name in files:
        meta = check_one(os.path.join(d, name), name, spec, rep)
        if meta:
            items[name] = meta

    check_duplicates(items, spec, rep)
    if args.tasks:
        check_against_tasks(items, args.tasks, rep)

    if args.json:
        print(json.dumps(rep.rows, ensure_ascii=False, indent=2))
    else:
        icon = {"FAIL": "❌", "WARN": "⚠️ ", "OK": "✅"}
        for lvl in ("FAIL", "WARN", "OK"):
            for r in [x for x in rep.rows if x["level"] == lvl]:
                print(f"{icon[lvl]} {r['target']}: {r['msg']}")
        if items:
            up_kb = sorted(v["up_kb"] for v in items.values())
            kind_cnt = {}
            for v in items.values():
                kind_cnt[v["kind"]] = kind_cnt.get(v["kind"], 0) + 1
            tag = {"main": "主图", "sub": "副图", "other": "其它"}
            print(f"\n--- 汇总 ---")
            print(f"检查 {len(items)} 张：" + "、".join(f"{tag[k]} {c}" for k, c in sorted(kind_cnt.items())))
            print(f"上传后体积 中位 {up_kb[len(up_kb)//2]:.0f}KB / 最大 {up_kb[-1]:.0f}KB（链路：≤{UPLOAD_MAX_DIM}px + JPEG q{UPLOAD_JPEG_QUALITY}）")
        print(f"\n{'✅ 全部通过' if not rep.fails else f'❌ {rep.fails} 项必须修复'}"
              f" — FAIL {rep.fails} / WARN {rep.warns} / 共 {len(items)} 张")
    return min(rep.fails, 125)


if __name__ == "__main__":
    sys.exit(main())
