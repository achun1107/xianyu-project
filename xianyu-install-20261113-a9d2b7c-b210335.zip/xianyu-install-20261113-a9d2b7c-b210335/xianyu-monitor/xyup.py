#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
xyup.py — 一句话上架：「城市 明星」→ 出图 → 建任务 → 远程触发发布（全自动）

流程（三步全部可远程完成，不需要手动点任何按钮）:
    1. 出图   POST /api/poster/make        （默认 source=damai_official，用大麦官方底图）
    2. 建任务 写 ~/.xianyu-daily-tasks-<店铺>.json
    3. 发布   POST /api/agent/eval-on-store → window.kunPublish.runOneStore()
              （先 syncTasksFromDisk 再 runOneStore，否则会读到旧列表判定「无待发布」）

用法:
    python xyup.py 上海 周杰伦 @一店
    python xyup.py 上海 周杰伦 二开 @一店 --price 50 --apply
    python xyup.py 北京 林俊杰 @二店 --budget 80 --bid 3.0 --apply

自定义规格价（覆盖店铺固定 50/500/800，只影响本次任务）:
    python xyup.py 广州 周杰伦 @一店 --spec-price "组团:50,看台:500,内场:800" --apply
    python xyup.py 广州 周杰伦 @一店 --spec-price "内场:900" --apply   # 只发内场一档
    python xyup.py 广州 周杰伦 @一店 --spec-price "内场:900" --spec-fill --apply  # 其余档按 50/500 补全
    python xyup.py 广州 周杰伦 @一店 --spec-price "内场:800:200" --apply  # 第三位是库存
    python xyup.py 广州 周杰伦 @一店 --no-spec --price 88 --apply    # 本次不带规格

店铺代号:
    一店 = 好易美代拍      二店 = 好易美娱乐
    （也可直接写全名，如 @好易美代拍）

安全设计:
    1. 默认演练(dry-run)，什么都不写；加 --apply 才真正出图+建任务
    2. 同 SKU(城市+明星+场次) 默认只发一店，两店都发需显式 @一店,二店 并加 --force
    3. 出图会消耗出图额度，dry-run 阶段不出图
    4. 任务文件按店分写，读-合并-写，不整份覆盖（避免冲掉进行中的任务）

注意: 本文件位于 Chrome 扩展根目录，禁止 import 本地模块，
      否则会生成 __pycache__ 导致扩展加载失败。
"""
import sys

sys.dont_write_bytecode = True  # 防御：扩展根目录不允许出现 __pycache__

import argparse
import base64
import json
import os
import re
import urllib.request
from datetime import datetime
from pathlib import Path

# ===== 配置 =====
STORE_ALIAS = {
    "一店": "好易美代拍",
    "二店": "好易美娱乐",
    "1店": "好易美代拍",
    "2店": "好易美娱乐",
    "1": "好易美代拍",
    "2": "好易美娱乐",
}
KNOWN_STORES = ["好易美代拍", "好易美娱乐"]

ASSET_ROOT = Path(r"C:\Users\43462\Desktop\闲鱼上架图片")
SERVICE = "http://127.0.0.1:8093"
SESSION_WORDS = ["首开", "二开", "三开", "一开", "预售", "正式"]
HOME = Path.home()


def log(msg, level="info"):
    mark = {"info": "  ", "ok": "✓ ", "warn": "! ", "err": "✗ "}.get(level, "  ")
    print(mark + msg)


def resolve_stores(raw):
    """@一店 / @二店 / @一店,二店 / @好易美代拍 → 全名列表"""
    names = []
    for part in str(raw or "").split(","):
        part = part.strip()
        if not part:
            continue
        full = STORE_ALIAS.get(part, part)
        if full not in KNOWN_STORES and full not in names:
            # 允许其它店铺名（如 casa家居），但不做校验
            pass
        names.append(full)
    return names


def daily_tasks_file(store):
    safe = "".join(c if c not in '\\/:*?"<>|' else "_" for c in str(store)).strip()
    return HOME / (".xianyu-daily-tasks-" + safe + ".json")


def task_key(t):
    """与 native_host._task_key 保持一致：star|city|sessionType|imageName"""
    return (
        str(t.get("star", ""))
        + "|"
        + str(t.get("city", ""))
        + "|"
        + str(t.get("sessionType", ""))
        + "|"
        + str(t.get("imageName", ""))
    )


def read_tasks(store):
    f = daily_tasks_file(store)
    if not f.exists():
        return {}
    try:
        with open(f, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception as e:
        log(f"读取任务文件失败 {f.name}: {e}", "err")
        return {}


def write_tasks_merged(store, new_tasks):
    """读-合并-写：复刻 native_host.write_daily_tasks 的合并语义，
    不整份覆盖，避免冲掉正在进行的任务 / 已发布的 itemId。"""
    f = daily_tasks_file(store)
    existing = read_tasks(store)
    et = existing.get("tasks", []) if isinstance(existing.get("tasks"), list) else []

    merged = {}
    for t in et:
        if isinstance(t, dict):
            merged[task_key(t)] = t
    added = 0
    for t in new_tasks:
        k = task_key(t)
        cur = merged.get(k)
        if cur is None or (t.get("itemId") and not cur.get("itemId")):
            merged[k] = t
            added += 1

    out = dict(existing)
    out["tasks"] = list(merged.values())

    # 原子写：临时文件 + 替换，避免写到一半被 publish.js 读到半个 JSON
    # 注意：不能用 Path.with_suffix()，它要求后缀只含一个点，传 "json.tmp" 会抛
    # ValueError: Invalid suffix 'json.tmp'（2026-09-14 首次真实执行踩到）
    tmp = f.parent / (f.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, f)
    return added, len(out.get("tasks", []))


def find_sku_in_other_stores(city, star, session, exclude_store):
    """同 SKU 是否已发到别的店（用于两店重复的阻断判断）"""
    hits = []
    for st in KNOWN_STORES:
        if st == exclude_store:
            continue
        for t in read_tasks(st).get("tasks", []):
            if (
                str(t.get("city", "")) == city
                and str(t.get("star", "")) == star
                and str(t.get("sessionType", "")) == session
            ):
                hits.append(st)
                break
    return hits


# ===== 规格（SKU 档位） =====
# 一店默认档位名（与 localStorage 里的店铺配置保持一致；用 --spec-price 可临时覆盖价格）
DEFAULT_SPEC_NAME = "代拍费"
DEFAULT_SPEC_VALUES = ["多人组团可优惠", "看台", "内场"]

# 店铺级固定价（与一店 localStorage kun_store_cfg_好易美代拍.specs 保持一致）
# 只有 --spec-fill 会用到：把 --spec-price 里没提到的档位按这个价补全
DEFAULT_SPEC_PRICES = {"多人组团可优惠": 50, "看台": 500, "内场": 800}

# 输入别名：指令里写短名也能对上档位（不区分大小写）
SPEC_ALIAS = {
    "组团": "多人组团可优惠",
    "多人": "多人组团可优惠",
    "多人组团": "多人组团可优惠",
    "优惠": "多人组团可优惠",
    "团购": "多人组团可优惠",
    "看台": "看台",
    "内场": "内场",
}


def match_spec_value(word, pool):
    """把指令里的短名对上档位全名：精确 → 别名 → 包含匹配。对不上返回 None"""
    w = str(word or "").strip()
    if not w:
        return None
    for p in pool:
        if str(p).strip() == w:
            return p
    a = SPEC_ALIAS.get(w)
    if a:
        for p in pool:
            if str(p).strip() == a:
                return p
    for p in pool:
        sp = str(p).strip()
        if w in sp or sp in w:
            return p
    return None


def parse_spec_price(raw):
    """解析 '组团:50,看台:500,内场:800' 或 '内场:800:9999'（第三位是库存）
    → [(档名, 价格, 库存orNone), ...]"""
    out = []
    for part in re.split(r"[,，;；]", str(raw or "")):
        part = part.strip()
        if not part:
            continue
        bits = re.split(r"[:：]", part)
        name = bits[0].strip()
        if not name:
            continue
        try:
            price = float(bits[1]) if len(bits) > 1 and bits[1].strip() else None
        except (ValueError, IndexError):
            price = None
        stock = None
        if len(bits) > 2 and bits[2].strip():
            try:
                stock = int(float(bits[2]))
            except ValueError:
                stock = None
        out.append((name, price, stock))
    return out


def build_specs(raw, prop_name, default_stock, pool=None, fill=False):
    """--spec-price → publish.js buildSkuPayload 认识的 specs 结构。
    默认只生成指令里写到的档位（所见即所得）；fill=True 时，
    没写到的默认档位按店铺固定价补全。档名对不上时作为新档位追加并打 warn。"""
    items = parse_spec_price(raw)
    if not items:
        return None
    pool = list(pool) if pool else list(DEFAULT_SPEC_VALUES)
    values = []
    for name, price, stock in items:
        real = match_spec_value(name, pool)
        if real is None:
            real = name
            log(f"档位「{name}」不在默认档位里，将作为新档位追加", "warn")
        else:
            real = str(real).strip()
        if price is None:
            log(f"档位「{real}」没填价格，跳过（格式：档名:价格）", "warn")
            continue
        if price <= 0:
            log(f"档位「{real}」价格必须 > 0，跳过", "warn")
            continue
        values.append({
            "value": real,
            "priceYuan": price,
            "stock": stock if stock is not None else int(default_stock),
        })
    if not values:
        return None
    if fill:
        got = {v["value"] for v in values}
        for name in pool:
            nm = str(name).strip()
            if nm in got:
                continue
            p = DEFAULT_SPEC_PRICES.get(nm)
            if p is None:
                continue
            values.append({"value": nm, "priceYuan": p, "stock": int(default_stock)})
            log(f"档位「{nm}」未指定，按店铺固定价 ¥{p:g} 补全", "info")
        # 补全后排回固定顺序：组团 → 看台 → 内场（闲鱼按提交顺序展示档位）
        order = {str(n).strip(): i for i, n in enumerate(pool)}
        values.sort(key=lambda v: order.get(v["value"], len(order)))
    return {
        "enabled": True,
        "propertyName": prop_name or DEFAULT_SPEC_NAME,
        "supportImage": False,
        "values": values,
    }


def fmt_specs(specs):
    if not specs or not specs.get("values"):
        return "（无）"
    return " / ".join(
        f'{v["value"]} ¥{v["priceYuan"]:g} ×{v["stock"]}' for v in specs["values"]
    )


def trigger_publish(store):
    """远程触发该店开始发布（走 8093 eval-on-store）。

    必须在执行 runOneStore 前先 syncTasksFromDisk()：
    publish.js 的 loadDailyTasks() 读的是 localStorage，而本脚本写的是磁盘文件。
    不同步的话 runOneStore 会读到旧列表、判定「无待发布任务」直接返回，
    而接口仍然返回 started —— 表现为任务永远 pending（2026-09-14 实测踩到）。
    """
    code = (
        "(async function(){ await window.kunPublish.syncTasksFromDisk();"
        ' if (window.kunPublish.dailyRunning) return "already-running";'
        " window.kunPublish.runOneStore(%s); return \"started\"; })()" % json.dumps(store)
    )
    return call_service("/api/agent/eval-on-store", {"store": store, "code": code}, timeout=60)


def call_service(path, payload=None, timeout=180):
    url = SERVICE + path
    data = None
    headers = {"Content-Type": "application/json"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def gen_poster(city, star, template_id="", source="damai_official"):
    payload = {
        "city": city,
        "star": star,
        "source": source,
        "ratio": "3:4",
    }
    if template_id:
        payload["templateId"] = template_id
    r = call_service("/api/poster/make", payload)
    if not r.get("ok") or not r.get("imageB64"):
        raise RuntimeError(r.get("error") or "出图失败（可能没搜到该场次海报）")
    return r["imageB64"]


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    ap = argparse.ArgumentParser(
        description="一句话上架：城市 明星 → 出图 → 建任务 → 自动发布",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("words", nargs="+", help="城市 明星 [场次] [@店名]")
    ap.add_argument("--store", default="", help="店铺：一店 / 二店 / 全名。PowerShell 下请优先用它")
    ap.add_argument("--apply", action="store_true", help="真正执行：出图 + 建任务 + 触发发布（默认只演练）")
    ap.add_argument("--style", default="", help="版式 templateId（留空用服务默认）")
    ap.add_argument("--source", default="damai_official", help="海报源，默认 damai_official")
    ap.add_argument("--price", default="50", help="价格，默认 50")
    ap.add_argument("--stock", default="9999", help="库存，默认 9999")
    ap.add_argument("--category", default="代购", help="类目名，默认 代购")
    ap.add_argument("--spec-price", default="",
                    help='本次规格各档价格，覆盖店铺固定价。例："组团:50,看台:500,内场:800"；'
                         '可带库存 "内场:800:9999"，可只改一档 "内场:900"')
    ap.add_argument("--spec-name", default="", help="规格名，默认 代拍费")
    ap.add_argument("--spec-values", default="",
                    help='档位名列表，默认 "多人组团可优惠,看台,内场"')
    ap.add_argument("--spec-fill", action="store_true",
                    help="--spec-price 没写到的档位，按店铺固定价（50/500/800）补全")
    ap.add_argument("--no-spec", action="store_true", help="本次不带规格，退回单一口价模式")
    ap.add_argument("--bid", type=float, default=2.6, help="擦亮出价，默认 2.6")
    ap.add_argument("--budget", type=float, default=50, help="擦亮日预算，默认 50")
    ap.add_argument("--target", default="chat", choices=["chat", "order"], help="bidTarget")
    ap.add_argument("--no-campaign", action="store_true", help="不建擦亮推广计划")
    ap.add_argument("--no-publish", action="store_true", help="只写出图+建任务，不自动触发发布")
    ap.add_argument("--force", action="store_true", help="允许同一 SKU 发到多个店（有封号风险）")
    args = ap.parse_args()

    # ---- 解析指令：城市 明星 [场次] [@店名] ----
    city = args.words[0]
    star = ""
    session = "首开"
    store_raw = ""
    for w in args.words[1:]:
        if w.startswith("@"):
            store_raw += w[1:] + ","
        elif w in SESSION_WORDS:
            session = w
        elif not star:
            star = w
        else:
            star += " " + w

    if not star:
        log("格式：城市 明星 [场次] [@一店|@二店]，例：python xyup.py 上海 周杰伦 @一店", "err")
        return 2

    # --store 优先：PowerShell 会吞掉裸写的 @店名（argv 里直接消失），加引号才安全
    stores = resolve_stores(args.store or store_raw.strip(",")) or ["好易美代拍"]
    for st in stores:
        if st not in KNOWN_STORES:
            log(f"未知店铺「{st}」，已知：一店=好易美代拍，二店=好易美娱乐", "err")
            return 2

    # ---- 规格 ----
    # 不传 --spec-price：沿用店铺级固定配置（一店目前 50/500/800）
    # 传了：写进任务，任务级优先于店铺级，只影响这一条
    # --no-spec：本次退回单一口价
    spec_pool = [v.strip() for v in re.split(r"[,，]", args.spec_values) if v.strip()] or list(DEFAULT_SPEC_VALUES)
    specs = None
    if args.no_spec:
        specs = {"enabled": False}
        spec_line = "关闭（单一口价）"
    elif args.spec_price.strip():
        specs = build_specs(args.spec_price, args.spec_name, args.stock, spec_pool, args.spec_fill)
        if not specs:
            log("--spec-price 没解析出有效档位，格式：\"组团:50,看台:500,内场:800\"", "err")
            return 2
        spec_line = fmt_specs(specs)
    else:
        spec_line = f"沿用店铺配置（{' / '.join(spec_pool)}）"

    sku = f"{city} {star} {session}"
    print("=" * 56)
    print(f"  SKU   : {sku}")
    print(f"  店铺  : {'、'.join(stores)}")
    print(f"  价格  : 一口价 ¥{args.price} ×{args.stock}" if specs and specs.get("enabled") is False
          else f"  库存  : {args.stock}（规格内各档库存）")
    print(f"  规格  : {spec_line}")
    print(f"  推广  : {'关闭' if args.no_campaign else f'出价{args.bid} 日预算{args.budget} 目标{args.target}'}")
    print(f"  模式  : {'【执行】' if args.apply else '【演练】未加 --apply 不会出图也不会写任务'}")
    print("=" * 56)
    if specs and specs.get("enabled"):
        log("已开规格：--price 一口价会被忽略，价格以各档为准（闲鱼取最低档做展示价）", "warn")

    # ---- 同 SKU 跨店锁 ----
    if len(stores) > 1 and not args.force:
        log("同一 SKU 发到多个店会触发闲鱼店群关联判定（限流/封号）。", "err")
        log("确认要双发请加 --force。已取消。", "err")
        return 1
    for st in stores:
        others = find_sku_in_other_stores(city, star, session, st)
        for o in others:
            log(f"该 SKU 已存在于 {o}，再发到 {st} 属重复铺货。确认请加 --force。", "err")
        if others and not args.force:
            return 1

    # ---- 重复检查（同店） ----
    for st in stores:
        for t in read_tasks(st).get("tasks", []):
            if (
                str(t.get("city", "")) == city
                and str(t.get("star", "")) == star
                and str(t.get("sessionType", "")) == session
            ):
                log(f"{st} 已有该 SKU（状态 {t.get('status', '?')}），跳过。", "warn")
                return 0

    if not args.apply:
        log("演练结束：以上是将会执行的动作。加 --apply 真正执行。", "ok")
        return 0

    # ---- 检查服务 ----
    try:
        call_service("/health", None, timeout=8)
    except Exception as e:
        log(f"8093 服务不可达（{e}）。请先启动：桌面「启动闲鱼服务.bat」", "err")
        return 1

    ok = 0
    for st in stores:
        try:
            log(f"[{st}] 出图：{city} {star} ...")
            b64 = gen_poster(city, star, args.style, args.source)
            ts = str(int(datetime.now().timestamp() * 1000))
            image_name = f"{city} {star} {session}-{ts}"
            # 素材落盘规则：{闲鱼上架图片}/{店铺}/{imageName}，文件名不带扩展名
            img_dir = ASSET_ROOT / st
            img_dir.mkdir(parents=True, exist_ok=True)
            img_path = img_dir / image_name
            with open(img_path, "wb") as fh:
                fh.write(base64.b64decode(b64))
            size_kb = img_path.stat().st_size // 1024
            log(f"[{st}] 海报已保存 {image_name}（{size_kb}KB）", "ok")

            task = {
                "star": star,
                "city": city,
                "eventType": "演唱会",
                "sessionType": session,
                "categoryName": args.category,
                "price": str(args.price),
                "stock": str(args.stock),
                "imageName": image_name,
                "store": st,
                "imageUrls": [image_name],
                "bidPrice": args.bid,
                "maxDayBudget": args.budget,
                "bidTarget": args.target,
                "skipCampaign": args.no_campaign,
                "status": "pending",
            }
            if specs:
                # 任务级规格：publish.js 优先用它，其次才回落店铺配置
                task["specs"] = specs
            added, total = write_tasks_merged(st, [task])
            log(f"[{st}] 任务已写入（新增 {added}，该店共 {total} 条）", "ok")
            ok += added

            # 写盘之后必须显式触发，页面不会自己捡起磁盘上的新任务
            if added and not args.no_publish:
                try:
                    r = trigger_publish(st)
                    if r.get("ok"):
                        res = r.get("result")
                        if res == "already-running":
                            log(f"[{st}] 该店正在发布中，本次任务将在其下一轮被捡起", "warn")
                        else:
                            log(f"[{st}] 已触发发布，正在后台执行（约 20 秒～数分钟）", "ok")
                    else:
                        log(f"[{st}] 触发发布失败：{r.get('error')}。可稍后手动执行 "
                            f"`node console-tools/trigger-publish.js {st}`", "err")
                except Exception as e:
                    log(f"[{st}] 触发发布异常：{e}。可稍后手动执行 "
                        f"`node console-tools/trigger-publish.js {st}`", "err")
        except Exception as e:
            log(f"[{st}] 失败：{e}", "err")

    if ok:
        print()
        if args.no_publish:
            log(f"完成 {ok} 个任务（未触发发布）。触发用："
                f"node console-tools/trigger-publish.js <店铺全名>", "ok")
        else:
            log(f"完成 {ok} 个任务，发布已在店铺页后台开始。", "ok")
            log("查看结果：任务盘 ~/.xianyu-daily-tasks-<店铺>.json 里该条 status/itemId", "info")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
