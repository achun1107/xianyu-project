# 闲鱼批量发布 - Native Messaging Host 安装脚本
# 以管理员身份在 PowerShell 中运行（安装 Python 依赖时可能需要）

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  闲鱼批量发布 - Native Host 安装" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 1. 检查 Python
Write-Host "[1/4] 检查 Python 环境..." -ForegroundColor Yellow
$python = $null
foreach ($cmd in @("python", "python3", "py")) {
    try {
        $v = & $cmd --version 2>&1
        if ($LASTEXITCODE -eq 0) {
            $python = $cmd
            Write-Host "  ✓ 找到: $v" -ForegroundColor Green
            break
        }
    } catch {}
}
if (-not $python) {
    Write-Host "  ✗ 未找到 Python，请先安装 Python 3.8+ (https://python.org)" -ForegroundColor Red
    Write-Host "    安装时请勾选 'Add Python to PATH'" -ForegroundColor Yellow
    exit 1
}

# 2. 安装 openpyxl
Write-Host "[2/4] 安装 Python 依赖 (openpyxl)..." -ForegroundColor Yellow
& $python -m pip install openpyxl --quiet 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "  ⚠ openpyxl 安装失败，尝试继续..." -ForegroundColor Yellow
} else {
    Write-Host "  ✓ openpyxl 已安装" -ForegroundColor Green
}

# 3. 获取扩展 ID
Write-Host "[3/4] 配置扩展 ID..." -ForegroundColor Yellow
Write-Host ""
Write-Host "  请打开 Chrome 浏览器，访问 chrome://extensions/" -ForegroundColor White
Write-Host "  找到 '闲鱼超级擦亮监控' 扩展，复制它的 ID（一串小写字母）" -ForegroundColor White
Write-Host ""

$extId = Read-Host "  粘贴扩展 ID"

if (-not $extId -or $extId.Length -lt 10) {
    Write-Host "  ✗ 扩展 ID 无效" -ForegroundColor Red
    exit 1
}

# 更新 manifest
$hostManifestPath = Join-Path $PSScriptRoot "native_host_manifest.json"
$manifest = Get-Content $hostManifestPath -Raw | ConvertFrom-Json
$manifest.allowed_origins = @("chrome-extension://$extId/")
$manifest.path = Join-Path $PSScriptRoot "native_host.py"
$manifest | ConvertTo-Json -Depth 3 | Set-Content $hostManifestPath -Encoding UTF8
Write-Host "  ✓ 已更新 native_host_manifest.json" -ForegroundColor Green

# 4. 写入注册表
Write-Host "[4/4] 注册 Native Messaging Host..." -ForegroundColor Yellow
$regPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.kun.xianyu.host"
try {
    New-Item -Path $regPath -Force | Out-Null
    Set-ItemProperty -Path $regPath -Name "(Default)" -Value $hostManifestPath
    Write-Host "  ✓ 注册表已写入" -ForegroundColor Green
} catch {
    Write-Host "  ✗ 注册表写入失败: $_" -ForegroundColor Red
    Write-Host "  请尝试以管理员身份运行此脚本" -ForegroundColor Yellow
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  安装完成！" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "  下一步:" -ForegroundColor White
Write-Host "  1. 在 chrome://extensions/ 中重新加载扩展" -ForegroundColor White
Write-Host "  2. 打开闲鱼页面测试连接" -ForegroundColor White
Write-Host ""

Read-Host "按 Enter 退出"
