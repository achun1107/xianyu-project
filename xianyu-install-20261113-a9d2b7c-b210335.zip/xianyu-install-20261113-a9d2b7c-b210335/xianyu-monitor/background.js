// ===== 扩展图标点击 → 打开发布台 =====
chrome.action.onClicked.addListener(() => {
    chrome.tabs.create({ url: chrome.runtime.getURL('publish_dashboard.html') });
});

// Background Service Worker - 处理 API 请求 + 定时同步 + 失败缓存重试 + 操作台中转
importScripts('api.js');

const FEISHU_WEBHOOK = 'https://open.feishu.cn/open-apis/bot/v2/hook/691fc3af-c391-4e0e-9122-776abe998fdd';
const NATIVE_HOST = 'com.kun.xianyu.host';
const PENDING_KEY = 'xianyu_pending_sync';
const MAX_PENDING = 100;

// 保活：每4分钟唤醒一次，防止 Service Worker 被销毁 + 重试失败缓存
chrome.alarms.create('keepalive', { periodInMinutes: 4 });

// 每天早上9点同步昨日数据
function getDelayUntil9AM() {
    const now = new Date();
    const target = new Date(now);
    target.setDate(target.getDate() + 1);
    target.setHours(9, 0, 0, 0);
    return Math.floor((target - now) / 60000);
}

chrome.alarms.create('sync_yesterday', { delayInMinutes: getDelayUntil9AM(), periodInMinutes: 1440 });

// 找到打开的 dayu.goofish.com 标签页
async function findDayuTab() {
    const tabs = await chrome.tabs.query({ url: 'https://dayu.goofish.com/*' });
    return tabs.length > 0 ? tabs[0] : null;
}

// ===== 失败缓存 + 重试 =====
async function cachePendingSync(payload) {
    try {
        const result = await chrome.storage.local.get(PENDING_KEY);
        const pending = result[PENDING_KEY] || [];
        pending.push({ payload, timestamp: Date.now() });
        if (pending.length > MAX_PENDING) pending.splice(0, pending.length - MAX_PENDING);
        await chrome.storage.local.set({ [PENDING_KEY]: pending });
        console.log('[xianyu] 缓存待重试:', pending.length, '组');
    } catch(e) { console.log('[xianyu] cache error:', e); }
}

async function retryPendingSync() {
    try {
        const result = await chrome.storage.local.get(PENDING_KEY);
        const pending = result[PENDING_KEY] || [];
        if (pending.length === 0) return;
        console.log('[xianyu] 重试缓存:', pending.length, '组');
        const failed = [];
        for (const item of pending) {
            try {
                await xianyuApi.ingest(item.payload);
                console.log('[xianyu] 重试成功');
            } catch(e) { console.log('[xianyu] 重试失败:', e.message); failed.push(item); }
        }
        await chrome.storage.local.set({ [PENDING_KEY]: failed });
        console.log('[xianyu] 重试完成，剩余失败:', failed.length, '组');
    } catch(e) { console.log('[xianyu] retry error:', e); }
}

// 扩展启动时重试一次
chrome.runtime.onInstalled.addListener(() => { retryPendingSync(); });

// 处理 API 请求
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    // ===== 账号管理 API =====
    if (request.type === 'SAVE_COOKIE') {
        (async () => {
            try {
                var domains = ['goofish.com','taobao.com','alipay.com']; var cookies = []; for (var di = 0; di < domains.length; di++) { var c = await chrome.cookies.getAll({ domain: domains[di] }); cookies = cookies.concat(c); }
                var data = { store: request.store, cookies: cookies, time: Date.now() };
                var result = await chrome.storage.local.get('xianyu_cookies');
                var all = result.xianyu_cookies || {};
                all[request.store] = data;
                await chrome.storage.local.set({ xianyu_cookies: all });
                sendResponse({ ok: !!profile });
            } catch(e) { sendResponse({ ok: false, error: e.message }); }
        })();
        return true;
    }
    if (request.type === 'LOAD_COOKIE') {
        (async () => {
            try {
                var result = await chrome.storage.local.get('xianyu_cookies');
                var all = result.xianyu_cookies || {};
                var profile = all[request.store];
                console.log('[DEBUG] 切换账号:', request.store);
                if (profile) {
                    console.log('[DEBUG] 保存时间:', new Date(profile.time).toLocaleString());
                    console.log('[DEBUG] 待写入 cookie 数量:', profile.cookies.length);
                    console.log('[DEBUG] cookie 列表:', profile.cookies.map(function(c){return c.name+' (domain='+c.domain+', httpOnly='+c.httpOnly+', hostOnly='+c.hostOnly+')';}));
                } else {
                    console.log('[DEBUG] 未找到已保存的登录，仅清除当前 Cookie');
                }

                // 清 localStorage（保留 kun_*）
                var tabs = await chrome.tabs.query({ url: 'https://www.goofish.com/*' });
                if (tabs.length > 0) {
                    try {
                        await chrome.scripting.executeScript({
                            target: { tabId: tabs[0].id },
                            func: function() {
                                var keep = ['kun_publish_v2','kun_stores','kun_cur_store','kun_store_projects','kun_trend_db','kun_project_configs','kun_replied_sessions'];
                                var saved = {};
                                for (var i = 0; i < keep.length; i++) {
                                    var v = localStorage.getItem(keep[i]);
                                    if (v) saved[keep[i]] = v;
                                }
                                localStorage.clear(); sessionStorage.clear();
                                for (var k in saved) localStorage.setItem(k, saved[k]);
                            }
                        });
                    } catch(e) { console.log('[DEBUG] localStorage clear error:', e.message); }
                }

                // 逐个删除所有相关 Cookie（比 browsingData.remove 更可靠）
                var clearDomains = ['goofish.com','www.goofish.com','taobao.com','www.taobao.com','alipay.com','www.alipay.com'];
                var allExisting = [];
                for (var di = 0; di < clearDomains.length; di++) {
                    try { var cks = await chrome.cookies.getAll({ domain: clearDomains[di] }); allExisting = allExisting.concat(cks); } catch(e) {}
                }
                console.log('[DEBUG] 待清除 cookie 数量:', allExisting.length);
                var removed = 0;
                for (var ri = 0; ri < allExisting.length; ri++) {
                    var ck0 = allExisting[ri];
                    var rmUrl = 'https://' + (ck0.domain || 'goofish.com').replace(/^\./, '') + (ck0.path || '/');
                    try { await chrome.cookies.remove({ url: rmUrl, name: ck0.name }); removed++; }
                    catch(e) { console.log('[DEBUG] REMOVE FAIL', ck0.name, e.message); }
                }
                console.log('[DEBUG] 已清除 cookie:', removed);

                // 验证清除
                var remaining = await chrome.cookies.getAll({ domain: 'goofish.com' });
                console.log('[DEBUG] 清除后剩余 goofish cookie:', remaining.length);

                // 写入（仅当有已保存的 Cookie 时）
                var ok = 0, fail = 0;
                if (profile) {
                for (var j = 0; j < profile.cookies.length; j++) {
                    var ck = profile.cookies[j];
                    if (!ck.name || !ck.value) continue;
                    var host = (ck.domain || 'goofish.com').replace(/^\./, '');
                    var opts = {
                        url: 'https://' + host + (ck.path || '/'),
                        name: ck.name, value: ck.value,
                        path: ck.path || '/',
                        secure: !!ck.secure, httpOnly: !!ck.httpOnly,
                        sameSite: ck.sameSite || 'no_restriction'
                    };
                    if (!ck.hostOnly && ck.domain) opts.domain = ck.domain;
                    if (ck.expirationDate) opts.expirationDate = ck.expirationDate;
                    if (ck.partitionKey) opts.partitionKey = ck.partitionKey;
                    try { await chrome.cookies.set(opts); ok++; }
                    catch(e) { console.log('[DEBUG] SET FAIL '+ck.name+':', e.message); fail++; }
                }
                }
                console.log('[DEBUG] 写入结果: '+ok+' 成功, '+fail+' 失败');

                // 验证写入
                var after = await chrome.cookies.getAll({ domain: 'goofish.com' });
                console.log('[DEBUG] 写入后 goofish cookie 数量:', after.length);
                console.log('[DEBUG] 写入后 cookie 列表:', after.map(function(c){return c.name;}));

                sendResponse({ ok: !!profile });
            } catch(e) { console.log('[DEBUG] FATAL:', e.message, e.stack); sendResponse({ ok: false, error: e.message }); }
        })();
        return true;
    }
    if (request.type === 'FETCH_ACCOUNTS') {
        (async () => {
            try {
                var resp = await fetch('https://manager.hympro.cn/api/xianyu-accounts', {
                    headers: { 'X-API-Key': xianyuApi.KEY }
                });
                var data = await resp.json();
                sendResponse(data);
            } catch(e) { sendResponse({ ok: false, error: e.message }); }
        })();
        return true;
    }
    if (request.type === 'AGENT_API') {
        // 转发到本地 Playwright 服务
        (async () => {
            try {
                var url = 'http://localhost:8093' + request.path;
                var opts = {
                    method: request.method || 'GET',
                    headers: { 'Content-Type': 'application/json', 'X-API-Key': xianyuApi.KEY }
                };
                if (request.body) opts.body = JSON.stringify(request.body);
                var resp = await fetch(url, opts);
                var data = await resp.json();
                sendResponse(data);
            } catch(e) { sendResponse({ ok: false, error: e.message }); }
        })();
        return true;
    }
    if (request.type === 'SYNC_TO_BACKEND') {
        (async () => {
            try {
                const result = await xianyuApi.ingest(request.data);
                sendResponse({ success: true, message: result.message || '同步成功' });
                sendFeishuSyncNotify(request.data).catch(() => {});
            } catch(e) {
                await cachePendingSync(request.data);
                sendResponse({ success: false, message: e.message || '同步失败，已缓存待重试' });
            }
        })();
        return true;
    }

    // 查看已上报数据（从后台拉取）
    if (request.type === 'FETCH_REPORTED_DATA') {
        (async () => {
            try {
                const result = await xianyuApi.reported({ limit: 50, days: 7 });
                sendResponse({ success: true, data: result.data, summary: result.summary });
            } catch(e) {
                sendResponse({ success: false, message: e.message });
            }
        })();
        return true;
    }

    // 拉取闲鱼账户（用于自动登录）
    if (request.type === 'FETCH_XIANYU_ACCOUNTS') {
        (async () => {
            try {
                const accounts = await xianyuApi.fetchAccounts();
                sendResponse({ success: true, data: accounts });
            } catch(e) {
                sendResponse({ success: false, message: e.message });
            }
        })();
        return true;
    }

    // 操作台：打开 dashboard
    if (request.type === 'OPEN_DASHBOARD') {
        const url = chrome.runtime.getURL('dashboard.html');
        chrome.tabs.create({ url: url + '#config' });
        return;
    }

    // 告警通知
    if (request.type === 'SHOW_ALERT') {
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon.png',
            title: '闲鱼告警',
            message: (request.messages || []).join('\\n')
        });
        return;
    }

    // Webhook 推送
    if (request.type === 'SEND_WEBHOOK') {
        (async () => {
            try {
                const result = await chrome.storage.local.get('kun_alert_config');
                const cfg = result.kun_alert_config || {};
                if (!cfg.webhook) return;
                const tab = await findDayuTab();
                if (!tab) return;
                const data = await chrome.tabs.sendMessage(tab.id, { type: 'FETCH_DATA' });
                if (data && data.success && data.data) {
                    const d = data.data.summary || {};
                    const body = {
                        date: data.data.date,
                        cost: (d.cost || 0) / 100,
                        clickPv: d.clickPv || 0,
                        chatPv: d.chatPv || 0,
                        inquiries: d.inquiries || 0,
                        payPv: d.payPv || 0
                    };
                    await fetch(cfg.webhook, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(body)
                    });
                }
            } catch(e) {
                console.log('webhook error:', e);
            }
        })();
        return;
    }

    // Native Host 消息转发
    if (request.type === 'NATIVE_HOST') {
        chrome.runtime.sendNativeMessage(NATIVE_HOST, request.payload, (response) => {
            if (chrome.runtime.lastError) {
                sendResponse({ success: false, error: chrome.runtime.lastError.message });
            } else {
                sendResponse({ success: true, data: response });
            }
        });
        return true;
    }

    // ===== 操作台：从 dayu 页面取数 =====
    if (request.type === 'FETCH_XIANYU_DATA') {
        (async () => {
            try {
                const tab = await findDayuTab();
                if (!tab) {
                    sendResponse({ error: '请先打开 dayu.goofish.com 页面' });
                    return;
                }
                const result = await chrome.tabs.sendMessage(tab.id, {
                    type: 'FETCH_DATA',
                    date: request.date,
                    inspect: request.inspect || false
                });
                sendResponse(result);
            } catch(e) {
                sendResponse({ error: e.message || '通信失败' });
            }
        })();
        return true;
    }

    // ===== 发布台 API =====
    // 获取店铺列表（含项目绑定）
    if (request.type === 'PD_GET_STORES') {
        (async () => {
            try {
                var stores = [];
                try { var result = await chrome.storage.local.get('kun_stores'); 
                    var raw = result.kun_stores;
                    if (typeof raw === 'string') raw = JSON.parse(raw);
                    stores = Array.isArray(raw) ? raw : ['店铺A','店铺B','店铺C','店铺D','店铺E'];
                } catch(e) { stores = ['店铺A','店铺B','店铺C','店铺D','店铺E']; }
                var storeProj = {};
                try { var sp = await chrome.storage.local.get('kun_store_projects');
                    var rawSp = sp.kun_store_projects;
                    if (typeof rawSp === 'string') rawSp = JSON.parse(rawSp);
                    storeProj = rawSp || {};
                } catch(e) {}
                // 获取 cookie 保存状态
                var cookies = {};
                try { var cr = await chrome.storage.local.get('xianyu_cookies');
                    var all = cr.xianyu_cookies || {};
                    for (var s = 0; s < stores.length; s++) {
                        cookies[stores[s]] = !!all[stores[s]];
                    }
                } catch(e) {}
                sendResponse({ ok: true, stores: stores, storeProjects: storeProj, cookies: cookies });
            } catch(e) { sendResponse({ ok: false, error: e.message }); }
        })();
        return true;
    }
    // 获取店铺 Cookie（用于图片上传）
    if (request.type === 'PD_GET_COOKIES') {
        (async () => {
            try {
                var result = await chrome.storage.local.get('xianyu_cookies');
                var all = result.xianyu_cookies || {};
                var profile = all[request.store];
                if (!profile || !profile.cookies) { sendResponse({ ok: false, error: '该店铺未保存登录' }); return; }
                var cookieStr = profile.cookies.map(function(c) { return c.name + '=' + c.value; }).join('; ');
                sendResponse({ ok: true, cookies: cookieStr });
            } catch(e) { sendResponse({ ok: false, error: e.message }); }
        })();
        return true;
    }
    // 保存/读取发布任务
    if (request.type === 'PD_SAVE_TASKS') {
        chrome.storage.local.set({ 'pd_tasks': request.tasks });
        sendResponse({ ok: true });
        return;
    }
    if (request.type === 'PD_GET_TASKS') {
        (async () => {
            var result = await chrome.storage.local.get('pd_tasks');
            sendResponse({ ok: true, tasks: result.pd_tasks || [] });
        })();
        return true;
    }
    // 打开发布台
    if (request.type === 'OPEN_PUBLISH_DASHBOARD') {
        var url = chrome.runtime.getURL('publish_dashboard.html');
        chrome.tabs.create({ url: url });
        return;
    }
    // 图片上传到闲鱼 CDN（通过 Native Host）
    if (request.type === 'PD_UPLOAD_IMAGES') {
        (async () => {
            var results = [];
            for (var i = 0; i < request.images.length; i++) {
                var img = request.images[i];
                try {
                    // 通过 native_host 的 uploadToMtop 直传
                    var resp = await new Promise(function(resolve) {
                        chrome.runtime.sendNativeMessage(NATIVE_HOST,
                            { action: 'uploadToMtop', base64: img.base64, cookies: request.cookies || '' },
                            function(r) { resolve(r); }
                        );
                    });
                    if (resp && resp.url) {
                        results.push({ index: i, url: resp.url, ok: true });
                    } else {
                        results.push({ index: i, ok: false, error: (resp && resp.error) || '上传失败' });
                    }
                } catch(e) {
                    results.push({ index: i, ok: false, error: e.message });
                }
            }
            sendResponse({ ok: true, results: results });
        })();
        return true;
    }
    // 启动发布流程
    if (request.type === 'PD_START_PUBLISH') {
        (async () => {
            try {
                // 查找 goofish.com 标签页
                var tabs = await chrome.tabs.query({ url: 'https://www.goofish.com/*' });
                var tab;

                if (tabs.length > 0) {
                    tab = tabs[0];
                    // 切换 Cookie：先清除再注入目标店铺的 Cookie
                    await switchCookiesForStore(request.store);
                    // 重载页面使 Cookie 生效
                    await chrome.tabs.reload(tab.id);
                    // 等待页面加载完成
                    await new Promise(function(resolve) {
                        var check = function(tabId, info) {
                            if (tabId === tab.id && info.status === 'complete') {
                                chrome.tabs.onUpdated.removeListener(check);
                                setTimeout(resolve, 3000); // 等 MTOP 初始化
                            }
                        };
                        chrome.tabs.onUpdated.addListener(check);
                        setTimeout(function() { chrome.tabs.onUpdated.removeListener(check); resolve(); }, 20000);
                    });
                } else {
                    // 新建标签页前先注入 Cookie
                    await switchCookiesForStore(request.store);
                    tab = await chrome.tabs.create({ url: 'https://www.goofish.com/', active: false });
                    await new Promise(function(resolve) {
                        var check = function(tabId, info) {
                            if (tabId === tab.id && info.status === 'complete') {
                                chrome.tabs.onUpdated.removeListener(check);
                                setTimeout(resolve, 3000);
                            }
                        };
                        chrome.tabs.onUpdated.addListener(check);
                        setTimeout(function() { chrome.tabs.onUpdated.removeListener(check); resolve(); }, 20000);
                    });
                }

                // 发送发布命令到 bridge.js
                chrome.tabs.sendMessage(tab.id, {
                    type: 'PD_PREPARE_PUBLISH',
                    store: request.store,
                    tasks: request.tasks,
                    imageUrls: request.imageUrls,
                    templateId: request.templateId,
                    autoPolish: request.autoPolish,
                    publishInterval: request.publishInterval,
                    pubMode: request.pubMode,
                    project: request.project
                }, function(resp) {
                    if (chrome.runtime.lastError) {
                        // 如果 direct sendMessage 失败，再等 2 秒后重试一次
                        setTimeout(function() {
                            chrome.tabs.sendMessage(tab.id, {
                                type: 'PD_PREPARE_PUBLISH',
                                store: request.store, tasks: request.tasks, imageUrls: request.imageUrls,
                                templateId: request.templateId, autoPolish: request.autoPolish,
                                publishInterval: request.publishInterval, pubMode: request.pubMode, project: request.project
                            }).catch(function(){});
                        }, 2000);
                    }
                });
                sendResponse({ ok: true });
            } catch(e) { sendResponse({ ok: false, error: e.message }); }
        })();
        return true;
    }

    // Cookie 切换辅助函数
    async function switchCookiesForStore(storeName) {
        var result = await chrome.storage.local.get('xianyu_cookies');
        var all = result.xianyu_cookies || {};
        var profile = all[storeName];

        // 清除现有 Cookie
        var clearDomains = ['goofish.com','www.goofish.com','taobao.com','www.taobao.com','alipay.com','www.alipay.com'];
        for (var di = 0; di < clearDomains.length; di++) {
            try {
                var cks = await chrome.cookies.getAll({ domain: clearDomains[di] });
                for (var ri = 0; ri < cks.length; ri++) {
                    var ck0 = cks[ri];
                    var rmUrl = 'https://' + (ck0.domain || 'goofish.com').replace(/^\./, '') + (ck0.path || '/');
                    try { await chrome.cookies.remove({ url: rmUrl, name: ck0.name }); }
                    catch(e) {}
                }
            } catch(e) {}
        }

        // 注入目标店铺 Cookie
        if (profile && profile.cookies) {
            for (var j = 0; j < profile.cookies.length; j++) {
                var ck = profile.cookies[j];
                if (!ck.name || !ck.value) continue;
                var host = (ck.domain || 'goofish.com').replace(/^\./, '');
                var opts = {
                    url: 'https://' + host + (ck.path || '/'),
                    name: ck.name, value: ck.value,
                    path: ck.path || '/',
                    secure: !!ck.secure, httpOnly: !!ck.httpOnly,
                    sameSite: ck.sameSite || 'no_restriction'
                };
                if (!ck.hostOnly && ck.domain) opts.domain = ck.domain;
                if (ck.expirationDate) opts.expirationDate = ck.expirationDate;
                if (ck.partitionKey) opts.partitionKey = ck.partitionKey;
                try { await chrome.cookies.set(opts); } catch(e) {}
            }
        }
    }
    // 停止发布
    if (request.type === 'PD_STOP_PUBLISH') {
        // 2026-11-13 修：这里原来直接写 await，但外层 onMessage listener 不是 async
        //   → Chrome 加载 background.js 时抛 SyntaxError，整个 background 不加载。
        //   （其他分支都用了 (async () => {...})() 包起来，唯独这个漏了）
        (async () => {
            var tabs = await chrome.tabs.query({ url: 'https://www.goofish.com/*' });
            for (var ti = 0; ti < tabs.length; ti++) {
                chrome.tabs.sendMessage(tabs[ti].id, { type: 'PD_STOP_PUBLISH' }).catch(function(){});
            }
            sendResponse({ ok: true });
        })();
        return true;   // 保持消息通道，等 async 里 sendResponse
    }
    // 发布进度回报（从 goofish 页面 → 发布台面板）
    if (request.type === 'PD_PROGRESS') {
        // 写入 chrome.storage，面板轮询读取
        chrome.storage.local.set({ 'pd_progress': request });
        sendResponse({ ok: true });
        return;
    }
    if (request.type === 'PD_GET_PROGRESS') {
        (async () => {
            var result = await chrome.storage.local.get('pd_progress');
            sendResponse(result.pd_progress || { phase: 'idle' });
        })();
        return true;
    }

    // ===== 操作台：发现字段 =====
    if (request.type === 'DISCOVER_FIELDS') {
        (async () => {
            try {
                const tab = await findDayuTab();
                if (!tab) {
                    sendResponse({ error: '请先打开 dayu.goofish.com 页面' });
                    return;
                }
                const result = await chrome.tabs.sendMessage(tab.id, {
                    type: 'DISCOVER_FIELDS'
                });
                sendResponse(result);
            } catch(e) {
                sendResponse({ error: e.message || '通信失败' });
            }
        })();
        return true;
    }
});

// ===== 飞书同步通知 =====
async function sendFeishuSyncNotify(campaigns) {
    if (!campaigns || !campaigns.length) return;
    const dates = [...new Set(campaigns.map(c => c.date))].sort();
    const totalCost = (campaigns.reduce((s, c) => s + (c.cost || 0), 0) / 100).toFixed(2);
    const totalClicks = campaigns.reduce((s, c) => s + (c.clickPv || 0), 0);
    const totalChats = campaigns.reduce((s, c) => s + (c.chatPv || 0), 0);
    const uniqueCampaigns = [...new Set(campaigns.map(c => c.campaign_id))].length;

    const body = {
        msg_type: 'interactive',
        card: {
            header: {
                title: { tag: 'plain_text', content: '📊 闲鱼数据同步' },
                template: 'green'
            },
            elements: [
                { tag: 'div', text: { tag: 'lark_md', content: `**xianyu-monitor** 推送 ${campaigns.length} 条推广数据` } },
                { tag: 'hr' },
                { tag: 'div', text: { tag: 'lark_md', content: `📅 日期：${dates.join('、')}\n📋 推广计划：${uniqueCampaigns} 个\n💰 消耗：¥${totalCost}\n👆 点击数：${totalClicks}\n💬 咨询数：${totalChats}` } },
                { tag: 'hr' },
                { tag: 'action', actions: [{ tag: 'button', text: { tag: 'plain_text', content: '查看后台' }, url: 'https://manager.hympro.cn/#/xianyu-campaigns', type: 'primary' }] },
                { tag: 'note', elements: [{ tag: 'plain_text', content: new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' }) }] }
            ]
        }
    };

    try {
        await fetch(FEISHU_WEBHOOK, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        console.log('[xianyu] 飞书通知已发送');
    } catch(e) {
        console.log('[xianyu] 飞书通知失败:', e.message);
    }
}

// 处理定时任务
chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === 'keepalive') {
        // 每 4 分钟重试失败缓存
        await retryPendingSync();
        return;
    }

    if (alarm.name === 'sync_yesterday') {
        const tabs = await chrome.tabs.query({ url: 'https://dayu.goofish.com/*' });
        if (tabs.length === 0) return;

        for (const tab of tabs) {
            chrome.tabs.sendMessage(tab.id, { type: 'AUTO_SYNC_YESTERDAY' }).catch(() => {});
        }
    }
});
