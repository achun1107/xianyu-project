﻿// Bridge: 负责 MAIN 世界 ↔ background worker 之间的消息转发
(function() {
    'use strict';

    console.log('🔌 Bridge 脚本已加载 (隔离世界)');

    // 监听 background worker 发来的消息（定时同步 + 操作台取数）
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        console.log('🔌 Bridge 收到 background 消息:', request.type);
        if (request.type === 'AUTO_SYNC_YESTERDAY') {
            console.log('🔌 Bridge 转发 AUTO_SYNC_YESTERDAY 到 MAIN 世界');
            window.postMessage({ type: 'AUTO_SYNC_YESTERDAY' }, '*');
        }

        // 操作台远程取数：background → MAIN 世界
        if (request.type === 'FETCH_DATA' || request.type === 'DISCOVER_FIELDS') {
            (async () => {
                // 转发到 MAIN 世界，等待结果
                const result = await new Promise((resolve) => {
                    const handler = (event) => {
                        if (event.data && event.data.type === 'FETCH_DATA_RESULT' && event.data.requestId === reqId) {
                            window.removeEventListener('message', handler);
                            resolve(event.data);
                        }
                    };
                    window.addEventListener('message', handler);
                    const reqId = Date.now() + '_' + Math.random().toString(36).substring(2, 6);
                    window.postMessage({ type: request.type, date: request.date, requestId: reqId }, '*');
                    setTimeout(() => { window.removeEventListener('message', handler); resolve({ error: '超时' }); }, 30000);
                });
                sendResponse(result);
            })();
            return true;
        }

        // 发布台：准备发布 + 执行发布
        if (request.type === 'PD_PREPARE_PUBLISH') {
            console.log('🔌 Bridge 转发 PD_PREPARE_PUBLISH 到 MAIN 世界');
            window.postMessage({
                type: 'PD_PREPARE_PUBLISH',
                store: request.store,
                tasks: request.tasks,
                imageUrls: request.imageUrls,
                templateId: request.templateId,
                autoPolish: request.autoPolish,
                publishInterval: request.publishInterval,
                pubMode: request.pubMode,
                project: request.project
            }, '*');
            sendResponse({ ok: true });
        }

        if (request.type === 'PD_STOP_PUBLISH') {
            console.log('🔌 Bridge 转发 PD_STOP_PUBLISH 到 MAIN 世界');
            window.postMessage({ type: 'PD_STOP_PUBLISH' }, '*');
            sendResponse({ ok: true });
        }
    });

    // 监听 MAIN 世界发来的同步请求
    window.addEventListener('message', async (event) => {
        if (!event.data || !event.data.type) return;
        console.log('🔌 Bridge 收到 MAIN 消息:', event.data.type);

        if (event.data.type === 'OPEN_DASHBOARD') {
            console.log('🔌 Bridge OPEN_DASHBOARD received, forwarding to background');
            chrome.runtime.sendMessage({ type: 'OPEN_DASHBOARD' });
            return;
        }

        if (event.data.type === 'OPEN_PUBLISH_DASHBOARD') {
            console.log('🔌 Bridge OPEN_PUBLISH_DASHBOARD received, forwarding to background');
            chrome.runtime.sendMessage({ type: 'OPEN_PUBLISH_DASHBOARD' });
            return;
        }

        if (event.data.type === 'SYNC_XIANYU_DATA') {
            console.log('🔌 Bridge 转发数据到 background, 共', event.data.payload.length, '条');
            try {
                const result = await chrome.runtime.sendMessage({
                    type: 'SYNC_TO_BACKEND',
                    data: event.data.payload
                });
                console.log('🔌 Bridge 收到 background 响应:', result);
                window.postMessage({
                    type: 'SYNC_XIANYU_RESULT',
                    success: result.success,
                    message: result.message
                }, '*');
            } catch(e) {
                console.error('🔌 Bridge 转发失败:', e.message);
                window.postMessage({
                    type: 'SYNC_XIANYU_RESULT',
                    success: false,
                    message: e.message
                }, '*');
            }
        }

        // 查看已上报数据：MAIN → background → /api/xianyu-reported → 返回
        if (event.data.type === 'FETCH_REPORTED_DATA') {
            console.log('🔌 Bridge 转发 FETCH_REPORTED_DATA 到 background');
            try {
                const result = await chrome.runtime.sendMessage({ type: 'FETCH_REPORTED_DATA' });
                window.postMessage({
                    type: 'FETCH_REPORTED_DATA_RESULT',
                    success: result.success,
                    data: result.data,
                    summary: result.summary,
                    message: result.message
                }, '*');
            } catch(e) {
                window.postMessage({
                    type: 'FETCH_REPORTED_DATA_RESULT',
                    success: false,
                    message: e.message
                }, '*');
            }
        }

        // 拉取闲鱼账户：MAIN → background → /api/xianyu-accounts
        if (event.data.type === 'FETCH_XIANYU_ACCOUNTS') {
            console.log('🔌 Bridge 转发 FETCH_XIANYU_ACCOUNTS 到 background');
            try {
                const result = await chrome.runtime.sendMessage({ type: 'FETCH_XIANYU_ACCOUNTS' });
                window.postMessage({
                    type: 'FETCH_XIANYU_ACCOUNTS_RESULT',
                    success: result.success,
                    data: result.data,
                    message: result.message
                }, '*');
            } catch(e) {
                window.postMessage({
                    type: 'FETCH_XIANYU_ACCOUNTS_RESULT',
                    success: false,
                    message: e.message
                }, '*');
            }
        }

        // Native Host 消息转发: MAIN → background → native host → 返回
        if (event.data.type === 'NATIVE_HOST') {
            const requestId = event.data.requestId;
            console.log('🔌 Bridge 转发 NATIVE_HOST 到 background, action:', event.data.payload?.action);
            try {
                const result = await chrome.runtime.sendMessage({
                    type: 'NATIVE_HOST',
                    payload: event.data.payload
                });
                window.postMessage({
                    type: 'NATIVE_HOST_RESULT',
                    requestId: requestId,
                    success: result.success,
                    data: result.data,
                    error: result.error
                }, '*');
            } catch(e) {
                window.postMessage({
                    type: 'NATIVE_HOST_RESULT',
                    requestId: requestId,
                    success: false,
                    error: e.message
                }, '*');
            }
        }

        // 发布台进度回报：MAIN → background
        if (event.data.type === 'PD_PROGRESS') {
            console.log('🔌 Bridge 转发 PD_PROGRESS 到 background');
            chrome.runtime.sendMessage({
                type: 'PD_PROGRESS',
                phase: event.data.phase,
                current: event.data.current,
                total: event.data.total,
                log: event.data.log
            }).catch(function(){});
        }
    });

    // 账号查询
    window.addEventListener('message', function(event) {
        // 如果 bridge_direct 已激活，跳过（避免双桥冲突导致闪退）
        if (document.documentElement.dataset.kunBridgeDirect === '1') return;
        if (event.data && event.data.type === 'SAVE_COOKIE') {
            chrome.runtime.sendMessage({ type: 'SAVE_COOKIE', store: event.data.store }, function(resp) {
                window.postMessage({ type: 'SAVE_COOKIE_RESULT', ok: resp.ok, error: resp.error }, '*');
            });
        }
        if (event.data && event.data.type === 'LOAD_COOKIE') {
            chrome.runtime.sendMessage({ type: 'LOAD_COOKIE', store: event.data.store }, function(resp) {
                window.postMessage({ type: 'LOAD_COOKIE_RESULT', ok: resp.ok, error: resp.error }, '*');
            });
        }
        if (event.data && event.data.type === 'FETCH_ACCOUNTS') {
            chrome.runtime.sendMessage({ type: 'FETCH_ACCOUNTS' }, function(resp) {
                window.postMessage({ type: 'FETCH_ACCOUNTS_RESULT', data: resp }, '*');
            });
        }

        // ===== 本地 Playwright Agent 通信 =====
        if (event.data && event.data.type === 'AGENT_STATUS') {
            chrome.runtime.sendMessage({ type: 'AGENT_API', method: 'GET', path: '/api/agent/status' }, function(resp) {
                window.postMessage({ type: 'AGENT_STATUS_RESULT', data: resp }, '*');
            });
        }
        if (event.data && event.data.type === 'AGENT_SWITCH') {
            chrome.runtime.sendMessage({ type: 'AGENT_API', method: 'POST', path: '/api/agent/switch', body: { storeName: event.data.storeName } }, function(resp) {
                window.postMessage({ type: 'AGENT_SWITCH_RESULT', data: resp }, '*');
            });
        }
        if (event.data && event.data.type === 'AGENT_LOGIN') {
            chrome.runtime.sendMessage({ type: 'AGENT_API', method: 'POST', path: '/api/agent/login', body: { accountId: event.data.accountId } }, function(resp) {
                window.postMessage({ type: 'AGENT_LOGIN_RESULT', data: resp }, '*');
            });
        }
    });
    console.log('🔌 Bridge 已就绪');

    // 发布台按钮（bridge.js 有 chrome API 权限，直接创建）
    if (!document.getElementById('kun-dash-btn')) {
        var dashBtn = document.createElement('div');
        dashBtn.id = 'kun-dash-btn';
        dashBtn.textContent = '🚀 发布台';
        dashBtn.style.cssText = 'position:fixed;top:80px;right:130px;z-index:99999;background:linear-gradient(135deg,#4A90D9,#357ABD);color:#fff;padding:12px 20px;border-radius:50px;font-size:14px;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.3);font-family:system-ui,sans-serif;font-weight:500;';
        dashBtn.onclick = function() {
            console.log('🚀 发布台按钮被点击');
            try {
                var url = chrome.runtime.getURL('publish_dashboard.html');
                console.log('🚀 打开:', url);
                window.open(url, '_blank');
            } catch(e) {
                console.log('🚀 打开失败:', e.message);
            }
        };
        // 等 body 存在再插入
        function appendBtn() {
            if (document.body) { document.body.appendChild(dashBtn); }
            else { setTimeout(appendBtn, 100); }
        }
        appendBtn();
    }

    // 同步项目配置：chrome.storage → goofish localStorage
    try {
        chrome.storage.local.get('kun_project_configs', function(result) {
            if (result.kun_project_configs) {
                localStorage.setItem('kun_project_configs', JSON.stringify(result.kun_project_configs));
                console.log('🔌 项目配置已同步');
            }
        });
    } catch(e) {}
})();
