#!/usr/bin/env python3
"""
Xianyu Native Messaging Host
读写共享任务队列、解析 Excel、读取本地图片文件。
Chrome 扩展通过 stdin/stdout JSON 消息与它通信（Native Messaging 协议）。
"""
import json
import struct
import sys
import os
import io
import base64
import traceback
from pathlib import Path

# ============ 配置 ============
TASK_FILE = Path.home() / ".xianyu-task-queue.json"
IMAGE_POOL_FILE = Path.home() / ".xianyu-image-pool.json"
TEMPLATES_FILE = Path.home() / ".xianyu-templates.json"
PROJECT_CONFIGS_FILE = Path.home() / ".xianyu-project-configs.json"
DAILY_TASKS_FILE = Path.home() / ".xianyu-daily-tasks.json"
LOCK_TIMEOUT = 5  # seconds

# ============ 文件锁 (Windows) ============
if os.name == "nt":
    import msvcrt

    def lock_file(f):
        """非阻塞获取排他锁，失败抛异常"""
        msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)

    def unlock_file(f):
        msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
else:
    import fcntl

    def lock_file(f):
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)

    def unlock_file(f):
        fcntl.flock(f, fcntl.LOCK_UN)


# ============ JSON 读写 ============
def safe_read_json(path: Path, default=None):
    """线程安全地读取 JSON 文件"""
    if default is None:
        default = {}
    if not path.exists():
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            lock_file(f)
            try:
                data = json.load(f)
            finally:
                try:
                    f.seek(0)
                    unlock_file(f)
                except OSError:
                    pass  # Windows 上解锁位置错误会报 PermissionError，数据已读完，可忽略
        return data
    except (json.JSONDecodeError, OSError):
        return default


def safe_write_json(path: Path, data):
    """线程安全地写入 JSON 文件"""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        lock_file(f)
        try:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        finally:
            try:
                f.seek(0)
                unlock_file(f)
            except OSError:
                pass  # Windows 上解锁位置错误会报 PermissionError，数据已写入，可忽略


# ============ 图片处理 ============
def read_image_base64(image_path: str) -> dict:
    """读取本地图片，返回 base64 和 MIME 类型
    自动压缩大图：最长边不超过 1920px，JPEG 质量 85，确保 JSONP 上传可用"""
    p = Path(image_path)
    if not p.exists():
        return {"error": f"文件不存在: {image_path}"}

    if not p.is_file():
        return {"error": f"不是文件: {image_path}"}

    ext = p.suffix.lower()
    mime_map = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".bmp": "image/bmp",
    }
    mime = mime_map.get(ext, "image/jpeg")

    try:
        with open(p, "rb") as f:
            raw_data = f.read()

        # 尝试用 Pillow 压缩图片
        try:
            from PIL import Image
            import io as io_mod
            img = Image.open(io_mod.BytesIO(raw_data))
            orig_w, orig_h = img.size
            max_dim = 1920
            if orig_w > max_dim or orig_h > max_dim:
                scale = max_dim / max(orig_w, orig_h)
                new_w = int(orig_w * scale)
                new_h = int(orig_h * scale)
                img = img.resize((new_w, new_h), Image.LANCZOS)
            # 转为 RGB（去掉 alpha 通道，避免 JPEG 不支持）
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
            buf = io_mod.BytesIO()
            img.save(buf, format="JPEG", quality=85, optimize=True)
            data = buf.getvalue()
            mime = "image/jpeg"
        except Exception:
            # Pillow 不可用或格式不支持，用原始数据
            data = raw_data

        b64 = base64.b64encode(data).decode("ascii")
        return {
            "path": str(p.resolve()),
            "name": p.name,
            "size": len(data),
            "original_size": len(raw_data),
            "mime": mime,
            "base64": b64,
        }
    except Exception as e:
        return {"error": str(e)}


# ============ 图片上传到闲鱼 mtop（绕过浏览器 CORS）============
def upload_to_mtop(base64_data: str, cookies: str = "") -> dict:
    """通过 Python HTTP POST 上传图片到闲鱼 mtop API"""
    import hashlib
    import time
    import urllib.request
    import urllib.error

    if not base64_data:
        return {"error": "缺少 base64 数据"}

    appKey = "12574478"
    v = "1.0"
    # 多个可能的图片上传 API
    PICTURE_APIS = ["mtop.taobao.picture.upload", "mtop.idle.pc.picture.upload", "mtop.idle.picture.upload", "mtop.taobao.file.upload"]

    for api in PICTURE_APIS:
        t = str(int(time.time() * 1000))
        data_json = json.dumps({"file": base64_data, "fileType": "jpg", "space": "fleamarket"}, ensure_ascii=False)

        # 尝试从 cookie 提取 _m_h5_tk token
        token = ""
        if cookies:
            for part in cookies.replace(" ", "").split(";"):
                if part.startswith("_m_h5_tk="):
                    tk = part.split("=", 1)[1]
                    token = tk.split("_")[0] if "_" in tk else tk
                    break

        # mtop H5 签名: md5(token + "&" + t + "&" + appKey + "&" + data_json)
        raw = f"{token}&{t}&{appKey}&{data_json}"
        sign = hashlib.md5(raw.encode("utf-8")).hexdigest()

        # 构造 URL
        params = urllib.parse.urlencode({
            "jsv": "2.7.2",
            "appKey": appKey,
            "t": t,
            "sign": sign,
            "api": api,
            "v": v,
            "type": "originaljson",
            "dataType": "jsonp",
        })
        url = f"https://h5api.m.goofish.com/h5/{api}/{v}/?{params}"

        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        }
        if cookies:
            headers["Cookie"] = cookies

        body = urllib.parse.urlencode({"data": data_json}).encode("utf-8")

        try:
            req = urllib.request.Request(url, data=body, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=60) as resp:
                raw_body = resp.read()
                text = raw_body.decode("utf-8", errors="replace")
                # mtop 返回格式可能是 JSON 或 JSONP callback
                if text.startswith("mtopjsonp"):
                    start = text.index("(") + 1
                    end = text.rindex(")")
                    text = text[start:end]
                result = json.loads(text)
                ret = result.get("ret", [])
                if ret and isinstance(ret, list) and len(ret) > 0 and ret[0].startswith("SUCCESS"):
                    url_result = result.get("data", {}).get("url", "")
                    return {"url": url_result, "ret": ret[0], "api": api}
                else:
                    sys.stderr.write(f"[native_host] API {api} 返回: {ret[0] if ret else '未知'}\n")
                    sys.stderr.flush()
        except urllib.error.HTTPError as e:
            body_err = e.read().decode("utf-8", errors="replace") if e.fp else str(e)
            sys.stderr.write(f"[native_host] API {api} HTTP {e.code}\n")
            sys.stderr.flush()
        except Exception as e:
            sys.stderr.write(f"[native_host] API {api} 异常: {e}\n")
            sys.stderr.flush()

    return {"error": "所有API均失败", "ret": "FAIL_SYS_API_NOT_FOUNDED"}


# ============ Excel 解析 ============
def parse_excel(file_path: str) -> dict:
    """解析 Excel 任务表，返回任务列表"""
    p = Path(file_path)
    if not p.exists():
        return {"error": f"文件不存在: {file_path}"}

    try:
        import openpyxl
    except ImportError:
        return {"error": "缺少 openpyxl 库。请执行: pip install openpyxl"}

    try:
        wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
        ws = wb.active

        rows = list(ws.iter_rows(values_only=True))
        if len(rows) < 2:
            return {"error": "Excel 至少需要标题行 + 1 行数据"}

        headers = [str(h).strip() if h else "" for h in rows[0]]
        # 标准化列名（大小写不敏感）
        col_map = {}
        for i, h in enumerate(headers):
            key = h.lower()
            col_map[key] = i

        # 必需列检查
        required = ["标题", "描述", "价格", "图片路径", "城市", "目标店铺"]
        for r in required:
            if r.lower() not in col_map and r not in headers:
                # 尝试模糊匹配
                found = False
                for h in headers:
                    if r in h:
                        found = True
                        break
                if not found:
                    return {
                        "error": f"缺少列: '{r}'，当前列: {headers}",
                        "headers": headers,
                    }

        tasks = []
        for row_idx, row in enumerate(rows[1:], start=2):
            if not row or all(c is None or str(c).strip() == "" for c in row):
                continue  # 跳过空行

            def get_cell(col_name):
                idx = col_map.get(col_name.lower())
                if idx is not None and idx < len(row) and row[idx] is not None:
                    return str(row[idx]).strip()
                return ""

            title = get_cell("标题")
            if not title:
                continue  # 无标题视为空行

            task = {
                "id": f"task-{row_idx:04d}",
                "title": title,
                "desc": get_cell("描述"),
                "price": get_cell("价格") or "1",
                "imagePath": get_cell("图片路径"),
                "imagePaths": [p.strip() for p in get_cell("图片路径").split(";") if p.strip()]
                or [get_cell("图片路径")],
                "city": get_cell("城市"),
                "prov": get_cell("省份") or "",
                "targetStore": get_cell("目标店铺"),
                "categoryName": get_cell("分类") or "创业/副业培训",
                "status": "pending",
            }
            tasks.append(task)

        wb.close()
        return {"tasks": tasks, "total": len(tasks), "headers": headers}

    except Exception as e:
        return {"error": f"解析 Excel 失败: {e}"}


# ============ 任务队列操作 ============
def read_task_queue():
    return safe_read_json(TASK_FILE, {"tasks": [], "stores": {}})


def write_task_queue(data):
    safe_write_json(TASK_FILE, data)


def read_image_pool():
    return safe_read_json(
        IMAGE_POOL_FILE,
        {"images": [], "usedImages": []},
    )


def write_image_pool(data):
    safe_write_json(IMAGE_POOL_FILE, data)


def read_templates():
    return safe_read_json(TEMPLATES_FILE, [])


def write_templates(data):
    safe_write_json(TEMPLATES_FILE, data)


def read_project_configs():
    return safe_read_json(PROJECT_CONFIGS_FILE, {})


def write_project_configs(data):
    safe_write_json(PROJECT_CONFIGS_FILE, data)


def _daily_tasks_file(store=None):
    """每日任务按店铺分文件，避免多店并发写同一文件打架"""
    if not store:
        return DAILY_TASKS_FILE
    safe = "".join(c if c not in '\\/:*?"<>|' else '_' for c in str(store)).strip()
    if not safe:
        return DAILY_TASKS_FILE
    return Path.home() / (".xianyu-daily-tasks-" + safe + ".json")


def read_daily_tasks(store=None):
    return safe_read_json(_daily_tasks_file(store), {})


def _task_key(t):
    return str(t.get("star", "")) + "|" + str(t.get("city", "")) + "|" + str(t.get("sessionType", "")) + "|" + str(t.get("imageName", ""))

def write_daily_tasks(data, store=None):
    """合并写入，避免整份覆盖冲掉其它任务：按 star|city|场次 去重，优先保留带 itemId/status 的版本。
    data["_replace"] == True 时改为整份覆盖：用于删除/重置任务，
    否则合并逻辑会把「磁盘上有、本次没有」的任务补回来，导致删除和重置永远不生效。"""
    f = _daily_tasks_file(store)
    if data.get("_replace") is True:
        out = dict(data)
        out.pop("_replace", None)
        if not isinstance(out.get("tasks"), list):
            out["tasks"] = []
        safe_write_json(f, out)
        return
    existing = safe_read_json(f, {})
    if not isinstance(existing, dict):
        existing = {}
    et = existing.get("tasks", []) if isinstance(existing.get("tasks"), list) else []
    nt = data.get("tasks", []) if isinstance(data.get("tasks"), list) else []
    merged = {}
    for t in et:  # 已有的先放(带 itemId/status)
        if isinstance(t, dict):
            merged[_task_key(t)] = t
    for t in nt:  # 新增; 若同一key: 新版本有itemId则替换, 否则保留已有(不丢已发布状态)
        if not isinstance(t, dict):
            continue
        k = _task_key(t)
        cur = merged.get(k)
        if cur is None or (t.get("itemId") and not cur.get("itemId")):
            merged[k] = t
    out = dict(existing); out.update(data); out["tasks"] = list(merged.values())
    safe_write_json(f, out)


def import_tasks_to_queue(new_tasks: list, overwrite: bool = False):
    """将任务导入共享队列"""
    queue = read_task_queue()

    if overwrite:
        queue["tasks"] = []
        queue["stores"] = {}

    existing_ids = {t["id"] for t in queue["tasks"]}
    added = 0
    for t in new_tasks:
        tid = t.get("id", "")
        if tid and tid not in existing_ids:
            t["status"] = "pending"
            t["claimedBy"] = None
            t["claimedAt"] = None
            t["doneAt"] = None
            t["itemId"] = None
            t["error"] = None
            queue["tasks"].append(t)
            existing_ids.add(tid)
            added += 1

    write_task_queue(queue)
    return {"added": added, "total": len(queue["tasks"])}


def claim_task(store_name: str):
    """店铺领取一个待处理任务"""
    import time

    queue = read_task_queue()
    for t in queue["tasks"]:
        if t.get("status") == "pending":
            if t.get("targetStore") and t["targetStore"] != store_name:
                continue  # 不是分配给该店铺的
            t["status"] = "claimed"
            t["claimedBy"] = store_name
            t["claimedAt"] = time.strftime("%Y-%m-%d %H:%M:%S")
            write_task_queue(queue)
            return t
    return None


def complete_task(task_id: str, store_name: str, item_id: str = None, error: str = None):
    """完成任务或标记失败"""
    queue = read_task_queue()
    for t in queue["tasks"]:
        if t.get("id") == task_id:
            if error:
                t["status"] = "failed"
                t["error"] = error
            else:
                t["status"] = "done"
                t["itemId"] = item_id
            t["doneAt"] = __import__("time").strftime("%Y-%m-%d %H:%M:%S")

            # 更新店铺统计
            if store_name not in queue.setdefault("stores", {}):
                queue["stores"][store_name] = {"doneToday": 0, "failedToday": 0}
            if error:
                queue["stores"][store_name]["failedToday"] = (
                    queue["stores"][store_name].get("failedToday", 0) + 1
                )
            else:
                queue["stores"][store_name]["doneToday"] = (
                    queue["stores"][store_name].get("doneToday", 0) + 1
                )
            write_task_queue(queue)
            return {"ok": True}
    return {"error": f"任务 {task_id} 不存在"}


def get_progress():
    """获取整体进度"""
    queue = read_task_queue()
    total = len(queue["tasks"])
    pending = sum(1 for t in queue["tasks"] if t.get("status") == "pending")
    claimed = sum(1 for t in queue["tasks"] if t.get("status") == "claimed")
    done = sum(1 for t in queue["tasks"] if t.get("status") == "done")
    failed = sum(1 for t in queue["tasks"] if t.get("status") == "failed")
    return {
        "total": total,
        "pending": pending,
        "claimed": claimed,
        "done": done,
        "failed": failed,
        "stores": queue.get("stores", {}),
    }


# ============ Native Messaging 协议 ============
def read_message():
    """从 stdin 读取一条 Native Messaging 消息"""
    raw_len = sys.stdin.buffer.read(4)
    if not raw_len or len(raw_len) < 4:
        return None
    msg_len = struct.unpack("@I", raw_len)[0]
    if msg_len == 0:
        return None
    raw_msg = sys.stdin.buffer.read(msg_len)
    return json.loads(raw_msg.decode("utf-8"))


def send_message(msg):
    """向 stdout 写入一条 Native Messaging 消息"""
    raw = json.dumps(msg, ensure_ascii=False).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("@I", len(raw)))
    sys.stdout.buffer.write(raw)
    sys.stdout.buffer.flush()


# ============ 命令路由 ============
def handle_message(msg):
    action = msg.get("action", "")
    try:
        if action == "ping":
            return {"ok": True, "pong": True}

        elif action == "parseExcel":
            path = msg.get("path", "")
            if not path:
                return {"error": "缺少 path 参数"}
            return parse_excel(path)

        elif action == "readImage":
            path = msg.get("path", "")
            if not path:
                return {"error": "缺少 path 参数"}
            result = read_image_base64(path)
            # 如果文件不存在，在父目录的子文件夹中搜索
            if "error" in result:
                base = Path(path).parent
                fname = Path(path).name
                if base.exists():
                    for sub in base.iterdir():
                        if sub.is_dir():
                            alt = sub / fname
                            if alt.exists():
                                result = read_image_base64(str(alt))
                                break
            return result

        elif action == "importTasks":
            tasks = msg.get("tasks", [])
            overwrite = msg.get("overwrite", False)
            return import_tasks_to_queue(tasks, overwrite)

        elif action == "claimTask":
            store = msg.get("store", "")
            if not store:
                return {"error": "缺少 store 参数"}
            task = claim_task(store)
            return {"task": task} if task else {"task": None, "message": "无待处理任务"}

        elif action == "completeTask":
            task_id = msg.get("taskId", "")
            store = msg.get("store", "")
            item_id = msg.get("itemId")
            error = msg.get("error")
            return complete_task(task_id, store, item_id, error)

        elif action == "getProgress":
            return get_progress()

        elif action == "readQueue":
            return read_task_queue()

        elif action == "writeQueue":
            write_task_queue(msg.get("data", {}))
            return {"ok": True}

        elif action == "readImagePool":
            return read_image_pool()

        elif action == "writeImagePool":
            write_image_pool(msg.get("data", {}))
            return {"ok": True}

        elif action == "readTemplates":
            return {"ok": True, "data": read_templates()}

        elif action == "writeTemplates":
            write_templates(msg.get("data", []))
            return {"ok": True}

        elif action == "readProjectConfigs":
            return {"ok": True, "data": read_project_configs()}

        elif action == "writeProjectConfigs":
            write_project_configs(msg.get("data", {}))
            return {"ok": True}

        elif action == "readDailyTasks":
            return {"ok": True, "data": read_daily_tasks(msg.get("store"))}

        elif action == "writeDailyTasks":
            write_daily_tasks(msg.get("data", {}), msg.get("store"))
            return {"ok": True}

        elif action == "writeImage":
            # 将 base64 图片写入磁盘
            path = msg.get("path", "")
            base64_data = msg.get("base64", "")
            if not path or not base64_data:
                return {"error": "缺少 path 或 base64 参数"}
            try:
                p = Path(path)
                p.parent.mkdir(parents=True, exist_ok=True)
                data = base64.b64decode(base64_data)
                with open(p, "wb") as f:
                    f.write(data)
                return {"ok": True, "path": str(p.resolve()), "size": len(data)}
            except Exception as e:
                return {"error": f"写入失败: {e}"}

        elif action == "listImages":
            # 列出店铺图片目录里的图片（用于把「已写盘但发布台列表里没有」的图扫回来）
            folder = msg.get("folder", "")
            if not folder:
                return {"error": "缺少 folder 参数"}
            exts = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}
            out = []
            try:
                d = Path(folder)
                if d.exists() and d.is_dir():
                    for f in d.iterdir():
                        if not f.is_file() or f.suffix.lower() not in exts:
                            continue
                        # 副图（副图N / 0副图N）是发布素材，不算底图，跳过
                        if f.stem.startswith("副图") or f.stem.startswith("0副图"):
                            continue
                        st = f.stat()
                        out.append({"name": f.name, "size": st.st_size, "mtime": st.st_mtime})
            except Exception as e:
                return {"error": "读取目录失败: %s" % e}
            out.sort(key=lambda x: x["mtime"])
            return {"ok": True, "folder": folder, "files": out}

        elif action == "uploadToMtop":
            # 通过 Python HTTP 上传图片到闲鱼 mtop（绕过浏览器 CORS）
            base64_data = msg.get("base64", "")
            cookies = msg.get("cookies", "")
            return upload_to_mtop(base64_data, cookies)

        elif action == "pickFile":
            # 用 tkinter 弹出文件选择框
            try:
                import tkinter as tk
                from tkinter import filedialog

                root = tk.Tk()
                root.withdraw()
                root.attributes("-topmost", True)

                filetypes = msg.get("filetypes", [])
                if filetypes:
                    ft = [(d, p) for d, p in filetypes]
                else:
                    ft = [("Excel files", "*.xlsx *.xls"), ("All files", "*.*")]

                path = filedialog.askopenfilename(
                    title=msg.get("title", "选择文件"), filetypes=ft
                )
                root.destroy()
                return {"path": path} if path else {"path": None, "message": "未选择文件"}
            except Exception as e:
                return {"error": f"文件选择失败: {e}"}

        elif action == "pickFiles":
            # 多选文件
            try:
                import tkinter as tk
                from tkinter import filedialog
                root = tk.Tk()
                root.withdraw()
                root.attributes("-topmost", True)
                filetypes = msg.get("filetypes", [])
                if filetypes:
                    ft = [(d, p) for d, p in filetypes]
                else:
                    ft = [("Image files", "*.jpg *.jpeg *.png *.gif *.webp"), ("All files", "*.*")]
                paths = filedialog.askopenfilenames(
                    title=msg.get("title", "选择多个文件"), filetypes=ft
                )
                root.destroy()
                return {"paths": list(paths)} if paths else {"paths": [], "message": "未选择文件"}
            except Exception as e:
                return {"error": f"文件选择失败: {e}"}

        else:
            return {"error": f"未知操作: {action}"}

    except Exception as e:
        return {"error": str(e), "traceback": traceback.format_exc()}


# ============ 主循环 ============
def main():
    # stderr 用于调试日志（不影响 stdout 的 Native Messaging 协议）
    sys.stderr.write("[native_host] 启动\n")
    sys.stderr.flush()

    while True:
        try:
            msg = read_message()
            if msg is None:
                break  # stdin 关闭
            sys.stderr.write(f"[native_host] 收到: {msg.get('action', '?')}\n")
            sys.stderr.flush()
            resp = handle_message(msg)
            send_message(resp)
        except json.JSONDecodeError as e:
            sys.stderr.write(f"[native_host] JSON 解析失败: {e}\n")
            sys.stderr.flush()
            send_message({"error": f"JSON 解析失败: {e}"})
        except Exception as e:
            sys.stderr.write(f"[native_host] 异常: {traceback.format_exc()}\n")
            sys.stderr.flush()
            try:
                send_message({"error": str(e)})
            except Exception:
                break

    sys.stderr.write("[native_host] 退出\n")
    sys.stderr.flush()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--file', help='从文件读取输入（单次模式，用于本地服务调用）')
    args = parser.parse_args()
    if args.file:
        # 单次模式：从文件读取一条消息，处理后输出到 stdout
        with open(args.file, 'rb') as f:
            raw_len = f.read(4)
            if len(raw_len) < 4:
                sys.exit(1)
            msg_len = struct.unpack('@I', raw_len)[0]
            raw_msg = f.read(msg_len)
            msg = json.loads(raw_msg.decode('utf-8'))
        resp = handle_message(msg)
        send_message(resp)
    else:
        main()
