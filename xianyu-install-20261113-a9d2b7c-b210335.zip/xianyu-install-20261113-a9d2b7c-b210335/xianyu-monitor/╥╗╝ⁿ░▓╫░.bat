@echo off
chcp 65001 >nul
echo ============================
echo   闲鱼项目 - 一键安装
echo ============================
echo.

:: 检查 Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [X] 未检测到 Node.js，请先安装：https://nodejs.org （选 18 以上版本）
    pause
    exit /b 1
)
echo [OK] Node.js 已安装

:: 检查 Git
where git >nul 2>&1
if %errorlevel% neq 0 (
    echo [X] 未检测到 Git，请先安装：https://git-scm.com
    pause
    exit /b 1
)
echo [OK] Git 已安装
echo.

:: 拉取闲鱼监控插件（含控制台脚本）
if not exist "xianyu-monitor" (
    echo [1/3] 拉取闲鱼监控插件...
    git clone https://gitlab.com/hym-company/xianyu-monitor.git
) else (
    echo [1/3] xianyu-monitor 已存在，跳过
)

:: 拉取 Playwright 服务
if not exist "xianyu-playwright-service" (
    echo [2/3] 拉取 Playwright 服务...
    git clone https://gitlab.com/hym-company/xianyu-playwright-service.git
) else (
    echo [2/3] xianyu-playwright-service 已存在，跳过
)

:: 安装依赖
echo [3/3] 安装 Playwright 依赖...
cd xianyu-playwright-service
call npm install
cd ..

:: 安装 museav-cli CLI
echo.
echo [额外] 安装出图工具 museav-cli...
call npm install -g museav-cli

echo.
echo ============================
echo   安装完成！
echo ============================
echo.
echo 接下来：
echo   1. Chrome 打开 chrome://extensions，开启「开发者模式」
echo   2. 点「加载已解压的扩展程序」，选 xianyu-monitor 文件夹
echo   3. 双击 xianyu-playwright-service\start.bat 启动服务
echo   4. 控制台脚本在 xianyu-monitor\console-tools\ 里
echo.
pause
