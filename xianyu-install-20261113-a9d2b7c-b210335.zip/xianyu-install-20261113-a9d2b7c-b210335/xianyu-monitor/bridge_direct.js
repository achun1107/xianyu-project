﻿// Bridge 替代版：不依赖 Chrome 扩展后台，直接调本地 API
(function() {
    'use strict';
    if (window.__kunBridgeReady) return;
    window.__kunBridgeReady = true;
    document.documentElement.dataset.kunBridgeDirect = '1';
    console.log('🔌 Bridge (直连版) 已加载');

    const API_KEY = '';
    // 本地服务端口可能因启动方式不同而变化（start.bat=8094 / 默认=8093），自动探测避免写死导致 ERR_CONNECTION_REFUSED
    const LOCAL_APIS = ['http://127.0.0.1:8093', 'http://127.0.0.1:8094'];
    let __localApi = null; // 探测成功后的固定根
    const REMOTE_API = 'https://manager.hympro.cn/api';

    async function apiFetch(url, opts = {}) {
        const resp = await fetch(url, {
            headers: { 'X-API-Key': API_KEY, 'Content-Type': 'application/json', ...opts.headers },
            ...opts
        });
        return resp.json();
    }

    // localFetch：自动在候选端口间探测并记住可用的那个
    async function localFetch(path, opts = {}) {
        const roots = __localApi ? [__localApi].concat(LOCAL_APIS) : LOCAL_APIS;
        let lastErr = null;
        for (const root of roots) {
            try {
                const r = await apiFetch(root + path, opts);
                __localApi = root;
                return r;
            } catch (e) { lastErr = e; __localApi = null; }
        }
        throw lastErr || new Error('本地服务不可达');
    }

    // 处理 MAIN 世界发来的消息
    window.addEventListener('message', async (event) => {
        if (!event.data || !event.data.type) return;

        const msg = event.data;

        // 同步数据到后台
        if (msg.type === 'SYNC_XIANYU_DATA') {
            try {
                const result = await localFetch('/api/agent/sync', {
                    method: 'POST',
                    body: JSON.stringify({ campaigns: msg.payload })
                });
                window.postMessage({ type: 'SYNC_XIANYU_RESULT', success: result.ok, message: result.message || 'OK' }, '*');
            } catch(e) {
                window.postMessage({ type: 'SYNC_XIANYU_RESULT', success: false, message: e.message }, '*');
            }
        }

        // 拉取账户列表
        if (msg.type === 'FETCH_ACCOUNTS' || msg.type === 'FETCH_XIANYU_ACCOUNTS') {
            try {
                const result = await apiFetch(REMOTE_API + '/xianyu-accounts');
                window.postMessage({
                    type: 'FETCH_ACCOUNTS_RESULT',
                    data: result.data || []
                }, '*');
                window.postMessage({
                    type: 'FETCH_XIANYU_ACCOUNTS_RESULT',
                    success: true,
                    data: result.data || []
                }, '*');
            } catch(e) {
                window.postMessage({ type: 'FETCH_ACCOUNTS_RESULT', data: [] }, '*');
                window.postMessage({ type: 'FETCH_XIANYU_ACCOUNTS_RESULT', success: false, message: e.message }, '*');
            }
        }

        // 查询 Agent 状态
        if (msg.type === 'AGENT_STATUS') {
            try {
                const result = await localFetch('/api/agent/status');
                window.postMessage({ type: 'AGENT_STATUS_RESULT', data: result.data || result }, '*');
            } catch(e) {
                window.postMessage({ type: 'AGENT_STATUS_RESULT', data: { running: false } }, '*');
            }
        }

        // 切换账号
        if (msg.type === 'AGENT_SWITCH') {
            try {
                const result = await localFetch('/api/agent/switch', {
                    method: 'POST',
                    body: JSON.stringify({ storeName: msg.storeName })
                });
                window.postMessage({ type: 'AGENT_SWITCH_RESULT', data: result }, '*');
            } catch(e) {
                window.postMessage({ type: 'AGENT_SWITCH_RESULT', data: { ok: false, error: e.message } }, '*');
            }
        }

        // 登录
        if (msg.type === 'AGENT_LOGIN') {
            try {
                const result = await localFetch('/api/agent/login', {
                    method: 'POST',
                    body: JSON.stringify({ accountId: msg.accountId })
                });
                window.postMessage({ type: 'AGENT_LOGIN_RESULT', data: result }, '*');
            } catch(e) {
                window.postMessage({ type: 'AGENT_LOGIN_RESULT', data: { ok: false, error: e.message } }, '*');
            }
        }

        // 保存 Cookie
        if (msg.type === 'SAVE_COOKIE') {
            try {
                await localFetch('/api/agent/save-cookie', { method: 'POST' });
                window.postMessage({ type: 'SAVE_COOKIE_RESULT', ok: true }, '*');
            } catch(e) {
                window.postMessage({ type: 'SAVE_COOKIE_RESULT', ok: false, error: e.message }, '*');
            }
        }

        // 加载 Cookie（Playwright 模式无需切换，返回失败避免刷新页面）
        if (msg.type === 'LOAD_COOKIE') {
            window.postMessage({ type: 'LOAD_COOKIE_RESULT', ok: false, error: 'Playwright模式，店铺已设为当前' }, '*');
        }

        // 打开操作台
        if (msg.type === 'OPEN_DASHBOARD') {
            window.open(chrome.runtime ? chrome.runtime.getURL('dashboard.html') : '', '_blank');
        }

        // 拉取已上报数据
        if (msg.type === 'FETCH_REPORTED_DATA') {
            try {
                const qs = new URLSearchParams({ limit: msg.limit || 50 }).toString();
                const result = await apiFetch(REMOTE_API + '/xianyu-reported?' + qs);
                window.postMessage({
                    type: 'FETCH_REPORTED_DATA_RESULT',
                    success: true,
                    data: result.data || [],
                    summary: result.summary || {}
                }, '*');
            } catch(e) {
                window.postMessage({ type: 'FETCH_REPORTED_DATA_RESULT', success: false, message: e.message }, '*');
            }
        }

        // ===== Native Host 消息（文件选择 / 图片读取 / 队列 / Excel） =====
        if (msg.type === 'NATIVE_HOST') {
            const reqId = msg.requestId;
            const payload = msg.payload || {};

            // pickFile / pickFiles → 用浏览器 file input
            if (payload.action === 'pickFile' || payload.action === 'pickFiles') {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = (payload.filetypes || []).map(f => f[1]).join(',') || 'image/*';
                if (payload.action === 'pickFiles') input.multiple = true;
                input.style.display = 'none';
                document.body.appendChild(input);
                input.onchange = function() {
                    input.remove();
                    if (payload.action === 'pickFiles') {
                        const paths = [];
                        for (let i = 0; i < input.files.length; i++) paths.push(input.files[i].name);
                        window.postMessage({ type: 'NATIVE_HOST_RESULT', requestId: reqId, success: true, data: { paths } }, '*');
                    } else {
                        window.postMessage({ type: 'NATIVE_HOST_RESULT', requestId: reqId, success: true, data: { path: input.files[0]?.name || '' } }, '*');
                    }
                };
                input.oncancel = function() {
                    input.remove();
                    window.postMessage({ type: 'NATIVE_HOST_RESULT', requestId: reqId, success: true, data: { path: '' } }, '*');
                };
                input.click();
                return;
            }

            // 其他 action → 转发到本地服务端
            try {
                const result = await localFetch('/api/agent/native-host', {
                    method: 'POST',
                    body: JSON.stringify(payload)
                });
                window.postMessage({ type: 'NATIVE_HOST_RESULT', requestId: reqId, success: result.ok, data: result.data, error: result.error }, '*');
            } catch(e) {
                window.postMessage({ type: 'NATIVE_HOST_RESULT', requestId: reqId, success: false, error: e.message }, '*');
            }
        }
    });

    // 定期同步 chrome.storage → localStorage（没有扩展就不做）
    console.log('🔌 Bridge (直连版) 已就绪');
})();
