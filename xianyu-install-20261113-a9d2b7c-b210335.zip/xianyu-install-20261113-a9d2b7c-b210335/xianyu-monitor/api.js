// API 客户端 — 统一管理对 hym-admin 后台的 HTTP 请求
// 通过 importScripts 加载，暴露为全局 xianyuApi
const xianyuApi = (() => {
  const BASE = 'https://manager.hympro.cn/api';
  const KEY = '';

  return {
    KEY,
    /** POST 上报推广数据 */
    async ingest(campaigns) {
      const resp = await fetch(`${BASE}/xianyu-ingest`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-Key': KEY },
        body: JSON.stringify({ campaigns })
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || data.message || `HTTP ${resp.status}`);
      return data;
    },
    /** GET 拉取已上报数据 */
    async reported(params = {}) {
      const qs = new URLSearchParams({ limit: params.limit || 50, ...params }).toString();
      const resp = await fetch(`${BASE}/xianyu-reported?${qs}`, {
        headers: { 'X-API-Key': KEY }
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
      return data;
    },
    /** GET 拉取闲鱼账户列表（含 username/password，用于自动登录） */
    async fetchAccounts() {
      const resp = await fetch(`${BASE}/xianyu-accounts`, {
        headers: { 'X-API-Key': KEY }
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
      return data.data || [];
    },
  };
})();
