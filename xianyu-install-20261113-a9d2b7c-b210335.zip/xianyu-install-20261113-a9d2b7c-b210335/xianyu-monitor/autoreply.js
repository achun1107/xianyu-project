// 闲鱼自动回复 - API检测 + DOM发送
// v2：支持 店铺/全局 关键词→默认 两级回复配置（kun_reply_rules[_店名]）
//     无配置时行为与旧版完全一致（内置默认话术回复所有未读会话）
(function() {
    'use strict';
    if (document.getElementById('kun-autoreply-btn')) return;

    const DEFAULT_REPLY = '亲，你好！我现在不在，看到消息会第一时间回复你。可以先拍，我看到后改下0.01，拍完后发你详情';
    const KEY = 'kun_replied_sessions';
    const CUR_STORE_KEY = 'kun_cur_store';
    const REPLY_CFG_PREFIX = 'kun_reply_rules_';
    const GLOBAL_REPLY_CFG = 'kun_reply_rules';

    function getReplied() { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch(e) { return []; } }
    function addReplied(id) { const list = getReplied(); if (!list.includes(id)) { list.push(id); localStorage.setItem(KEY, JSON.stringify(list)); } }

    // 读取回复配置：当前店铺配置 > 全局配置 > 默认
    function getReplyConfig() {
        let cfg = null;
        try {
            const store = localStorage.getItem(CUR_STORE_KEY) || '';
            const raw = localStorage.getItem(REPLY_CFG_PREFIX + (store || 'default')) || localStorage.getItem(GLOBAL_REPLY_CFG);
            if (raw) cfg = JSON.parse(raw);
        } catch(e) {}
        if (!cfg || typeof cfg !== 'object') cfg = {};
        return cfg;
    }

    // 取会话最后一条消息文本（防御性探测多个字段）
    function getLastMessageText(s) {
        const m = s.message || {};
        const cands = [
            m.summary && (m.summary.summaryText || m.summary.text || m.summary.content),
            m.latestMessage && (m.latestMessage.content || m.latestMessage.text),
            m.lastMessage && (m.lastMessage.content || m.lastMessage.text),
            s.session && s.session.lastMessage && (s.session.lastMessage.content || s.session.lastMessage.text)
        ];
        for (const c of cands) { if (typeof c === 'string' && c.trim()) return c.trim(); }
        return '';
    }

    // 关键词匹配：支持 /正则/ 或普通子串（不区分大小写）
    function matchKeyword(text, kw) {
        if (!text) return false;
        kw = String(kw).trim();
        if (!kw) return false;
        if (kw.startsWith('/') && kw.lastIndexOf('/') > 0) {
            try {
                const last = kw.lastIndexOf('/');
                const re = new RegExp(kw.slice(1, last), kw.slice(last + 1) || 'i');
                return re.test(text);
            } catch(e) { return text.includes(kw); }
        }
        return text.toLowerCase().includes(kw.toLowerCase());
    }

    // 选择回复：首个命中规则 > 默认回复 > 内置默认
    function pickReply(text, cfg) {
        const rules = Array.isArray(cfg.rules) ? cfg.rules : [];
        for (const r of rules) {
            if (!r || !Array.isArray(r.keywords) || !r.keywords.length) continue;
            if (r.keywords.some(k => matchKeyword(text, k))) {
                const hit = String(r.reply || '').trim();
                if (hit) return hit;
            }
        }
        const def = String(cfg.defaultReply || '').trim();
        return def || DEFAULT_REPLY;
    }

    async function sendViaDOM(text) {
        const input = document.querySelector('textarea, [contenteditable="true"]');
        if (!input) throw new Error('no input');
        var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        setter.call(input, text);
        input.dispatchEvent(new Event('input', { bubbles: true }));
        await new Promise(r => setTimeout(r, 500));
        var btns = document.querySelectorAll('button');
        for (var b of btns) {
            if (b.textContent?.trim() === '发送') { b.click(); return; }
        }
        input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
    }

    async function checkAndReply() {
        try {
            if (!window.lib?.mtop?.request) return;
            const cfg = getReplyConfig();
            if (cfg.enabled === false) return; // 配置里关闭了自动回复
            const r = await window.lib.mtop.request({ api: 'mtop.taobao.idlemessage.pc.session.sync', v: '3.0', data: { fetchNum: 20 } });
            if (!r?.data?.sessions) return;
            const replied = getReplied();

            for (const s of r.data.sessions) {
                const id = s.session?.sessionId;
                const type = s.session?.sessionType;
                const unread = parseInt(s.message?.summary?.unread || '0');
                if (!id || replied.includes(id)) continue;
                if (type === '62' || type === '6' || type === '10') continue; // 系统消息
                if (unread === 0) continue; // 没有未读不回复

                try {
                    // 尝试多种方式点击会话
                    let el = document.querySelector(`[data-session-id="${id}"]`);
                    if (!el) {
                        // 通过文本内容找会话
                        const name = s.session?.ownerInfo?.fishNick || s.session?.userInfo?.nick;
                        if (name) {
                            const allItems = document.querySelectorAll('[class*="session"], [class*="Session"], [class*="list"] > div, li');
                            for (const item of allItems) {
                                if (item.textContent?.includes(name) && item.offsetParent !== null) {
                                    el = item; break;
                                }
                            }
                        }
                    }
                    if (!el) continue; // 实在找不到就跳过

                    const text = getLastMessageText(s);
                    const reply = pickReply(text, cfg);
                    if (!reply) continue;

                    el.click();
                    await new Promise(r => setTimeout(r, 1200));
                    await sendViaDOM(reply);
                    addReplied(id);
                    console.log('✅ 已回复:', s.session?.ownerInfo?.fishNick || id, text ? ('| 消息:「' + text.slice(0, 20) + '」') : '');
                } catch(e2) {
                    console.log('❌ 发送失败:', e2?.message);
                }
            }
        } catch(e) {
            console.log('⚠️', e?.ret?.[0] || e?.message);
        }
    }

    const btn = document.createElement('div');
    btn.id = 'kun-autoreply-btn';
    btn.textContent = '💬 自动回复';
    btn.style.cssText = 'position:fixed;bottom:140px;right:12px;z-index:99999;background:#27ae60;color:#fff;padding:10px 16px;border-radius:50px;font-size:13px;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.3);font-family:system-ui,sans-serif;font-weight:500;user-select:none;';

    let timer = null;
    btn.onclick = function() {
        if (timer) { clearInterval(timer); timer = null; btn.textContent = '💬 自动回复'; btn.style.background = '#27ae60'; return; }
        btn.textContent = '⏳ 运行中'; btn.style.background = '#e74c3c';
        checkAndReply();
        timer = setInterval(checkAndReply, 12000);
    };

    const wait = setInterval(() => {
        if (document.body && !document.getElementById('kun-autoreply-btn')) {
            clearInterval(wait);
            document.body.appendChild(btn);
            console.log('💬 自动回复已加载');
        }
    }, 1000);
})();
