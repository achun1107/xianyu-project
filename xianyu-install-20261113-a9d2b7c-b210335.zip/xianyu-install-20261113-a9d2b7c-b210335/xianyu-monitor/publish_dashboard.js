// 闲鱼发布台 v2 - 基于 localhost 服务，不依赖扩展 API
(function() {
    'use strict';

    // [FIX] file:// 直开时 window.location.origin 是字符串 "null"(truthy)，不能当 API 根。
    // 按优先级选可用后端：当前源(若有效) → 8093(服务实跑端口) → 8094(旧端口兜底)；api() 会顺序尝试并记住可用的那个。
    var __apiRoots = (function () {
        var o = window.location.origin;
        if (window.location.protocol === 'file:' || !o || o === 'null' || o === 'file://') o = null;
        var roots = [];
        if (o) roots.push(o);
        roots.push('http://localhost:8093', 'http://localhost:8094');
        var seen = {};
        return roots.filter(function (r) { if (seen[r]) return false; seen[r] = 1; return true; });
    })();
    var __apiRootIdx = 0;
    var API = __apiRoots[0];
    var KEY = '';
    var REMOTE_API = 'https://manager.hympro.cn/api';

    // ===== 状态 =====
    var state = {
        accounts: [],       // 从服务拉取的账号列表
        currentStore: '',   // 当前编辑模板的店铺
        selectedStores: [], // 勾选要发布的店铺
        templates: [
            { id: 1, name: '模板1', price: '50', stock: '9999', categoryName: '代购' },
            { id: 2, name: '模板2', price: '50', stock: '9999', categoryName: '代购' }
        ],
        activeTemplateId: 1,
        images: [],         // { name, base64, url, uploading }
        tasks: [],          // { star, city, eventType, sessionType, categoryName, price, stock, imageName }
        publishing: false
    };

    // 出图工坊精简模式的店铺（只显示 ①输入 ②来源 ③文字层模板 ④生成海报，隐藏借调性/首开模板/高级工具）
    // 暂清空：让「文字层模板」和「版式」都显示（好易美代拍也显示 wshExtra）
    var SIMPLIFIED_WORKSHOP_STORES = [];
    function applyWorkshopVisibility() {
        var e = $('wshExtra');
        if (!e) return;
        var simplified = SIMPLIFIED_WORKSHOP_STORES.indexOf(state.currentStore) >= 0;
        e.style.display = simplified ? 'none' : '';
    }

    var $ = function(id) { return document.getElementById(id); };

    // ===== API 封装 =====
    async function api(path, body) {
        var opts = {
            method: body ? 'POST' : 'GET',
            headers: { 'Content-Type': 'application/json', 'X-API-Key': KEY }
        };
        if (body) opts.body = JSON.stringify(body);
        // P1-8：180s 超时 + 非 2xx 抛错；超时足够覆盖搜索/AI 长生成
        var ctrl = new AbortController();
        opts.signal = ctrl.signal;
        var timer = setTimeout(function() { ctrl.abort(); }, 180000);
        try {
            var lastErr = null, root = null, res = null;
            for (var i = 0; i < __apiRoots.length; i++) {
                root = __apiRoots[(i + __apiRootIdx) % __apiRoots.length];
                try {
                    res = await fetch(root + path, opts);
                    if (!res.ok) throw { __http: res.status };
                    __apiRootIdx = __apiRoots.indexOf(root);
                    return await res.json();
                } catch (e) {
                    if (e && e.__http) throw new Error('HTTP ' + e.__http); // 后端可达但返回非2xx，不换后端
                    lastErr = e; // 网络/超时错误，尝试下一个后端
                }
            }
            throw lastErr;
        } finally {
            clearTimeout(timer);
        }
    }

    async function nativeHost(payload) {
        var r = await api('/api/agent/native-host', payload);
        if (r.ok && r.data) return r.data;
        if (r.ok) return {};
        throw new Error(r.error || 'native host error');
    }

    async function evalOnStore(store, code) {
        var r = await api('/api/agent/eval-on-store', { store: store, code: code });
        return r;
    }
    // 把指定店铺的页面提到浏览器前台，避免后台 tab 被 Chromium 强节流拖慢发布
    async function bringStoreToFront(store) {
        try { await api('/api/agent/show-store', { name: store }); } catch(e) {}
    }

    // ===== 店铺选择持久化（刷新后不丢「底图管理 / 任务列表」）=====
    // 根因：state.currentStore / state.selectedStores 只在「🏪 店铺」勾选框里赋值，
    // 没有任何恢复逻辑。刷新页面后 currentStore 为空 → loadStoreData() 走
    // 「清空 tasks/images」分支 → 底图管理显示 0 张、任务列表空白（图其实还在磁盘上）。
    var SELECTED_STORES_KEY = 'kun_dash_selected_stores';
    function loadSelectedStores() {
        try {
            var v = JSON.parse(localStorage.getItem(SELECTED_STORES_KEY) || 'null');
            if (v && Array.isArray(v.stores)) {
                state.selectedStores = v.stores;
                state.currentStore = v.current || v.stores[0] || '';
            }
        } catch(e) {}
    }
    function saveSelectedStores() {
        try {
            localStorage.setItem(SELECTED_STORES_KEY, JSON.stringify({
                stores: state.selectedStores,
                current: state.currentStore || ''
            }));
        } catch(e) {}
    }

    // ===== 初始化 =====
    async function init() {
        loadSelectedStores();  // 必须在 loadAccounts 之前：renderStoreSelector 要按它勾选
        await loadAccounts();
        // 账号列表里已不存在的店铺（改名/停用）要从恢复结果里剔掉
        state.selectedStores = state.selectedStores.filter(function(s) {
            return state.accounts.some(function(a) { return a.name === s; });
        });
        if (state.currentStore && !state.selectedStores.length) state.selectedStores = [state.currentStore];
        if (state.currentStore && state.selectedStores.indexOf(state.currentStore) < 0) {
            state.currentStore = state.selectedStores[0] || '';
        }
        bindEvents();
        renderStoreSelector();
        renderTemplates();
        loadSettings();
        updatePolishVisibility();
        // 不自动选中任何店铺（owner 2026-09-17 明确要求）：
        // 原先这里有两级兜底 —— ① 从 kun_dash_data_<店> 反推、② 落到 accounts[0]
        // （账号接口返回的第一个，实际恒为「好易美代拍」）。两者都会让发布台一打开
        // 就停在一家**用户没有主动选过**的店铺上，底图/任务列表随之显示该店数据，
        // 极易在非目标店铺上误发。
        // 现在只认 kun_dash_selected_stores 里记住的选择（loadSelectedStores）；
        // 没有记住就保持空选，由用户从右上角「🏪 店铺」显式勾选。
        if (!state.currentStore && state.accounts.length > 0) {
            addLog('ℹ 未记住上次店铺，已保持空选（不再自动选中任何店铺）', 'info');
            addLog('💡 请点右上角「🏪 店铺」勾选目标店铺，勾选后会自动记住', 'dim');
        }
        if (state.selectedStores.length !== 0) renderStoreSelector(); // 兜底改过勾选，同步复选框
        // 恢复上次的当前店铺：把底图管理缩略图 / 任务列表重新读出来
        if (state.currentStore) {
            addLog('🔄 已恢复上次店铺：' + state.currentStore + '（底图与任务已重新载入）', 'info');
            checkStoreReady(state.currentStore);
            loadStoreData();
            loadStoreCfgPanel();
        } else {
            // 无店铺时保持空态：清掉可能残留的上一份数据，避免"看着有内容、其实没选店"
            state.tasks = [];
            state.images = [];
            renderImages();
            renderTasks();
            updateScrapeCard();
            if (state.accounts.length === 0) {
                addLog('❌ 没有可用店铺：8093 未启动或账号列表为空，底图/任务无法显示', 'err');
            } else {
                addLog('ℹ 尚未选择店铺 —— 底图与任务列表为空态，选店后自动载入', 'info');
            }
        }
        updatePublishButtons();
        addLog('🚀 发布台已就绪', 'info');
        addLog('💡 提示：先确保 Playwright 服务运行中，且目标店铺已启动', 'dim');
    }

    async function loadAccounts() {
        try {
            var r = await api('/api/agent/accounts');
            if (r.ok && r.data) {
                state.accounts = r.data;
                renderStoreSelector();
                addLog('📋 已加载 ' + r.data.length + ' 个账号', 'info');
                return;
            }
        } catch(e) {
            addLog('⚠ 本地服务未连接，切换远程账号源...', 'warn');
        }
        // 本地 8093 未起 → 远程兜底拉账号列表
        try {
            var r2 = await fetch(REMOTE_API + '/xianyu-accounts', {
                headers: { 'Content-Type': 'application/json', 'X-API-Key': KEY }
            });
            var j = await r2.json();
            if (j.ok && j.data) {
                state.accounts = j.data;
                renderStoreSelector();
                addLog('📋 已加载 ' + j.data.length + ' 个账号（远程）', 'info');
            } else {
                addLog('⚠ 远程也未获取到账号', 'warn');
            }
        } catch(e2) {
            addLog('❌ 本地与远程均连接失败: ' + e2.message, 'err');
        }
    }

    // ===== 事件绑定 =====
    function bindEvents() {
        // 店铺面板切换
        $('hdStoreBtn').onclick = function(e) {
            e.stopPropagation();
            var panel = $('hdStorePanel');
            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        };
        document.addEventListener('click', function(e) {
            if (!e.target.closest('#hdStorePanel') && !e.target.closest('#hdStoreBtn')) {
                $('hdStorePanel').style.display = 'none';
            }
        });

        $('btnRefreshStore').onclick = async function() {
            addLog('🔄 刷新账号列表...', 'info');
            await loadAccounts();
        };

        // 图片上传：拖拽 + 点击 + 选文件
        var zone = $('uploadZone');
        zone.onclick = function() { $('fileInput').click(); };
        zone.ondragover = function(e) { e.preventDefault(); zone.classList.add('drag-over'); };
        zone.ondragleave = function() { zone.classList.remove('drag-over'); };
        zone.ondrop = function(e) {
            e.preventDefault(); zone.classList.remove('drag-over');
            // 裂变图片拖拽（dataURL）
            var fissUrl = e.dataTransfer.getData('text/fission');
            if (fissUrl) {
                addFissionImage(fissUrl);
                return;
            }
            handleFiles(Array.prototype.slice.call(e.dataTransfer.files || []));
        };
        $('fileInput').onchange = function() {
            // ⚠ 坑：input.files 是「活」的 FileList，而 handleFiles 是 async（内部 await 读 base64 + 写盘）。
            // 旧写法 handleFiles(this.files); this.value=''; 会在第一次 await 之前就把 FileList 清空，
            // 导致「一次选 N 张，只进来第 1 张」。必须先快照成数组再清空。
            var _list = Array.prototype.slice.call(this.files || []);
            this.value = '';
            if (_list.length) handleFiles(_list);
        };

        $('btnClearImages').onclick = function() {
            state.images = [];
            renderImages();
        };

        // 🔍 自检：一键输出关键状态，排查「上传了却不显示 / 找不到副图入口」
        var _diagBtn = $('btnDashDiag');
        if (_diagBtn) _diagBtn.onclick = function() {
            var L = [];
            L.push('=== 发布台自检 ' + new Date().toLocaleString() + ' ===');
            L.push('当前店铺: ' + (state.currentStore ? state.currentStore : '(空 ← 底图/任务不显示多半就是它)'));
            L.push('已勾选店铺: ' + (state.selectedStores.length ? state.selectedStores.join('、') : '(无)'));
            L.push('账号列表: ' + (state.accounts.length ? state.accounts.map(function(a) { return a.name; }).join('、') : '(空 → 8093 服务可能没启动)'));
            L.push('底图 state.images: ' + state.images.length + ' 张');
            L.push('任务 state.tasks: ' + state.tasks.length + ' 个');
            L.push('界面显示: 底图 ' + (($('imageCount') || {}).textContent || '?') + ' / 任务 ' + (($('taskCount') || {}).textContent || '?'));
            var _lsKeys = [];
            try { for (var _i = 0; _i < localStorage.length; _i++) { var _k = localStorage.key(_i); if (_k && _k.indexOf('kun_') === 0) _lsKeys.push(_k); } } catch(e) {}
            L.push('localStorage(kun_*): ' + (_lsKeys.length ? _lsKeys.join(', ') : '(无)'));
            L.push('记住店铺的 key: ' + (localStorage.getItem('kun_dash_selected_stores') || '(无 → 说明没有持久化过店铺选择)'));
            var _d = null;
            if (state.currentStore) { try { _d = JSON.parse(localStorage.getItem('kun_dash_data_' + state.currentStore) || 'null'); } catch(e) {} }
            L.push('本地缓存 kun_dash_data_' + (state.currentStore || '?') + ': ' + (_d ? ('任务 ' + ((_d.tasks || []).length) + ' / 图 ' + ((_d.images || []).length) + ' ✓') : '(不存在 → 从未保存成功)'));
            L.push('副图上传按钮: ' + ($('iwSubImgBtn') ? '已找到' : '找不到(HTML 未更新?)'));
            L.push('图片工坊 imageWorkshop: ' + (($('imageWorkshop') && $('imageWorkshop').style.display !== 'none') ? '显示中' : '隐藏'));
            L.push('店铺配置 storeCfgCard: ' + ($('storeCfgCard') ? '存在' : '不存在'));
            L.push('=== 完 ===');
            for (var _j = 0; _j < L.length; _j++) addLog(L[_j], 'dim');
            alert(L.join('\n'));
        };

        // 📥 从磁盘恢复：上传其实已写盘，但发布台列表丢了时，一键扫回来
        var _scanBtn = $('btnScanImages');
        if (_scanBtn) _scanBtn.onclick = async function() {
            if (!state.currentStore) { alert('请先在右上角「🏪 店铺」勾选店铺'); return; }
            _scanBtn.disabled = true; _scanBtn.textContent = '📥 扫描中...';
            try {
                var _r = await nativeHost({ action: 'listImages', folder: getImagesFolder() });
                var _fs = (_r && _r.files) || [];
                if (!_fs.length) {
                    alert('目录里没有可恢复的图片：\n' + getImagesFolder());
                    return;
                }
                var _add = 0;
                for (var _si = 0; _si < _fs.length; _si++) {
                    var _nm = _fs[_si].name;
                    if (state.images.some(function(x) { return x.name === _nm; })) continue;
                    state.images.push({ name: _nm, saved: true });
                    _add++;
                }
                renderImages();
                autoCreateTasks();
                try { saveStoreData(); } catch(e) {} // 双保险：确保补回的图与新建任务落到 localStorage
                addLog('📥 扫描「' + getImagesFolder() + '」共 ' + _fs.length + ' 个文件，补回 ' + _add + ' 张底图', _add ? 'ok' : 'dim');
                if (!_add) alert('这 ' + _fs.length + ' 个文件都已经在底图列表里了');
            } catch(e) {
                alert('扫描失败: ' + e.message);
            } finally {
                _scanBtn.disabled = false; _scanBtn.textContent = '📥 从磁盘恢复';
            }
        };

        // 模板选择
        $('templateList').onclick = function(e) {
            var card = e.target.closest('.template-card');
            if (!card) return;
            state.activeTemplateId = parseInt(card.dataset.tid);
            renderTemplates();
        };

        // 任务
        $('btnAddTask').onclick = addTask;
        $('btnClearTasks').onclick = function() {
            state.tasks = [];
            renderTasks();
            try { saveStoreData(true); } catch(e){} // 整份覆盖，否则磁盘上的任务会被合并回来
        };
        var _btnClearDone = $('btnClearDone');
        if (_btnClearDone) _btnClearDone.onclick = function() {
            for (var i = 0; i < state.tasks.length; i++) { if (state.tasks[i].status === 'done' || state.tasks[i].status === 'failed') { delete state.tasks[i].status; delete state.tasks[i].itemId; delete state.tasks[i].error; } }
            renderTasks();
            // 整份覆盖：否则 native_host 合并时「保留带 itemId 的旧版本」会让重置失效
            try { saveStoreData(true); } catch(e){}
            addLog('🧹 已清已发/失败任务（重置为待发）', 'ok');
        };
        var _btnRemoveDone = $('btnRemoveDone');
        if (_btnRemoveDone) _btnRemoveDone.onclick = function() {
            if (!confirm('🧹 移除所有"已完成(✅)"任务？\n\n（仅从发布台任务列表移除，已上架的商品不受影响）')) return;
            state.tasks = state.tasks.filter(function(t) { return t.status !== 'done' && t.status !== 'failed'; });
            renderTasks();
            try { saveStoreData(true); } catch(e){} // 整份覆盖，真正从磁盘删掉
            addLog('🧹 已移除已完成/失败任务', 'ok');
        };


        // 店铺配置面板
        var _btnLoadCfg = $('btnLoadStoreCfg');
        if (_btnLoadCfg) _btnLoadCfg.onclick = loadStoreCfgPanel;
        var _btnSaveCfg = $('btnSaveStoreCfg');
        if (_btnSaveCfg) _btnSaveCfg.onclick = saveStoreCfgPanel;
        // 发布
        $('btnPublishAll').onclick = startPublish;
        $('btnStop').onclick = stopPublish;
        var _btnOne = $('btnPublishOne');
        if (_btnOne) _btnOne.onclick = publishCurrentStore;
        var _btnBatch = $('btnBatchPublish');
        if (_btnBatch) _btnBatch.onclick = batchPublishSelected;
        var _btnQuick = $('btnQuickPublish');
        if (_btnQuick) _btnQuick.onclick = quickPublishStore;
        // 任务列表视图开关：只看待发/按城市分组（IIFE 内绑定，自动渲染 + 记住勾选）
        loadTaskView();
        var _onlyPending = $('tOnlyPending');
        if (_onlyPending) _onlyPending.onchange = function() { renderTasks(); saveTaskView(); };
        var _byCity = $('tByCity');
        if (_byCity) _byCity.onchange = function() { renderTasks(); saveTaskView(); };
        var _autoPub = $('iwAutoPub');
        if (_autoPub) _autoPub.onchange = function() { saveTaskView(); };

        // ===== 搬运店铺 =====
        var _scrapeBtn = $('iwScrapeBtn');
        if (_scrapeBtn) _scrapeBtn.onclick = scrapeCurrentStore;

        // ===== 版式模板库（本地 poster-templates.json，用户自存；AI出图用） =====
        var _tplSel = $('iwPosterTpl');
        var _posterTplsCache = []; // 缓存完整版式（含 layers），供版本选择时按 id 查主标题文字层
        async function loadPosterTemplates() {
            try {
                // 本地版式（用户自己存的），不走中台
                var r = await api('/api/poster/templates');
                if (r.ok && r.items) {
                    _posterTplsCache = r.items;
                    var cur = _tplSel.value;
                    var html = '<option value="__shoukai">首开紫块样式（紫块+红字三行）</option>';
                    // 自存文字层版式（🖼 图片逆向/图生模板存的版式）
                    try { Object.keys(_iw.layerTpls || {}).forEach(function(n){ html += '<option value="__layer:' + esc(n) + '"' + (cur === '__layer:' + n ? ' selected' : '') + '>' + esc(n) + '</option>'; }); } catch(e){}
                    // 历史版式 id 不再混进下拉（shoukai-v1 已废弃改用 __shoukai、yikai-v1 已下线）；留着是防御，防止旧数据再冒出来
                    var _exclude = { 'shoukai-v1': 1, 'yikai-v1': 1 };
                    for (var i = 0; i < r.items.length; i++) {
                        if (_exclude[r.items[i].id]) continue;
                        html += '<option value="' + esc(r.items[i].id) + '"' + ((cur && cur === r.items[i].id) || (!cur && i === 0) ? ' selected' : '') + '>' + esc(r.items[i].name) + '</option>';
                    }
                    _tplSel.innerHTML = html || '<option value="">无版式（先存一个）</option>';
                    try { _renderGenStyles(); _renderStylePick(); } catch(e){} // 版式库加载完 → 批量出图下拉/挑款式也同步刷新
                }
            } catch(e) { try{ _tplSel.innerHTML = '<option value="">版式加载失败</option>'; }catch(_e){} addLog('⚠ 版式库加载失败: ' + (e && e.message ? e.message : e), 'warn'); }
        }
        if (_tplSel) loadPosterTemplates();
        // 副图库：上传自定义副图(1-8)到服务端，发布优先用；没有才用 副图N.jpg
        var _subBtn = $('iwSubImgBtn'), _subFile = $('iwSubImgFile'), _subBox = $('iwSubImgs'), _subTip = $('iwSubImgTip');
        function loadSubImgs() { if (!_subBox) return; api('/api/poster/sub-images').then(function(r) { if (r.ok && r.items) { _subBox.innerHTML = r.items.sort(function(a,b){ a=a.group||''; b=b.group||''; return 0; }).map(function(it){ return '<div style="position:relative;text-align:center;"><img src="' + API + it.url + '" style="width:56px;height:56px;object-fit:cover;border:1px solid #ddd;border-radius:6px;"><button data-i="' + it.index + '" data-g="' + esc(it.group || '') + '" class="subimg-del" style="position:absolute;top:-6px;right:-6px;background:#e74c3c;color:#fff;border:none;border-radius:50%;width:18px;height:18px;cursor:pointer;font-size:10px;line-height:18px;padding:0;">✕</button>' + (it.group ? '<div style="font-size:9px;color:#666;max-width:56px;overflow:hidden;">' + esc(it.group) + '</div>' : '') + '</div>'; }).join(''); _subBox.querySelectorAll('.subimg-del').forEach(function(b){ b.onclick = async function() { var idx = parseInt(this.getAttribute('data-i')); var grp = this.getAttribute('data-g') || ''; if (!isNaN(idx)) { await api('/api/poster/sub-image', { index: idx, b64: '', group: grp }); loadSubImgs(); } }; }); } else { _subBox.innerHTML = ''; } }).catch(function(){}); }
        if (_subBtn && _subFile) {
            _subBtn.onclick = function(){ _subFile.click(); };
            _subFile.onchange = function() {
                var files = [].slice.call(_subFile.files || []).slice(0, 8); if (!files.length) return;
                if (_subTip) _subTip.textContent = '上传中...';
                (async function() { var idx = 0, ok = 0; var _grp = ''; try { _grp = ($('iwSubImgGroup') ? $('iwSubImgGroup').value : '').trim(); } catch(_e){}; for (var f of files) { idx++; try { var b64 = await new Promise(function(res){ var fr = new FileReader(); fr.onload = function(){ res(String(fr.result)); }; fr.readAsDataURL(f); }); await api('/api/poster/sub-image', { index: idx, b64: b64, group: _grp }); ok++; } catch(e){} } if (_subTip) _subTip.textContent = '✅ 已传 ' + ok + ' 张' + (_grp ? '（分组 ' + _grp + '）' : ''); _subFile.value = ''; loadSubImgs(); })();
            };
        }
        if (_subBox) loadSubImgs();
        var _tplAddBtn = $('iwTplAdd');
        if (_tplAddBtn) _tplAddBtn.onclick = async function() {
            if (!_iw.sourceUrl) { addLog('⚠ 请先在高级工具 → 📁本地上传底图/📋粘贴底图，把版式图传上来', 'warn'); return; }
            var name = prompt('版式名称（如：徐良版式2）：');
            if (!name || !name.trim()) return;
            var desc = prompt('版式固定描述（{城市} {明星} 会自动替换）：\n例：顶部黄块写7级店铺、中央紫块写{城市}{明星}、底部黄横幅写命中率百分百：');
            if (!desc || !desc.trim()) return;
            try {
                var dataUrl = await _iwSourceToDataURL();
                var b64 = dataUrl.replace(/^data:image\/[^;]+;base64,/, '');
                var r = await api('/api/poster/templates', { name: name.trim(), prompt: desc.trim(), imageB64: b64, stickers: _iwStickerUrls() });
                if (r.ok) { addLog('✅ 版式「' + name.trim() + '」已保存', 'ok'); loadPosterTemplates(); }
                else addLog('❌ 保存失败: ' + (r.error || ''), 'err');
            } catch(e) { addLog('❌ ' + (e.message || e), 'err'); }
        };

        // ☁️ 共享版式到好易美后台中台版式库
        var _shareTplBtn = $('iwShareTpl');
        if (_shareTplBtn) _shareTplBtn.onclick = async function() {
            try {
                var _tplSel2 = $('iwPosterTpl');
                var selVal = _tplSel2 ? _tplSel2.value : '';
                var isRealId = selVal && selVal.indexOf('__') !== 0; // 非虚拟(__shoukai/__layer:)
                var body = null, label = '';

                if (isRealId) {
                    // 复用已存本地版式的底图+描述
                    label = selVal;
                    body = { id: selVal };
                } else if (_iw.sourceUrl) {
                    // 当前底图直接推：让用户填名称+描述
                    var nm = prompt('共享到好易美 — 版式名称（如：四横幅紫块）：');
                    if (!nm || !nm.trim()) return;
                    var ds = prompt('共享到好易美 — 版式固定描述（{城市} {明星} 会自动替换）：\n例：竖版{城市}{明星}演唱会海报，中央横幅写{城市}{明星}，顶部黄块写7级店铺：');
                    if (!ds || !ds.trim()) return;
                    var dataUrl = await _iwSourceToDataURL();
                    var b64 = dataUrl.replace(/^data:image\/[^;]+;base64,/, '');
                    label = nm.trim();
                    body = { name: nm.trim(), prompt: ds.trim(), imageB64: b64 };
                } else {
                    addLog('⚠ 请先在版式下拉里选一个已有版式，或在高级工具里传底图再共享', 'warn');
                    return;
                }

                if (body && body.id && !confirm('确认把本地版式「' + label + '」共享到好易美后台版式库？')) return;

                addLog('☁️ 正在把「' + (label || '') + '」共享到好易美后台...', 'info');
                var r = await api('/api/poster/share-to-hym', body);
                if (r.ok) {
                    addLog('✅ 已共享到好易美后台版式库: ' + (r.name || '') + ' (id=' + (r.id || '?') + ')', 'ok');
                } else if (r.duplicate) {
                    var nm2 = (r.existing && r.existing[0]) ? r.existing[0].name : (r.name || '');
                    var ok2 = confirm('⚠ 中台已存在同名版式「' + nm2 + '」，继续共享会生成一个重复项。\n仍要再共享一份吗？');
                    if (ok2) {
                        var body2 = Object.assign({}, body, { force: true });
                        addLog('☁️ 检测到同名，按你的确认强制共享「' + (label || '') + '」...', 'info');
                        var r2 = await api('/api/poster/share-to-hym', body2);
                        if (r2.ok) addLog('✅ 已共享到好易美后台版式库: ' + (r2.name || '') + ' (id=' + (r2.id || '?') + ')', 'ok');
                        else addLog('❌ 强制共享失败: ' + (r2.error || ''), 'err');
                    } else {
                        addLog('⏭ 已取消共享（中台已有同名版式「' + nm2 + '」）', 'warn');
                    }
                } else {
                    addLog('❌ 共享失败: ' + (r.error || ''), 'err');
                }
            } catch(e) { addLog('❌ ' + (e.message || e), 'err'); }
        };

        // 日志清空
        $('btnClearLog').onclick = function() {
            $('logBox').innerHTML = '<div class="dim">日志已清空</div>';
            var lb = $('logBoxLeft'); if (lb) lb.innerHTML = '<div class="dim">日志已清空</div>';
        };
        var _clrLeft = $('btnClearLogLeft');
        if (_clrLeft) _clrLeft.onclick = function() {
            $('logBoxLeft').innerHTML = '<div class="dim">日志已清空</div>';
            var rb = $('logBox'); if (rb) rb.innerHTML = '<div class="dim">日志已清空</div>';
        };


        // ===== 图片工坊 =====
        var _iw = { sourceUrl: '', sourceName: '', sources: [], resultUrls: [], resultMeta: [], layers: [], templates: {}, blockLayout: null, blockDirty: false, cands: [], candB64: '', candKey: '', stickerImgs: [] };
        // 解析输入行：「城市 明星 [场次/活动类型]」第三词智能识别，不填默认首开+演唱会
        var _SESSION_WORDS = ['首开', '一开', '二开', '三开', '捡漏回流', '回流', '开票'];
        var _EVENT_WORDS = ['演唱会', '音乐节', '话剧', '音乐剧', '见面会', '签售会', '脱口秀', '总决赛', '季后赛', '巡演', '电竞赛事', '体育赛事'];
        function _parseLine(line) {
            var parts = String(line || '').trim().split(/\s+/);
            var city = parts[0] || '';
            var star = '';
            var session = '首开';
            var event = '演唱会';
            var store = ''; // 行尾 @店名 → 指定发布到该店
            for (var pi = 1; pi < parts.length; pi++) {
                var w = parts[pi];
                if (w.charAt(0) === '@') { store = w.slice(1); continue; }
                if (_SESSION_WORDS.indexOf(w) >= 0) { session = w; continue; }
                if (_EVENT_WORDS.indexOf(w) >= 0) { event = w; continue; }
                if (!star) star = w; else star += ' ' + w; // 明星名带空格时合并
            }
            return { city: city, star: star, session: session, event: event, store: store };
        }
        // 加载模板预设（localStorage['kun_img_templates']，仅本发布台 localhost:8093 源可用；与 goofish 页不同源、不互通）—— S4 更正
        try { _iw.templates = JSON.parse(localStorage.getItem('kun_img_templates') || '{}'); } catch(e) {}
        function _iwSaveTemplates() { localStorage.setItem('kun_img_templates', JSON.stringify(_iw.templates)); _iwRenderTplSelect(); }
        function _iwRenderTplSelect() {
            var sel = $('iwTplSelect'); if (!sel) return;
            var cur = sel.value; sel.innerHTML = '<option value="">— 选择模板 —</option>';
            Object.keys(_iw.templates).forEach(function(k) {
                sel.innerHTML += '<option value="' + k + '"' + (cur === k ? ' selected' : '') + '>' + k + '</option>';
            });
            // 镜像下拉已随「生成最终图」按钮移除（统一版式后 🎨生成海报即最终图）
        }
        // 把当前底图转成 dataURL 才能持久化到 localStorage（blob: URL 重载后失效）
        function _iwSourceToDataURL() {
            return fetch(_iw.sourceUrl).then(function(r) { return r.blob(); }).then(function(b) {
                return new Promise(function(resolve, reject) {
                    var fr = new FileReader();
                    fr.onload = function() { resolve(fr.result); };
                    fr.onerror = function() { reject(new Error('底图转 base64 失败')); };
                    fr.readAsDataURL(b);
                });
            });
        }
        // 来源：本地上传（支持多选，多张底图进入缩略图条，点选切换当前底图）
        $('iwLocalUpload').onclick = function() { $('iwFileInput').click(); };
        $('iwFileInput').onchange = function() {
            if (!this.files || this.files.length === 0) return;
            for (var fi = 0; fi < this.files.length; fi++) {
                var file = this.files[fi];
                if (!file.type.startsWith('image/')) continue;
                (function(f) {
                    var reader = new FileReader();
                    reader.onload = function() {
                        var url = reader.result;
                        var name = f.name;
                        // 同名去重
                        var exists = _iw.sources.some(function(s) { return s.name === name; });
                        if (exists) return;
                        _iw.sources.push({ name: name, url: url });
                        if (!_iw.sourceUrl) _iwSetSource(name, url);
                        _iwRenderSources();
                        // P0-6：写盘持久化（刷新后从磁盘恢复），并记录文件名
                        var b64 = String(url).split(',')[1] || '';
                        if (b64) persistImage(name, b64);
                        try {
                            var wsKey = 'kun_ws_sources_' + (state.currentStore || 'default');
                            var names = JSON.parse(localStorage.getItem(wsKey) || '[]');
                            if (names.indexOf(name) < 0) { names.push(name); localStorage.setItem(wsKey, JSON.stringify(names)); }
                        } catch(e) {}
                    };
                    reader.readAsDataURL(f);
                })(file);
            }
            this.value = '';
        };
        function _iwSetSource(name, url) {
            _iw.sourceUrl = url; _iw.sourceName = name || '';
            $('iwSourcePreview').innerHTML = '<img src="' + url + '" style="max-width:280px;max-height:200px;border-radius:8px;border:2px solid #E67E22;">';
            $('iwSourcePreview').style.display = '';
        }
        function _iwRenderSources() {
            var list = $('iwSourceList'); if (!list) return;
            if (_iw.sources.length === 0) { list.innerHTML = ''; return; }
            var html = '';
            for (var i = 0; i < _iw.sources.length; i++) {
                var s = _iw.sources[i];
                var active = _iw.sourceUrl === s.url;
                html += '<div style="position:relative;border:' + (active ? '2px solid #E67E22' : '1px solid #ddd') + ';border-radius:6px;overflow:hidden;cursor:pointer;" title="' + esc(s.name) + '">' +
                    '<img src="' + s.url + '" data-src-idx="' + i + '" style="width:56px;height:56px;object-fit:cover;display:block;">' +
                    '<button data-src-del="' + i + '" style="position:absolute;top:0;right:0;background:rgba(0,0,0,0.6);color:#fff;border:none;border-radius:0 0 0 6px;font-size:10px;cursor:pointer;padding:1px 4px;">✕</button>' +
                    (active ? '<span style="position:absolute;bottom:0;left:0;right:0;background:rgba(231,126,34,0.85);color:#fff;font-size:9px;text-align:center;">当前</span>' : '') +
                '</div>';
            }
            list.innerHTML = html;
            list.style.display = 'flex';
            list.querySelectorAll('img[data-src-idx]').forEach(function(img) {
                img.onclick = function() { _iwSetSource(_iw.sources[parseInt(this.dataset.srcIdx)].name, _iw.sources[parseInt(this.dataset.srcIdx)].url); _iwRenderSources(); };
            });
            list.querySelectorAll('button[data-src-del]').forEach(function(btn) {
                btn.onclick = function() {
                    var idx = parseInt(this.dataset.srcDel);
                    var wasActive = _iw.sourceUrl === _iw.sources[idx].url;
                    _iw.sources.splice(idx, 1);
                    if (!_iw.sources.length) {
                        _iw.sourceUrl = ''; _iw.sourceName = '';
                        $('iwSourcePreview').style.display = 'none';
                    } else if (wasActive) {
                        var last = _iw.sources[_iw.sources.length - 1];
                        _iwSetSource(last.name, last.url);
                    }
                    _iwRenderSources();
                };
            });
        }
        // 📌 贴图库（中台贴纸/印花）：读 /api/poster/stickers，点选预加载进 _iw.stickerImgs 供 _iwApplyText 叠印
        function loadStickerLib() {
            var box = $('iwStickerLib'); if (!box) return;
            api('/api/poster/stickers').then(function(r) {
                var items = (r && r.ok && r.items) ? r.items : [];
                var cnt = $('iwStickerCount'); if (cnt) cnt.textContent = items.length ? (items.length + ' 张') : '';
                box.innerHTML = '';
                items.forEach(function(s) {
                    var img = document.createElement('img');
                    img.src = s.url; img.title = s.name || ''; img.crossOrigin = 'anonymous';
                    img.style.cssText = 'width:56px;height:56px;object-fit:contain;background:#fff;border:1px solid #ddd;border-radius:6px;cursor:pointer;';
                    img.onclick = function() {
                        var p = new Image(); p.crossOrigin = 'anonymous';
                        p.onload = function() { _iw.stickerImgs.push({ img: p, url: s.url, w: 0.22 }); addLog('📌 贴图已选: ' + (s.name || s.id), 'ok'); };
                        p.onerror = function() { addLog('⚠ 贴图加载失败(可能跨域限制): ' + (s.name || s.id), 'warn'); };
                        p.src = s.url;
                        img.style.border = '2px solid #4A90D9';
                    };
                    box.appendChild(img);
                });
                if (!items.length) box.innerHTML = '<span style="color:#999;font-size:10px;">无贴图</span>';
            }).catch(function(e) { box.innerHTML = '<span style="color:#999;font-size:10px;">贴图库加载失败</span>'; });
        }
        (function(){ var _sr = $('iwStickerReload'); if (_sr) _sr.onclick = loadStickerLib; loadStickerLib(); })();
        // 版式携带贴图：把当前 _iw.stickerImgs 序列化为 [{url,w}]，供存版式持久化
        function _iwStickerUrls() { return _iw.stickerImgs.map(function(s){ return { url: s.url, w: s.w || 0.22 }; }); }
        // 从 [{url,w,x,y}] 加载贴图到 _iw.stickerImgs（用于选中带贴图的版式时自动叠印）；返回 Promise，等所有贴图加载完
        function _iwLoadStickers(arr) {
            return new Promise(function(resolve) {
                _iw.stickerImgs = [];
                if (!arr || !arr.length) { resolve(); return; }
                var todo = arr.filter(function(st) { return st && st.url; });
                if (!todo.length) { resolve(); return; }
                var done = 0;
                todo.forEach(function(st) {
                    var p = new Image(); p.crossOrigin = 'anonymous';
                    p.onload = function() { _iw.stickerImgs.push({ img: p, url: st.url, w: st.w || 0.22, x: (st.x != null ? st.x : null), y: (st.y != null ? st.y : null) }); if (++done >= todo.length) resolve(); };
                    p.onerror = function() { if (++done >= todo.length) resolve(); };
                    // 相对路径('/'开头)基于 API 绝对地址，file:// 直开也正确
                    p.src = (st.url && st.url.indexOf('/') === 0) ? API + st.url : st.url;
                });
            });
        }
        // 刷新后从磁盘恢复工坊底图（按当前店铺；loadStoreData 切店时调用）
        window.__restoreWsSources = function() {
            if (_iw.sources.length > 0) return; // 已有底图不重复恢复
            try {
                var wsKey = 'kun_ws_sources_' + (state.currentStore || 'default');
                var names = JSON.parse(localStorage.getItem(wsKey) || '[]');
                if (!Array.isArray(names) || names.length === 0) return;
                var folder = getImagesFolder();
                Promise.all(names.map(function(nm) {
                    return nativeHost({ action: 'readImage', path: folder + nm }).then(function(r) {
                        if (r && r.base64) _iw.sources.push({ name: nm, url: 'data:' + (r.mime || 'image/jpeg') + ';base64,' + r.base64 });
                    }).catch(function() {});
                })).then(function() {
                    if (_iw.sources.length) {
                        _iwSetSource(_iw.sources[0].name, _iw.sources[0].url);
                        _iwRenderSources();
                        addLog('🖼 已从磁盘恢复工坊底图 ' + _iw.sources.length + ' 张', 'info');
                    }
                });
            } catch(e) {}
        };
        // 来源：AI 出图
        $('iwGenBtn').onclick = async function() {
            var prompt = ($('iwPrompt').value || '').trim();
            if (!prompt) { addLog('⚠ 请输入出图描述', 'warn'); return; }
            addLog('🤖 AI 出图中...', 'info');
            $('iwGenBtn').disabled = true;
            try {
                var r = await api('/api/agent/studio-gen', { prompt: prompt });
                if (r.ok && r.url) {
                    if (_iw.sourceUrl && _iw.sourceUrl.startsWith('blob:')) URL.revokeObjectURL(_iw.sourceUrl);
                    _iw.sourceUrl = r.url;
                    $('iwSourcePreview').innerHTML = '<img src="' + r.url + '" style="max-width:280px;max-height:200px;border-radius:8px;border:2px solid #E67E22;">';
                    $('iwSourcePreview').style.display = '';
                    addLog('✅ AI 出图完成', 'ok');
                } else { addLog('❌ 出图失败: ' + (r.error || ''), 'err'); }
            } catch(e) { addLog('❌ ' + e.message, 'err'); }
            $('iwGenBtn').disabled = false;
        };
        // 来源：图片逆向（当前网络底图 → prompt 填入出图描述）
        $('iwReverseBtn').onclick = async function() {
            var url = _iw.sourceUrl || '';
            if (!url) { addLog('⚠ 先有底图（AI生成/加载网络图），本地粘贴的图不支持逆向', 'warn'); return; }
            if (url.indexOf('http') !== 0) { addLog('⚠ 本地上传/粘贴的图无法逆向，需要网络图片（如AI生成的图）', 'warn'); return; }
            addLog('🔍 逆向中（约1分钟）...', 'info');
            $('iwReverseBtn').disabled = true;
            try {
                var r = await api('/api/agent/studio-reverse', { url: url });
                if (r.ok && r.prompt) {
                    $('iwPrompt').value = r.prompt;
                    addLog('✅ 逆向完成，已填入出图描述，可改后点生成', 'ok');
                } else { addLog('❌ 逆向失败: ' + (r.error || ''), 'err'); }
            } catch(e) { addLog('❌ ' + e.message, 'err'); }
            $('iwReverseBtn').disabled = false;
        };
        // 36 模板清单 + 模板生成
        async function loadStudioTemplates() {
            try {
                var r = await api('/api/studio/templates', null);
                if (r.ok && r.items && r.items.length > 0) {
                    var sel = $('iwTpl36');
                    sel.innerHTML = '<option value="">— 36模板（可选） —</option>';
                    r.items.forEach(function(t) {
                        sel.innerHTML += '<option value="' + t.id + '">' + t.name + '（' + t.ratio + '）</option>';
                    });
                    addLog('🎭 已加载 ' + r.items.length + ' 个出图模板', 'dim');
                } else if (r.error) { addLog('⚠ 模板清单: ' + r.error, 'warn'); }
            } catch(e) { addLog('⚠ 模板清单加载失败: ' + e.message, 'warn'); }
        }
        loadStudioTemplates();
        $('iwTplGenBtn').onclick = async function() {
            var tid = $('iwTpl36').value;
            if (!tid) { addLog('⚠ 先在下拉框选一个模板', 'warn'); return; }
            var fieldsStr = ($('iwTplFields') ? $('iwTplFields').value : '').trim();
            var fields = {};
            if (fieldsStr) {
                try { fields = JSON.parse(fieldsStr); } catch(e) { addLog('⚠ 字段格式不对，需 JSON 如 {"artist":"周杰伦"}，或留空', 'warn'); return; }
            }
            addLog('🎭 模板生成中（约1分钟）...', 'info');
            $('iwTplGenBtn').disabled = true;
            try {
                var r = await api('/api/studio/gen-template', { templateId: tid, fields: fields });
                if (r.ok && r.url) {
                    if (_iw.sourceUrl && _iw.sourceUrl.startsWith('blob:')) URL.revokeObjectURL(_iw.sourceUrl);
                    _iw.sourceUrl = r.url;
                    $('iwSourcePreview').innerHTML = '<img src="' + r.url + '" style="max-width:280px;max-height:200px;border-radius:8px;border:2px solid #E67E22;">';
                    $('iwSourcePreview').style.display = '';
                    addLog('✅ 模板生成完成，已设为底图', 'ok');
                } else { addLog('❌ ' + (r.error || '生成失败'), 'err'); }
            } catch(e) { addLog('❌ ' + e.message, 'err'); }
            $('iwTplGenBtn').disabled = false;
        };
        // 文字图层
        $('iwAddLayer').onclick = function() {
            _iw.layers.push(_normLayer({ text: '', pos: 'center', size: 48, color: '#ffffff' }));
            _iwRenderLayers();
        };
        // 层字段归一化（兼容旧模板缺字段）
        function _normLayer(l) {
            l = l || {};
            return {
                text: l.text || '', pos: l.pos || 'center', size: parseInt(l.size) || 48, color: l.color || '#ffffff',
                x: (l.x !== undefined && l.x !== '' && l.x !== null) ? parseFloat(l.x) : 50,
                y: (l.y !== undefined && l.y !== '' && l.y !== null) ? parseFloat(l.y) : '',
                align: l.align || 'center', weight: l.weight || 'bold',
                stroke: (l.stroke === undefined || l.stroke === null) ? true : !!l.stroke,
                opacity: (l.opacity === undefined || l.opacity === null) ? 100 : parseInt(l.opacity),
                bg: l.bg || '',
                fontFamily: l.fontFamily || '', bgAlpha: l.bgAlpha, strokeColor: l.strokeColor || '', bgRadius: l.bgRadius,
                rot: (l.rot !== undefined && l.rot !== null) ? parseFloat(l.rot) : 0,
                sizePct: (l.sizePct !== undefined && l.sizePct !== null) ? parseFloat(l.sizePct) : 0,
                strokeWidth: (l.strokeWidth !== undefined && l.strokeWidth !== null) ? parseFloat(l.strokeWidth) : 0
            };
        }
        function _iwRenderLayers() {
            var list = $('iwLayerList'); if (!list) return;
            list.style.display = _iw.layers.length > 0 ? '' : 'none';
            var html = '<div style="font-size:10px;color:#999;margin-bottom:2px;">文字层（占位符 {城市} {明星} {场次类型} {活动类型}；X%/Y% 相对整图位置，留空Y=按顶/中/底）</div>';
            for (var i = 0; i < _iw.layers.length; i++) {
                var l = _normLayer(_iw.layers[i]);
                _iw.layers[i] = l;
                html += '<div style="border:1px solid #eee;border-radius:6px;padding:4px 6px;margin-bottom:4px;">' +
                    '<div style="display:flex;gap:4px;align-items:center;margin-bottom:3px;">' +
                        '<input class="iw-layer-text" data-idx="' + i + '" value="' + esc(l.text) + '" placeholder="文字(支持{城市}{明星})" style="flex:1;padding:4px;border:1px solid #ddd;border-radius:4px;font-size:11px;">' +
                        '<button class="iw-layer-del" data-idx="' + i + '" title="删除该层" style="background:#e74c3c;color:#fff;border:none;border-radius:4px;padding:2px 6px;cursor:pointer;font-size:10px;">✕</button>' +
                    '</div>' +
                    '<div style="display:flex;gap:4px;align-items:center;flex-wrap:wrap;">' +
                        '<select class="iw-layer-pos" data-idx="' + i + '" style="padding:3px;border:1px solid #ddd;border-radius:4px;font-size:10px;"><option value="top"' + (l.pos==='top'?' selected':'') + '>顶</option><option value="center"' + (l.pos==='center'?' selected':'') + '>中</option><option value="bottom"' + (l.pos==='bottom'?' selected':'') + '>底</option></select>' +
                        '<label style="font-size:9px;color:#999;">X%</label><input type="number" class="iw-layer-x" data-idx="' + i + '" value="' + l.x + '" style="width:38px;padding:3px;border:1px solid #ddd;border-radius:4px;font-size:10px;">' +
                        '<label style="font-size:9px;color:#999;">Y%</label><input type="number" class="iw-layer-y" data-idx="' + i + '" value="' + l.y + '" placeholder="自动" style="width:42px;padding:3px;border:1px solid #ddd;border-radius:4px;font-size:10px;">' +
                        '<select class="iw-layer-align" data-idx="' + i + '" style="padding:3px;border:1px solid #ddd;border-radius:4px;font-size:10px;"><option value="left"' + (l.align==='left'?' selected':'') + '>左</option><option value="center"' + (l.align==='center'?' selected':'') + '>中</option><option value="right"' + (l.align==='right'?' selected':'') + '>右</option></select>' +
                        '<input type="number" class="iw-layer-size" data-idx="' + i + '" value="' + l.size + '" title="字号" style="width:40px;padding:3px;border:1px solid #ddd;border-radius:4px;font-size:10px;">' +
                        '<input type="color" class="iw-layer-color" data-idx="' + i + '" value="' + l.color + '" title="颜色" style="width:22px;height:22px;border:1px solid #ddd;border-radius:4px;">' +
                        '<label style="font-size:9px;color:#999;"><input type="checkbox" class="iw-layer-weight" data-idx="' + i + '"' + (l.weight !== 'normal' ? ' checked' : '') + '>粗</label>' +
                        '<label style="font-size:9px;color:#999;"><input type="checkbox" class="iw-layer-stroke" data-idx="' + i + '"' + (l.stroke ? ' checked' : '') + '>描边</label>' +
                        '<label style="font-size:9px;color:#999;">透明</label><input type="number" class="iw-layer-opacity" data-idx="' + i + '" value="' + l.opacity + '" style="width:38px;padding:3px;border:1px solid #ddd;border-radius:4px;font-size:10px;">' +
                        '<input type="text" class="iw-layer-bg" data-idx="' + i + '" value="' + esc(l.bg) + '" placeholder="底条色(#000000)" title="文字底条颜色，留空无" style="width:70px;padding:3px;border:1px solid #ddd;border-radius:4px;font-size:10px;">' +
                    '</div>' +
                '</div>';
            }
            list.innerHTML = html;
            list.querySelectorAll('.iw-layer-text').forEach(function(el) { el.oninput = function() { _iw.layers[parseInt(this.dataset.idx)].text = this.value; }; });
            list.querySelectorAll('.iw-layer-pos').forEach(function(el) { el.onchange = function() { _iw.layers[parseInt(this.dataset.idx)].pos = this.value; }; });
            list.querySelectorAll('.iw-layer-x').forEach(function(el) { el.onchange = function() { _iw.layers[parseInt(this.dataset.idx)].x = parseFloat(this.value); }; });
            list.querySelectorAll('.iw-layer-y').forEach(function(el) { el.onchange = function() { var v = parseFloat(this.value); _iw.layers[parseInt(this.dataset.idx)].y = isNaN(v) ? '' : v; }; });
            list.querySelectorAll('.iw-layer-align').forEach(function(el) { el.onchange = function() { _iw.layers[parseInt(this.dataset.idx)].align = this.value; }; });
            list.querySelectorAll('.iw-layer-size').forEach(function(el) { el.onchange = function() { _iw.layers[parseInt(this.dataset.idx)].size = parseInt(this.value) || 48; }; });
            list.querySelectorAll('.iw-layer-color').forEach(function(el) { el.onchange = function() { _iw.layers[parseInt(this.dataset.idx)].color = this.value; }; });
            list.querySelectorAll('.iw-layer-weight').forEach(function(el) { el.onchange = function() { _iw.layers[parseInt(this.dataset.idx)].weight = this.checked ? 'bold' : 'normal'; }; });
            list.querySelectorAll('.iw-layer-stroke').forEach(function(el) { el.onchange = function() { _iw.layers[parseInt(this.dataset.idx)].stroke = this.checked; }; });
            list.querySelectorAll('.iw-layer-opacity').forEach(function(el) { el.onchange = function() { _iw.layers[parseInt(this.dataset.idx)].opacity = parseInt(this.value) || 100; }; });
            list.querySelectorAll('.iw-layer-bg').forEach(function(el) { el.oninput = function() { _iw.layers[parseInt(this.dataset.idx)].bg = this.value.trim(); }; });
            list.querySelectorAll('.iw-layer-del').forEach(function(el) { el.onclick = function() { _iw.layers.splice(parseInt(this.dataset.idx), 1); _iwRenderLayers(); }; });
        }
        // ===== 文字层模板库（独立于底图的排版预设，localStorage: kun_layer_templates）=====
        var _LAYER_TPL_LIB = {
            '① 明星居中大字（经典）': [
                { text: '{城市} · {活动类型}', pos: 'top', size: 38, color: '#ffd700' },
                { text: '{明星}', pos: 'center', size: 96, color: '#ffffff', bg: '#000000' },
                { text: '{场次类型} 全程代拍 · 先拍后改', pos: 'bottom', size: 32, color: '#ffd700' }
            ],
            '② 顶部横幅 + 底部标语': [
                { text: '★ {城市} {活动类型} 火热预约 ★', pos: 'top', size: 36, color: '#ffd700', bg: '#000000' },
                { text: '{明星}', pos: 'center', size: 110, color: '#ffffff', stroke: true },
                { text: '命中率百分百 · 7级店铺', pos: 'bottom', size: 34, color: '#ffffff', bg: '#d40000' }
            ],
            '③ 左下角标 + 底部信息条': [
                { text: '{明星}', pos: 'center', x: 35, y: 40, size: 80, color: '#ffffff', stroke: true },
                { text: '{城市} {场次类型}', pos: 'center', x: 35, y: 62, size: 40, color: '#ffd700' },
                { text: '{活动类型} · 抢手招募', pos: 'bottom', size: 32, color: '#ffffff', bg: '#000000' }
            ],
            '④ 简约单层（仅明星）': [
                { text: '{明星}', pos: 'center', size: 130, color: '#ffffff', stroke: true }
            ],
            '⑤ 双层堆叠（城市+明星）': [
                { text: '{城市}', pos: 'center', y: 38, size: 44, color: '#ffd700' },
                { text: '{明星}', pos: 'center', y: 62, size: 100, color: '#ffffff', stroke: true }
            ],
            '⑥ 全要素版': [
                { text: '{城市}', pos: 'top', size: 40, color: '#ffd700' },
                { text: '{明星}', pos: 'center', y: 40, size: 88, color: '#ffffff', stroke: true },
                { text: '{活动类型}', pos: 'center', y: 62, size: 44, color: '#ffd700' },
                { text: '{场次类型} · 秒出票', pos: 'bottom', size: 34, color: '#ffffff', bg: '#000000' }
            ],
            '⑦ 促销特价版': [
                { text: '🔥 {城市} {活动类型} 🔥', pos: 'top', size: 36, color: '#ff4500', stroke: true },
                { text: '{明星}', pos: 'center', y: 42, size: 92, color: '#ffffff', stroke: true },
                { text: '特价代拍 先拍后改 0.01', pos: 'bottom', size: 34, color: '#ffff00', bg: '#000000' }
            ],
            '⑧ 竖版角标（左）': [
                { text: '{明星}', pos: 'center', x: 26, y: 45, size: 70, color: '#ffffff', stroke: true, align: 'center' },
                { text: '{城市} · {场次类型}', pos: 'center', x: 26, y: 62, size: 34, color: '#ffd700', align: 'center' }
            ],
            '⑨ 刘宪华首开样式（紫块白字+红字三行·居中）': [
                { text: '{城市}{明星}', pos: 'center', y: 22, size: 120, color: '#ffffff', bg: '#E637F0', bgAlpha: 1, align: 'center', fontFamily: '"STZhongsong","Microsoft YaHei",sans-serif' },
                { text: '万人团队', pos: 'center', y: 42, size: 168, color: '#ff2020', weight: 'bold', stroke: true, strokeColor: '#ffffff', align: 'center', fontFamily: '"STZhongsong","Microsoft YaHei",sans-serif' },
                { text: '不中全额退', pos: 'center', y: 58, size: 168, color: '#ff2020', weight: 'bold', stroke: true, strokeColor: '#ffffff', align: 'center', fontFamily: '"STZhongsong","Microsoft YaHei",sans-serif' },
                { text: '战绩可查', pos: 'center', y: 74, size: 168, color: '#ff2020', weight: 'bold', stroke: true, strokeColor: '#ffffff', align: 'center', fontFamily: '"STZhongsong","Microsoft YaHei",sans-serif' }
            ],
            '⑩ 刘宪华一开样式（红横幅白字+红黄标语）': [
                { text: '{明星}', pos: 'top', y: 10, size: 60, color: '#ffffff', bg: '#cc0000', align: 'center' },
                { text: '{城市}{明星}', pos: 'center', y: 35, size: 180, color: '#ffffff', weight: 'bold', stroke: true, bg: '#cc0000', align: 'center' },
                { text: '找我有票', pos: 'center', y: 45, size: 180, color: '#ff0000', weight: 'bold', align: 'center' },
                { text: '来就中', pos: 'center', x: 70, y: 55, size: 180, color: '#ffff00', weight: 'bold', align: 'center' },
                { text: '9/20(SUN.) 7PM', pos: 'center', x: 10, y: 85, size: 24, color: '#000000', align: 'left' }
            ],
            '⑪ 复古Y2K票务海报（大字铺满·去粉字）': [
                { text: '捡漏有票就能中', pos: 'center', y: 32, size: 78, color: '#FF8C00', weight: 'bold', outerColor: '#000000', outerWidth: 0.2, offsetColor: '#E03131', offsetX: 6, offsetY: 7, align: 'center', curve: true, curveArc: 0.1, letterSpace: 6 },
                { text: '{城市}{明星}', pos: 'center', y: 60, size: 152, color: '#FF6A00', weight: 'bold', outerColor: '#000000', outerWidth: 0.2, offsetColor: '#E03131', offsetX: 8, offsetY: 10, align: 'center', letterSpace: 10 }
            ]
        };
        _iw.layerTpls = {};
        try { _iw.layerTpls = JSON.parse(localStorage.getItem('kun_layer_templates') || '{}'); } catch(e) {}
        function _iwSaveLayerTpls() { localStorage.setItem('kun_layer_templates', JSON.stringify(_iw.layerTpls)); }
        function _iwRenderLayerTplSelect() {
            var sel = $('iwLayerTpl'); if (!sel) return;
            var cur = sel.value;
            var html = '<option value="">— 文字层模板 —</option>';
            Object.keys(_LAYER_TPL_LIB).forEach(function(k) {
                html += '<option value="' + k + '"' + (cur === k ? ' selected' : '') + '>【内置】' + k + '</option>';
            });
            Object.keys(_iw.layerTpls).forEach(function(k) {
                html += '<option value="' + k + '"' + (cur === k ? ' selected' : '') + '>' + k + '</option>';
            });
            sel.innerHTML = html;
        }
        function _iwApplyLayerTpl(name) {
            var layers = _LAYER_TPL_LIB[name] || _iw.layerTpls[name];
            if (!layers) { addLog('⚠ 模板不存在: ' + name, 'warn'); return; }
            _iw.layers = JSON.parse(JSON.stringify(layers)).map(_normLayer);
            _iwRenderLayers();
            addLog('📦 文字层模板「' + name + '」已应用（' + _iw.layers.length + ' 层）', 'ok');
        }
        var _ltSel = $('iwLayerTpl');
        if (_ltSel) {
            _iwRenderLayerTplSelect();
            var _ltApply = $('iwLayerTplApply');
            if (_ltApply) _ltApply.onclick = function() { var n = _ltSel.value; if (n) _iwApplyLayerTpl(n); else addLog('⚠ 请先选择文字层模板', 'warn'); };
            var _ltSave = $('iwLayerTplSave');
            if (_ltSave) _ltSave.onclick = function() {
                if (_iw.layers.length === 0) { addLog('⚠ 当前没有文字层可保存', 'warn'); return; }
                var n = prompt('文字层模板名称:'); if (!n || !n.trim()) return;
                _iw.layerTpls[n.trim()] = JSON.parse(JSON.stringify(_iw.layers)).map(_normLayer);
                _iwSaveLayerTpls();
                _iwRenderLayerTplSelect();
                _ltSel.value = n.trim();
                addLog('💾 文字层模板「' + n.trim() + '」已保存', 'ok');
            };
            var _ltDel = $('iwLayerTplDelete');
            if (_ltDel) _ltDel.onclick = function() {
                var n = _ltSel.value; if (!n) { addLog('⚠ 请先选择要删除的模板', 'warn'); return; }
                if (_LAYER_TPL_LIB[n]) { addLog('⚠ 内置模板不可删除', 'warn'); return; }
                if (confirm('删除文字层模板「' + n + '」？')) {
                    delete _iw.layerTpls[n];
                    _iwSaveLayerTpls();
                    _iwRenderLayerTplSelect();
                    addLog('🗑 已删除「' + n + '」', 'ok');
                }
            };
        }
        // 预览（叠加文字到底图；没底图时自动走海报生成）
        $('iwPreviewBtn').onclick = async function() {
            var firstText = ((_iw.layers[0] && _iw.layers[0].text) || '').trim();
            // 解析"城市 明星"：支持空格分隔，也支持无空格（按城市名匹配）
            var city = '', star = '';
            if (firstText) {
                var parts = firstText.split(/\s+/);
                if (parts.length >= 2 && parts[0] && parts[1]) {
                    city = parts[0];
                    star = parts.slice(1).join(' ');
                } else if (typeof PROVINCE_MAP !== 'undefined') {
                    var names = Object.keys(PROVINCE_MAP).sort(function(a, b) { return b.length - a.length; });
                    for (var ci = 0; ci < names.length; ci++) {
                        if (firstText.indexOf(names[ci]) === 0) { city = names[ci]; star = firstText.substring(city.length); break; }
                    }
                }
                star = (star || '').trim();
            }
            if (city && star && firstText.indexOf('{') < 0) {
                // 有城市明星 → 套用海报模板（紫色块+黄标签）出成品；文字含 { 占位符时走文字层叠加，不进海报路由
                addLog('🎨 海报生成: ' + city + ' ' + star + '...', 'info');
                try {
                    var payload = { city: city, star: star, variant: $('iwPosterVariant') ? $('iwPosterVariant').value : '首开', source: $('iwPosterSource') ? $('iwPosterSource').value : 'ai', ratio: '3:4' };
                    if (_iw.blockDirty && _iw.blockLayout) { var _bt = _iwBuildBlocksTags(); if (_bt) { payload.blocks = _bt.blocks; payload.tags = _bt.tags; } }
                    if (_iw.sourceUrl) {
                        // 有底图：转 base64 传给服务器，服务器只叠加模板文字
                        try {
                            var dataUrl = await _iwSourceToDataURL();
                            payload.posterB64 = dataUrl.replace(/^data:image\/[^;]+;base64,/, '');
                        } catch(e) { addLog('⚠ 底图转换失败，改用自动模式', 'warn'); }
                    }
                    var r = await api('/api/poster/make', payload);
                    if (r.ok && r.imageB64) {
                        _iw.resultUrls = ['data:image/jpeg;base64,' + r.imageB64];
                        _iwRenderResults();
                        addLog('✅ 成品海报已生成（' + (r.mode || '') + '）', 'ok');
                    } else addLog('❌ ' + (r.error || '失败'), 'err');
                } catch(e) { addLog('❌ ' + (e.message || e), 'err'); }
                return;
            }
            // 无城市明星：老逻辑（底图 + 文字层叠加）
            if (!_iw.sourceUrl) { addLog('⚠ 请先选底图，或在文字层输入"城市 明星"', 'warn'); return; }
            _iwApplyText(function(dataUrl) {
                _iw.resultUrls = [dataUrl];
                _iwRenderResults();
                addLog('✅ 预览已生成', 'ok');
            });
        };
        function _iwApplyText(callback, overrides, srcUrl, layersOverride) {
            var img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = function() {
                var canvas = document.createElement('canvas');
                canvas.width = img.width; canvas.height = img.height;
                var ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);
                // 贴图叠印（中台贴纸/印花：已预加载的 _iw.stickerImgs；支持按 x/y/w 定位，否则右下角堆叠）
                // 先画贴纸（横幅），再画文字层，保证文字在贴纸之上（不被半透明横幅盖住）
                if (_iw.stickerImgs && _iw.stickerImgs.length) {
                    var _stN = _iw.stickerImgs.length;
                    for (var si = 0; si < _stN; si++) {
                        var _st = _iw.stickerImgs[si]; if (!_st || !_st.img || !_st.img.width) continue;
                        var simg = _st.img;
                        var stW = Math.round(canvas.width * (_st.w || 0.22));
                        // 高 = 宽 × (图高/图宽)：横图(宽>高)比例正确，不会把高度算爆
                        var sh = Math.round(stW * simg.height / simg.width);
                        var sx, sy;
                        if (_st.x != null && _st.y != null) {
                            sx = Math.round(canvas.width * _st.x / 100 - stW / 2);
                            sy = Math.round(canvas.height * _st.y / 100 - sh / 2);
                        } else {
                            sx = canvas.width - stW - Math.round(canvas.width * 0.04);
                            sy = (canvas.height - Math.round(canvas.width * 0.04) - Math.round(canvas.width * 0.20)) - sh * si;
                            if (sy < 0) sy = canvas.height - Math.round(canvas.width * 0.04) - sh;
                        }
                        ctx.save(); ctx.globalAlpha = 1.0; ctx.drawImage(simg, sx, sy, stW, sh); ctx.restore();
                    }
                }
                var layers = layersOverride || _iw.layers;
                for (var li = 0; li < layers.length; li++) {
                    var l = _normLayer(layers[li]);
                    // 字号随底图宽度缩放（sizePct=宽度%），否则小底图文字会溢出
                    var _sz = l.sizePct ? Math.round(canvas.width * l.sizePct / 100) : Math.round((parseInt(l.size) || 48) * Math.max(0.5, canvas.width / 1020)); // 固定px字号按底图宽(以1020为基准)缩放，小底图不重叠
                    var text = String(l.text || '');
                    if (overrides) {
                        text = text
                            .replace(/\{城市\}/g, overrides.city || '')
                            .replace(/\{明星\}/g, overrides.star || '')
                            .replace(/\{场次类型\}/g, overrides.sessionType || '')
                            .replace(/\{活动类型\}/g, overrides.eventType || '');
                    }
                    if (!text) continue;
                    // 位置：X% 锚点 + Y%（留空按 顶/中/底 推算）
                    var x = (canvas.width * (parseFloat(l.x) || 50)) / 100;
                    var yPct = (l.y !== '' && l.y !== undefined && l.y !== null && !isNaN(parseFloat(l.y))) ? parseFloat(l.y) : null;
                    var y;
                    if (yPct !== null) y = (canvas.height * yPct) / 100;
                    else y = l.pos === 'top' ? l.size + 20 : (l.pos === 'bottom' ? canvas.height - 20 : canvas.height / 2);
                    ctx.save();
                    ctx.globalAlpha = Math.max(0, Math.min(100, parseInt(l.opacity) || 100)) / 100;
                    // 【2026-10-07 改】倾斜(l.rot) 原来只作用在**文字**上（在底条绘制之后才 rotate），
                    // 于是「倾斜的色块」做不出来 —— 而老板的 hope 样板正是每根粉条各自带倾角。
                    // 这里把旋转提到最前面，让 **色块 + 文字一起转**（绕 (x,y)）。
                    // 旧位置（常规文字分支里的那次 rotate）已移除，否则会转两次。
                    // 对不带 rot 的层完全无影响（rot 缺省 0）。
                    if (l.rot) { ctx.translate(x, y); ctx.rotate(l.rot * Math.PI / 180); ctx.translate(-x, -y); }
                    ctx.font = (l.weight === 'normal' ? 'normal ' : 'bold ') + _sz + 'px ' + (l.fontFamily || '"PingFang SC", "Microsoft YaHei", sans-serif');
                    ctx.textAlign = l.align || 'center';
                    ctx.textBaseline = 'middle';
                    // 多行：按 \n 拆分，逐行绘制
                    var lines = text.split('\n');
                    var lineHeight = _sz * 1.25;
                    var startY = y - (lineHeight * (lines.length - 1)) / 2;
                    // 文字底条（半透明背景）
                    if (l.bg) {
                        var maxW = 0;
                        for (var mi = 0; mi < lines.length; mi++) {
                            var w = ctx.measureText(lines[mi]).width;
                            if (w > maxW) maxW = w;
                        }
                        var padX = l.size * 0.4, padY = l.size * 0.3;
                        var barW = maxW + padX * 2;
                        var barH = lineHeight * lines.length + padY * 2;
                        var barX = l.align === 'left' ? x : (l.align === 'right' ? x - barW : x - barW / 2);
                        var barY = startY - barH / 2, brad = (l.bgRadius != null ? l.bgRadius : Math.min(barH / 2, l.size * 0.35));
                        ctx.save();
                        ctx.beginPath();
                        ctx.moveTo(barX + brad, barY);
                        ctx.arcTo(barX + barW, barY, barX + barW, barY + barH, brad);
                        ctx.arcTo(barX + barW, barY + barH, barX, barY + barH, brad);
                        ctx.arcTo(barX, barY + barH, barX, barY, brad);
                        ctx.arcTo(barX, barY, barX + barW, barY, brad);
                        ctx.closePath();
                        ctx.fillStyle = l.bg;
                        ctx.globalAlpha = ctx.globalAlpha * (l.bgAlpha != null ? l.bgAlpha : 0.55);
                        ctx.fill();
                        ctx.restore();
                        ctx.globalAlpha = Math.max(0, Math.min(100, parseInt(l.opacity) || 100)) / 100;
                    }
                    // 曲线（弧形）排列：逐字沿上凸弧线，立体贴纸
                    if (l.curve) {
                        var chars = String(text).split('');
                        var sp = l.letterSpace || 0;
                        var _wd = chars.map(function(ch){ return ctx.measureText(ch).width; });
                        var _tot = 0; _wd.forEach(function(w){ _tot += w; }); _tot += sp * (chars.length - 1);
                        var arc = Math.PI * (l.curveArc || 0.16), rad = _tot / (2 * arc);
                        for (var ci = 0; ci < chars.length; ci++) {
                            var t = (ci + 0.5) / chars.length, ang = -arc + t * 2 * arc;
                            var px = x + Math.sin(ang) * rad, py = y + rad - rad * Math.cos(ang);
                            ctx.save(); ctx.translate(px, py); ctx.rotate(ang);
                            ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
                            if (l.outerColor) { ctx.strokeStyle = l.outerColor; ctx.lineWidth = Math.max(2, l.size * (l.outerWidth || 0.22)); ctx.strokeText(chars[ci], 0, 0); }
                            if (l.offsetColor) { ctx.strokeStyle = l.offsetColor; ctx.lineWidth = Math.max(2, l.size / 14); ctx.strokeText(chars[ci], l.offsetX || 0, l.offsetY || 0); }
                            if (l.stroke) { ctx.strokeStyle = l.strokeColor || 'rgba(0,0,0,0.6)'; ctx.lineWidth = Math.max(2, (l.strokeWidth != null ? l.strokeWidth : _sz / 20)); ctx.strokeText(chars[ci], 0, 0); }
                            ctx.fillStyle = l.color; ctx.fillText(chars[ci], 0, 0);
                            ctx.restore();
                        }
                    } else {
                        // 常规：逐字（支持字间距 letterSpace），保留多行
                        var _sp = l.letterSpace || 0;
                        var _drawLine = function(txt, cx, cy) {
                            // 【2026-10-07 修】原来用 txt.split('') / txt[_j] 按【UTF-16 码元】迭代，
                            // 而 emoji（💯 U+1F4AF、🀄 U+1F004）是**代理对**（2 个码元）→ 被劈成两半，
                            // 每半个都渲染成豆腐块（实测：「超高命中率💯🀄」出成三个「？」）。
                            // 改成按【码点】切（Array.from），emoji 才是一个整体。
                            var _chars = Array.from(txt);
                            var _cw = _chars.map(function(ch){ return ctx.measureText(ch).width; });
                            var _tw = 0; _cw.forEach(function(w){ _tw += w; }); _tw += _sp * (_chars.length - 1);
                            var _cx = (_chars.length === 1) ? cx : cx - _tw / 2;
                            var _cum = 0;
                            for (var _j = 0; _j < _chars.length; _j++) {
                                var _posX = _cx + _cum + _sp * _j + _cw[_j] / 2;
                                if (l.outerColor) { ctx.strokeStyle = l.outerColor; ctx.lineWidth = Math.max(2, l.size * (l.outerWidth || 0.22)); ctx.strokeText(_chars[_j], _posX, cy); }
                                if (l.offsetColor) { ctx.strokeStyle = l.offsetColor; ctx.lineWidth = Math.max(2, l.size / 14); ctx.strokeText(_chars[_j], _posX + (l.offsetX || 0), cy + (l.offsetY || 0)); }
                                if (l.stroke) { ctx.strokeStyle = l.strokeColor || 'rgba(0,0,0,0.6)'; ctx.lineWidth = Math.max(2, (l.strokeWidth != null ? l.strokeWidth : _sz / 20)); ctx.strokeText(_chars[_j], _posX, cy); }
                                ctx.fillStyle = l.color; ctx.fillText(_chars[_j], _posX, cy);
                                _cum += _cw[_j];
                            }
                        };
                        ctx.save();
                        // 【2026-10-07 移走】旋转已在层开头统一施加（色块+文字一起转），这里不能再转一次
                        for (var li2 = 0; li2 < lines.length; li2++) _drawLine(lines[li2], x, startY + li2 * lineHeight);
                        ctx.restore();
                    }
                    ctx.restore();
                }
                callback(canvas.toDataURL('image/png'));
            };
            img.onerror = function() { addLog('⚠ 图片加载失败', 'warn'); callback(null); };
            img.src = srcUrl || _iw.sourceUrl;
        }
        // 裂变（复用旧逻辑，色相旋转）
        $('iwFissBtn').onclick = function() {
            if (!_iw.sourceUrl) { addLog('⚠ 请先选底图', 'warn'); return; }
            var count = parseInt($('iwFissCount').value) || 5;
            // P0-1：三个效果开关，元素缺失时安全降级为默认值
            var doBg = $('iwFissBg') ? $('iwFissBg').checked : true;
            var doParticles = $('iwFissParticles') ? $('iwFissParticles').checked : false;
            var doBright = $('iwFissBrightness') ? $('iwFissBrightness').checked : false;
            addLog('🎨 裂变 ' + count + ' 张...', 'info');
            var img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = function() {
                _iw.resultUrls = [];
                var step = 360 / count;
                var offset = Math.random() * 360;
                var shifts = [];
                for (var hi = 0; hi < count; hi++) shifts.push((offset + hi * step) % 360);
                shifts.sort(function() { return Math.random() - 0.5; });
                for (var fi = 0; fi < count; fi++) {
                    var c2 = document.createElement('canvas');
                    c2.width = img.width; c2.height = img.height;
                    var ctx2 = c2.getContext('2d');
                    ctx2.drawImage(img, 0, 0);
                    if (doBg) {
                        var idata = ctx2.getImageData(0, 0, c2.width, c2.height);
                        var d = idata.data;
                        for (var pi = 0; pi < d.length; pi += 4) {
                            var max = Math.max(d[pi], d[pi+1], d[pi+2]);
                            var min = Math.min(d[pi], d[pi+1], d[pi+2]);
                            var lum = (max + min) / 2;
                            var sat = (max - min) / 255;
                            if (sat < 0.05) continue;
                            var hue = 0;
                            if (max === d[pi]) hue = ((d[pi+1] - d[pi+2]) / (max - min)) % 6;
                            else if (max === d[pi+1]) hue = (d[pi+2] - d[pi]) / (max - min) + 2;
                            else hue = (d[pi] - d[pi+1]) / (max - min) + 4;
                            hue = (hue * 60 + shifts[fi] + 360) % 360;
                            var c = sat;
                            var x = c * (1 - Math.abs((hue / 60) % 2 - 1));
                            var m = lum / 255 - c / 2;
                            var nr, ng, nb;
                            if (hue < 60) { nr=c; ng=x; nb=0; }
                            else if (hue < 120) { nr=x; ng=c; nb=0; }
                            else if (hue < 180) { nr=0; ng=c; nb=x; }
                            else if (hue < 240) { nr=0; ng=x; nb=c; }
                            else if (hue < 300) { nr=x; ng=0; nb=c; }
                            else { nr=c; ng=0; nb=x; }
                            d[pi] = Math.round((nr + m) * 255);
                            d[pi+1] = Math.round((ng + m) * 255);
                            d[pi+2] = Math.round((nb + m) * 255);
                        }
                        ctx2.putImageData(idata, 0, 0);
                    }
                    if (doParticles) {
                        for (var pt = 0; pt < 20; pt++) {
                            ctx2.fillStyle = 'rgba(255,255,255,' + (0.1 + Math.random()*0.3) + ')';
                            ctx2.beginPath();
                            ctx2.arc(Math.random()*c2.width, Math.random()*c2.height, 1+Math.random()*3, 0, Math.PI*2);
                            ctx2.fill();
                        }
                    }
                    if (doBright) {
                        var bdata = ctx2.getImageData(0, 0, c2.width, c2.height);
                        var bd = bdata.data;
                        var boost = 0.9 + Math.random() * 0.2;
                        for (var bi = 0; bi < bd.length; bi += 4) {
                            bd[bi] = Math.min(255, bd[bi] * boost);
                            bd[bi+1] = Math.min(255, bd[bi+1] * boost);
                            bd[bi+2] = Math.min(255, bd[bi+2] * boost);
                        }
                        ctx2.putImageData(bdata, 0, 0);
                    }
                    _iw.resultUrls.push(c2.toDataURL('image/png'));
                }
                _iwRenderResults();
                addLog('✅ 裂变完成: ' + _iw.resultUrls.length + ' 张', 'ok');
            };
            img.src = _iw.sourceUrl;
        };
        // 产出渲染
        function _iwRenderResults() {
            var container = $('iwResults'); if (!container) return;
            var html = '';
            for (var i = 0; i < _iw.resultUrls.length; i++) {
                html += '<div style="width:72px;"><img src="' + _iw.resultUrls[i] + '" style="width:72px;height:72px;object-fit:cover;border-radius:6px;border:2px solid #27ae60;cursor:pointer;" onclick="window.open(this.src)">' +
                    '<button data-sidx="' + i + '" class="iw-use-src" style="width:72px;margin-top:2px;background:#fff;color:#E67E22;border:1px solid #f0c9a0;border-radius:4px;font-size:10px;padding:2px 0;cursor:pointer;">设为底图</button></div>';
            }
            container.innerHTML = html;
            container.querySelectorAll('.iw-use-src').forEach(function(btn) {
                btn.onclick = async function() {
                    var url = _iw.resultUrls[parseInt(this.dataset.sidx)];
                    if (!url) return;
                    if (_iw.sourceUrl && _iw.sourceUrl.startsWith('blob:')) URL.revokeObjectURL(_iw.sourceUrl);
                    _iw.sourceUrl = url;
                    // http 图转 dataURL 再当底图，避免画布跨域污染导致预览/批量生成失败
                    if (url.indexOf('http') === 0) {
                        try { var d = await _iwSourceToDataURL(); if (d) _iw.sourceUrl = d; } catch(e) {}
                    }
                    $('iwSourcePreview').innerHTML = '<img src="' + _iw.sourceUrl + '" style="max-width:280px;max-height:200px;border-radius:8px;border:2px solid #E67E22;">';
                    $('iwSourcePreview').style.display = '';
                    addLog('📄 成品已设为底图，可加文字层做成模板', 'ok');
                };
            });
            if (_iw.resultUrls.length > 0) {
                $('iwDownloadAll').style.display = '';
                $('iwAddToGallery').style.display = '';
            }
        }
        $('iwDownloadAll').onclick = function() {
            _iw.resultUrls.forEach(function(url, i) {
                var a = document.createElement('a'); a.href = url; a.download = 'img_' + (i+1) + '.png'; a.click();
            });
        };
        // 加入底图管理 = 一步到位：图传闲鱼图床换 http 链接 + 直接建好发布任务（城市/明星/场次/活动/图）
        $('iwAddToGallery').onclick = async function() {
            if (!state.currentStore) { addLog('⚠ 请先选店铺（图要传到该店铺的闲鱼图床）', 'warn'); return; }
            if (!_iw.resultUrls.length) return;
            var btn = this; btn.disabled = true;
            var tpl = getActiveTemplate();
            var ok = 0, fail = 0;
            for (var i = 0; i < _iw.resultUrls.length; i++) {
                var url = _iw.resultUrls[i];
                var meta = _iw.resultMeta[i] || {};
                var b64 = String(url).replace(/^data:image\/[^;]+;base64,/, '');
                if (!b64 || b64 === url) { fail++; continue; } // 非 dataURL（如 http 链接）跳过
                try {
                    // 图床直传走服务端（店铺 context 带 cookie，绕过页面 CORS）
                    var up = await api('/api/agent/upload-image', { store: state.currentStore, imageB64: b64 });
                    var httpUrl = (up && up.ok && up.url && up.url.indexOf('http') === 0) ? up.url : '';
                    if (!httpUrl) {
                        fail++; addLog('❌ 图床上传失败 ' + (meta.city || '') + ' ' + (meta.star || '') + ': ' + ((up && up.error) || '未返回URL'), 'err');
                        continue;
                    }
                    var name = (meta.city || '') + (meta.star || '') + (meta.session || '');
                    state.images.push({ name: name, url: httpUrl, saved: true });
                    state.tasks.push({
                        star: meta.star || '', city: meta.city || '',
                        eventType: meta.event || '演唱会', sessionType: meta.session || '首开',
                        categoryName: tpl.categoryName, price: tpl.price, stock: tpl.stock,
                        imageName: name, imageUrls: [httpUrl], status: 'pending'
                    });
                    ok++;
                    addLog('✅ 任务就绪: ' + name, 'ok');
                } catch(e) { fail++; addLog('❌ ' + ((meta.city || '') + ' ' + (meta.star || '')) + ': ' + (e.message || e), 'err'); }
            }
            renderImages(); renderTasks(); saveStoreData();
            addLog('📌 完成：' + ok + ' 个任务已建好' + (fail ? '，失败 ' + fail : '') + ' → 点「📤 发当前」上架', 'ok');
            btn.disabled = false;
        };
        // 模板
        $('iwTplSave').onclick = async function() {
            if (!_iw.sourceUrl) { addLog('⚠ 请先选底图', 'warn'); return; }
            if (_iw.layers.length === 0) { addLog('⚠ 请先添加文字层', 'warn'); return; }
            var name = prompt('模板名称:');
            if (!name) return;
            addLog('💾 保存模板中...', 'info');
            try {
                var base64 = await _iwSourceToDataURL();
                _iw.templates[name] = { sourceUrl: base64, layers: JSON.parse(JSON.stringify(_iw.layers)) };
                _iwSaveTemplates();
                $('iwTplSelect').value = name;
                addLog('💾 模板「' + name + '」已保存（含底图）', 'ok');
            } catch(e) { addLog('❌ ' + e.message, 'err'); }
        };
        $('iwTplLoad').onclick = function() {
            var name = $('iwTplSelect').value;
            if (!name || !_iw.templates[name]) return;
            var tpl = _iw.templates[name];
            _iw.layers = JSON.parse(JSON.stringify(tpl.layers));
            _iwRenderLayers();
            if (tpl.sourceUrl) {
                _iw.sources = [{ name: name + '（模板）', url: tpl.sourceUrl }];
                _iwRenderSources();
                _iwSetSource(name + '（模板）', tpl.sourceUrl);
            }
            addLog('📦 模板「' + name + '」已加载（底图+文字层）', 'ok');
        };
        $('iwTplDelete').onclick = function() {
            var name = $('iwTplSelect').value;
            if (!name || !_iw.templates[name]) return;
            delete _iw.templates[name];
            _iwSaveTemplates();
            addLog('🗑 模板「' + name + '」已删除', 'ok');
        };
        // 批量生成（支持多底图：每张底图 × 每行 城市明星）
        var _bb=$('iwBatchBtn'); if(_bb) _bb.onclick = function() {
            var input = ($('iwBatchInput').value || '').trim();
            if (!input) { addLog('⚠ 请输入城市 明星', 'warn'); return; }
            var sources = _iw.sources.length ? _iw.sources : (_iw.sourceUrl ? [{ name: _iw.sourceName || '底图', url: _iw.sourceUrl }] : []);
            if (sources.length === 0) { addLog('⚠ 请先上传底图（📁本地上传可多选）', 'warn'); return; }
            var lines = input.split('\n').filter(Boolean);
            // 任务队列：每张底图 × 每行
            var tasks = [];
            for (var si2 = 0; si2 < sources.length; si2++) {
                for (var li2 = 0; li2 < lines.length; li2++) {
                    tasks.push({ src: sources[si2], meta: _parseLine(lines[li2]) });
                }
            }
            var statusEl = $('iwBatchStatus');
            statusEl.textContent = '⏳ 处理 ' + tasks.length + ' 个（' + sources.length + ' 底图 × ' + lines.length + ' 行）...';
            _iw.resultUrls = [];
            var _idx = 0;
            function processNext() {
                if (_idx >= tasks.length) {
                    statusEl.textContent = '✅ 完成 ' + _iw.resultUrls.length + ' 张';
                    _iwRenderResults();
                    return;
                }
                var task = tasks[_idx];
                statusEl.textContent = '⏳ ' + (_idx+1) + '/' + tasks.length + ': ' + task.src.name + ' · ' + task.meta.city + ' ' + task.meta.star;
                (function(t) {
                    _iwApplyText(function(dataUrl) {
                        _iw.resultUrls.push(dataUrl);
                        _iw.resultMeta.push(t.meta);
                        _idx++;
                        setTimeout(processNext, 100);
                    }, { city: t.meta.city, star: t.meta.star }, t.src.url);
                })(task);
            }
            processNext();
        };
        // 搜候选底图：筛选后的真海报列表，点缩略图选一张当底图，再生成
        var _candBtn = $('iwCandBtn');
        if (_candBtn) _candBtn.onclick = async function() {
            var input = ($('iwBatchInput').value || '').trim();
            var m = _parseLine(input.split('\n')[0] || '');
            if (!m.star) { addLog('⚠ 请输入 城市 明星', 'warn'); return; }
            var source = $('iwPosterSource').value;
            if (source === 'local' || source === 'aigen') { addLog('⚠ ' + (source === 'local' ? '本地上传' : 'AI出图') + ' 模式不支持搜候选底图', 'warn'); return; }
            var list = $('iwCandList'); if (!list) return;
            list.innerHTML = '<span style="font-size:12px;color:#999;">⏳ 搜索中...</span>';
            addLog('🔎 搜索 ' + (m.city || '') + ' ' + m.star + ' 候选海报...', 'info');
            var r;
            try { r = await api('/api/poster/candidates', { city: m.city, star: m.star, source: source }); }
            catch(e) { list.innerHTML = ''; addLog('❌ 搜索失败: ' + e.message, 'err'); return; }
            if (!r.ok) { list.innerHTML = ''; addLog('❌ ' + (r.error || '失败'), 'err'); return; }
            if (!r.items || !r.items.length) { list.innerHTML = '<span style="font-size:12px;color:#999;">未搜到候选海报</span>'; addLog('⚠ 未搜到候选海报', 'warn'); return; }
            _iw.cands = r.items;
            _iw.candKey = source + '|' + m.city + '|' + m.star;
            _iw.candB64 = '';
            var html = '';
            for (var i = 0; i < r.items.length; i++) {
                var c = r.items[i];
                html += '<div data-cand="' + i + '" style="position:relative;width:74px;border:1px solid #ddd;border-radius:6px;overflow:hidden;cursor:pointer;">' +
                    '<img src="' + c.thumb + '" style="width:74px;height:98px;object-fit:cover;display:block;">' +
                    '<div style="position:absolute;left:0;right:0;bottom:0;background:rgba(0,0,0,0.45);color:#fff;font-size:9px;text-align:center;padding:1px;">' + c.w + '×' + c.h + '</div>' +
                '</div>';
            }
            list.innerHTML = html;
            list.querySelectorAll('[data-cand]').forEach(function(el) {
                el.onclick = function() {
                    var idx = parseInt(el.dataset.cand);
                    var c = _iw.cands[idx];
                    _iw.candB64 = c.b64;
                    list.querySelectorAll('[data-cand]').forEach(function(e2) { e2.style.border = '1px solid #ddd'; });
                    el.style.border = '2px solid #E67E22';
                    addLog('✅ 已选底图 ' + c.w + '×' + c.h + '（分数' + c.s + '），点 🎨生成海报', 'ok');
                };
            });
            addLog('✅ 搜到 ' + r.items.length + ' 张候选，点一张再生成', 'ok');
        };
        // ===== 版式块编辑器（通用：紫块/黄块/带块 大小/位置/旋转/颜色/文字）=====
        function _iwBlockChanged() { _iw.blockDirty = true; }
        function _iwBlockName(b, idx) {
            function isPurple(c) {
                if (!c) return true;
                c = String(c).toLowerCase();
                if (c.charAt(0) !== '#') return true;
                var r = parseInt(c.substr(1, 2), 16), g = parseInt(c.substr(3, 2), 16), b2 = parseInt(c.substr(5, 2), 16);
                return (r > g) && (b2 > g);
            }
            return isPurple(b.color) ? ('紫块' + idx) : ('带块' + idx);
        }
        function _iwNumRow(label, item, key, min, max, def) {
            var row = document.createElement('div');
            row.style.cssText = 'display:flex;align-items:center;gap:4px;margin:2px 0;';
            var lab = document.createElement('span'); lab.textContent = label; lab.style.cssText = 'width:38px;font-size:11px;color:#666;';
            var cur = (item[key] != null && !isNaN(Number(item[key]))) ? Number(item[key]) : def;
            var rng = document.createElement('input'); rng.type = 'range'; rng.min = min; rng.max = max; rng.step = '0.01'; rng.value = cur;
            rng.style.cssText = 'flex:1;';
            var num = document.createElement('input'); num.type = 'number'; num.min = min; num.max = max; num.step = '0.01'; num.value = cur;
            num.style.cssText = 'width:58px;font-size:11px;';
            function apply(v) { var n = parseFloat(v); if (isNaN(n)) return; item[key] = n; rng.value = n; num.value = n; _iwBlockChanged(); }
            rng.oninput = function() { apply(this.value); };
            num.oninput = function() { apply(this.value); };
            row.appendChild(lab); row.appendChild(rng); row.appendChild(num);
            return row;
        }
        function _iwColorRow(label, item, key, def) {
            var row = document.createElement('div');
            row.style.cssText = 'display:flex;align-items:center;gap:4px;margin:2px 0;';
            var lab = document.createElement('span'); lab.textContent = label; lab.style.cssText = 'width:38px;font-size:11px;color:#666;';
            var col = document.createElement('input'); col.type = 'color'; col.value = item[key] || def;
            col.style.cssText = 'width:44px;height:22px;padding:0;border:1px solid #ddd;border-radius:4px;';
            col.oninput = function() { item[key] = this.value; _iwBlockChanged(); };
            row.appendChild(lab); row.appendChild(col);
            return row;
        }
        function _iwLabelRow(item) {
            var row = document.createElement('div');
            row.style.cssText = 'display:flex;align-items:center;gap:4px;margin:2px 0;';
            var lab = document.createElement('span'); lab.textContent = '文字'; lab.style.cssText = 'width:38px;font-size:11px;color:#666;';
            var inp = document.createElement('input'); inp.type = 'text'; inp.value = item.label || '';
            inp.style.cssText = 'flex:1;padding:3px 4px;border:1px solid #ddd;border-radius:4px;font-size:11px;';
            inp.oninput = function() { item.label = this.value; _iwBlockChanged(); };
            row.appendChild(lab); row.appendChild(inp);
            return row;
        }
        function _iwCheckRow(label, item, key) {
            var row = document.createElement('div');
            row.style.cssText = 'display:flex;align-items:center;gap:4px;margin:2px 0;';
            var lab = document.createElement('span'); lab.textContent = label; lab.style.cssText = 'width:38px;font-size:11px;color:#666;';
            var chk = document.createElement('input'); chk.type = 'checkbox'; chk.checked = !!item[key];
            chk.onchange = function() { item[key] = this.checked; _iwBlockChanged(); };
            row.appendChild(lab); row.appendChild(chk);
            return row;
        }
        function _iwBlockItem(kind, name, item) {
            var box = document.createElement('div');
            box.style.cssText = 'border:1px solid #e8d5f5;background:#fff;border-radius:6px;padding:6px;margin-bottom:6px;';
            var head = document.createElement('div');
            head.style.cssText = 'font-size:12px;font-weight:600;color:#7a3fa8;margin-bottom:4px;';
            head.textContent = name;
            box.appendChild(head);
            if (kind === 'tag') {
                box.appendChild(_iwLabelRow(item));
            } else {
                var fix = document.createElement('div'); fix.style.cssText = 'font-size:11px;color:#999;margin:2px 0;';
                fix.textContent = '文字: 城市+明星（自动替换）'; box.appendChild(fix);
            }
            box.appendChild(_iwNumRow('宽%', item, 'w', 0.05, 1.5, 0.3));
            box.appendChild(_iwNumRow('高%', item, 'h', 0.05, 1.5, 0.1));
            box.appendChild(_iwNumRow('水平%', item, 'cx', 0, 1, 0.5));
            box.appendChild(_iwNumRow('垂直%', item, 'cy', 0, 1, 0.5));
            box.appendChild(_iwNumRow('旋转°', item, 'rot', -45, 45, 0));
            box.appendChild(_iwColorRow('填充', item, 'color', (kind === 'tag' ? '#ffdd11' : '#dd11ff')));
            if (kind === 'tag') {
                box.appendChild(_iwColorRow('字色', item, 'textColor', '#1a1a1a'));
                box.appendChild(_iwCheckRow('3图标', item, 'icon3'));
                box.appendChild(_iwCheckRow('红中', item, 'zhong'));
            }
            return box;
        }
        function _iwRenderBlockEditor() {
            var list = $('iwBlockList'); if (!list) return;
            var bl = _iw.blockLayout;
            list.innerHTML = '';
            if (!bl) { list.innerHTML = '<span style="font-size:11px;color:#999;">版式块加载中...</span>'; return; }
            var nameEl = $('iwBlockName'); if (nameEl) nameEl.textContent = '（' + (bl.name || '') + '）';
            (bl.blocks || []).forEach(function(b, i) { list.appendChild(_iwBlockItem('blk', _iwBlockName(b, i + 1), b)); });
            (bl.tags || []).forEach(function(t, j) { list.appendChild(_iwBlockItem('tag', '黄块' + (j + 1), t)); });
            if ((!bl.blocks || !bl.blocks.length) && (!bl.tags || !bl.tags.length)) {
                list.innerHTML = '<span style="font-size:11px;color:#999;">该版式暂无块，请先 ➕存版式 或换一个版式</span>';
            }
        }
        async function _iwLoadBlockLayout(tid) {
            var r;
            try { r = await api('/api/poster/block-layout', { templateId: tid || '' }); }
            catch(e) { addLog('❌ 加载版式块失败: ' + (e && e.message ? e.message : e), 'err'); return null; }
            if (r && r.ok) {
                _iw.blockLayout = { templateId: r.templateId || tid || '', name: r.name || tid || '', blocks: r.blocks || [], tags: r.tags || [] };
                _iw.blockDirty = false;
                return _iw.blockLayout;
            }
            if (r && !r.ok) addLog('❌ ' + (r.error || '加载版式块失败'), 'err');
            return null;
        }
        function _iwBuildBlocksTags() {
            var bl = _iw.blockLayout;
            if (!bl) return null;
            return { blocks: JSON.parse(JSON.stringify(bl.blocks || [])), tags: JSON.parse(JSON.stringify(bl.tags || [])) };
        }
        var _blkEditBtn = $('iwBlockEditBtn');
        if (_blkEditBtn) _blkEditBtn.onclick = async function() {
            var panel = $('iwBlockEditor'); if (!panel) return;
            if (panel.style.display !== 'none') { panel.style.display = 'none'; return; }
            panel.style.display = '';
            var tid = _tplSel ? _tplSel.value : '';
            if (!_iw.blockLayout || _iw.blockLayout.templateId !== tid) {
                var bl = await _iwLoadBlockLayout(tid);
                _iwRenderBlockEditor();
                if (bl) { var n = (bl.blocks || []).length + (bl.tags || []).length; addLog('🧩 已加载「' + (bl.name || tid || '默认') + '」版式的 ' + n + ' 个块，拖动滑块实时改值', 'info'); }
            } else {
                _iwRenderBlockEditor();
            }
        };
        var _blkResetBtn = $('iwBlockResetBtn');
        if (_blkResetBtn) _blkResetBtn.onclick = async function() {
            var tid = _tplSel ? _tplSel.value : '';
            var bl = await _iwLoadBlockLayout(tid);
            _iwRenderBlockEditor();
            addLog('↺ 已重置回版式默认块', 'info');
        };
        var _blkPrevBtn = $('iwBlockPreviewBtn');
        if (_blkPrevBtn) _blkPrevBtn.onclick = async function() {
            var input = ($('iwBatchInput').value || '').trim();
            var m = _parseLine(input.split('\n')[0] || '');
            if (!m.star) { addLog('⚠ 预览需先输入 城市 明星', 'warn'); return; }
            var bt = _iwBuildBlocksTags(); if (!bt) { addLog('⚠ 请先打开版式块编辑器', 'warn'); return; }
            var pp = $('iwBlockPreview'); if (!pp) return;
            pp.innerHTML = '<span style="font-size:11px;color:#999;">⏳ 预览生成中...</span>';
            var source = $('iwPosterSource') ? $('iwPosterSource').value : 'ai';
            var posterB64 = '';
            if (source === 'local') {
                if (!_iw.sourceUrl) { pp.innerHTML = ''; addLog('⚠ 本地上传底图模式需先在高级工具传底图', 'warn'); return; }
                try { posterB64 = (await _iwSourceToDataURL()).replace(/^data:image\/[^;]+;base64,/, ''); }
                catch(e) { pp.innerHTML = ''; addLog('⚠ 底图转换失败: ' + e.message, 'warn'); return; }
            }
            try {
                var r = await api('/api/poster/make', { city: m.city, star: m.star, source: source, posterB64: posterB64, templateId: (_tplSel ? _tplSel.value : ''), ratio: '3:4', blocks: bt.blocks, tags: bt.tags });
                if (r.ok && r.imageB64) {
                    pp.innerHTML = '<img src="data:image/jpeg;base64,' + r.imageB64 + '" style="max-width:100%;border-radius:6px;border:2px solid #27ae60;cursor:pointer;" onclick="window.open(this.src)">';
                    addLog('🖼 版式块预览已更新', 'ok');
                } else { pp.innerHTML = ''; addLog('❌ 预览失败: ' + ((r && r.error) || '生成失败'), 'err'); }
            } catch(e) { pp.innerHTML = ''; addLog('❌ 预览失败: ' + (e.message || e), 'err'); }
        };
        // 切换版式时：清空缓存块 & 关闭编辑器（避免跨版式误用自定义块）
        if (_tplSel) _tplSel.onchange = function() {
            _iw.blockLayout = null; _iw.blockDirty = false;
            var panel = $('iwBlockEditor'); if (panel) panel.style.display = 'none';
            var pv = $('iwBlockPreview'); if (pv) pv.innerHTML = '';
            if (this.value === '__shoukai') {
                // 刘宪华首开样式：自动套 ⑨ 文字层（紫块{城市}{明星}+红字三行·居中）
                _iw.layers = (JSON.parse(JSON.stringify(_LAYER_TPL_LIB['⑨ 刘宪华首开样式（紫块白字+红字三行·居中）'] || [])));
                // 有底图才预览，避免未选底图时误报「图片加载失败」
                if (_iw.sourceUrl) _iwApplyText(function(){}, {});
                addLog('🎨 已套用 刘宪华首开样式（紫块+红字三行），底图用②来源', 'ok');
            } else if (this.value === '__y2k') {
                // 复古Y2K票务海报：套用 Y2K 文字层（叠在外部底图上，底图用②来源）
                _iw.layers = JSON.parse(JSON.stringify(_LAYER_TPL_LIB['⑪ 复古Y2K票务海报（大字铺满·去粉字）'] || []));
                if (_iw.sourceUrl) _iwApplyText(function(){}, {});
                addLog('🎨 已套用 复古Y2K票务海报（文字层），底图用②来源', 'ok');
            } else if (this.value.indexOf('__layer:') === 0) {
                // 自存文字层模板（如图生模板主标题{城市}{明星}）：套用其文字层
                var _ln = this.value.slice(8);
                _iw.layers = JSON.parse(JSON.stringify(_iw.layerTpls[_ln] || []));
                if (_iw.sourceUrl) _iwApplyText(function(){}, {});
                addLog('🎨 已套用文字层模板「' + _ln + '」，底图用②来源（文字层可改）', 'ok');
            } else {
                // 真实版式（如 tpl_* 逆向版式）：若带主标题文字层(layers)，加载进 _iw.layers，生成时自动替换 {城市}{明星}
                var _found = null;
                for (var _pi = 0; _pi < _posterTplsCache.length; _pi++) { if (_posterTplsCache[_pi].id === this.value) { _found = _posterTplsCache[_pi]; break; } }
                if (_found) {
                    // 主标题文字层（逆向版式）：{城市}{明星} 自动替换
                    if (_found.layers && _found.layers.length) {
                        _iw.layers = JSON.parse(JSON.stringify(_found.layers));
                        if (_iw.sourceUrl) _iwApplyText(function(){}, {});
                        addLog('🎨 已套用「' + (_found.name || '') + '」主标题文字层（{城市}{明星} 自动替换，底图自带版式整图用）', 'ok');
                    }
                    // 版式携带的贴图（中台贴纸/印花）
                    if (_found.stickers && _found.stickers.length) { addLog('📌 [DBG] 开始加载版式贴纸 ' + _found.stickers.length + ' 张（' + _found.stickers.map(function(s){return s.url;}).join(',') + '）', 'info'); _iw._stickerP = _iwLoadStickers(_found.stickers); }
                    else { addLog('📌 [DBG] 该版式没有 stickers（_found.stickers 为空）', 'warn'); }
                }
            }
        };
        // 🚀 批量出图（每行 城市 明星 [店] → 自动生成海报，预览；发商品下一步接）
        // ===== 批量出图版式（🎛 挑款式：勾选哪些进批量出图，随机档只在这些里随机）=====
        var _BATCH_STYLES = {  // 固定款式定义（kind 决定渲染方式）
          'xuliang-v1': { label: '三黄块+一紫块版式', kind: 'make', templateId: 'xuliang-v1' },
          '__shoukai':  { label: '首开紫块样式（紫块+红字三行）', kind: 'layer', layerLib: '⑨ 刘宪华首开样式（紫块白字+红字三行·居中）' }
        };
        // 判断一个版式用哪种方式渲染：纯贴纸/纯文字层 → 'tpl'(干净底图+叠贴纸/文字)，否则 → 'make'(服务端叠模板/底图)
        function _autoKind(v) {
            if (v && v.stickers && v.stickers.length && !v.file && !(v.blocks && v.blocks.length)) return 'tpl';
            if (v && v.layers && v.layers.length && !v.file && !(v.blocks && v.blocks.length)) return 'tpl';
            return 'make';
        }
        var _batchStyleKey = 'kun_batch_styles_v1';
        // 所有可挑的款式（固定 + 本地版式库），返回 {id: {label, kind, def/version}}
        function _allBatchStyles() {
            var all = {};
            Object.keys(_BATCH_STYLES).forEach(function(k){ all[k] = { label: _BATCH_STYLES[k].label, kind: _BATCH_STYLES[k].kind, def: _BATCH_STYLES[k] }; });
            (_posterTplsCache || []).forEach(function(v){ if (!v || !v.id || all[v.id]) return; all[v.id] = { label: v.name || v.id, kind: _autoKind(v), version: v }; });
            return all;
        }
        // 已勾选的款式 id（localStorage 记住；默认 = 固定款式）
        function _pickedBatchStyles() {
            // 过滤掉已被删除的版式 id：localStorage 里可能还留着老默认值(如 tpl_suibian2/3、tpl_hb_banner)
            var all = _allBatchStyles();
            try { var p = localStorage.getItem(_batchStyleKey); if (p) { var a = JSON.parse(p); if (Array.isArray(a) && a.length) { a = a.filter(function(id){ return !!all[id]; }); if (a.length) return a; } } } catch(e){}
            // 默认 = 固定款式 + 白底红字（随便问红榜版/随便问必中版已删除）
            var def = Object.keys(_BATCH_STYLES).slice();
            ['tpl_redtext'].forEach(function(id){ if (def.indexOf(id) < 0) def.push(id); });
            return def;
        }
        // 批量出图下拉 = 随机 + 勾选的款式
        function _renderGenStyles() {
            var sel = $('iwGenStyle'); if (!sel) return;
            var cur = sel.value, html = '<option value="__random"' + (cur === '__random' ? ' selected' : '') + '>随机</option>';
            var all = _allBatchStyles();
            _pickedBatchStyles().forEach(function(id){ var s = all[id]; if (!s) return; html += '<option value="' + esc(id) + '"' + (cur === id ? ' selected' : '') + '>' + esc(s.label) + '</option>'; });
            sel.innerHTML = html || '<option value="__random">随机</option>';
        }
        // 渲染「挑款式」勾选框
        function _renderStylePick() {
            var box = $('iwStylePick'); if (!box) return;
            var all = _allBatchStyles(), pick = _pickedBatchStyles();
            box.innerHTML = Object.keys(all).map(function(id){ return '<label style="display:inline-block;margin:2px 8px 2px 0;white-space:nowrap;"><input type="checkbox" class="iw-style-chk" data-id="' + esc(id) + '"' + (pick.indexOf(id) >= 0 ? ' checked' : '') + ' style="vertical-align:middle;"> ' + esc(all[id].label) + '</label>'; }).join('');
            box.querySelectorAll('.iw-style-chk').forEach(function(cb){
                cb.onchange = function() {
                    var id = this.getAttribute('data-id'), cur = _pickedBatchStyles();
                    if (this.checked) { if (cur.indexOf(id) < 0) cur.push(id); } else { cur = cur.filter(function(x){ return x !== id; }); }
                    try { localStorage.setItem(_batchStyleKey, JSON.stringify(cur)); } catch(e){}
                    _renderGenStyles();
                };
            });
        }
        (function(){ var tg = $('iwStylePickToggle'); if (tg) { tg.onclick = function(){ var b = $('iwStylePick'); if (b) b.style.display = (b.style.display === 'none' ? '' : 'none'); _renderStylePick(); }; } _renderStylePick(); })();
        _renderGenStyles();
        // 服务端已烘焙贴纸(如三紫块横幅)的底图 + 叠文字层——只叠文字，不重复叠贴纸
        async function _overlayVersion(baseB64, tplId, city, star) {
            var found = null;
            for (var _i2 = 0; _i2 < _posterTplsCache.length; _i2++) { if (_posterTplsCache[_i2].id === tplId) { found = _posterTplsCache[_i2]; break; } }
            if (!found) return baseB64;
            var layer = (found.layers && found.layers.length) ? JSON.parse(JSON.stringify(found.layers)) : null;
            try { _iw.stickerImgs = []; } catch(e){} // 贴纸已由服务端烘焙：只叠文字，避免重复
            return await new Promise(function(res){ _iwApplyText(function(d){ res(d || baseB64); }, { city: city, star: star }, baseB64, layer); });
        }

        var _genBatchBtn = $('iwGenBatchBtn');
        if (_genBatchBtn) _genBatchBtn.onclick = async function() {
            // 防重入：出图过程是 await 的，连点两次会让两次运行交错、各自基于同一份快照去重 → 生成重复版式
            if (window.__batchGenRunning) { addLog('⏳ 批量出图正在进行中，请等待完成（连点会造成重复上架）', 'warn'); return; }
            window.__batchGenRunning = true;
            var _btnLabel0 = _genBatchBtn.textContent;
            _genBatchBtn.disabled = true;
            _genBatchBtn.textContent = '⏳ 出图中...';
            function _endGenGuard() { // 幂等释放
                if (!window.__batchGenRunning) return;
                window.__batchGenRunning = false;
                _genBatchBtn.disabled = false;
                _genBatchBtn.textContent = _btnLabel0;
            }
            try {
            var input = ($('iwBatchGen').value || '').trim();
            if (!input) { addLog('⚠ 请输入城市 明星（每行一组）', 'warn'); return; }
            var style = ($('iwGenStyle') ? $('iwGenStyle').value : 'xuliang-v1');
            var lines = input.split('\n').filter(Boolean);
            var out = $('iwGenBatchOut'); if (!out) return;
            out.innerHTML = '<span style="font-size:12px;color:#999;">生成中...</span>';
            var imgs = [];
            var storesWithTasks = []; // 本次出图实际拿到任务的店（供「⚡出图即发」触发并发上架）
            var skippedDup = [];      // 被去重跳过的「商品+版式」
            var isMulti = $('iwGenMulti') ? $('iwGenMulti').checked : false;
            // 去重：按「城市+明星+版式」判断（一个商品每个版式各上架1条是允许的）。
            // 只拦「同一商品同一版式」被重复生图发布的情况（历史重复主要就是这么来的）。
            function _styleOfImageName(nm) {
                if (!nm) return '';
                var s = String(nm).replace(/-\d{13}$/, '').replace(/-\d+$/, '');
                var parts = s.split(/\s+/).filter(Boolean);
                return parts.length ? parts[parts.length - 1] : s;
            }
            var existingKeys = {};
            for (var _ei = 0; _ei < state.tasks.length; _ei++) {
                var _et = state.tasks[_ei];
                // 记下已有的是「已上架」还是「还没发的待发」，跳过时好告诉用户是哪一种
                var _stLbl = _et.itemId ? '已上架' : (_et.status === 'failed' ? '失败待处理' : '待发未上架');
                existingKeys[(_et.city || '') + '\u0001' + (_et.star || '') + '\u0001' + _styleOfImageName(_et.imageName)] = _stLbl;
            }
            for (var i = 0; i < lines.length; i++) {
                var mParsed = _parseLine(lines[i]);
                var city = mParsed.city || '', star = mParsed.star || '';
                var _ev = mParsed.event || '演唱会', _ss = mParsed.session || (mParsed.eventType || '演唱会');
                // 行尾 @店名 → 指定发布到该店；没写则沿用当前店铺
                var store = mParsed.store || state.currentStore || '';
                if (!star) { addLog('⚠ 第' + (i+1) + '行格式: 城市 明星 [活动类型] [场次] [@店名]', 'warn'); continue; }
                var styles = [];
                var _picked = _pickedBatchStyles().filter(function(k){ return k !== '__random'; });
                if (isMulti) {
                    // 多版式：每行出「所有勾选款式」各一张
                    styles = _picked.slice();
                } else if (style === '__random') {
                    // 随机：从勾选款式中随机挑一个
                    styles.push(_picked[Math.floor(Math.random() * _picked.length)] || 'xuliang-v1');
                } else styles.push(style);
                for (var k = 0; k < styles.length; k++) {
                var st = styles[k]; var imgUrl = '';
                // 同商品同版式已存在 → 跳过（允许同商品的其他版式继续生成）
                var _cfgPre = _BATCH_STYLES[st];
                var _autoPre = null;
                for (var _ap = 0; _ap < _posterTplsCache.length; _ap++) { if (_posterTplsCache[_ap].id === st) { _autoPre = _posterTplsCache[_ap]; break; } }
                var _styleLabelPre = (_cfgPre && _cfgPre.label) || (_autoPre && _autoPre.name) || '版式';
                var _pkey = city + '\u0001' + star + '\u0001' + _styleLabelPre;
                if (existingKeys[_pkey]) {
                    skippedDup.push(city + ' ' + star + ' · ' + _styleLabelPre + '（已存在：' + existingKeys[_pkey] + '）');
                    addLog('⏭ 跳过重复版式: ' + city + ' ' + star + ' · ' + _styleLabelPre + '（任务表已有，状态=' + existingKeys[_pkey] + '；防重复上架）', 'warn');
                    continue;
                }
                try {
                    try { _iw.stickerImgs = []; } catch(e){} // 每个款式独立：清空上次残留的贴纸,避免三紫块横幅叠到别的款上
                    var _cfg = _BATCH_STYLES[st];
                    var _autoV = null;
                    for (var _ai = 0; _ai < _posterTplsCache.length; _ai++) { if (_posterTplsCache[_ai].id === st) { _autoV = _posterTplsCache[_ai]; break; } }
                    if (!_cfg && !_autoV) _cfg = _BATCH_STYLES['xuliang-v1'];
                    // 款式没写 kind → 自动判断(版式结构决定)；写了就用
                    var _kind = (_cfg && _cfg.kind) ? _cfg.kind : (_autoV ? _autoKind(_autoV) : 'make');
                    var _tplId = (_cfg && _cfg.kind === 'make') ? _cfg.templateId : ((_cfg && _cfg.tplId) ? _cfg.tplId : st);
                    if (_kind === 'make') {
                        var r = await api('/api/poster/make', { city: city, star: star, source: 'damai_official', templateId: _tplId, ratio: '3:4' });
                        if (r.ok && r.imageB64) {
                            imgUrl = 'data:image/jpeg;base64,' + r.imageB64;
                            if (r.baseOrigin === 'ai') addLog('⚠ ' + city + ' ' + star + '：大麦没搜到这个项目，已用 AI 兜底出图（不是官方海报）。换官方叫法可重出，如 gapday', 'warn');
                        } else if (r.error) { addLog('⚠ ' + city + ' ' + star + ' 出图失败: ' + r.error, 'warn'); }
                    } else {
                        // tpl 款式：版式带贴纸(三紫块)→服务端烘焙贴纸；纯文字层版式→干净底图+叠文字层
                        var _tplV = (_autoV || (function(){ var v=null; for (var _pi2=0;_pi2<_posterTplsCache.length;_pi2++){ if(_posterTplsCache[_pi2].id===_tplId){ v=_posterTplsCache[_pi2]; break; } } return v; })());
                        var _tplHasStickers = !!(_tplV && _tplV.stickers && _tplV.stickers.length);
                        var r2 = await api('/api/poster/make', { city: city, star: star, source: 'damai_official', templateId: (_kind === 'tpl' && _tplHasStickers) ? _tplId : '', blocks: [], tags: [], ratio: '3:4' });
                        if (r2.ok && r2.baseOrigin === 'ai') addLog('⚠ ' + city + ' ' + star + '：大麦没搜到这个项目，已用 AI 兜底出图（不是官方海报）', 'warn');
                        if (r2.ok && r2.imageB64) {
                            var base = 'data:image/jpeg;base64,' + r2.imageB64;
                            if (_kind === 'layer') {
                                var layer = JSON.parse(JSON.stringify(_LAYER_TPL_LIB[_cfg.layerLib] || []));
                                imgUrl = await new Promise(function(res){ _iwApplyText(function(d){ res(d || base); }, { city: city, star: star }, base, layer); });
                            } else if (_kind === 'tpl') {
                                imgUrl = await _overlayVersion(base, _tplId, city, star);
                            } else {
                                imgUrl = base; // 兜底：干净底图
                            }
                        }
                    }
                } catch(e) { addLog('⚠ ' + city + ' ' + star + ' 出图失败: ' + e.message, 'warn'); }
                if (imgUrl) {
                    imgs.push({ city: city, star: star, img: imgUrl, line: lines[i] });
                    var styleNm = (_BATCH_STYLES[st] && _BATCH_STYLES[st].label) || (_autoV && _autoV.name) || '版式';
                    var imgName = city + ' ' + star + ' ' + styleNm + '-' + Date.now();
                    var _saved = false;
                    try { var _b64 = imgUrl.replace(/^data:image\/[^;]+;base64,/, ''); _saved = await persistImage(imgName, _b64); } catch(e){}
                    state.images.push({ name: imgName, url: imgUrl, thumbUrl: imgUrl, saved: _saved });
                    var tpl0 = getActiveTemplate();
                    // targetStore 用于发布过滤路由（rowBatchPublish/startPublish 按此择店）；store 仅作标记载保留
                    state.tasks.push({ star: star, city: city, eventType: _ev, sessionType: _ss, categoryName: tpl0.categoryName, price: tpl0.price, stock: tpl0.stock, imageName: imgName, store: store, targetStore: store });
                    existingKeys[_pkey] = '本次已生成'; // 本批次内防同版式重复
                    if (store && storesWithTasks.indexOf(store) < 0) storesWithTasks.push(store);
                    try { renderTasks(); renderImages(); } catch(e){}
                    try { saveStoreTasksToDisk(store); } catch(e){}
                }
                }
                addLog('✅ ' + city + ' ' + star + ' 出图完成', 'ok');
            }
            out.innerHTML = imgs.map(function(x) { return '<div style="text-align:center;position:relative;"><img src="' + x.img + '" style="width:120px;height:160px;object-fit:cover;border:1px solid #ddd;border-radius:6px;"><div style="font-size:10px;color:#666;margin-top:2px;">' + x.city + ' ' + x.star + '</div></div>'; }).join('') || '<span style="color:#999;font-size:12px;">无结果</span>';
            window._batchGenImgs = imgs;
            addLog('🚀 批量出图完成 ' + imgs.length + ' 张（下一步接发商品）', 'ok');
            // 出图后刷新并显示 credits 余量（好易美中台）
            try { if (window.refreshStudioCredits) window.refreshStudioCredits(); } catch(e){}
            // 出图阶段结束 → 释放防重入（发布阶段由 state.publishing 守卫，不再锁死出图按钮）
            _endGenGuard();
            // ⚡出图即发：勾选后自动把本次分派到的店一起并发上架；否则停在列表让你确认
            var autoPub = $('iwAutoPub') ? $('iwAutoPub').checked : false;
            if (autoPub && storesWithTasks.length > 0) {
                // 安全校验：行尾@店名/分派到的店，若不在当前勾选店铺内，弹出确认，防止误发给未勾选的店
                var notChecked = storesWithTasks.filter(function(s) { return state.selectedStores.indexOf(s) < 0; });
                if (notChecked.length > 0) {
                    var ok = confirm('⚠ 以下店铺不在你当前勾选的店铺里：\n\n' + notChecked.join('、') +
                        '\n\n⚡「出图即发」会把任务发到这些店。\n\n要继续自动上架吗？\n（点「取消」则只出图不发布，你可先勾选这些店再手动发）');
                    if (!ok) {
                        addLog('🛑 已取消自动上架（店铺不在勾选范围）。请在 🏪店铺 勾选 ' + notChecked.join('、') + ' 后手动发布，或关掉「出图即发」', 'warn');
                        return;
                    }
                }
                addLog('⚡ 已勾选「出图即发」，自动并发上架 ' + storesWithTasks.length + ' 个店: ' + storesWithTasks.join('、'), 'ok');
                await runStoreBatch(storesWithTasks.slice());
            } else if (autoPub && storesWithTasks.length === 0) {
                addLog('⚠ 无成功出图任务，未触发上架', 'warn');
            } else {
                addLog('💡 出图完成，请在任务列表核对「店」归属后，点「🚀 一键发布 或 📦 批量发布」三店并发上架', 'dim');
            }
            // 去重汇总：明确告诉你跳过了什么，避免把"没生成"误当成故障
            if (skippedDup.length > 0) {
                addLog('⏭ 本次跳过 ' + skippedDup.length + ' 个已存在的「商品+版式」：' + skippedDup.slice(0, 8).join('；') + (skippedDup.length > 8 ? ' 等' : ''), 'warn');
                alert('⏭ 已跳过 ' + skippedDup.length + ' 个重复（任务表已有该商品+版式）：\n\n' + skippedDup.join('\n') +
                      '\n\n如需重发，请先在任务表里点对应任务的 🔄 重置为待发（清掉 ✅/itemId）后再生成。');
            }
            } finally {
                _endGenGuard(); // 幂等：异常路径也能恢复按钮，避免按钮永久卡在"出图中"
            }
        };
        // 🎫 近期场次采集：调 /api/title/collect-damai → 点清单填入批量出图输入
        var _titleBtn = $('iwTitleBtn');
        if (_titleBtn) _titleBtn.onclick = async function() {
            var out = $('iwGenBatchOut'); if (!out) return;
            out.innerHTML = '<span style="font-size:12px;color:#999;">采集近期场次中...</span>';
            try {
                var r = await api('/api/title/collect-intel-hot');
                if (r.ok && r.items) {
                    out.innerHTML = r.items.map(function(x){ return '<button class="iw-title-set" data-v="' + esc(x.city + ' ' + x.star) + '" style="margin:3px;padding:4px 8px;border:1px solid #ddd;border-radius:5px;font-size:11px;cursor:pointer;">' + esc(x.city + ' ' + x.star + (x.showTime ? ' · ' + x.showTime : '') + ' · 热' + x.ipvuv) + '</button>'; }).join('') || '无';
                    out.querySelectorAll('.iw-title-set').forEach(function(b){ b.onclick = function(){ var inp = $('iwBatchGen'); if (inp) { inp.value += (inp.value ? '\n' : '') + this.getAttribute('data-v'); } addLog('已填入: ' + this.getAttribute('data-v'), 'ok'); }; });
                } else { out.innerHTML = '采集失败: ' + (r.error || ''); }
            } catch(e) { out.innerHTML = '采集失败: ' + e.message; }
        };
        // @店名 联想：在 iwBatchGen 里输入 @ 后弹出店铺名下拉，选中自动替换
        (function() {
            var ta = $('iwBatchGen');
            if (!ta) return;
            var ddl = document.createElement('div');
            ddl.style.cssText = 'position:fixed;z-index:10000;background:#fff;border:1px solid #ddd;border-radius:6px;box-shadow:0 6px 20px rgba(0,0,0,0.15);max-height:180px;overflow-y:auto;font-size:12px;display:none;min-width:160px;';
            document.body.appendChild(ddl);
            var _match = null;      // 候选数组
            var _sel = -1;          // 高亮索引
            var _caret = -1;        // 最近一次光标位置（input/focus 时捕获，点击下拉后仍可用）
            function storeNames() {
                try { return (state.accounts || []).map(function(a){ return a.name; }).filter(Boolean); } catch(e){ return []; }
            }
            function hide() { ddl.style.display = 'none'; _match = null; _sel = -1; }
            function showAt(input) {
                // 光标处的 @ 前缀（当前行里，从最后一个非空白或行首找 @）
                var pos = (_caret >= 0 ? _caret : input.selectionStart);
                var v = input.value;
                var lineStart = v.lastIndexOf('\n', pos - 1) + 1;
                var seg = v.substring(lineStart, pos);
                var at = seg.lastIndexOf('@');
                if (at < 0) { hide(); return; }
                var query = seg.substring(at + 1).trim();
                var names = storeNames();
                var filtered = names.filter(function(n){ return !query || n.indexOf(query) >= 0; });
                if (filtered.length === 0) { hide(); return; }
                _match = filtered;
                if (_sel >= filtered.length) _sel = -1; // 候选变少时重置高亮，避免指向已不存在的项
                // 定位下拉到文本域左下角
                var rect = ta.getBoundingClientRect();
                ddl.style.left = Math.min(rect.left + 8, window.innerWidth - 170) + 'px';
                ddl.style.top = (rect.top + ta.offsetHeight + 2) + 'px';
                var html = '';
                for (var i = 0; i < filtered.length; i++) {
                    html += '<div data-i="' + i + '" style="padding:6px 10px;cursor:pointer;' + (i === _sel ? 'background:#eaf3ff;color:#3050a0;' : 'color:#333;') + '">' + esc(filtered[i]) + '</div>';
                }
                ddl.innerHTML = html;
                ddl.style.display = 'block';
                // 点击选择
                Array.prototype.forEach.call(ddl.children, function(el) {
                    el.onclick = function() {
                        var idx = parseInt(this.getAttribute('data-i'), 10);
                        insertAt(input, filtered[idx]);
                        hide();
                        input.focus();
                    };
                });
            }
            function insertAt(input, name) {
                var pos = (_caret >= 0 ? _caret : input.selectionStart);
                var v = input.value;
                var lineStart = v.lastIndexOf('\n', pos - 1) + 1;
                var seg = v.substring(lineStart, pos);
                var at = seg.lastIndexOf('@');
                if (at < 0) return;
                var start = lineStart + at;
                // 替换 @开始 到 行尾（保留行尾其它 token 用空格分隔）
                var rest = v.substring(pos).replace(/^\S*/, ''); // 去掉光标后紧邻的未完成词
                var newVal = v.substring(0, start) + '@' + name + ' ' + rest;
                input.value = newVal;
                var newPos = start + 1 + name.length + 1;
                try { input.setSelectionRange(newPos, newPos); } catch(e) {}
            }
            ta.addEventListener('input', function() { _caret = ta.selectionStart; showAt(ta); });
            ta.addEventListener('click', function() { _caret = ta.selectionStart; });
            ta.addEventListener('focus', function() { _caret = ta.selectionStart; });
            ta.addEventListener('keydown', function(e) {
                if (ddl.style.display === 'none' || !_match || _match.length === 0) return;
                if (e.key === 'ArrowDown') { e.preventDefault(); _sel = (_sel + 1) % _match.length; renderHl(); }
                else if (e.key === 'ArrowUp') { e.preventDefault(); _sel = (_sel - 1 + _match.length) % _match.length; renderHl(); }
                else if (e.key === 'Enter' || e.key === 'Tab') {
                    if (_sel >= 0) { e.preventDefault(); insertAt(ta, _match[_sel]); hide(); }
                } else if (e.key === 'Escape') { hide(); }
                function renderHl() {
                    for (var i = 0; i < ddl.children.length; i++) {
                        ddl.children[i].style.background = (i === _sel) ? '#eaf3ff' : '';
                        ddl.children[i].style.color = (i === _sel) ? '#3050a0' : '#333';
                    }
                }
            });
            // 点击外部关闭
            document.addEventListener('click', function(e) {
                if (!ddl.contains(e.target) && e.target !== ta) hide();
            });
        })();
        // 🖼 图片逆向：上传版式图 → 逆向描述 → 自动存为版式
        // 逆向主标题贴纸底色：从底图 (xPct,yPct) 周边采样区域平均色，作为文字层 bg（盖住烤死旧标题）
        function _iwSampleRegion(b64, xPct, yPct) {
            return new Promise(function(resolve) {
                if (!b64) { resolve('#888888'); return; }
                var img = new Image();
                img.onload = function() {
                    try {
                        var c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
                        var ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
                        var cx = Math.max(0, Math.min(img.width - 1, Math.round(img.width * xPct / 100)));
                        var cy = Math.max(0, Math.min(img.height - 1, Math.round(img.height * yPct / 100)));
                        var R = Math.max(6, Math.round(Math.min(img.width, img.height) * 0.03));
                        var x0 = Math.max(0, cx - R), y0 = Math.max(0, cy - R);
                        var w = Math.min(img.width - x0, R * 2), h = Math.min(img.height - y0, R * 2);
                        var d = ctx.getImageData(x0, y0, w, h).data;
                        var rs = 0, gs = 0, bs = 0, n = 0;
                        for (var i = 0; i < d.length; i += 4) { rs += d[i]; gs += d[i+1]; bs += d[i+2]; n++; }
                        if (!n) { resolve('#888888'); return; }
                        resolve('rgb(' + Math.round(rs/n) + ',' + Math.round(gs/n) + ',' + Math.round(bs/n) + ')');
                    } catch(e) { resolve('#888888'); }
                };
                img.onerror = function() { resolve('#888888'); };
                img.src = 'data:image/jpeg;base64,' + b64;
            });
        }
        var _revBtn = $('iwRevBtn');
        if (_revBtn) _revBtn.onclick = async function() {
            var fi = $('iwRevFile'); if (!fi || !fi.files || !fi.files[0]) { addLog('⚠ 请先选一张版式图', 'warn'); return; }
            var file = fi.files[0];
            var b64 = await new Promise(function(res) { var fr = new FileReader(); fr.onload = function(){ res(String(fr.result).replace(/^data:image\/[^;]+;base64,/, '')); }; fr.readAsDataURL(file); });
            addLog('🔄 图生模板「' + file.name + '」提取文字层...', 'info');
            var r; try { r = await api('/api/agent/image-to-template', { imageB64: b64 }); } catch(e) { addLog('❌ 图生模板失败: ' + e.message, 'err'); return; }
            if (!r.ok) { addLog('❌ 图生模板失败: ' + (r.error || ''), 'err'); return; }
            // 图生模板：只取「主标题」并绑定 {城市}{明星}；副标题/日期是底图自带信息，不提取为可换文字层
            var layers = (r.text_layers || []).filter(function(l) { return l.role === 'title'; }).map(function(l) {
                return { text: '{城市}{明星}', pos: 'center',
                    x: Math.round(((l.coords && l.coords.x) || 0.5) * 100),
                    y: Math.round(((l.coords && l.coords.y) || 0.5) * 100),
                    size: Math.max(12, Math.round((l.size_ratio || 0.05) * 1360)),
                    color: l.color || '#ffffff',
                    align: l.alignment === 'left' ? 'left' : (l.alignment === 'right' ? 'right' : 'center'),
                    weight: l.font_weight === '粗' ? 'bold' : 'normal', bg: '' };
            });
            // 逆向主标题替换：采样标题处底条色当贴纸底(bg)，盖住烤死老标题 —— 用贴图/叠字功能实现
            for (var ti = 0; ti < layers.length; ti++) {
                var _bg = await _iwSampleRegion(b64, layers[ti].x, layers[ti].y);
                layers[ti].bg = _bg;
                layers[ti].bgAlpha = 1;   // 不透明，盖住底图上的旧标题
                layers[ti].bgRadius = 0.22;
            }
            var box = $('iwRevResult'); if (box) { box.style.display = ''; box.innerHTML = '提取文字层（' + layers.length + '处，已采样底条色）：\n' + layers.map(function(l,i){ return (i+1) + '.「' + l.text + '」 x' + l.x + '% y' + l.y + '%  #' + l.color + ' 底' + l.bg; }).join('\n'); }
            if (!layers.length) { addLog('⚠ 未提取到文字层（图可能无清晰文字）', 'warn'); return; }
            var base = (file.name || '').replace(/\.[^.]+$/, '') || '文字模板';
            var tplName = base;
            // 直接存到③版式（服务端版式库），选它即可用
            var desc = '文字层版式（图生模板逆向），主标题写{城市}{明星}；' + ((r.prompt_cn || r.prompt || '').slice(0, 200)) + '；按上传图排版，{城市}{明星} 为可替换主标题。';
            var s; try { s = await api('/api/poster/templates', { name: tplName, prompt: desc, imageB64: b64, layers: layers, stickers: _iwStickerUrls() }); } catch(e) { addLog('❌ 存③版式异常: ' + e.message, 'err'); return; }
            if (s.ok) {
                addLog('✅ 已存到③版式「' + tplName + '」，版式下拉可选', 'ok');
                if (box) box.innerHTML += '\n\n已存到③版式：' + tplName + '\n<img src="data:image/jpeg;base64,' + b64 + '" style="max-width:150px;border-radius:6px;margin-top:6px;">';
                try { loadPosterTemplates(); } catch(e){}
            } else addLog('❌ 存③版式失败: ' + (s.error || ''), 'err');
        };
        // 海报生成（城市+明星 → 完整海报，走 8093 海报服务）
        $('iwPosterBtn').onclick = async function() {
            var input = ($('iwBatchInput').value || '').trim();
            if (!input) { addLog('⚠ 请输入城市 明星', 'warn'); return; }
            var source = $('iwPosterSource').value;
            var localB64 = '';
            if (source === 'local') {
                // 本地上传模式：底图转 base64 发给服务端，统一叠同款紫块字
                if (!_iw.sourceUrl) { addLog('⚠ 本地上传模式：请先在高级工具 → 📁本地上传底图 / 📋粘贴底图', 'warn'); return; }
                try { localB64 = (await _iwSourceToDataURL()).replace(/^data:image\/[^;]+;base64,/, ''); }
                catch(e) { addLog('⚠ 底图转换失败: ' + e.message, 'warn'); return; }
            }
            var variant = $('iwPosterVariant').value;
            var lines = input.split('\n').filter(Boolean);
            var statusEl = $('iwBatchStatus');
            _iw.resultUrls = [];
            _iwRenderResults();
            var done = 0, fail = 0;
            for (var i = 0; i < lines.length; i++) {
                var m = _parseLine(lines[i]);
                var city = m.city, star = m.star;
                if (!star) { fail++; addLog('❌ 第' + (i+1) + '行格式不对: ' + lines[i], 'err'); continue; }
                statusEl.textContent = '⏳ ' + (i+1) + '/' + lines.length + ': ' + city + ' ' + star;
                try {
                    var useB64 = localB64;
                    if (!useB64 && _iw.candB64 && _iw.candKey === (source + '|' + city + '|' + star)) useB64 = _iw.candB64;
                    var p = { city: city, star: star, source: source, posterB64: useB64, ratio: '3:4' };
                    // 贴图版式（带 stickers 且无 file/blocks 的纯贴纸叠印版式）：要干净底图，不叠默认块，贴纸由前端 _iwApplyText 叠
                    var _selV = null;
                    for (var _pi = 0; _pi < _posterTplsCache.length; _pi++) { if (_posterTplsCache[_pi].id === _tplSel.value) { _selV = _posterTplsCache[_pi]; break; } }
                    var _isStickerOnly = !!( _selV && _selV.stickers && _selV.stickers.length && !_selV.file && !(_selV.blocks && _selV.blocks.length) );
                    var _isPureLayer = !!( _selV && _selV.layers && _selV.layers.length && !_selV.file && !(_selV.blocks && _selV.blocks.length) && !(_selV.stickers && _selV.stickers.length) );
                    if (_tplSel && (_tplSel.value === '__shoukai' || _tplSel.value === '__y2k' || _tplSel.value.indexOf('__layer:') === 0)) { p.templateId = ''; p.blocks = []; p.tags = []; }
                    else if (_tplSel && _isStickerOnly) { p.templateId = _tplSel.value; p.blocks = []; p.tags = []; } // 贴图版式(三紫块横幅): 服务端烘焙贴纸，前端只叠文字
                    else if (_tplSel && _isPureLayer) { p.templateId = ''; p.blocks = []; p.tags = []; } // 纯文字层版式(白底红字): 干净底图+叠文字层
                    else p.templateId = (_tplSel ? _tplSel.value : '');
                    // 版式块被用户编辑过 → 把编辑后的 blocks/tags 传给服务端覆盖默认（否则沿用版式原样）
                    if (_iw.blockDirty && _iw.blockLayout) { var bt = _iwBuildBlocksTags(); if (bt) { p.blocks = bt.blocks; p.tags = bt.tags; } }
                    var r = await api('/api/poster/make', p);
                    if (r.ok && r.imageB64) {
                        var _finalUrl = 'data:image/jpeg;base64,' + r.imageB64;
                        // 版式带文字层或贴图（如 贴图版式：横幅贴纸 + {城市}{明星}）：任一有内容就叠（否则横幅不显示）
                        if ((_iw.layers && _iw.layers.length) || (_iw.stickerImgs && _iw.stickerImgs.length)) {
                            // 确保贴纸图已加载完（避免缓存秒出时图还没加载好、横幅不显示）
                            try { if (_iw._stickerP) await _iw._stickerP; } catch(e){}
                            if (_isStickerOnly) { try { _iw.stickerImgs = []; } catch(e){} } // 服务端已烘焙贴纸：前端只叠文字，避免横幅重复
                            _finalUrl = await new Promise(function(resolve){
                                _iwApplyText(function(d){ resolve(d || _finalUrl); }, { city: city, star: star, sessionType: m.session, eventType: m.event }, 'data:image/jpeg;base64,' + r.imageB64, (_iw.layers && _iw.layers.length) ? _iw.layers : null);
                            });
                        }
                        _iw.resultUrls.push(_finalUrl);
                        _iw.resultMeta.push(m);
                        done++;
                        addLog('✅ ' + city + ' ' + star + '（' + (r.mode || source) + '）', 'ok');
                    } else {
                        fail++;
                        addLog('❌ ' + city + ' ' + star + ': ' + (r.error || '失败'), 'err');
                    }
                } catch(e) {
                    fail++;
                    addLog('❌ ' + city + ' ' + star + ': ' + (e.message || e), 'err');
                }
                _iwRenderResults();
            }
            statusEl.textContent = '✅ 完成 ' + done + ' 张' + (fail ? '，失败 ' + fail : '');
            // 成品自动设为底图：生成完直接进模板流程（加文字层→保存），不用再手动设
            if (done > 0 && _iw.resultUrls.length > 0) {
                if (_iw.sourceUrl && _iw.sourceUrl.startsWith('blob:')) URL.revokeObjectURL(_iw.sourceUrl);
                _iw.sourceUrl = _iw.resultUrls[0];
                $('iwSourcePreview').innerHTML = '<img src="' + _iw.sourceUrl + '" style="max-width:280px;max-height:200px;border-radius:8px;border:2px solid #E67E22;">';
                $('iwSourcePreview').style.display = '';
                addLog('📄 成品已自动设为底图，可 ➕ 文字层 后保存为模板', 'ok');
            }
        };
        // 借调性出图：用「刘宪华首开」拆解出的排版调性，换艺人/城市/文案直接出图（无人物，服务端 AI）
        var _jdBtn = $('iwJdBtn');
        if (_jdBtn) _jdBtn.onclick = async function() {
            var input = ($('iwBatchInput').value || '').trim();
            if (!input) { addLog('⚠ 请输入城市 明星', 'warn'); return; }
            var slogan = ($('iwJdSlogan') && $('iwJdSlogan').value.trim()) || '万人团队 不中全额退 战绩可查';
            var lines = input.split('\n').filter(Boolean);
            var statusEl = $('iwBatchStatus');
            _iw.resultUrls = []; _iw.resultMeta = [];
            _iwRenderResults();
            var done = 0, fail = 0;
            for (var i = 0; i < lines.length; i++) {
                var m = _parseLine(lines[i]);
                if (!m.star) { fail++; addLog('❌ 第' + (i+1) + '行格式不对: ' + lines[i], 'err'); continue; }
                var prompt = '音乐演唱会宣传海报，竖版 3:4。顶部中央一个大紫色矩形框，框内白色无衬线大字「' + (m.city || '') + ' ' + m.star + '」；中部一条红色粗体大字「' + slogan + '」带黑色描边；底部中央小字「' + (m.city || '') + '站」，左下角小字「9/20(SUN.) 7PM」；背景为舞台聚光灯、高对比度、暖色调，模糊的观众席氛围。画面中不出现具体人物。';
                statusEl.textContent = '⏳ 借调性出图 ' + (i+1) + '/' + lines.length + ': ' + m.city + ' ' + m.star + '（约30-60秒）';
                try {
                    var r = await api('/api/agent/studio-gen', { prompt: prompt, ratio: '3:4' });
                    if (r.ok && r.url) {
                        _iw.resultUrls.push(r.url);
                        _iw.resultMeta.push(m);
                        done++;
                        addLog('✅ ' + m.city + ' ' + m.star + ' 借调性海报已出', 'ok');
                    } else { fail++; addLog('❌ ' + m.city + ' ' + m.star + ': ' + (r.error || '失败'), 'err'); }
                } catch(e) { fail++; addLog('❌ ' + m.city + ' ' + m.star + ': ' + e.message, 'err'); }
                _iwRenderResults();
            }
            statusEl.textContent = '✅ 完成 ' + done + ' 张' + (fail ? '，失败 ' + fail : '');
            if (done > 0) addLog('📌 点「加入底图管理」可建任务并发布', 'info');
        };

        // 🟪 首开模板出图：底图(紫块模板) + 城市明星 + 底部日期/场馆参数化
        function _effW(s) {
            var e = 0;
            for (var i = 0; i < s.length; i++) {
                var c = s.charCodeAt(i);
                if (c > 0x2E80) e += 1; else if (s[i] === ' ') e += 0.5; else e += 0.55;
            }
            return e;
        }
        function drawShoukaiTemplate(city, star, date, venue) {
            return new Promise(function(resolve, reject) {
                var img = new Image();
                img.crossOrigin = 'anonymous';
                img.onload = function() {
                    var W = 1080, H = 1440;
                    var canvas = document.createElement('canvas');
                    canvas.width = W; canvas.height = H;
                    var ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, W, H);
                    // 紫块：78%宽 16%高，红字顶34% - 7%间距
                    var blockW = Math.round(W * 0.78), blockH = Math.round(H * 0.16);
                    var bx = Math.round((W - blockW) / 2);
                    var by = Math.round(H * 0.34) - Math.round(H * 0.07) - blockH;
                    var r = Math.round(blockH * 0.10);
                    ctx.fillStyle = '#D81AF8';
                    ctx.beginPath();
                    ctx.moveTo(bx + r, by);
                    ctx.arcTo(bx + blockW, by, bx + blockW, by + blockH, r);
                    ctx.arcTo(bx + blockW, by + blockH, bx, by + blockH, r);
                    ctx.arcTo(bx, by + blockH, bx, by, r);
                    ctx.arcTo(bx, by, bx + blockW, by, r);
                    ctx.closePath();
                    ctx.fill();
                    // 白字标题（超长自动缩）
                    var title = city + ' ' + star;
                    var fsTitle = Math.min(Math.round(H * 0.12), Math.round((blockW - blockH * 0.12) / _effW(title)));
                    ctx.font = 'bold ' + fsTitle + 'px "Microsoft YaHei","PingFang SC",sans-serif';
                    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
                    ctx.fillStyle = '#ffffff';
                    ctx.fillText(title, W / 2, by + blockH / 2);
                    // 底部参数化
                    var bottom = city + '站 ' + date + ' ' + venue + ' 票价详询';
                    var fsB = Math.min(Math.round(H * 0.026), Math.round((W * 0.94) / _effW(bottom)));
                    ctx.font = fsB + 'px "Microsoft YaHei","PingFang SC",sans-serif';
                    ctx.fillStyle = '#000000';
                    ctx.fillText(bottom, W / 2, Math.round(H * 0.88));
                    resolve(canvas.toDataURL('image/jpeg', 0.92));
                };
                img.onerror = function() { reject(new Error('底图加载失败')); };
                img.src = API + '/首开样式-背景模板.png';
            });
        }
        var _skBtn = $('iwSkBtn');
        if (_skBtn) _skBtn.onclick = async function() {
            var input = ($('iwBatchInput').value || '').trim();
            if (!input) { addLog('⚠ 请输入城市 明星', 'warn'); return; }
            var date = ($('iwSkDate') && $('iwSkDate').value.trim()) || '';
            var venue = ($('iwSkVenue') && $('iwSkVenue').value.trim()) || '';
            var lines = input.split('\n').filter(Boolean);
            var statusEl = $('iwBatchStatus');
            _iw.resultUrls = []; _iw.resultMeta = [];
            _iwRenderResults();
            var done = 0, fail = 0;
            for (var i = 0; i < lines.length; i++) {
                var m = _parseLine(lines[i]);
                if (!m.star) { fail++; addLog('❌ 第' + (i+1) + '行格式不对: ' + lines[i], 'err'); continue; }
                statusEl.textContent = '⏳ ' + (i+1) + '/' + lines.length + ': ' + m.city + ' ' + m.star;
                try {
                    var dataUrl = await drawShoukaiTemplate(m.city, m.star, date, venue);
                    _iw.resultUrls.push(dataUrl);
                    _iw.resultMeta.push(m);
                    done++;
                    addLog('✅ ' + m.city + ' ' + m.star + ' 首开模板出图完成', 'ok');
                } catch(e) { fail++; addLog('❌ ' + m.city + ' ' + m.star + ': ' + e.message, 'err'); }
                _iwRenderResults();
            }
            statusEl.textContent = '✅ 完成 ' + done + ' 张' + (fail ? '，失败 ' + fail : '');
            if (done > 0) addLog('📌 点「加入底图管理」可建任务并发布', 'info');
        };

        // 近期记录
        $('iwJobsBtn').onclick = async function() {
            try {
                var r = await api('/api/agent/studio-jobs', {});
                if (r.ok && r.data) {
                    var list = Array.isArray(r.data) ? r.data : [];
                    addLog('🕐 近期 ' + list.length + ' 条记录', 'info');
                } else { addLog('⚠ 获取失败', 'warn'); }
            } catch(e) { addLog('❌ ' + e.message, 'err'); }
        };
                // 竞品分析
        $('iwCompetitorBtn').onclick = async function() {
            var keyword = ($('iwCompetitorKeyword').value || '').trim() || '开通鱼小铺';
            addLog('🔍 竞品分析: 搜索「' + keyword + '」...', 'info');
            $('iwCompetitorBtn').disabled = true;
            try {
                var navUrl = 'https://www.goofish.com/search?q=' + encodeURIComponent(keyword);
                await api('/api/agent/navigate', { url: navUrl });
                addLog('📡 已打开搜索结果', 'dim');
                await new Promise(function(r) { setTimeout(r, 4000); });

                // 点"新发布"
                await evalOnStore(state.currentStore,
                    '(function(){var els=document.querySelectorAll("*");for(var i=0;i<els.length;i++){if(els[i].textContent.trim()==="新发布"&&els[i].children.length<=1){els[i].dispatchEvent(new MouseEvent("click",{bubbles:true}));break;}}return "ok";})()'
                );
                await new Promise(function(r) { setTimeout(r, 2000); });

                // 点"3天内"
                await evalOnStore(state.currentStore,
                    '(function(){var els=document.querySelectorAll("*");for(var i=0;i<els.length;i++){var t=els[i].textContent.trim();if((t.indexOf("3天内")>=0||t.indexOf("三天内")>=0)&&els[i].children.length<=1){els[i].dispatchEvent(new MouseEvent("click",{bubbles:true}));break;}}return "ok";})()'
                );
                await new Promise(function(r) { setTimeout(r, 3000); });

                // 抓取结果
                var scrapeResult = await evalOnStore(state.currentStore,
                    '(function(){var items=[];var all=document.querySelectorAll("*");var wantEls=[];for(var i=0;i<all.length;i++){if(all[i].children.length===0&&all[i].textContent.match(/\\d+人想要/)){wantEls.push(all[i]);}}wantEls.forEach(function(el){var want=parseInt((el.textContent.match(/(\\d+)人想要/)||[0])[1]);var card=el;for(var j=0;j<10&&card;j++){card=card.parentElement;if(!card)break;var img=card.querySelector("img");if(img&&img.src&&!img.src.startsWith("data:")&&(img.src.indexOf("alicdn")>=0||img.src.indexOf("gw.alicdn")>=0)){var title=card.textContent.split("想要")[0].trim();title=title.split("\\n").pop().substring(0,80);items.push({want:want,img:img.src,title:title});break;}}});items.sort(function(a,b){return b.want-a.want});return JSON.stringify(items.slice(0,5));})()'
                );

                if (scrapeResult.ok && scrapeResult.result) {
                    var topItems = JSON.parse(scrapeResult.result);
                    addLog('✅ 找到 ' + topItems.length + ' 个热门商品', 'ok');
                    for (var i = 0; i < topItems.length; i++) {
                        var item = topItems[i];
                        if (item.img) {
                            state.images.push({ name: '竞品_' + (i+1) + '_' + item.want + '想要', thumbUrl: item.img, saved: true });
                            addLog('  ' + (i+1) + '. ' + item.want + '想要: ' + (item.title||'').substring(0,40), 'dim');
                        }
                    }
                    renderImages();
                    autoCreateTasks();
                } else {
                    addLog('⚠ 抓取失败，请检查店铺是否已启动', 'warn');
                }
                // 恢复到 goofish 首页
                setTimeout(function() {
                    api('/api/agent/navigate', { url: 'https://www.goofish.com/' }).catch(function(){});
                }, 2000);
            } catch(e) {
                addLog('❌ 竞品分析失败: ' + (e.message || e), 'err');
            }
            $('iwCompetitorBtn').disabled = false;
        };

// 粘贴支持
        $('iwPasteBtn').onclick = async function() {
            try {
                // 先试剪贴板图片
                if (navigator.clipboard && navigator.clipboard.read) {
                    var items = await navigator.clipboard.read();
                    for (var i = 0; i < items.length; i++) {
                        var types = items[i].types || [];
                        var imgType = null;
                        for (var t = 0; t < types.length; t++) { if (types[t].indexOf('image/') === 0) { imgType = types[t]; break; } }
                        if (imgType) {
                            var blob = await items[i].getType(imgType);
                            if (_iw.sourceUrl && _iw.sourceUrl.startsWith('blob:')) URL.revokeObjectURL(_iw.sourceUrl);
                            _iw.sourceUrl = URL.createObjectURL(blob);
                            $('iwSourcePreview').innerHTML = '<img src="' + _iw.sourceUrl + '" style="max-width:280px;max-height:200px;border-radius:8px;border:2px solid #E67E22;">';
                            $('iwSourcePreview').style.display = '';
                            addLog('📋 已粘贴图片作为底图', 'ok');
                            return;
                        }
                    }
                }
                // 再试文字链接
                var text = await navigator.clipboard.readText();
                text = (text || '').trim();
                if (text.indexOf('http') === 0) {
                    if (_iw.sourceUrl && _iw.sourceUrl.startsWith('blob:')) URL.revokeObjectURL(_iw.sourceUrl);
                    _iw.sourceUrl = text;
                    $('iwSourcePreview').innerHTML = '<img src="' + text + '" style="max-width:280px;max-height:200px;border-radius:8px;border:2px solid #E67E22;">';
                    $('iwSourcePreview').style.display = '';
                    addLog('🔗 已使用链接底图', 'ok');
                } else {
                    addLog('⚠ 剪贴板里没有图片或链接', 'warn');
                }
            } catch(e) { addLog('⚠ 粘贴失败: ' + (e.message || e) + '（也可在页面按 Ctrl+V）', 'warn'); }
        };
        document.addEventListener('paste', function(e) {
            if ($('imageWorkshop') && $('imageWorkshop').style.display === 'none') return;
            var items = e.clipboardData && e.clipboardData.items;
            if (!items) return;
            for (var pi = 0; pi < items.length; pi++) {
                if (items[pi].type.startsWith('image/')) {
                    e.preventDefault();
                    var blob = items[pi].getAsFile();
                    if (_iw.sourceUrl && _iw.sourceUrl.startsWith('blob:')) URL.revokeObjectURL(_iw.sourceUrl);
                    _iw.sourceUrl = URL.createObjectURL(blob);
                    $('iwSourcePreview').innerHTML = '<img src="' + _iw.sourceUrl + '" style="max-width:280px;max-height:200px;border-radius:8px;border:2px solid #E67E22;">';
                    $('iwSourcePreview').style.display = '';
                    addLog('📋 图片已粘贴', 'info');
                    return;
                }
            }
        });
        // 加载余额
        window.refreshStudioCredits = function() {
            var el = $('studioCredits');
            api('/api/agent/studio-balance').then(function(bal) {
                if (bal.ok) {
                    var c = bal.credits || bal.creation_credits || '?';
                    if (el) el.textContent = '💰 ' + c + ' credits';
                }
            }).catch(function(){});
        };
        window.refreshStudioCredits();
        // 初始化模板下拉
        _iwRenderTplSelect();
    }

    // ===== 店铺就绪检查 + 自动启动 =====
    async function checkStoreReady(storeName) {
        var store = storeName || state.currentStore;
        if (!store) {
            $('cookieBadge').className = 'cookie-status unknown';
            $('cookieBadge').textContent = '🔍 未选择';
            return;
        }
        // 防重复启动：同一店铺已在启动/就绪时跳过，避免双开浏览器
        if (state._startingStores && state._startingStores[store]) return;
        if (!state._startingStores) state._startingStores = {};
        state._startingStores[store] = true;

        $('cookieBadge').className = 'cookie-status unknown';
        $('cookieBadge').textContent = '⏳ 启动中...';
        $('btnPublishAll').disabled = true;

        try {
            // 步骤1：确保 agent 已启动
            var health = await api('/health');
            if (!health.running) {
                addLog('🔧 Playwright 服务未启动，正在初始化...', 'info');
                var startAll = await api('/api/agent/start-all', {});
                if (!startAll.ok) {
                    $('cookieBadge').className = 'cookie-status none';
                    $('cookieBadge').textContent = '❌ 启动失败';
                    addLog('❌ 服务初始化失败: ' + (startAll.error || ''), 'err');
                    return;
                }
                addLog('✅ 服务已初始化', 'ok');
            }

            // 步骤2：启动指定店铺
            addLog('🚀 启动店铺「' + store + '」...', 'info');
            var startOne = await api('/api/agent/start-one', { name: store });

            if (!startOne.ok) {
                $('cookieBadge').className = 'cookie-status none';
                $('cookieBadge').textContent = '❌ 启动失败';
                addLog('❌ 店铺启动失败: ' + (startOne.error || ''), 'err');
                state._startingStores[store] = false;
                return;
            }

            // 步骤3：等页面加载（goofish 页面已在 switchTo 里打开）
            addLog('⏳ 等待闲鱼页面加载...', 'dim');
            await sleep(3000);

            // 步骤4：检查页面就绪
            try {
                var check = await evalOnStore(store, '!!window.kunPublish');
                if (check.ok && check.result === true) {
                    $('cookieBadge').className = 'cookie-status ok';
                    $('cookieBadge').textContent = '✅ 就绪';
                    $('btnPublishAll').disabled = state.selectedStores.length === 0;
                    updatePublishButtons();
                    addLog('✅ 店铺「' + store + '」已就绪', 'ok');
                    if (store === state.currentStore) await loadStoreTemplates();
                } else {
                    $('cookieBadge').className = 'cookie-status none';
                    $('cookieBadge').textContent = '⚠ 页面未就绪';
                    $('btnPublishAll').disabled = state.selectedStores.length === 0;
                    updatePublishButtons();
                    addLog('⚠ 页面脚本未加载，可以尝试发布（会自动注入）', 'warn');
                }
            } catch(e) {
                $('cookieBadge').className = 'cookie-status none';
                $('cookieBadge').textContent = '⚠ 未就绪';
                $('btnPublishAll').disabled = state.selectedStores.length === 0;
                updatePublishButtons();
                addLog('⚠ 店铺未就绪: ' + e.message, 'warn');
            }
            state._startingStores[store] = false;
        } catch(e) {
            // P1-2：8093 服务未启动/网络异常时兜底，避免未捕获 rejection 导致按钮永久卡住
            state._startingStores[store] = false;
            $('cookieBadge').className = 'cookie-status none';
            $('cookieBadge').textContent = '❌ 服务不可用';
            $('btnPublishAll').disabled = state.selectedStores.length === 0;
            updatePublishButtons();
            addLog('❌ 无法连接本地 Playwright 服务：' + (e && e.message ? e.message : e) + '。请先启动 Playwright 服务（运行 start.bat，服务端口 8093）。', 'err');
        }
    }

    function sleep(ms) { return new Promise(function(r) { setTimeout(r, ms); }); }

    function updatePublishButtons() {
        var has = state.selectedStores.length > 0;
        $('btnPublishAll').disabled = !has;
        var _b1 = $('btnPublishOne'); if (_b1) _b1.disabled = !has;
        var _b2 = $('btnBatchPublish'); if (_b2) _b2.disabled = !has;
        var _b3 = $('btnQuickPublish'); if (_b3) _b3.disabled = !has;
    }
    function updateScrapeCard() {
        var el = $('scrapeStoreName');
        if (el) el.textContent = state.currentStore || '未选店铺';
    }

    // ===== 文件名解析 → 自动建任务 =====
    // 开票轮次。⚠️ 与 publish.js 是【同一份清单的两处副本】，必须同步改。
    // 2026-10-04：补「一开」；「捡漏回流」拆成「捡漏」「回流」。
    // 2026-10-06：加「回流捡漏」（4 字，排序后自动排最前，优先命中，不被「捡漏」先吃掉）。
    var SESSION_TYPES = ['回流捡漏', '首开', '一开', '二开', '三开', '捡漏', '回流'];
    var KNOWN_CITIES = [
        '哈尔滨','乌鲁木齐','石家庄','呼和浩特','连云港','驻马店','齐齐哈尔',
        '北京','上海','广州','深圳','杭州','成都','武汉','南京','苏州','重庆',
        '长沙','青岛','西安','厦门','天津','大连','沈阳','长春','郑州','洛阳',
        '济南','太原','合肥','南昌','福州','昆明','南宁','贵阳','兰州','银川',
        '香港','西宁','海口','三亚','拉萨','徐州','温州','宁波','无锡','佛山','东莞',
        '珠海','中山','惠州','汕头','桂林','丽江','大理','襄阳','宜昌','株洲',
        '绵阳','泸州','南充','德阳','宜宾','遵义','赣州','上饶','九江','衡阳',
        '岳阳','开封','新乡','南阳','许昌','淄博','烟台','潍坊','临沂','保定',
        '廊坊','唐山','秦皇岛','鞍山','锦州','吉林','延吉','绍兴','金华','台州',
        '嘉兴','湖州','莆田','泉州','漳州','湛江','江门','肇庆','茂名','清远',
        '柳州','梧州','北海','宜昌','黄石','十堰','咸宁','荆门','鄂州','黄冈'
    ];

    function parseFileName(fileName) {
        var name = fileName.replace(/\.[^.]+$/, '').trim();
        var sessionType = '';

        // 匹配场次
        var types = SESSION_TYPES.slice().sort(function(a, b) { return b.length - a.length; });
        for (var t = 0; t < types.length; t++) {
            var idx = name.indexOf(types[t]);
            if (idx >= 0) {
                sessionType = types[t];
                name = name.replace(types[t], '').trim();
                break;
            }
        }

        // 匹配城市（按长度倒序，优先长城市名）
        var cities = KNOWN_CITIES.slice().sort(function(a, b) { return b.length - a.length; });
        var city = '';
        var star = name;
        for (var c = 0; c < cities.length; c++) {
            var ci = name.indexOf(cities[c]);
            if (ci >= 0) {
                city = cities[c];
                star = name.replace(cities[c], '').trim();
                break;
            }
        }

        // 匹配活动类型
        var eventType = '演唱会';
        var eventTypes = ['总决赛','半决赛','常规赛','试听会','脱口秀','戏剧','话剧','音乐节','音乐剧','歌剧','舞剧','见面会','签售会','巡演','演唱会','演出'];
        for (var e = 0; e < eventTypes.length; e++) {
            if (name.indexOf(eventTypes[e]) >= 0) { eventType = eventTypes[e]; break; }
        }

        return { star: star, city: city, sessionType: sessionType, eventType: eventType };
    }

    // ===== 图片处理 =====
    var IMAGES_ROOT = 'C:/Users/43462/Desktop/闲鱼上架图片/';
    function getImagesFolder() {
        return IMAGES_ROOT + (state.currentStore ? state.currentStore + '/' : '');
    }
    // P0-6：上传的图同时写盘（发布时页面从磁盘目录读文件，刷新后也能恢复缩略图）
    async function persistImage(name, base64) {
        try {
            var r = await nativeHost({ action: 'writeImage', path: getImagesFolder() + name, base64: base64 });
            if (r && r.ok) return true;
            addLog('⚠ 图片写盘失败: ' + ((r && r.error) || '未知'), 'warn');
        } catch(e) { addLog('⚠ 图片写盘失败: ' + e.message, 'warn'); }
        return false;
    }

    // 裂变图片直接加入底图管理
    function addFissionImage(dataUrl) {
        var name = 'fission_' + Date.now() + '_' + Math.floor(Math.random()*1000) + '.png';
        if (state.images.some(function(img) { return img.name === name; })) return;
        var b64 = String(dataUrl).split(',')[1] || '';
        if (b64) persistImage(name, b64); // P0-6：裂变图也写盘
        state.images.push({ name: name, thumbUrl: dataUrl, saved: true });
        renderImages();
        autoCreateTasks();
        addLog('🖼 裂变图已加入底图管理', 'info');
    }

    async function handleFiles(files) {
        var list = Array.prototype.slice.call(files || []);
        var added = 0, skippedType = 0, renamed = 0;
        for (var i = 0; i < list.length; i++) {
            var file = list[i];
            if (!file.type || file.type.indexOf('image/') !== 0) { skippedType++; continue; }
            // 同名不再静默丢弃：自动加 _2/_3 后缀。
            // 旧写法直接 continue，用户传两张同名图（不同文件夹导出的图很常见）会以为「只显示一张」。
            var finalName = file.name, seq = 1;
            while (state.images.some(function(img) { return img.name === finalName; })) {
                seq++; renamed++;
                var _dot = file.name.lastIndexOf('.');
                finalName = _dot > 0
                    ? file.name.substring(0, _dot) + '_' + seq + file.name.substring(_dot)
                    : file.name + '_' + seq;
            }
            // P0-6：读 base64 并写盘（发布时页面按文件名从磁盘目录读取）
            var b64 = '';
            try { b64 = await readFileAsBase64(file); } catch(e) {}
            var saved = false;
            if (b64) saved = await persistImage(finalName, b64);
            state.images.push({ name: finalName, thumbUrl: URL.createObjectURL(file), saved: saved });
            added++;
        }
        renderImages();
        if (skippedType > 0) addLog('⚠ 跳过 ' + skippedType + ' 个非图片文件', 'warn');
        if (renamed > 0) addLog('🔧 有 ' + renamed + " 张图与现有底图重名，已自动改名（原名会被覆盖的风险已避开）", 'dim');
        if (added > 0) {
            addLog('🖼 已添加 ' + added + ' 张图片' + (state.currentStore ? '（店铺:' + state.currentStore + '）' : '（未选店铺，写入根目录）'), 'info');
            autoCreateTasks();
        }
    }

    // 上传图片后自动创建任务（每张图一条）
    function autoCreateTasks() {
        var tpl = getActiveTemplate();
        for (var i = 0; i < state.images.length; i++) {
            var img = state.images[i];
            // 已有同名任务则跳过
            var exists = state.tasks.some(function(t) { return t.imageName === img.name; });
            if (exists) continue;

            var parsed = parseFileName(img.name);
            state.tasks.push({
                star: parsed.star,
                city: parsed.city,
                eventType: parsed.eventType,
                sessionType: parsed.sessionType,
                categoryName: tpl.categoryName,
                price: tpl.price,
                stock: tpl.stock,
                imageName: img.name
            });
            addLog('📝 自动建任务: ' + (parsed.city || '') + ' ' + (parsed.star || '') + ' ' + (parsed.sessionType || ''), 'dim');
        }
        renderTasks();
    }

    function readFileAsBase64(file) {
        return new Promise(function(resolve) {
            var reader = new FileReader();
            reader.onload = function() { resolve(reader.result.split(',')[1]); };
            reader.readAsDataURL(file);
        });
    }

    function renderImages() {
        var container = $('imgGallery');
        $('imageCount').textContent = state.images.length + ' 张';
        if (state.images.length === 0) {
            container.innerHTML = '';
            return;
        }
        var html = '';
        for (var i = 0; i < state.images.length; i++) {
            var img = state.images[i];
            var src = img.thumbUrl || img.url || '';
            var showImg = !!src;
            html += '<div style="position:relative;width:72px;height:72px;">' +
                (showImg 
                ? '<img src="' + src + '" style="width:72px;height:72px;border-radius:8px;object-fit:cover;border:2px solid ' + (img.url ? '#27ae60' : '#ccc') + ';" title="' + esc(img.name) + '">'
                : '<div style="width:72px;height:72px;border-radius:8px;border:2px solid #eee;display:flex;align-items:center;justify-content:center;text-align:center;font-size:9px;color:#999;background:#f5f5f5;">' + esc(img.name.replace(/^.*[\\/]/, '').substring(0, 12)) + '</div>') +
                (img.uploading ? '<div style="position:absolute;inset:0;background:rgba(0,0,0,0.5);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:20px;">⏳</div>' : '') +
                '<div data-act="delimg" data-idx="' + i + '" style="position:absolute;top:-6px;right:-6px;width:18px;height:18px;background:#e74c3c;color:#fff;border-radius:50%;font-size:10px;line-height:18px;text-align:center;cursor:pointer;" class="img-del-' + i + '">×</div>' +
                '</div>';
        }
        container.innerHTML = html;
        // 绑定图片删除
        container.querySelectorAll('[data-act="delimg"]').forEach(function(el) {
            el.addEventListener('click', function() {
                var idx = parseInt(this.dataset.idx);
                state.images.splice(idx, 1);
                renderImages();
            });
        });
        saveStoreData();
    }
    // ===== 任务管理 =====
    function addTask() {
        var tpl = getActiveTemplate();
        state.tasks.push({
            star: '',
            city: '',
            eventType: '演唱会',
            sessionType: '首开',
            categoryName: tpl.categoryName,
            price: tpl.price,
            stock: tpl.stock,
            imageName: state.images.length > 0 ? state.images[0].name : ''
        });
        renderTasks();
    }

    function getActiveTemplate() {
        for (var i = 0; i < state.templates.length; i++) {
            if (state.templates[i].id === state.activeTemplateId) return state.templates[i];
        }
        return state.templates[0];
    }

    // 标题微调（与 publish.js 同步）
    var _PD_SYN = [
        ['开通', ['开启', '激活', '代办开通']],
        ['快速', ['极速', '迅速', '快捷']],
        ['极速', ['快速', '迅速', '光速']],
        ['入口', ['渠道', '通道', '直通车']],
        ['秒开', ['快开', '秒开通', '立即开']],
        ['100%', ['百分百', '必定', '100%成功']],
        ['百分百', ['100%', '全部', '必成']],
        ['失败包退', ['不过全退', '失败退款', '未开通退款']],
        ['官方邀约', ['平台邀约', '官方渠道', '正规邀约']],
        ['新老号', ['所有号', '新旧号', '全部账号']],
        ['三分钟', ['3分钟', '两三分钟', '几分钟']],
        ['2分钟', ['两分钟', '2-3分钟', '1分钟']],
        ['无二次收费', ['一次收费', '无额外费用', '无隐形消费']],
        ['标价开', ['标价即开', '标价就开', '拍下即开']],
        ['直接开', ['马上开', '立即开', '即刻开']],
    ];
    function _pdTweakTitle(title, seed) {
        seed = seed || 0;
        function _rand(n) { var x = Math.sin(seed * 9301 + 49297 + n * 233) * 233280; return x - Math.floor(x); }
        var avail = [];
        for (var i = 0; i < _PD_SYN.length; i++) {
            if (title.indexOf(_PD_SYN[i][0]) >= 0) avail.push(_PD_SYN[i]);
        }
        if (avail.length === 0) return title;
        // 用种子确定性排序，不用 Math.random
        var order = [];
        for (var oi = 0; oi < avail.length; oi++) order.push(oi);
        order.sort(function(a, b) { return _rand(a) - _rand(b); });
        var sorted = order.map(function(oi) { return avail[oi]; });
        sorted.sort(function(a, b) { return b[0].length - a[0].length; });
        // 替换量 ≈ 15%：至少2个，最多取总数的60%
        var count = Math.max(2, Math.min(sorted.length, Math.ceil(sorted.length * 0.6)));
        // 用 seed 选具体替换数
        var actualCount = 2 + Math.floor(_rand(100) * Math.max(1, count - 1));
        actualCount = Math.min(actualCount, sorted.length);
        for (var p = 0; p < actualCount; p++) {
            var alts = sorted[p][1];
            var pick = Math.floor(_rand(p + 200) * alts.length);
            title = title.replace(sorted[p][0], alts[pick]);
        }
        return title;
    }

    function renderTasks() {
        var container = $('taskTableWrap');
        $('taskCount').textContent = state.tasks.length + ' 个';
        if (state.tasks.length === 0) {
            container.innerHTML = '<div class="empty-state"><div class="icon">📋</div><div>还没有任务，点击"添加"创建</div></div>';
            saveStoreData(); // P0-2：删除最后一个任务也要落盘，否则刷新/切店后旧任务会从磁盘回来
            return;
        }
        var cities = KNOWN_CITIES;
        // 2026-10-04：老板点名要的 6 个排在最前（演唱会/见面会/音乐节/话剧/戏剧/脱口秀），
        // 原有的 4 个赛事类保留在后面，避免删掉体育票务的下拉项。
        var events = ['演唱会','见面会','音乐节','话剧','戏剧','脱口秀','总决赛','试听会','半决赛','常规赛'];
        var sessions = ['首开','二开','三开','捡漏回流'];
        var cats = ['代购','创业/副业培训','技能类招工','互联网产品与运营技能培训'];
        var imgNames = state.images.map(function(img) { return img.name; });

        function sel(field, options, current) {
            // 确保 current 在列表里，否则加到最前面
            if (current && options.indexOf(current) < 0) options = [current].concat(options);
            var h = '<select class="tsk-sel" data-field="' + field + '" style="width:100%;padding:4px 2px;border:1px solid #ddd;border-radius:4px;font-size:11px;">';
            for (var i = 0; i < options.length; i++) {
                h += '<option value="' + esc(options[i]) + '"' + (options[i] === current ? ' selected' : '') + '>' + esc(options[i]) + '</option>';
            }
            return h + '</select>';
        }

        var tplNames = state.templates.map(function(t) { return t.name; });
        var storeNames = state.accounts.map(function(a) { return a.name; });
        // 城市 datalist（搜索用）
        var cityListHtml = '';
        for (var ci = 0; ci < KNOWN_CITIES.length; ci++) {
            cityListHtml += '<option value="' + esc(KNOWN_CITIES[ci]) + '">';
        }

        var isSimpleStore = state.selectedStores.length === 1;
        var html = '<datalist id="cityList">' + cityListHtml + '</datalist><table class="task-table"><thead><tr>' +
            '<th>模板</th><th>明星</th><th>城市</th><th>活动</th><th>场次</th><th>分类</th><th>价格</th><th>库存</th><th>图片</th><th>店</th><th></th>' +
            '</tr></thead><tbody>';
        // 瘦身：只看待发 + 按城市分组
        var _onlyPending = ($('tOnlyPending') && $('tOnlyPending').checked);
        var _byCity = ($('tByCity') && $('tByCity').checked);
        var _rows = [];
        for (var _ri = 0; _ri < state.tasks.length; _ri++) {
            var _rt = state.tasks[_ri];
            if (_onlyPending && (_rt.status === 'done' || _rt.status === 'failed' || _rt.itemId)) continue;
            _rows.push({ idx: _ri, t: _rt });
        }
        if (_byCity) _rows.sort(function(a, b) { return String(a.t.city || '').localeCompare(String(b.t.city || ''), 'zh'); });
        for (var k = 0; k < _rows.length; k++) {
            var i = _rows[k].idx;
            var t = _rows[k].t;
            if (_byCity) {
                var _city = t.city || '(无)';
                var _prevCity = k > 0 ? (_rows[k-1].t.city || '(无)') : null;
                if (_prevCity !== _city) html += '<tr class="city-head"><td colspan="11" style="background:#f0f4ff;color:#3050a0;font-weight:bold;padding:4px 8px;font-size:12px;">📍 ' + esc(_city) + '</td></tr>';
            }
            // 单店模式：图片下拉框排除已被其他行占用的
            var rowImgNames = imgNames;
            if (isSimpleStore) {
                rowImgNames = imgNames.filter(function(n) {
                    for (var oi = 0; oi < state.tasks.length; oi++) {
                        if (oi === i) continue;
                        if (state.tasks[oi].imageName === n) return false;
                    }
                    return true;
                });
            }
            html += '<tr data-idx="' + i + '">' +
                '<td>' + sel('templateName', ['随机'].concat(tplNames), t.templateName || '随机') + '</td>' +
                '<td><input class="tsk-inp" data-field="star" value="' + esc(t.star) + '" style="width:60px;padding:4px;border:1px solid #ddd;border-radius:4px;font-size:11px;"></td>' +
                '<td><input class="tsk-inp" data-field="city" value="' + esc(t.city) + '" list="cityList" placeholder="搜索城市" style="width:70px;padding:4px;border:1px solid #ddd;border-radius:4px;font-size:11px;"></td>' +
                '<td>' + sel('eventType', events, t.eventType) + '</td>' +
                '<td>' + sel('sessionType', sessions, t.sessionType) + '</td>' +
                '<td>' + sel('categoryName', cats, t.categoryName) + '</td>' +
                '<td><input class="tsk-inp" data-field="price" value="' + esc(t.price) + '" style="width:45px;padding:4px;border:1px solid #ddd;border-radius:4px;font-size:11px;"></td>' +
                '<td><input class="tsk-inp" data-field="stock" value="' + esc(t.stock) + '" style="width:50px;padding:4px;border:1px solid #ddd;border-radius:4px;font-size:11px;"></td>' +
                '<td>' + sel('imageName', rowImgNames.length > 0 ? rowImgNames : ['(无图片)'], t.imageName) + '</td>' +
                '<td>' + sel('targetStore', ['(未分配)'].concat(storeNames), t.targetStore || '') + '</td>' +
                '<td><button data-act="preview" data-idx="' + i + '" style="background:#e8f4fd;color:#4A90D9;border:1px solid #b3d4f0;border-radius:4px;padding:2px 6px;cursor:pointer;font-size:11px;margin-right:2px;">👁</button>' +
                '<button data-act="delete" data-idx="' + i + '" style="background:#fff0f0;color:#e74c3c;border:1px solid #ffccc7;border-radius:4px;padding:2px 6px;cursor:pointer;font-size:11px;">✕</button>' +
                ((t.status === 'done' || t.status === 'failed' || t.itemId) ? '<button data-act="reset" data-idx="' + i + '" title="重置为待发（清空商品ID后可重发）" style="background:#fff7e6;color:#d48806;border:1px solid #ffe58f;border-radius:4px;padding:2px 6px;cursor:pointer;font-size:11px;margin-left:2px;">🔄</button>' : '') +
                '<span style="margin-left:4px;font-size:12px;">' + (t.status === 'done' ? '✅' : t.status === 'failed' ? '❌' : '⬜') + '</span></td>' +
                '</tr>';
        }
        html += '</tbody></table>';
        container.innerHTML = html;

        // 绑定编辑
        container.querySelectorAll('.tsk-inp, .tsk-sel').forEach(function(el) {
            var handler = function() {
                var row = el.closest('tr');
                var idx = parseInt(row.dataset.idx);
                state.tasks[idx][el.dataset.field] = el.value;
                scheduleSave(); // P0-2：编辑防抖落盘，切店/刷新不丢
                // 单店模式：图片选了就刷新去重
                if (el.dataset.field === 'imageName' && state.selectedStores.length === 1) renderTasks();
            };
            el.onchange = handler;
            el.oninput = handler;
        });
        // 绑定预览和删除按钮
        container.querySelectorAll('button[data-act]').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var act = this.dataset.act;
                var idx = parseInt(this.dataset.idx);
                if (act === 'preview') window._pdPreviewTask(idx);
                else if (act === 'delete') { state.tasks.splice(idx, 1); renderTasks(); try { saveStoreData(true); } catch(e){} } // 整份覆盖，真正从磁盘删除
                else if (act === 'reset') {
                    var rt = state.tasks[idx];
                    if (rt && confirm('重置「' + (rt.star || '') + ' ' + (rt.city || '') + '」为待发？\n\n将清空商品ID和状态，再次发布会生成新链接（可能造成重复上架）。')) {
                        delete rt.itemId; delete rt.error;
                        rt.status = 'pending';
                        renderTasks();
                        try { saveStoreData(true); } catch(e){} // 整份覆盖：否则磁盘上带 itemId 的旧版本会被"保留"导致重置失效
                        addLog('🔄 已重置为待发: ' + (rt.star || '') + ' ' + (rt.city || '') + (rt.sessionType ? ' ' + rt.sessionType : ''));
                    }
                }
            });
        });
        saveStoreData();
    }
    // 搬运任务预览：直接用搬运来的标题/描述，不走演唱会模板
    function _previewScrapedTask(task) {
        var urls = (Array.isArray(task.imageUrls) && task.imageUrls.length > 0) ? task.imageUrls : (task.imageUrl ? [task.imageUrl] : []);
        var imgUrl = '';
        for (var pi = 0; pi < urls.length; pi++) { if (urls[pi] && urls[pi].indexOf('http') === 0) { imgUrl = urls[pi]; break; } }
        var modal = document.createElement('div');
        modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.4);z-index:10000;display:flex;align-items:center;justify-content:center;';
        var box = document.createElement('div');
        box.style.cssText = 'background:#fff;border-radius:12px;padding:24px;width:520px;max-height:85vh;overflow-y:auto;box-shadow:0 8px 32px rgba(0,0,0,0.2);';
        box.innerHTML = '' +
            '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">' +
            '<span style="font-size:16px;font-weight:600;">👁 发布预览（搬运商品）</span>' +
            '<button id="pdSClose1" style="background:none;border:none;font-size:20px;color:#999;cursor:pointer;">✕</button>' +
            '</div>' +
            (imgUrl ? '<div style="text-align:center;margin-bottom:8px;"><img src="' + imgUrl + '" style="max-width:180px;max-height:180px;border-radius:8px;border:2px solid #E67E22;"><div style="font-size:10px;color:#E67E22;margin-top:2px;">主图（共 ' + urls.length + ' 张）</div></div>' : '') +
            '<div style="margin-bottom:8px;"><span style="font-size:11px;color:#999;">标题（搬运原文）</span><div style="font-size:14px;font-weight:600;line-height:1.5;padding:8px;background:#f8f9fa;border-radius:6px;">' + esc(task.star || '') + '</div></div>' +
            '<div style="margin-bottom:8px;"><span style="font-size:11px;color:#999;">描述（搬运原文）</span><div style="font-size:12px;line-height:1.6;padding:8px;background:#f8f9fa;border-radius:6px;white-space:pre-wrap;max-height:200px;overflow-y:auto;">' + esc(task.description || '(空)') + '</div></div>' +
            '<div style="display:flex;gap:16px;padding:8px 0;">' +
            '<span style="font-size:12px;color:#666;">💰 价格: <b>¥' + esc(task.price || '-') + '</b></span>' +
            '<span style="font-size:12px;color:#666;">📦 库存: <b>' + esc(task.stock || '-') + '</b></span>' +
            '<span style="font-size:12px;color:#666;">🏙 城市: <b>' + esc(task.city || '发布时随机') + '</b></span>' +
            '</div>' +
            '<div style="font-size:10px;color:#bbb;">搬运任务：发布时按上面原文上架，不套用演唱会模板</div>' +
            '<div style="text-align:right;margin-top:12px;"><button id="pdSClose2" style="background:#4A90D9;color:#fff;border:none;border-radius:6px;padding:8px 20px;cursor:pointer;font-size:13px;">关闭</button></div>';
        modal.appendChild(box);
        document.body.appendChild(modal);
        modal.addEventListener('click', function(e) { if (e.target === modal) modal.remove(); });
        var c1 = box.querySelector('#pdSClose1');
        var c2 = box.querySelector('#pdSClose2');
        if (c1) c1.addEventListener('click', function() { modal.remove(); });
        if (c2) c2.addEventListener('click', function() { modal.remove(); });
    }

    window._pdPreviewTask = function(idx) {
        var task = state.tasks[idx];
        if (!task) return;
        if (task.directTitle) { _previewScrapedTask(task); return; }
        var isRandom = state.selectedStores.some(function(s){ try { var c=JSON.parse(localStorage.getItem('kun_store_cfg_'+s)||'{}'); return c.titleMode==='random'; } catch(e){ return false; } }) || getActiveTemplate().titleMode === 'random';
        var tpl;
        if (isRandom && state.templates.length > 0) {
            tpl = state.templates[idx % state.templates.length];
        } else {
            tpl = getActiveTemplate();
        }

        // 根据模板 locationMode 解析预览城市
        var TIER1 = ['北京','上海','广州','深圳','成都','杭州','武汉','南京','重庆','苏州','西安','天津'];
        var ALL_CITIES = TIER1.concat(['长沙','青岛','郑州','沈阳','大连','厦门','宁波','济南','哈尔滨','福州','无锡','合肥','昆明','南宁','太原','贵阳','南昌','石家庄','兰州','银川','西宁','海口','乌鲁木齐','拉萨','呼和浩特']);
        var locMode = tpl.locationMode || 'random_tier1';
        var previewCity = task.city || '';
        // 优先使用任务里填的城市，没填才按模板模式
        if (!previewCity) {
            if (locMode === 'random_tier1') {
                previewCity = TIER1[(idx + Math.floor(Math.random() * TIER1.length)) % TIER1.length];
            } else if (locMode === 'random_any') {
                previewCity = ALL_CITIES[(idx + Math.floor(Math.random() * ALL_CITIES.length)) % ALL_CITIES.length];
            } else if (locMode === 'fixed') {
                previewCity = '广州';
            }
        }

        // 渲染标题
        var title = tpl.titlePattern || '';
        title = title.replace(/\{明星\}/g, task.star || '')
            .replace(/\{城市\}/g, previewCity)
            .replace(/\{场次类型\}/g, task.sessionType || '')
            .replace(/\{活动类型\}/g, task.eventType || '演唱会');
        if (!tpl.titlePattern) {
            title = previewCity + (task.star || '') + (task.eventType || '演唱会') + (task.sessionType || '') + '代拍';
        }
        // 标题微调避开判重
        var _origTitle = title;
        var _sCfg = null; try { _sCfg = JSON.parse(localStorage.getItem('kun_store_cfg_'+(state.currentStore||''))||'{}'); } catch(e) { _sCfg = {}; } if (_sCfg.titleMode === 'random') { title = _pdTweakTitle(title, idx); }
        var _tweaked = (title !== _origTitle);

        // 渲染描述
        var desc = tpl.descPattern || '高命中率，抢不到全额退款';

        // 找主图
        var imgUrl = '', imgName = task.imageName || '';
        if (task.imageName) {
            for (var i = 0; i < state.images.length; i++) {
                if (state.images[i].name === task.imageName) {
                    imgUrl = state.images[i].thumbUrl || '';
                    break;
                }
            }
        }

        // 构建图片展示 HTML
        var imagesHtml = '';
        var _previewImgId = 'kp_' + Date.now() + '_' + Math.random().toString(36).substring(2,6);
        if (imgUrl && !imgUrl.startsWith('blob:')) {
            imagesHtml += '<div style="text-align:center;margin-bottom:8px;"><img src="' + imgUrl + '" style="max-width:180px;max-height:180px;border-radius:8px;border:2px solid #E67E22;"><div style="font-size:10px;color:#E67E22;margin-top:2px;">主图</div></div>';
        } else if (imgName) {
            // 从底图管理借缩略图
            var _borrowed = '';
            for (var bi = 0; bi < state.images.length; bi++) {
                if (state.images[bi].name === imgName && state.images[bi].thumbUrl && !state.images[bi].thumbUrl.startsWith('blob:')) {
                    _borrowed = state.images[bi].thumbUrl;
                    break;
                }
            }
            if (_borrowed) {
                imagesHtml += '<div style="text-align:center;margin-bottom:8px;"><img src="' + _borrowed + '" style="max-width:180px;max-height:180px;border-radius:8px;border:2px solid #E67E22;"><div style="font-size:10px;color:#E67E22;margin-top:2px;">主图</div></div>';
            } else {
                // 从本地文件夹加载图片
                imagesHtml += '<div style="text-align:center;margin-bottom:8px;"><img id="' + _previewImgId + '" src="" style="max-width:180px;max-height:180px;border-radius:8px;border:2px solid #ccc;display:none;"><div id="' + _previewImgId + '_lbl" style="font-size:10px;color:#E67E22;margin-top:2px;">📁 ' + esc(imgName.replace(/^.*[\\/]/, '')) + ' ⏳ 加载中...</div></div>';
            }
        }

        var modal = document.createElement('div');
        modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.4);z-index:10000;display:flex;align-items:center;justify-content:center;';
        var box = document.createElement('div');
        box.style.cssText = 'background:#fff;border-radius:12px;padding:24px;width:520px;max-height:85vh;overflow-y:auto;box-shadow:0 8px 32px rgba(0,0,0,0.2);';
        box.innerHTML = '' +
            '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">' +
            '<span style="font-size:16px;font-weight:600;">👁 发布预览</span>' +
            '<button id="pdCloseBtn" style="background:none;border:none;font-size:20px;color:#999;cursor:pointer;">✕</button>' +
            '</div>' +
            '<div id="pdSubImgs"></div>' +
            imagesHtml +
            '<div style="margin-bottom:8px;"><span style="font-size:11px;color:#999;">标题</span><div style="font-size:14px;font-weight:600;line-height:1.5;padding:8px;background:#f8f9fa;border-radius:6px;">' + esc(title) + '</div>' + (_tweaked ? '<div style="font-size:10px;color:#27ae60;margin-top:2px;">✅ 已微调</div><div style="font-size:10px;color:#bbb;margin-top:1px;">原: ' + esc(_origTitle) + '</div>' : '<div style="font-size:10px;color:#e74c3c;margin-top:2px;">⚠ 未微调（标题不含可替换关键词）</div>') + '</div>' +
            '<div style="margin-bottom:8px;"><span style="font-size:11px;color:#999;">描述</span><div style="font-size:12px;line-height:1.6;padding:8px;background:#f8f9fa;border-radius:6px;white-space:pre-wrap;">' + esc(desc) + '</div></div>' +
            '<div style="display:flex;gap:16px;padding:8px 0;">' +
            '<span style="font-size:12px;color:#666;">💰 价格: <b>¥' + esc(task.price || tpl.price) + '</b></span>' +
            '<span style="font-size:12px;color:#666;">📦 库存: <b>' + esc(task.stock || tpl.stock) + '</b></span>' +
            '<span style="font-size:12px;color:#666;">🏷 分类: <b>' + esc(task.categoryName || tpl.categoryName) + '</b></span>' +
            '</div>' +
            '<div style="display:flex;gap:16px;padding:4px 0;font-size:11px;color:#999;">' +
            '<span>🏙 城市: ' + esc(previewCity || '-') + ' <span style="font-size:10px;color:#bbb;">(' + ({city:'跟随标题',random_tier1:'随机一线',random_any:'随机',fixed:'固定'}[locMode]||locMode) + ')</span></span>' +
            '<span>🎤 明星: ' + esc(task.star || '-') + '</span>' +
            '<span>🎫 场次: ' + esc(task.sessionType || '-') + '</span>' +
            '</div>' +
            '<div style="text-align:right;margin-top:12px;"><button id="pdCloseBtn2" style="background:#4A90D9;color:#fff;border:none;border-radius:6px;padding:8px 20px;cursor:pointer;font-size:13px;">关闭</button></div>';
        modal.appendChild(box);
        document.body.appendChild(modal);
        modal.addEventListener('click', function(e) { if (e.target === modal) modal.remove(); });
        var cb1 = box.querySelector('#pdCloseBtn');
        var cb2 = box.querySelector('#pdCloseBtn2');
        if (cb1) cb1.addEventListener('click', function() { modal.remove(); });
        if (cb2) cb2.addEventListener('click', function() { modal.remove(); });

        // 后台加载副图
        var subContainer = modal.querySelector('#pdSubImgs');
        if (subContainer) {
            subContainer.innerHTML = '<div style="font-size:11px;color:#999;">副图随发布自动加载</div>';
        }
        // 从本地文件夹异步加载预览图
        if (imgName && imgUrl && !imgUrl.startsWith('blob:')) { /* 已有缩略图 */ }
        else if (imgName && evalOnStore) {
            (function(_pid, _fn) {
                var store = state.currentStore || (state.selectedStores[0] || '');
                var path = _fn.replace(/^.*[\\/]/, '');
                evalOnStore(store, '(async function(){try{var r=await window.kunPublish.readLocalImageBase64("' + path + '");if(r){return r.substring(0,200000)}return ""}catch(e){return ""}})()').then(function(res) {
                    if (res && res.ok && res.result) {
                        var b64 = (typeof res.result === 'string') ? res.result : '';
                        if (b64 && b64.length > 100) {
                            var img = document.getElementById(_pid);
                            var lbl = document.getElementById(_pid + '_lbl');
                            if (img) { img.src = 'data:image/png;base64,' + b64; img.style.display = ''; img.style.border = '2px solid #E67E22'; }
                            if (lbl) lbl.textContent = '📁 ' + _fn.replace(/^.*[\\/]/, '');
                        }
                    }
                }).catch(function(){});
            })(_previewImgId, imgName);
        }
    };

    // ===== 渲染 =====
    function renderStoreSelector() {
        var panel = $('hdStorePanel');
        var html = '';
        for (var i = 0; i < state.accounts.length; i++) {
            var a = state.accounts[i];
            var checked = state.selectedStores.indexOf(a.name) >= 0;
            html += '<label style="display:flex;align-items:center;gap:6px;padding:6px 8px;cursor:pointer;font-size:13px;color:#333;border-radius:4px;" onmouseover="this.style.background=\'#f5f5f5\'" onmouseout="this.style.background=\'\'">' +
                '<input type="checkbox" class="store-check" value="' + esc(a.name) + '"' + (checked ? ' checked' : '') + ' style="cursor:pointer;">' +
                esc(a.name) + '</label>';
        }
        if (state.accounts.length === 0) {
            html = '<div style="padding:12px;color:#999;text-align:center;font-size:12px;">无账号</div>';
        }
        panel.innerHTML = html;
        // 更新按钮文字
        $('hdStoreBtn').textContent = '🏪 店铺 (' + state.selectedStores.length + ')';
        // 绑定 checkbox
        panel.querySelectorAll('.store-check').forEach(function(cb) {
            cb.onchange = function() {
                var name = this.value;
                if (this.checked) {
                    if (state.selectedStores.indexOf(name) < 0) state.selectedStores.push(name);
                } else {
                    state.selectedStores = state.selectedStores.filter(function(s) { return s !== name; });
                }
                $('hdStoreBtn').textContent = '🏪 店铺 (' + state.selectedStores.length + ')';
                $('btnPublishAll').disabled = state.selectedStores.length === 0;
                updatePublishButtons();
                updateScrapeCard();
                // 自动启动勾选的店铺，并更新当前编辑店铺
                if (this.checked) {
                    saveStoreData(); saveSettings();
                    state.currentStore = name;
                    checkStoreReady(name);
                    loadStoreData(); loadSettings(); loadStoreCfgPanel();
                } else if (state.selectedStores.length > 0 && state.currentStore === name) {
                    saveStoreData(); saveSettings();
                    state.currentStore = state.selectedStores[0];
                    checkStoreReady(state.currentStore);
                    loadStoreData(); loadSettings();
                }
                saveSelectedStores();  // 记住勾选，刷新后自动恢复（否则底图/任务全空）
                updatePolishVisibility();
            };
        });

        // 💨 擦亮联动
        var apSel = $('setAutoPolish');
        if (apSel) apSel.onchange = updatePolishVisibility;
    }

    function updatePolishVisibility() {
        var polishOn = $('setAutoPolish') && $('setAutoPolish').value === 'true';
        var show = polishOn;
        var iwCard = $('imageWorkshop'); if (iwCard) iwCard.style.display = ''; // 图片工坊常驻显示（海报生成常用）
        // 显示日期
        var dateEl = $('publishDate');
        if (dateEl) {
            var now = new Date();
            dateEl.textContent = (now.getMonth()+1) + '月' + now.getDate() + '日';
            dateEl.style.display = state.selectedStores.length === 1 ? '' : 'none';
        }
        // 日志布局：单店=三栏左日志，多店=两栏右日志
        var isSingle = state.selectedStores.length === 1;
        var mainEl = document.querySelector('.main');
        var leftLog = $('leftLog');
        var sidebarLog = $('sidebarLog');
        if (isSingle) {
            if (mainEl) mainEl.classList.add('tri-col');
            if (leftLog) leftLog.classList.remove('hidden');
            if (sidebarLog) sidebarLog.classList.add('hidden');
            if ($('logBox') && $('logBoxLeft')) $('logBoxLeft').innerHTML = $('logBox').innerHTML;
        } else {
            if (mainEl) mainEl.classList.remove('tri-col');
            if (leftLog) leftLog.classList.add('hidden');
            if (sidebarLog) sidebarLog.classList.remove('hidden');
            if ($('logBox') && $('logBoxLeft')) $('logBox').innerHTML = $('logBoxLeft').innerHTML;
        }
        var rows = ['polishSettings', 'rowCampaignMode', 'polishSettings2', 'polishSettings3'];
        for (var i = 0; i < rows.length; i++) {
            var el = $(rows[i]);
            if (el) el.style.display = show ? '' : 'none';
        }
        // 计划数联动：显示/隐藏 Plan 2/3
        var ccSel = $('setCampaignCount');
        if (ccSel) {
            ccSel.onchange = function() {
                var cnt = parseInt(this.value) || 1;
                var p2 = $('polishSettings2'); if (p2) p2.style.display = cnt >= 2 ? '' : 'none';
                var p3 = $('polishSettings3'); if (p3) p3.style.display = cnt >= 3 ? '' : 'none';
            };
            // 初始状态
            var initCnt = parseInt(ccSel.value) || 1;
            var p2 = $('polishSettings2'); if (p2) p2.style.display = initCnt >= 2 ? '' : 'none';
            var p3 = $('polishSettings3'); if (p3) p3.style.display = initCnt >= 3 ? '' : 'none';
        }

        // 保存按钮
        var _saveBtn = $('btnSaveSettings');
        if (_saveBtn) _saveBtn.onclick = function() { saveSettings(); addLog('💾 设置已保存', 'info'); };


        // 定时发布检查器（每30秒检查）
        if (window.__kunPubTimer) clearInterval(window.__kunPubTimer);
        window.__kunPubTimer = setInterval(function() {
            var pubTime = $('setPublishTime') ? $('setPublishTime').value : '';
            if (!pubTime || state.publishing) return;
            var now = new Date();
            var cur = String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
            if (cur === pubTime) {
                // P1-9：同一天只触发一次（避免同分钟/跨分钟重复触发）
                var d0 = new Date();
                var today = d0.getFullYear() + '-' + String(d0.getMonth()+1).padStart(2,'0') + '-' + String(d0.getDate()).padStart(2,'0');
                if (!state.selectedStores.length || !state.tasks.length) return;
                if (localStorage.getItem('kun_last_pub_date') === today) return;
                localStorage.setItem('kun_last_pub_date', today);
                addLog('⏰ 定时发布触发！时间: ' + pubTime, 'info');
                startPublish();
            }
        }, 30000);
    }

    // ===== 设置保存/加载 =====
    function getSettingsKey() { return 'kun_dash_settings_' + (state.currentStore || 'default'); }
    // 任务列表视图开关（只看待发/按城市分组）—— 跨刷新记住
    var TASK_VIEW_KEY = 'kun_dash_taskview';
    function loadTaskView() {
        try {
            var v = JSON.parse(localStorage.getItem(TASK_VIEW_KEY) || '{}');
            if ($('tOnlyPending')) $('tOnlyPending').checked = v.onlyPending !== false; // 默认只看待发 = true
            if ($('tByCity')) $('tByCity').checked = !!v.byCity;
            if ($('iwAutoPub')) $('iwAutoPub').checked = !!v.autoPub; // ⚡出图即发开关
        } catch(e) {}
    }
    function saveTaskView() {
        try {
            localStorage.setItem(TASK_VIEW_KEY, JSON.stringify({
                onlyPending: $('tOnlyPending') ? $('tOnlyPending').checked : true,
                byCity: $('tByCity') ? $('tByCity').checked : false,
                autoPub: $('iwAutoPub') ? $('iwAutoPub').checked : false
            }));
        } catch(e) {}
    }
    var WAKE_KEY = 'kun_wake_times'; // {店铺名: 时间}
    function getWakeTimes() { try { return JSON.parse(localStorage.getItem(WAKE_KEY)) || {}; } catch(e) { return {}; } }
    // 从 goofish 页面源读取店铺配置（发布台与页面不同源，读本地永远为空）—— S3 修复
    async function readStoreCfgFromPage() {
        if (!state.currentStore) return {};
        try {
            var code = '(function(){var k="kun_store_cfg_"+' + JSON.stringify(state.currentStore) + ';var c=null;try{c=JSON.parse(localStorage.getItem(k));}catch(e){}return JSON.stringify(c||{});})()';
            var r = await evalOnStore(state.currentStore, code);
            if (r.ok && r.result) return (typeof r.result === 'string' ? JSON.parse(r.result) : r.result) || {};
        } catch(e) {}
        return {};
    }
    async function loadStoreConfigSettings() {
        if (!state.currentStore) return;
        var cfg = await readStoreCfgFromPage();
        var shipEl = $('setShipMode');
        if (shipEl && cfg.shipMode) shipEl.value = cfg.shipMode;
    }

    // ===== 店铺配置面板（读/写 goofish 页面的 kun_store_cfg_*）=====
    async function loadStoreCfgPanel() {
        if (!state.currentStore) { $('storeCfgStatus').textContent = '请先选店铺'; return; }
        $('storeCfgName').textContent = state.currentStore;
        $('storeCfgStatus').textContent = '⏳ 加载中...';
        try {
            var code = '(function(){var k="kun_store_cfg_"+' + JSON.stringify(state.currentStore) + ';var c=null;try{c=JSON.parse(localStorage.getItem(k));}catch(e){}return JSON.stringify(c||{});})()';
            var r = await evalOnStore(state.currentStore, code);
            if (r.ok && r.result) {
                var cfg = typeof r.result === 'string' ? JSON.parse(r.result) : r.result;
                $('cfgTitleMode').value = cfg.titleMode || '';
                $('cfgPrice').value = cfg.price || '';
                $('cfgStock').value = cfg.stock || '';
                $('cfgCategory').value = cfg.category || '';
                $('cfgShipMode').value = cfg.shipMode || '';
                if (cfg.subImg === true) $('cfgSubImg').value = 'true';
                else if (cfg.subImg === false) $('cfgSubImg').value = 'false';
                else $('cfgSubImg').value = '';
                $('storeCfgStatus').textContent = '✅ 已加载';
                setTimeout(function() { loadCategoryOptions(); }, 500);
            } else {
                $('storeCfgStatus').textContent = '⚠ 加载失败';
            }
        } catch(e) {
            $('storeCfgStatus').textContent = '❌ ' + e.message;
        }
    }
    async function saveStoreCfgPanel() {
        if (!state.currentStore) { $('storeCfgStatus').textContent = '请先选店铺'; return; }
        $('storeCfgStatus').textContent = '⏳ 保存中...';
        var cfg = {
            titleMode: $('cfgTitleMode').value,
            price: $('cfgPrice').value.trim(),
            stock: $('cfgStock').value.trim(),
            category: $('cfgCategory').value,
            shipMode: $('cfgShipMode').value,
            subImg: $('cfgSubImg').value === 'true' ? true : ($('cfgSubImg').value === 'false' ? false : null)
        };
        var code = '(function(){var k="kun_store_cfg_"+' + JSON.stringify(state.currentStore) + ';var o=null;try{o=JSON.parse(localStorage.getItem(k));}catch(e){}if(!o)o={};var n=' + JSON.stringify(cfg) + ';for(var k2 in n){if(n[k2]!==null&&n[k2]!=="")o[k2]=n[k2];else delete o[k2];}localStorage.setItem(k,JSON.stringify(o));return "ok";})()';
        try {
            var r = await evalOnStore(state.currentStore, code);
            if (r.ok) {
                $('storeCfgStatus').textContent = '✅ 已保存';
                addLog('🏪 店铺配置已保存到「' + state.currentStore + '」', 'ok');
            } else {
                $('storeCfgStatus').textContent = '⚠ 保存失败';
            }
        } catch(e) {
            $('storeCfgStatus').textContent = '❌ ' + e.message;
        }
    }

    async function loadCategoryOptions() {
        if (!state.currentStore) return;
        try {
            var code = '(function(){try{var r=localStorage.getItem("kun_categories_v2");if(r){var d=JSON.parse(r);if(d&&d.data)return JSON.stringify(d.data);}return "[]";}catch(e){return "[]";}})()';
            var r = await evalOnStore(state.currentStore, code);
            if (!r.ok || !r.result) return;
            var cats = typeof r.result === 'string' ? JSON.parse(r.result) : r.result;
            if (!Array.isArray(cats) || cats.length === 0) return;
            var sel = $('cfgCategory');
            if (!sel) return;
            var curVal = sel.value;
            sel.innerHTML = '<option value="">留空=跟模板</option>';
            for (var i = 0; i < cats.length; i++) {
                sel.innerHTML += '<option value="' + esc(cats[i].catName) + '"' + (curVal === cats[i].catName ? ' selected' : '') + '>' + esc(cats[i].catName) + '</option>';
            }
        } catch(e) { console.log('loadCategoryOptions error:', e); }
    }
    function loadSettings() {
        loadStoreConfigSettings();
        var s = {};
        try { s = JSON.parse(localStorage.getItem(getSettingsKey())) || {}; } catch(e) {}
        var keys = ['setAutoPolish','setBidPrice','setDayBudget','setBidTarget',
            'setBidPrice2','setDayBudget2','setBidTarget2','setBidPrice3','setDayBudget3','setBidTarget3',
            'setCampaignMode','setCampaignCount','setInterval','setStoreInterval','setConfirm','setShipMode',
            'setPublishTime'];
        for (var i = 0; i < keys.length; i++) {
            var el = $(keys[i]);
            if (el && s[keys[i]] !== undefined) el.value = s[keys[i]];
        }
        // 加载当前店铺的唤醒时间
        var wakeEl = $('setWakeTime');
        if (wakeEl) {
            var wt = getWakeTimes();
            wakeEl.value = wt[state.currentStore] || '';
        }
    }
    function saveSettings() {
        var s = {};
        var keys = ['setAutoPolish','setBidPrice','setDayBudget','setBidTarget',
            'setBidPrice2','setDayBudget2','setBidTarget2','setBidPrice3','setDayBudget3','setBidTarget3',
            'setCampaignMode','setCampaignCount','setInterval','setStoreInterval','setConfirm','setShipMode',
            'setPublishTime'];
        for (var i = 0; i < keys.length; i++) {
            var el = $(keys[i]);
            if (el) s[keys[i]] = el.value;
        }
        localStorage.setItem(getSettingsKey(), JSON.stringify(s));
        // 按店铺存唤醒时间，取所有店铺里最早的发给后端
        var wakeEl = $('setWakeTime');
        if (wakeEl && wakeEl.value && state.currentStore) {
            var allWake = getWakeTimes();
            allWake[state.currentStore] = wakeEl.value;
            localStorage.setItem(WAKE_KEY, JSON.stringify(allWake));
            // 找最早的
            var earliest = null;
            var earliestStore = '';
            for (var store in allWake) {
                if (allWake[store] && (!earliest || allWake[store] < earliest)) {
                    earliest = allWake[store];
                    earliestStore = store;
                }
            }
            if (earliest) {
                try {
                    fetch(API + '/api/system/schedule-wake', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-API-Key': KEY },
                        body: JSON.stringify({ time: earliest })
                    }).then(function(r) { return r.json(); }).then(function(d) {
                        if (d.ok) addLog('⏰ 唤醒已设置: 每天 ' + earliest + '（最早：' + earliestStore + '）', 'info');
                        else addLog('⚠ 唤醒设置失败: ' + (d.error || ''), 'warn');
                    }).catch(function() {});
                } catch(e) {}
            }
        }
    }

    // ===== 按店铺存储任务+图片 =====
    // forceReplace=true → 整份覆盖磁盘（删除任务时必须传，否则 native_host 的合并会把删掉的写回来）
    function saveStoreData(forceReplace) {
        // 静默 return 是「图明明传了、刷新却没了」的元凶：写盘走了 native host 不受影响，
        // 但 localStorage 存不进去 → 刷新后 loadStoreData 读不到底图列表。这里必须让用户看见。
        if (!state.currentStore) {
            if (!saveStoreData._warned) {
                saveStoreData._warned = true;
                addLog('⚠ 未选店铺：本次底图/任务改动不会保存。请在右上角「🏪 店铺」勾选店铺后重试', 'warn');
            }
            return;
        }
        saveStoreData._warned = false;
        var key = 'kun_dash_data_' + state.currentStore;
        try {
            // 只存任务+图片名，不存 thumbUrl（base64 太大会超 localStorage 上限）
            localStorage.setItem(key, JSON.stringify({
                tasks: state.tasks,
                images: state.images.map(function(img) { return { name: img.name, saved: img.saved }; })
            }));
        } catch(e) {
            // 如果还是超限，只存 tasks（最关键）
            try {
                localStorage.setItem(key, JSON.stringify({
                    tasks: state.tasks,
                    images: []
                }));
                addLog('⚠ 图片太多无法存储，已保留任务数据', 'warn');
            } catch(e2) {}
        }
        // 同步写磁盘（权威数据源，店铺页面发布循环从这里读）
        saveStoreTasksToDisk(state.currentStore, null, !!forceReplace).catch(function(e) {
            console.log('磁盘写入失败:', e);
        });
    }

    // ===== 任务写磁盘（每店一个文件） =====
    // forceReplace=true 时整份覆盖（用于删除任务：清空/移除已完成/删单条）
    async function saveStoreTasksToDisk(store, interval, forceReplace) {
        // P0-3：擦亮/确认/三档出价真正读界面设置，不再硬编码
        var autoPolish = $('setAutoPolish') ? $('setAutoPolish').value === 'true' : true;
        var confirmMode = $('setConfirm') ? $('setConfirm').value === 'true' : false;
        var campaignMode = $('setCampaignMode') ? $('setCampaignMode').value : 'single';
        var campaignCount = parseInt(($('setCampaignCount') && $('setCampaignCount').value) || '1') || 1;
        function _num(id, def) { var v = parseFloat($(id) ? $(id).value : ''); return isNaN(v) ? def : v; }
        var bidPrice = _num('setBidPrice', 13.6);
        var dayBudget = _num('setDayBudget', 50);
        var bidTarget = $('setBidTarget') ? $('setBidTarget').value : 'order';
        var bp2 = _num('setBidPrice2', 15), bd2 = _num('setDayBudget2', 60), bt2 = $('setBidTarget2') ? $('setBidTarget2').value : 'order';
        var bp3 = _num('setBidPrice3', 20), bd3 = _num('setDayBudget3', 80), bt3 = $('setBidTarget3') ? $('setBidTarget3').value : 'chat';
        var campaignPlans = [
            { bidPrice: bidPrice, maxDayBudget: dayBudget, bidTarget: bidTarget },
            { bidPrice: bp2, maxDayBudget: bd2, bidTarget: bt2 },
            { bidPrice: bp3, maxDayBudget: bd3, bidTarget: bt3 }
        ];
        // 批量合并推模式：单条不单独开擦亮（由页面收集后统一开）
        var skipCampaign = !autoPolish || campaignMode === 'batch';
        var tasksOut = (state.tasks || []).map(function(t) {
            var o = Object.assign({}, t);
            if ((!Array.isArray(o.imageUrls) || o.imageUrls.length === 0) && o.imageName) {
                o.imageUrls = [o.imageName];
            }
            // 每任务写入本轮擦亮参数，页面 doDailyTask/publishOneTask 按此执行
            o.bidPrice = bidPrice;
            o.maxDayBudget = dayBudget;
            o.bidTarget = bidTarget;
            o.campaignCount = campaignCount;
            o.campaignPlans = campaignPlans;
            o.skipCampaign = skipCampaign;
            return o;
        });
        var payload = {
            templateId: state.activeTemplateId || 1,
            imageUrl: '',
            publishInterval: parseInt(interval || (($('setInterval') && $('setInterval').value) || 60)) || 60,
            batchSize: parseInt(($('setBatchSize') && $('setBatchSize').value) || '0') || 0,
            batchInterval: parseInt(($('setBatchInterval') && $('setBatchInterval').value) || '') || parseInt(interval || (($('setInterval')&&$('setInterval').value)||60)) || 60,
            autoPolish: autoPolish,
            confirmMode: confirmMode,
            campaignMode: campaignMode,
            campaignPlans: campaignPlans,
            tasks: tasksOut
        };
        if (forceReplace) payload._replace = true; // 告知 native_host 整份覆盖，否则它的合并逻辑会把删掉的任务写回来
        // P0-7：落盘前先读磁盘，按 star|city|场次 合并去重（保留已有任务+新增），避免整份覆盖冲掉其它任务
        // forceReplace 时跳过合并，否则被删的任务会被"补回"而永远删不掉
        if (!forceReplace) try {
            var _disk = await nativeHost({ action: 'readDailyTasks', store: store });
            if (_disk && _disk.ok && _disk.data && Array.isArray(_disk.data.tasks) && _disk.data.tasks.length) {
                var _mkey = function(t){ return (t.star||'') + '|' + (t.city||'') + '|' + (t.sessionType||'') + '|' + (t.imageName||''); };
                var _have = {}; var _merged = [];
                payload.tasks.forEach(function(t){ _have[_mkey(t)] = 1; _merged.push(t); });
                _disk.data.tasks.forEach(function(dt){ if (!_have[_mkey(dt)]) _merged.push(dt); }); // 磁盘上有但本次没有的 → 补回,避免丢
                payload.tasks = _merged;
            }
        } catch(e) {}
        return await nativeHost({ action: 'writeDailyTasks', store: store, data: payload });
    }

    // ===== 状态回流（P0-4/P0-5）：磁盘是权威源，把页面回写的 itemId/status 合并回发布台 =====
    function taskKey(t) {
        return (t.star || '') + '|' + (t.city || '') + '|' + (t.sessionType || '') + '|' + (t.imageName || '');
    }
    function mergeDiskStatusIntoState(diskTasks) {
        if (!Array.isArray(diskTasks) || !Array.isArray(state.tasks)) return false;
        var changed = false;
        for (var i = 0; i < state.tasks.length; i++) {
            var t = state.tasks[i];
            var k = taskKey(t);
            for (var j = 0; j < diskTasks.length; j++) {
                var dt = diskTasks[j];
                if (taskKey(dt) !== k) continue;
                if (dt.itemId && !t.itemId) { t.itemId = dt.itemId; changed = true; }
                if (dt.status && t.status !== dt.status) { t.status = dt.status; changed = true; }
                if (dt.error && !t.error) { t.error = dt.error; changed = true; }
                break;
            }
        }
        return changed;
    }
    async function refreshTaskStatusFromDisk(stores) {
        try {
            var changed = false;
            for (var si = 0; si < stores.length; si++) {
                var r = await nativeHost({ action: 'readDailyTasks', store: stores[si] });
                if (r && r.ok && r.data && Array.isArray(r.data.tasks)) {
                    if (mergeDiskStatusIntoState(r.data.tasks)) changed = true;
                }
            }
            if (changed) renderTasks();
        } catch(e) {}
    }
    var _statusPollTimer = null;
    var _statusPollTicks = 0;
    function stopStatusPoll() {
        if (_statusPollTimer) { clearInterval(_statusPollTimer); _statusPollTimer = null; }
        _statusPollTicks = 0;
    }
    // 一键发布（每日节奏）无 getBatchStatus 轮询，这里统一用磁盘回写做进度回流
    function startStatusPoll(stores) {
        stopStatusPoll();
        if (!stores || stores.length === 0) return;
        _statusPollTicks = 0;
        _statusPollTimer = setInterval(function() {
            _statusPollTicks++;
            refreshTaskStatusFromDisk(stores);
            if (_statusPollTicks >= 90) { // 最长约 15 分钟，之后店铺页面仍在后台继续
                stopStatusPoll();
                var pc = $('progressCard'); if (pc) pc.style.display = 'none';
            }
        }, 10000);
    }

    // ===== 任务编辑防抖落盘（P0-2：改完不丢） =====
    var _saveTimer = null;
    function scheduleSave() {
        if (_saveTimer) clearTimeout(_saveTimer);
        _saveTimer = setTimeout(function() { _saveTimer = null; saveStoreData(); }, 400);
    }
    async function loadStoreData() {
        if (!state.currentStore) { state.tasks = []; state.images = []; renderImages(); renderTasks(); updateScrapeCard(); return; }
        var key = 'kun_dash_data_' + state.currentStore;
        try {
            var data = JSON.parse(localStorage.getItem(key));
            state.tasks = (data && data.tasks) ? data.tasks : [];
            state.images = (data && data.images) ? data.images : [];
        } catch(e) { state.tasks = []; state.images = []; }
        // 磁盘是权威数据源：发布台关闭/重装不丢，店铺页面发布循环也读同一份
        try {
            var r = await nativeHost({ action: 'readDailyTasks', store: state.currentStore });
            if (r && r.ok && r.data && Array.isArray(r.data.tasks)) {
                state.tasks = r.data.tasks || [];
                // 从本地图片路径恢复 imageName 供表格显示
                for (var i = 0; i < state.tasks.length; i++) {
                    var t = state.tasks[i];
                    if (!t.imageName && Array.isArray(t.imageUrls)) {
                        for (var j = 0; j < t.imageUrls.length; j++) {
                            var u = t.imageUrls[j] || '';
                            if (u && u.indexOf('http') !== 0) { t.imageName = u.replace(/^.*[\\/]/, ''); break; }
                        }
                    }
                }
            }
        } catch(e) {
            // 原先这里完全静默，导致「任务列表空」分不清是磁盘读失败还是真没任务
            addLog('⚠ 读取磁盘任务失败，已改用本地缓存（' + (e && e.message ? e.message : '未知错误') + '）', 'warn');
        }
        // 兼容旧任务：老数据只有 store 没有 targetStore，而发布过滤按 targetStore 择店。
        // 若不回填，targetStore 为空会让任务匹配「所有店」，三店并发时同一任务被重复上架。
        var _btCount = 0;
        for (var _bi = 0; _bi < state.tasks.length; _bi++) {
            var _bt = state.tasks[_bi];
            if (!_bt.targetStore && _bt.store) { _bt.targetStore = _bt.store; _btCount++; }
        }
        if (_btCount > 0) addLog('🔧 已回填 ' + _btCount + ' 条旧任务的归属店铺（防止多店重复上架）', 'dim');
        // P0-6：从磁盘恢复主图缩略图（刷新页面后不丢图）
        var needThumb = state.images.filter(function(img) { return !img.thumbUrl; });
        if (needThumb.length > 0) {
            var folder = getImagesFolder();
            Promise.all(needThumb.map(function(img) {
                return nativeHost({ action: 'readImage', path: folder + img.name }).then(function(r) {
                    if (r && r.base64) img.thumbUrl = 'data:' + (r.mime || 'image/jpeg') + ';base64,' + r.base64;
                }).catch(function() {});
            })).then(function() { renderImages(); });
        }
        // 恢复图片工坊底图（跨刷新持久化）
        if (window.__restoreWsSources) window.__restoreWsSources();
        renderImages();
        renderTasks();
        updateScrapeCard();
        applyWorkshopVisibility();
    }

    // ===== 从 goofish 页面加载该店铺的模板 =====
    async function loadStoreTemplates() {
        if (!state.currentStore) return;
        try {
            // 先 setStore 确保读到正确店铺的模板
            var code = '(function(){try{window.kunPublish.setStore(' + JSON.stringify(state.currentStore) + ');window.kunPublish.reloadStoreTemplates();var t=window.kunPublish.CONCERT_TEMPLATES||[];return JSON.stringify(t.map(function(x){return{id:x.id,name:x.name,titleMode:x.titleMode||"placeholder",titlePattern:x.titlePattern||"",descPattern:x.descPattern||"",price:x.price||"50",origPrice:x.origPrice||"",stock:x.stock||"9999",categoryName:x.categoryName||"代购",shipMode:x.shipMode||"nomail",locationMode:x.locationMode||"random_tier1",subImg:x.subImg!==false,commitment:x.commitment||{}};}));}catch(e){return JSON.stringify({error:e.message});}})()';
            var r = await evalOnStore(state.currentStore, code);
            if (r.ok && r.result) {
                var parsed = typeof r.result === 'string' ? JSON.parse(r.result) : r.result;
                if (parsed.error) throw new Error(parsed.error);
                if (Array.isArray(parsed) && parsed.length > 0) {
                    state.templates = parsed;
                    state.activeTemplateId = parsed[0].id;
                    renderTemplates();
                    addLog('📝 已加载店铺「' + state.currentStore + '」的 ' + parsed.length + ' 个模板', 'info');
                    return;
                }
            }
        } catch(e) {
            addLog('⚠ 加载模板失败: ' + e.message + '，使用默认模板', 'warn');
        }
        // 回退到默认模板
        state.templates = [
            { id: 1, name: '模板1·轮次代拍（原有）', titleMode: 'placeholder', titlePattern: '【{场次类型}代拍】{城市}{明星}{活动类型}接代拍{场次类型}代抢', descPattern: '高命中率，抢不到全额退款', price: '50', origPrice: '', stock: '9999', categoryName: '代购', shipMode: 'nomail', locationMode: 'random_tier1', subImg: true, commitment: {} },
            { id: 2, name: '模板2·必中秒付（原有）', titleMode: 'placeholder', titlePattern: '【代拍必中】{城市}{明星}{活动类型}接代拍{场次类型}代抢秒付必中', descPattern: '高命中率，抢不到全额退款', price: '50', origPrice: '', stock: '9999', categoryName: '代购', shipMode: 'nomail', locationMode: 'random_tier1', subImg: true, commitment: {} },
            { id: 3, name: '模板3·全额退款承诺', titleMode: 'placeholder', titlePattern: '【{城市}{明星}】{活动类型}{场次类型}代拍 抢不到全额退款 可看评价', descPattern: '高命中率，抢不到全额退款', price: '50', origPrice: '', stock: '9999', categoryName: '代购', shipMode: 'nomail', locationMode: 'random_tier1', subImg: true, commitment: {} },
            { id: 4, name: '模板4·全价位战绩可查', titleMode: 'placeholder', titlePattern: '{城市}{明星}{活动类型}代拍{场次类型} 全站全价位都可接 战绩可查', descPattern: '高命中率，抢不到全额退款', price: '50', origPrice: '', stock: '9999', categoryName: '代购', shipMode: 'nomail', locationMode: 'random_tier1', subImg: true, commitment: {} },
            { id: 5, name: '模板5·专业代拍团队', titleMode: 'placeholder', titlePattern: '【专业代拍】{城市}{明星}{活动类型}{场次类型}代抢 万人团队 高命中率', descPattern: '高命中率，抢不到全额退款', price: '50', origPrice: '', stock: '9999', categoryName: '代购', shipMode: 'nomail', locationMode: 'random_tier1', subImg: true, commitment: {} },
            { id: 6, name: '模板6·内场看台全接', titleMode: 'placeholder', titlePattern: '{明星}{城市}{活动类型}{场次类型}代抢 内场看台全接 秒付前排', descPattern: '高命中率，抢不到全额退款', price: '50', origPrice: '', stock: '9999', categoryName: '代购', shipMode: 'nomail', locationMode: 'random_tier1', subImg: true, commitment: {} }
        ];
        state.activeTemplateId = 1;
        renderTemplates();
    }

    function renderTemplates() {
        var list = $('templateList');
        var html = '';
        for (var i = 0; i < state.templates.length; i++) {
            var t = state.templates[i];
            var active = t.id === state.activeTemplateId;
            html += '<div class="template-card' + (active ? ' active' : '') + '" data-tid="' + t.id + '" style="display:flex;align-items:center;gap:6px;">' +
                '<div>' +
                '<div style="font-weight:' + (active ? '600' : '400') + ';">' + esc(t.name) + '</div>' +
                '<div style="font-size:11px;color:#999;margin-top:2px;">¥' + esc(t.price) + ' · ' + esc(t.categoryName) + '</div>' +
                '</div>' +
                '<button class="btn-tpl-edit" data-tpl-idx="' + i + '" style="background:none;border:1px solid #ddd;border-radius:4px;padding:2px 6px;cursor:pointer;font-size:11px;color:#666;margin-left:auto;">✏️</button>' +
                '</div>';
        }
        html += '<button id="btnAddTpl" style="padding:8px 14px;border-radius:8px;border:2px dashed #ddd;cursor:pointer;font-size:12px;color:#999;background:none;">➕ 新模板</button>';
        list.innerHTML = html;
        // 绑定编辑按钮
        list.querySelectorAll('.btn-tpl-edit').forEach(function(btn) {
            btn.onclick = function(e) {
                e.stopPropagation();
                openTplEditor(parseInt(this.dataset.tplIdx));
            };
        });
        var addBtn = $('btnAddTpl');
        if (addBtn) {
            addBtn.onclick = function(e) {
                e.stopPropagation();
                var newId = state.templates.length > 0 ? Math.max.apply(null, state.templates.map(function(t) { return t.id; })) + 1 : 1;
                state.templates.push({ id: newId, name: '新模板', titleMode: 'placeholder', titlePattern: '', descPattern: '', price: '50', origPrice: '', stock: '9999', categoryName: '代购', shipMode: 'nomail', locationMode: 'random_tier1', subImg: true, commitment: {} });
                openTplEditor(state.templates.length - 1);
            };
        }
    }

    // ===== 模板编辑弹窗 =====
    function openTplEditor(idx) {
        var t = state.templates[idx];
        if (!t) return;

        var modal = document.createElement('div');
        modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.4);z-index:10000;display:flex;align-items:center;justify-content:center;';
        modal.innerHTML = '' +
            '<div style="background:#fff;border-radius:12px;padding:24px;width:600px;max-height:85vh;overflow-y:auto;box-shadow:0 8px 32px rgba(0,0,0,0.2);">' +
            '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">' +
            '<span style="font-size:16px;font-weight:600;">✏️ 编辑模板</span>' +
            '<button id="tplEditClose" style="background:none;border:none;font-size:20px;color:#999;cursor:pointer;">✕</button>' +
            '</div>' +
            '<div style="margin-bottom:12px;"><label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">模板名称</label>' +
            '<input id="tplName" value="' + esc(t.name) + '" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:13px;box-sizing:border-box;"></div>' +
            '<div style="margin-bottom:12px;"><label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">标题模式</label>' +
            '<select id="tplTitleMode" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:13px;box-sizing:border-box;margin-bottom:8px;">' +
            '<option value="placeholder"' + (t.titleMode !== 'fixed' && t.titleMode !== 'random' ? ' selected' : '') + '>占位符模板（用 {明星} {城市} 等自动替换）</option>' +
            '<option value="fixed"' + (t.titleMode === 'fixed' ? ' selected' : '') + '>固定模板（标题写死，不替换）</option>' +
            '<option value="random"' + (t.titleMode === 'random' ? ' selected' : '') + '>随机模板标题（每次发布随机选模板，不重复轮回）</option>' +
            '</select>' +
            '<label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">标题 <span style="color:#999;font-size:10px;">（占位符模式可用: {明星} {城市} {场次类型} {活动类型}）</span></label>' +
            '<input id="tplTitle" value="' + esc(t.titlePattern || '') + '" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:13px;box-sizing:border-box;"></div>' +
            '<div style="margin-bottom:12px;"><label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">描述模板</label>' +
            '<textarea id="tplDesc" rows="6" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:12px;box-sizing:border-box;resize:vertical;line-height:1.5;">' + esc(t.descPattern || '') + '</textarea></div>' +
            '<div style="display:flex;gap:12px;margin-bottom:16px;">' +
            '<div style="flex:1;"><label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">价格（元）</label>' +
            '<input id="tplPrice" value="' + esc(t.price) + '" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:13px;box-sizing:border-box;"></div>' +
            '<div style="flex:1;"><label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">原价（元）<span style="color:#999;font-size:10px;">划线价，留空=同价格</span></label>' +
            '<input id="tplOrigPrice" value="' + esc(t.origPrice || '') + '" placeholder="留空=同价格" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:13px;box-sizing:border-box;"></div>' +
            '<div style="flex:1;"><label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">库存</label>' +
            '<input id="tplStock" value="' + esc(t.stock) + '" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:13px;box-sizing:border-box;"></div>' +
            '<div style="flex:1;"><label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">分类</label>' +
            '<select id="tplCat" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:13px;box-sizing:border-box;">' +
            '<option value="代购"' + (t.categoryName === '代购' ? ' selected' : '') + '>代购</option>' +
            '<option value="创业/副业培训"' + (t.categoryName === '创业/副业培训' ? ' selected' : '') + '>创业/副业培训</option>' +
            '<option value="技能类招工"' + (t.categoryName === '技能类招工' ? ' selected' : '') + '>技能类招工</option>' +
            '<option value="互联网产品与运营技能培训"' + (t.categoryName === '互联网产品与运营技能培训' ? ' selected' : '') + '>互联网产品与运营技能培训</option>' +
            '</select></div>' +
            '</div>' +
            '<div style="display:flex;gap:12px;margin-bottom:16px;">' +
            '<div style="flex:1;"><label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">交付方式</label>' +
            '<select id="tplShipMode" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:13px;box-sizing:border-box;">' +
            '<option value="nomail"' + ((t.shipMode || 'nomail') === 'nomail' ? ' selected' : '') + '>无需邮寄</option>' +
            '<option value="free"' + (t.shipMode === 'free' ? ' selected' : '') + '>包邮</option>' +
            '<option value="distance"' + (t.shipMode === 'distance' ? ' selected' : '') + '>不包邮-按距离付费</option>' +
            '<option value="fixed"' + (t.shipMode === 'fixed' ? ' selected' : '') + '>不包邮-固定邮费</option>' +
            '</select></div>' +
            '<div style="flex:1;"><label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">所在位置</label>' +
            '<select id="tplLocationMode" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:13px;box-sizing:border-box;">' +
            '<option value="city"' + ((t.locationMode || 'random_tier1') === 'city' ? ' selected' : '') + '>跟随标题城市</option>' +
            '<option value="random_tier1"' + ((t.locationMode || 'random_tier1') === 'random_tier1' ? ' selected' : '') + '>随机一线城市</option>' +
            '<option value="random_any"' + (t.locationMode === 'random_any' ? ' selected' : '') + '>随机任意城市</option>' +
            '<option value="fixed"' + (t.locationMode === 'fixed' ? ' selected' : '') + '>固定位置</option>' +
            '</select></div>' +
            '</div>' +
            '<div style="display:flex;gap:12px;margin-bottom:16px;align-items:flex-end;">' +
            '<div style="flex:1;"><label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">🖼️ 副图</label>' +
            '<select id="tplSubImg" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:13px;box-sizing:border-box;">' +
            '<option value="true"' + (t.subImg !== false ? ' selected' : '') + '>上传副图</option>' +
            '<option value="false"' + (t.subImg === false ? ' selected' : '') + '>无副图</option>' +
            '</select></div>' +
            '<div style="flex:2;"><label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">🔒 承诺</label>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap;padding:8px;border:1px solid #ddd;border-radius:6px;">' +
            '<label style="cursor:pointer;font-size:12px;"><input type="checkbox" id="tplCF"' + ((t.commitment||{}).refundFull ? ' checked' : '') + '> 描述不符全额退</label>' +
            '<label style="cursor:pointer;font-size:12px;"><input type="checkbox" id="tplCP"' + ((t.commitment||{}).refundPostage ? ' checked' : '') + '> 描述不符包邮退</label>' +
            '<label style="cursor:pointer;font-size:12px;"><input type="checkbox" id="tplCS"' + ((t.commitment||{}).fastShip ? ' checked' : '') + '> 10分钟发货</label>' +
            '</div></div>' +
            '</div>' +
            '<div style="display:flex;gap:8px;justify-content:flex-end;">' +
            (state.templates.length > 1 ? '<button id="tplDelete" style="background:#fff0f0;color:#e74c3c;border:1px solid #ffccc7;border-radius:6px;padding:8px 16px;cursor:pointer;font-size:13px;margin-right:auto;">🗑 删除</button>' : '') +
            '<button id="tplCancel" style="background:#f5f5f5;color:#333;border:1px solid #ddd;border-radius:6px;padding:8px 16px;cursor:pointer;font-size:13px;">取消</button>' +
            '<button id="tplSave" style="background:#E67E22;color:#fff;border:none;border-radius:6px;padding:8px 20px;cursor:pointer;font-size:13px;font-weight:600;">💾 保存</button>' +
            '</div>' +
            '</div>';
        document.body.appendChild(modal);

        // 关闭/取消
        function closeModal() { modal.remove(); }
        var _ec=$('tplEditClose'); if(_ec) _ec.onclick = closeModal;
        var _tc=$('tplCancel'); if(_tc) _tc.onclick = closeModal;

        // 保存
        var _ts=$('tplSave'); if(_ts) _ts.onclick = async function() {
            t.name = $('tplName').value || '模板';
            t.titlePattern = $('tplTitle').value;
            t.descPattern = $('tplDesc').value;
            t.price = $('tplPrice').value || '50';
            t.origPrice = $('tplOrigPrice') ? $('tplOrigPrice').value : '';
            t.stock = $('tplStock').value || '9999';
            t.titleMode = $('tplTitleMode').value;
            t.categoryName = $('tplCat').value;
            t.shipMode = $('tplShipMode').value;
            t.locationMode = $('tplLocationMode').value;
            t.subImg = $('tplSubImg').value === 'true';
            t.commitment = { refundFull: $('tplCF').checked, refundPostage: $('tplCP').checked, fastShip: $('tplCS').checked };
            renderTemplates();
            closeModal();
            addLog('💾 模板已更新', 'ok');
            // 保存到 goofish 页面
            await saveStoreTemplates();
        };

        // 删除
        var delBtn = $('tplDelete');
        if (delBtn) {
            delBtn.onclick = async function() {
                if (state.templates.length <= 1) return;
                state.templates.splice(idx, 1);
                if (state.activeTemplateId === t.id) state.activeTemplateId = state.templates[0].id;
                renderTemplates();
                closeModal();
                addLog('🗑 模板已删除', 'warn');
                await saveStoreTemplates();
            };
        }

        // 点遮罩关闭
        modal.onclick = function(e) { if (e.target === modal) closeModal(); };
    }

    // ===== 保存模板到 goofish 页面 =====
    async function saveStoreTemplates() {
        if (!state.currentStore) return;
        try {
            // 转成 publish.js 需要的格式，先 setStore 确保存到正确店铺
            var tplsJson = JSON.stringify(state.templates);
            var storeJson = JSON.stringify(state.currentStore);
            var code = '(function(){try{window.kunPublish.setStore(' + storeJson + ');var tpls=' + tplsJson + ';window.kunPublish.saveCustomTemplates(tpls);window.kunPublish.reloadStoreTemplates();return "ok";}catch(e){return e.message;}})()';
            var r = await evalOnStore(state.currentStore, code);
            if (r.ok && r.result === 'ok') {
                addLog('✅ 模板已保存到店铺「' + state.currentStore + '」', 'ok');
            } else {
                addLog('⚠ 模板保存: ' + (r.result || r.error || '未知'), 'warn');
            }
        } catch(e) {
            addLog('⚠ 模板保存失败: ' + e.message, 'warn');
        }
    }

    // ===== 搬运店铺：抓取 → 加入当前店铺任务 =====
    async function scrapeCurrentStore() {
        var store = state.currentStore;
        if (!store) { addLog('⚠ 请先在右上角选择店铺', 'warn'); return; }
        var url = ($('iwScrapeUrl').value || '').trim();
        if (!url) { addLog('⚠ 请输入店铺地址', 'warn'); return; }
        var mode = $('scrapeType').value;
        var mult = parseFloat($('scrapePriceMul').value) || 1;
        var st = $('scrapeStatus');
        if (st) st.textContent = '⏳ 抓取中...';
        $('iwScrapeBtn').disabled = true;
        try {
            var r = await api('/api/agent/scrape-shop', { store: store, url: url, mode: mode, limit: 20 });
            if (r.ok && r.items && r.items.length > 0) {
                var prefix = store;
                var tier1 = ['北京','上海','广州','深圳','杭州','成都','武汉','南京','重庆'];
                for (var i = 0; i < r.items.length; i++) {
                    var it = r.items[i];
                    // 清洗闲鱼卡片带进来的杂质：价格片段和「N人想要」
                    var rawTitle = (it.title || '').replace(/\d+人想要/g, '').replace(/¥[\d.]+/g, '').replace(/\s+/g, ' ').trim();
                    var ft = prefix + rawTitle;
                    var st30 = ft.length > 30 ? ft.substring(0, 30) : ft;
                    var task;
                    if (mode === 'xianyu') {
                        task = {
                            star: st30,
                            description: ft.length > 30 ? '[完整标题:' + ft + ']\n\n' + (it.description || '') : (it.description || ''),
                            price: String(it.price || ''), origPrice: '',
                            imageUrls: it.images || (it.image ? [it.image] : []),
                            city: '', categoryName: '', shipMode: 'free', stock: '999',
                            directTitle: true, status: 'pending'
                        };
                    } else {
                        var descText = '这款不是正品，是' + prefix + '工厂代工，品牌的做工品质！\n\n有需要的咨询~';
                        task = {
                            star: st30,
                            description: ft.length > 30 ? '[完整标题:' + ft + ']\n\n' + descText : descText,
                            price: String(Math.round((it.price || 0) * mult)), origPrice: String(it.price || ''),
                            imageUrls: it.images || (it.image ? [it.image] : []),
                            city: tier1[Math.floor(Math.random() * tier1.length)], categoryName: '装饰灯', shipMode: 'free', stock: '999',
                            directTitle: true, status: 'pending'
                        };
                    }
                    state.tasks.push(task);
                }
                renderTasks();
                saveStoreData();
                addLog('✅ 搬运完成：' + r.items.length + ' 个商品已加入「' + store + '」任务', 'ok');
                if (st) st.textContent = '✅ 已添加 ' + r.items.length + ' 个商品';
            } else {
                addLog('❌ 搬运失败: ' + (r.error || '未找到商品'), 'err');
                if (st) st.textContent = '❌ ' + (r.error || '未找到商品');
            }
        } catch(e) {
            addLog('❌ 搬运出错: ' + (e.message || e), 'err');
            if (st) st.textContent = '❌ ' + (e.message || e);
        }
        $('iwScrapeBtn').disabled = false;
    }

    // 📋 查全部计划：eval 店铺页 campaign.search → 状态/出价/花费
    // ⚡ 智能调价(试1个)：找第一个"投放中但烧不动"的计划 → campaign.edit 出价×1.1
    var _autoBidBtn = $('btnAutoBid');
    if (_autoBidBtn) _autoBidBtn.onclick = async function() {
        var store = state.currentStore; if (!store) { addLog('⚠ 请先选店铺', 'warn'); return; }
        addLog('📋 切到闲鱼后台 + 查询计划...', 'info');
        try { await api('/api/agent/move', { store: store, url: 'https://dayu.goofish.com/?site=FISHAD#/ad/home' }); } catch(e){}
        await sleep(4000);
        var expr = '(function(){ try { var t=new Date(); var ss=new Date(t.getTime()-30*86400000); function f(d){return d.getFullYear()+"-"+("0"+(d.getMonth()+1)).slice(-2)+"-"+("0"+d.getDate()).slice(-2);} var body={pageNum:1,pageSize:100,startDate:f(ss),endDate:f(t),includeEndDate:true,campaignStatus:[-6,-5,-4,-3,-2,1,2,3,4,5,6,99],statusGroup:[]}; return window.lib.mtop.request({api:"mtop.taobao.idle.ad.campaign.search",v:"1.0",data:{requestJson:JSON.stringify(body)},type:"POST"}).then(function(r){ if(r&&r.ret&&r.ret[0]&&r.ret[0].startsWith("SUCCESS")){ return JSON.stringify({list:(r.data&&r.data.result)||[]}); } return JSON.stringify({err:(r&&r.ret?r.ret[0]:"fail")}); }); } catch(e){ return Promise.resolve(JSON.stringify({err:e.message})); } })()';
        var rr; try { rr = await evalOnStore(store, expr); } catch(e){ addLog('❌ eval异常: ' + e.message, 'err'); return; }
        var d = JSON.parse(rr.result || '{}'); if (d.err) { addLog('❌ 查询失败: ' + d.err, 'err'); return; }
        var list = d.list || []; addLog('🔍 共 ' + list.length + ' 计划，挑一个出价低的试', 'info');
        // 挑一个 bidPrice 较小（烧不动）的
        var target = list.filter(function(c){ var b=(c.bidPrice!=null)?c.bidPrice:((c.infoTab&&c.infoTab.bidPrice!=null)?c.infoTab.bidPrice:0); return c.campaignId && b>0; }).sort(function(a,b){ var x=(a.bidPrice!=null?a.bidPrice:((a.infoTab&&a.infoTab.bidPrice)||0)); var y=(b.bidPrice!=null?b.bidPrice:((b.infoTab&&b.infoTab.bidPrice)||0)); return x-y; })[0];
        if (!target) { addLog('⚠ 没找到可调的计划', 'warn'); return; }
        var cid = target.campaignId || target.id; var bidNow = (target.bidPrice!=null?target.bidPrice:((target.infoTab&&target.infoTab.bidPrice)||0)) / 100; var bidNew = Math.round(bidNow * 1.1 * 100) / 100;
        addLog('🎯 试调: campaignId=' + cid + ' 当前出价¥' + bidNow + ' → 调至¥' + bidNew + '（×1.1）', 'info');
        var editExpr = '(function(){ try { var cid=' + cid + '; var nd=' + Math.round(bidNew*100) + '; var body={itemCampaigns:[{campaignId:cid,feedEntityType:1,bid:nd,infoTab:{bidPrice:nd,maxDayBudget:10000,budgetScheduleDurations:[8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]},maxDayBudget:10000,budgetScheduleDurations:[8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]}]}; return window.lib.mtop.request({api:"mtop.taobao.idle.ad.campaign.edit",v:"1.0",data:{requestJson:JSON.stringify(body)},type:"POST"}).then(function(r){ return JSON.stringify({ret:(r&&r.ret&&r.ret[0])||"fail", data:(r&&r.data)||{}}); }); } catch(e){ return Promise.resolve(JSON.stringify({ret:e.message})); } })()';
        var ee; try { ee = await evalOnStore(store, editExpr); } catch(e){ addLog('❌ 调价eval异常: ' + e.message, 'err'); return; }
        var ed = JSON.parse(ee.result || '{}');
        addLog((ed.ret && ed.ret.indexOf('SUCCESS') >= 0 ? '✅ 调价成功' : '❌ 调价失败: ' + ed.ret), ed.ret && ed.ret.indexOf('SUCCESS') >= 0 ? 'ok' : 'err');
    };
    var _campBtn = $('btnLoadCampaigns');
    if (_campBtn) _campBtn.onclick = async function() {
        var store = state.currentStore; if (!store) { addLog('⚠ 请先选店铺', 'warn'); return; }
        var out = $('campaignOut'); if (out) out.innerHTML = '⏳ 查询中...';
        addLog('📋 把店铺「' + store + '」切到闲鱼后台(dayu)再查...', 'info');
        try { var nv = await api('/api/agent/move', { store: store, url: 'https://dayu.goofish.com/?site=FISHAD#/ad/home' }); if (!nv || !nv.ok) addLog('⚠ 切dayu失败: ' + (nv && nv.error || ''), 'warn'); } catch(e){ addLog('⚠ 切dayu异常: ' + e.message, 'warn'); }
        await sleep(4500);
        addLog('📋 查询店铺「' + store + '」全部超级擦亮计划...', 'info');
        var expr = '(function(){ try { var t=new Date(); var ss=new Date(t.getTime()-30*86400000); function f(d){return d.getFullYear()+"-"+("0"+(d.getMonth()+1)).slice(-2)+"-"+("0"+d.getDate()).slice(-2);} var body={pageNum:1,pageSize:100,startDate:f(ss),endDate:f(t),includeEndDate:true,campaignStatus:[-6,-5,-4,-3,-2,1,2,3,4,5,6,99],statusGroup:[]}; return window.lib.mtop.request({api:"mtop.taobao.idle.ad.campaign.search",v:"1.0",data:{requestJson:JSON.stringify(body)},type:"POST"}).then(function(r){ if(r&&r.ret&&r.ret[0]&&r.ret[0].startsWith("SUCCESS")){ return JSON.stringify({list:(r.data&&r.data.result)||[],raw:JSON.stringify(r.data).slice(0,200)}); } return JSON.stringify({err:(r&&r.ret?r.ret[0]:"fail")}); }); } catch(e){ return Promise.resolve(JSON.stringify({err:e.message})); } })()';
        try {
            var rr = await evalOnStore(store, expr);
            if (!rr || !rr.ok) { addLog('❌ 查询失败: ' + (rr && rr.error || ''), 'err'); out.innerHTML = '查询失败'; return; }
            var d = JSON.parse(rr.result || '{}');
            if (d.err) { addLog('❌ campaign.search: ' + d.err, 'err'); out.innerHTML = '查询失败: ' + d.err; return; }
            var list = (d.list || []).filter(Boolean); addLog('🔍 campaign.search 返回: total=' + list.length + ' ' + (d.raw || ''), 'info');
            var stMap = { 1:'投放中',2:'暂停',3:'结束',4:'暂停',6:'投放中',99:'结束' };
            var rows = list.map(function(c){ var st = c.status != null ? c.status : c.campaignStatus; var stl = stMap[st] || ('状态' + st); var bid = (c.bidPrice != null) ? (c.bidPrice/100) : ((c.infoTab&&c.infoTab.bidPrice!=null)?(c.infoTab.bidPrice/100):''); var bg = (c.maxDayBudget != null) ? (c.maxDayBudget/100) : ((c.infoTab&&c.infoTab.maxDayBudget!=null)?(c.infoTab.maxDayBudget/100):''); var nm = c.campaignName || c.name || ((c.entityList&&c.entityList[0]&&c.entityList[0].title)||'') || (c.result && c.result[0] && c.result[0].title) || ''; return { name: nm, status: c.status != null ? c.status : stl, pause: c.pauseStatus, bid: c.bidPrice != null ? (c.bidPrice/100) : bid, budget: c.maxDayBudget != null ? (c.maxDayBudget/100) : bg, id: c.campaignId || c.id }; });
            out.innerHTML = rows.map(function(x){ var bar = x.pause===1 ? '×' : ''; return '<div style="padding:3px 0;border-bottom:1px solid #eee;">' + (bar||'') + ' <b>' + esc((x.name||x.id).slice(0,22)) + '</b> <span style="color:' + (x.status==='投放中' ? '#27ae60' : '#e67e22') + '">[' + x.status + ']</span> 出价¥' + x.bid + ' 预算¥' + x.budget + '</div>'; }).join('') || '无计划';
            addLog('📋 共 ' + list.length + ' 个计划（点击刷新可重查）', 'ok');
        } catch(e) { addLog('❌ 查询异常: ' + e.message, 'err'); out.innerHTML = '查询异常'; }
    };
    var _cStarBtn = $('iwCampaignStarBtn');
    if (_cStarBtn) _cStarBtn.onclick = async function() {
        var star = prompt('要合成推广的明星（如：孙燕姿）：'); if (!star) return;
        var store = state.currentStore; if (!store) { addLog('⚠ 请先选店铺', 'warn'); return; }
        var url = ($('iwScrapeUrl').value || '').trim(); if (!url) { addLog('⚠ 请先填店铺地址（iwScrapeUrl）', 'warn'); return; }
        addLog('🎯 抓取店铺商品，筛「' + star + '」...', 'info');
        var r; try { r = await api('/api/agent/scrape-shop', { store: store, url: url, mode: 'xianyu', limit: 50 }); } catch(e) { addLog('❌ 抓取异常: ' + e.message, 'err'); return; }
        if (!r.ok || !r.items) { addLog('❌ 抓取失败: ' + (r.error || ''), 'err'); return; }
        var matched = r.items.filter(function(it){ return (it.title || '').indexOf(star) >= 0; });
        if (!matched.length) { addLog('⚠ 没有标题含「' + star + '」的商品', 'warn'); return; }
        var ids = matched.map(function(it){ var m=((it.url||'').match(/id=(\d+)/)); return m ? { itemId: m[1], catId: 201456914, priceYuan: it.price || 50 } : null; }).filter(Boolean);
        if (!ids.length) { addLog('⚠ 无法取到 itemId', 'warn'); return; }
        addLog('🎯 找到 ' + ids.length + ' 条「' + star + '」，合成一个推广...', 'info');
        try {
            await evalOnStore(store, '(function(){ try { window.kunPublish.startCampaignBatch(' + JSON.stringify(ids.slice(0,10)) + ', { bidPrice: 13.6, bidTarget: "order", maxDayBudget: 100, city: "", star: "' + star + '" }); return "started"; } catch(e){ return "ERR:" + e.message; } })()');
            addLog('✅ 已下发合成推广指令（' + Math.min(ids.length,10) + '条）', 'ok');
        } catch(e) { addLog('❌ 合成失败: ' + e.message, 'err'); }
    };

    // 📊 擦亮看板：查询所有擦亮计划的投入/咨询/询单成本/下单成本，并按成本标色
    var _burnBtn = $('btnBurnBoard');
    if (_burnBtn) _burnBtn.onclick = async function() {
        var out = $('burnOut'); if (!out) return;
        out.innerHTML = '⏳ 查询擦亮计划...';
        var r; try { r = await api('/api/poster/burn-plans'); } catch(e) { out.innerHTML = '❌ ' + (e.message || e); return; }
        if (!r || !r.ok) { out.innerHTML = '❌ ' + (r && r.error || '加载失败'); addLog('📊 擦亮看板加载失败: ' + (r && r.error || ''), 'err'); return; }
        var list = (r.burn || []).filter(Boolean);
        function fmt(n) { return (n == null || isNaN(n)) ? '-' : (+n).toFixed(2); }
        function cls(v) { if (v == null || isNaN(v)) return '#999'; return v < 4 ? '#27ae60' : (v <= 33 ? '#e67e22' : '#e74c3c'); }
        var html = '<div style="margin-bottom:6px;padding:4px 6px;background:#f5f5f5;border-radius:4px;font-size:11px;color:#666;">🎯 目标：100块搞3单 ≈ <b>33.3元/单</b>，单次咨询 3-4元</div>';
        html += '<table style="width:100%;border-collapse:collapse;font-size:11px;">';
        html += '<tr style="background:#f8f9fa;"><th style="padding:4px;border-bottom:1px solid #eee;text-align:left;">ID</th><th style="padding:4px;border-bottom:1px solid #eee;">投入(元)</th><th style="padding:4px;border-bottom:1px solid #eee;">咨询</th><th style="padding:4px;border-bottom:1px solid #eee;">询单成本</th><th style="padding:4px;border-bottom:1px solid #eee;">下单成本</th></tr>';
        for (var i = 0; i < list.length; i++) {
            var it = list[i];
            html += '<tr style="border-bottom:1px solid #f0f0f0;">' +
                '<td style="padding:4px;text-align:left;">' + esc(it.id) + '</td>' +
                '<td style="padding:4px;text-align:center;">' + fmt(it.cost) + '</td>' +
                '<td style="padding:4px;text-align:center;">' + (it.inq != null ? it.inq : '-') + '</td>' +
                '<td style="padding:4px;text-align:center;font-weight:600;color:' + cls(it.costPerInquiry) + ';">' + fmt(it.costPerInquiry) + '</td>' +
                '<td style="padding:4px;text-align:center;font-weight:600;color:' + cls(it.costPerOrder) + ';">' + fmt(it.costPerOrder) + '</td>' +
            '</tr>';
        }
        html += '</table>';
        if (!list.length) html = '<div style="color:#999;padding:6px;">暂无数据</div>';
        out.innerHTML = html;
        addLog('📊 擦亮看板已加载 ' + list.length + ' 条', 'info');
    };

    // ===== 发当前：当前店铺批量发布 =====
    async function publishCurrentStore() {
        if (!state.currentStore) { addLog('⚠ 请先选择店铺', 'warn'); return; }
        if (state.publishing) { addLog('⏳ 发布流程进行中（正在下发指令/轮询进度），请稍候或点 ⏹停止 后再操作', 'warn'); return; }
        var pending = state.tasks.filter(function(t) { return t.status !== 'done' && t.status !== 'failed'; });
        if (pending.length === 0) { addLog('⚠ 当前店铺没有待发任务', 'warn'); return; }
        if (!confirm('📤 当前店铺「' + state.currentStore + '」批量发布 ' + pending.length + ' 个任务？\n\n发布在店铺页面后台运行，发布台可关闭。')) return;
        await runStoreBatch([state.currentStore]);
    }

    // ===== 快速发布：当前店铺马上发前 N 条(1-10)，连发不间隔 =====
    async function quickPublishStore() {
        if (!state.currentStore) { addLog('⚠ 请先选择店铺', 'warn'); return; }
        if (state.publishing) { addLog('⏳ 发布流程进行中（请稍候或点 ⏹停止 后再操作）', 'warn'); return; }
        var n = parseInt(($('setQuickCount') ? $('setQuickCount').value : 1)) || 1;
        n = Math.max(1, Math.min(10, n));
        var store = state.currentStore;
        var pending = state.tasks.filter(function(t) {
            if (t.status === 'done' || t.status === 'failed' || t.itemId) return false;
            return !t.targetStore || t.targetStore === store;
        });
        if (pending.length === 0) { addLog('⚠ 当前店铺「' + store + '」没有待发任务', 'warn'); return; }
        var willSend = Math.min(n, pending.length);
        if (!confirm('⚡ 快速发布「' + store + '」前 ' + willSend + ' 条？\n\n连发不间隔，在店铺页面后台运行，发布台可关闭。')) return;
        state.publishing = true;
        var _pc = $('progressCard'); if (_pc) _pc.style.display = 'block';
        addLog('⚡ 快速发布「' + store + '」前 ' + willSend + ' 条...', 'info');
        try {
            var h = await api('/health');
            if (!h.running) await api('/api/agent/start-all', {});
            var startOne = await api('/api/agent/start-one', { name: store });
            if (!startOne.ok) { addLog('❌ 店铺启动失败: ' + (startOne.error || ''), 'err'); state.publishing = false; return; }
            await sleep(3000);
            if (!(await ensureStoreEngine(store))) { state.publishing = false; return; }
            // 传 maxCount=willSend → runBatchPublish 只发前 N 条；直接塞任务进店铺页，绕过磁盘同步，确保读到
            var _pt = pending.map(function(t){ var o=Object.assign({},t); if((!Array.isArray(o.imageUrls)||!o.imageUrls.length)&&o.imageName){o.imageUrls=[o.imageName];} return o; });
            var _tplId = state.activeTemplateId || 1;
            var _iv = parseInt(($('setInterval') && $('setInterval').value) || 60) || 60;
            var code = '(async function(){try{' +
                'window.kunPublish.setStore(' + JSON.stringify(store) + ');' +
                'try{await window.kunPublish.syncTasksFromDisk();}catch(e){}' +
                // 下发前预上传图：把本地图转成 fleamarket URL 存进任务 imageUrls，发布直接用 URL(已验证能拿 itemId)，不现传
                'var _tasks=' + JSON.stringify(_pt) + ';' +
                'var sf="C:/Users/43462/Desktop/闲鱼上架图片/"+(window.kunPublish.currentStore||"")+"/";' +
                'for(var ti=0;ti<_tasks.length;ti++){var _t=_tasks[ti];if(_t&&Array.isArray(_t.imageUrls)){for(var ui=0;ui<_t.imageUrls.length;ui++){var _u=_t.imageUrls[ui];if(_u&&_u.indexOf("http")!==0){try{var _up=await window.kunPublish.uploadLocalImage(sf+_u);if(_up&&_up.indexOf("http")===0){_t.imageUrls[ui]=_up;}}catch(e){}}}}}' +
                'var d={templateId:' + _tplId + ',publishInterval:' + _iv + ',batchSize:0,batchInterval:' + _iv + ',autoPolish:' + ($('setAutoPolish') ? $('setAutoPolish').value === 'true' : false) + ',campaignMode:"' + (($('setCampaignMode')&&$('setCampaignMode').value)||'single') + '",tasks:_tasks};' +
                'localStorage.setItem("kun_daily_tasks_v2", JSON.stringify(d));' +
                'window.kunPublish.runBatchPublish(' + willSend + ');' +
                'return "started";}catch(e){return "err:"+e.message;}})()';
            var r = await evalOnStore(store, code);
            if (r.ok && r.result === 'started') {
                addLog('⚡ 已下发「' + store + '」快速发布 ' + willSend + ' 条（店铺页面后台连发）', 'ok');
                await pollStoreBatch(store, willSend);
            } else {
                addLog('❌ 快速发布启动失败: ' + (r.result || r.error || ''), 'err');
            }
        } catch(e) {
            addLog('❌ 快速发布异常: ' + e.message, 'err');
        }
        state.publishing = false;
        if (_pc) _pc.style.display = 'none';
    }

    // ===== 批量发布：所有勾选店铺 =====
    async function batchPublishSelected() {
        if (state.selectedStores.length === 0) { addLog('⚠ 请先勾选店铺', 'warn'); return; }
        if (state.publishing) { addLog('⏳ 发布流程进行中（正在下发指令/轮询进度），请稍候或点 ⏹停止 后再操作', 'warn'); return; }
        var pending = state.tasks.filter(function(t) { return t.status !== 'done' && t.status !== 'failed'; });
        if (pending.length === 0) { addLog('⚠ 没有待发任务', 'warn'); return; }
        if (!confirm('📦 批量发布 ' + state.selectedStores.length + ' 个店铺，共 ' + pending.length + ' 个任务？\n\n发布在店铺页面后台运行，发布台可关闭。')) return;
        await runStoreBatch(state.selectedStores.slice());
    }

    // 确保店铺页面引擎是新版（含磁盘同步）；旧版自动刷新页面重新注入，不打断正在发布的循环
    async function ensureStoreEngine(store) {
        var check = await evalOnStore(store, '(function(){try{return (window.kunPublish && window.kunPublish.EngineVer === "4") ? "ok" : "old";}catch(e){return "none";}})()');
        if (check.ok && check.result === 'ok') return true;
        addLog('🔄 店铺「' + store + '」发布引擎为旧版，自动刷新页面升级...', 'warn');
        var nav = await api('/api/agent/move', { store: store, url: 'https://www.goofish.com/' });
        if (!nav.ok) { addLog('❌ 刷新失败: ' + (nav.error || ''), 'err'); return false; }
        for (var i = 0; i < 10; i++) {
            await sleep(2000);
            var re = await evalOnStore(store, '(function(){try{return typeof window.kunPublish.syncTasksFromDisk;}catch(e){return "none";}})()');
            if (re.ok && re.result === 'function') { addLog('✅ 店铺「' + store + '」引擎已升级', 'ok'); return true; }
        }
        addLog('❌ 店铺「' + store + '」引擎升级超时，请在它的浏览器窗口按 F5 后重试', 'err');
        return false;
    }

    // ===== 遥控批量发布：启动店铺 → 店铺页面自己循环 =====
    async function runStoreBatch(stores) {
        state.publishing = true;
        $('btnPublishAll').style.display = 'none';
        $('btnStop').style.display = 'inline-block';
        $('progressCard').style.display = 'block';
        var launched = []; // { store, total } 已成功启动批量发布的店铺
        // 并行启动所有店铺（每店独立页面，互不干扰）
        await Promise.all(stores.map(async function(store) {
            if (!state.publishing) return;
            addLog('━━━━━━━━━━━━━━━━', 'dim');
            addLog('🏪 店铺: ' + store, 'info');
            try {
                if (store === state.currentStore) {
                    // P0-4：先合并磁盘已回写的 itemId/status，再写盘，避免内存覆盖抹掉防重发标记
                    await refreshTaskStatusFromDisk([store]);
                    await saveStoreTasksToDisk(store);
                }
                // 合并后检查该店是否还有待发任务；全已发布则跳过，避免启动空批次卡住
                var storePending = state.tasks.filter(function(t) {
                    if (t.status === 'done' || t.status === 'failed' || t.itemId) return false;
                    return !t.targetStore || t.targetStore === store;
                }).length;
                if (storePending === 0) {
                    addLog('⏭ 店铺「' + store + '」没有待发任务（任务已全部发布过；如需重发请先清除任务的 ✅/itemId）', 'warn');
                    return;
                }
                var h = await api('/health');
                if (!h.running) await api('/api/agent/start-all', {});
                var startOne = await api('/api/agent/start-one', { name: store });
                if (!startOne.ok) { addLog('❌ 店铺启动失败: ' + (startOne.error || ''), 'err'); return; }
                await sleep(3000);
                if (!(await ensureStoreEngine(store))) return;
                var _pst = state.tasks.filter(function(t){ if(t.status==='done'||t.status==='failed'||t.itemId) return false; return !t.targetStore || t.targetStore===store; }).map(function(t){ var o=Object.assign({},t); if((!Array.isArray(o.imageUrls)||!o.imageUrls.length)&&o.imageName){o.imageUrls=[o.imageName];} return o; });
                var _tplId = state.activeTemplateId || 1;
                var _iv = parseInt(($('setInterval') && $('setInterval').value) || 60) || 60;
                var _bs = parseInt(($('setBatchSize') && $('setBatchSize').value) || '0') || 0;       // 每批(如2) → 2个一组
                var _biv = parseInt(($('setBatchInterval') && $('setBatchInterval').value) || '0') || 0; // 批间分
                if (!_biv) _biv = _iv;
                var code = '(async function(){try{' +
                    'window.kunPublish.setStore(' + JSON.stringify(store) + ');' +
                    'try{await window.kunPublish.syncTasksFromDisk();}catch(e){}' +
                    'var _tasks=' + JSON.stringify(_pst) + ';' +
                    'var sf="C:/Users/43462/Desktop/闲鱼上架图片/"+(window.kunPublish.currentStore||"")+"/";' +
                    'for(var ti=0;ti<_tasks.length;ti++){var _t=_tasks[ti];if(_t&&Array.isArray(_t.imageUrls)){for(var ui=0;ui<_t.imageUrls.length;ui++){var _u=_t.imageUrls[ui];if(_u&&_u.indexOf("http")!==0){try{var _up=await window.kunPublish.uploadLocalImage(sf+_u);if(_up&&_up.indexOf("http")===0){_t.imageUrls[ui]=_up;}}catch(e){}}}}}' +
                    'var d={templateId:' + _tplId + ',publishInterval:' + _iv + ',batchSize:' + _bs + ',batchInterval:' + _biv + ',autoPolish:' + ($('setAutoPolish') ? $('setAutoPolish').value === 'true' : false) + ',tasks:_tasks};' +
                    'localStorage.setItem("kun_daily_tasks_v2", JSON.stringify(d));' +
                    'window.kunPublish.runBatchPublish();' +
                    'return "started";}catch(e){return "err:"+e.message;}})()';
                var r = await evalOnStore(store, code);
                if (r.ok && r.result === 'started') {
                    addLog('📦 店铺「' + store + '」批量发布已启动（在店铺页面后台运行）', 'ok');
                    launched.push({ store: store, total: storePending || 1 });
                } else {
                    addLog('❌ 店铺「' + store + '」启动发布失败: ' + (r.result || r.error || ''), 'err');
                }
            } catch(e) {
                addLog('❌ 店铺「' + store + '」异常: ' + e.message, 'err');
            }
        }));
        // 并行轮询已启动店铺的发布进度（每店独立更新自己的进度，不阻塞其它店）
        await Promise.all(launched.map(function(entry) {
            return pollStoreBatch(entry.store, entry.total);
        }));
        state.publishing = false;
        $('btnPublishAll').style.display = '';
        $('btnStop').style.display = 'none';
        var _pc = $('progressCard'); if (_pc) _pc.style.display = 'none';
        addLog('🎉 批量发布指令处理完成（店铺页面后台可能仍在发布）', 'ok');
    }

    // 轮询店铺批量发布进度（循环在店铺页面，这里只读状态）
    async function pollStoreBatch(store, total) {
        var fails = 0;
        var idlePolls = 0;
        for (var i = 0; i < 60; i++) {
            if (!state.publishing) return;
            await sleep(10000);
            // 把该店页面提到前台（后台 tab 强节流会把 setTimeout 钳到约1分钟，prevent 避免拖慢发布）
            await bringStoreToFront(store);
            try {
                var r = await evalOnStore(store, '(function(){try{var s=window.kunPublish.getBatchStatus?window.kunPublish.getBatchStatus():{running:false};return JSON.stringify(s);}catch(e){return JSON.stringify({running:false});}})()');
                fails = 0;
                if (r.ok && r.result) {
                    var bs = typeof r.result === 'string' ? JSON.parse(r.result) : r.result;
                    if (bs && bs.running) {
                        idlePolls = 0;
                        updateProgress(bs.done + bs.failed, bs.total || total, store + ': 批量发布中 ✅' + bs.done + ' ❌' + bs.failed);
                        await refreshTaskStatusFromDisk([store]); // P0-5：表格状态回流
                        continue;
                    }
                    if (bs && (bs.total || 0) > 0) {
                        updateProgress(bs.done + bs.failed, bs.total, store + ': 完成 ✅' + bs.done + ' ❌' + bs.failed);
                        addLog('✅ 店铺「' + store + '」批量发布结束: 成功 ' + bs.done + ' / 失败 ' + bs.failed, bs.failed > 0 ? 'warn' : 'ok');
                        // 展示每条失败详情
                        if (bs.failedDetails && bs.failedDetails.length > 0) {
                            bs.failedDetails.forEach(function(fd) {
                                var label = (fd.star || '?') + (fd.city ? ' · ' + fd.city : '') + (fd.sessionType ? ' · ' + fd.sessionType : '');
                                addLog('  ❌ ' + label + ': ' + (fd.error || '未知错误'), 'err');
                            });
                        }
                        await refreshTaskStatusFromDisk([store]); // P0-5：完成后最后一次回流
                        return;
                    }
                    // 页面无运行状态也无任务数：批次可能未实际开始（任务已全部发布过/页面未就绪）
                    idlePolls++;
                    if (idlePolls >= 3) {
                        addLog('⏭ 店铺「' + store + '」发布未实际开始（任务可能已全部发布过或店铺页面未就绪，已停止等待）', 'warn');
                        return;
                    }
                }
            } catch(e) {
                fails++;
                if (fails >= 3) {
                    addLog('⏱ 店铺「' + store + '」进度查询连续失败，已停止轮询（发布仍在店铺页面后台运行）', 'warn');
                    return;
                }
            }
            // 状态未就绪时继续等待（不再无条件 return）
        }
        addLog('⏱ 店铺「' + store + '」进度查询超时（发布仍在店铺页面后台运行）', 'warn');
    }

    // ===== 一键发布：每日节奏（写盘 → 店铺页面自己循环，发布台只下指令） =====
    async function startPublish() {
        if (state.publishing) { addLog('⏳ 发布流程进行中（正在下发指令/轮询进度），请稍候或点 ⏹停止 后再操作', 'warn'); return; }
        if (state.selectedStores.length === 0) { addLog('⚠ 请先勾选店铺', 'warn'); return; }
        if (state.tasks.length === 0) { addLog('⚠ 没有任务', 'warn'); return; }
        var pending = state.tasks.filter(function(t){return t.status!=='done' && t.status!=='failed'}).length;
        if (pending === 0) { addLog('⚠ 没有待发任务（全部已完成或失败）', 'warn'); return; }
        var taskInterval = parseInt($('setInterval').value) || 60;
        if (!confirm('确定开始每日节奏发布？\n\n' + state.selectedStores.length + ' 个店铺 · ' + pending + ' 个待发任务 · 间隔 ' + taskInterval + ' 分钟/条\n\n发布循环在店铺页面后台运行，发布台关掉也不影响。')) return;

        state.publishing = true;
        $('btnPublishAll').style.display = 'none';
        $('btnStop').style.display = 'inline-block';
        $('progressCard').style.display = 'block';

        // 并行下发：三个店铺各自启动 + 注入 runOneStore（后台各自跑自己的任务队列）
        await Promise.all(state.selectedStores.map(async function(store) {
            if (!state.publishing) return;
            addLog('━━━━━━━━━━━━━━━━', 'dim');
            addLog('🏪 店铺: ' + store, 'info');
            try {
                // P0-4：先合并磁盘已回写的 itemId/status，再写盘，避免内存覆盖抹掉防重发标记（与 runStoreBatch 一致）
                if (store === state.currentStore) {
                    await refreshTaskStatusFromDisk([store]);
                    await saveStoreTasksToDisk(store, taskInterval);
                }
                var h = await api('/health');
                if (!h.running) await api('/api/agent/start-all', {});
                var startOne = await api('/api/agent/start-one', { name: store });
                if (!startOne.ok) { addLog('❌ 店铺启动失败: ' + (startOne.error || ''), 'err'); return; }
                await sleep(3000);
                if (!(await ensureStoreEngine(store))) return;
                // runOneStore：只跑这个店自己的任务队列（不拉别的店铺）
                var code = '(async function(){try{' +
                    'window.kunPublish.setStore(' + JSON.stringify(store) + ');' +
                    'await window.kunPublish.syncTasksFromDisk();' +
                    'window.kunPublish.runOneStore(' + JSON.stringify(store) + ');' +
                    'return "started";}catch(e){return "err:"+e.message;}})()';
                var r = await evalOnStore(store, code);
                if (r.ok && r.result === 'started') {
                    addLog('🚀 店铺「' + store + '」每日发布已启动（读自己的任务队列，后台运行）', 'ok');
                } else {
                    addLog('❌ 店铺「' + store + '」启动发布失败: ' + (r.result || r.error || ''), 'err');
                }
            } catch(e) {
                addLog('❌ 店铺「' + store + '」异常: ' + e.message, 'err');
            }
        }));
        state.publishing = false;
        $('btnPublishAll').style.display = '';
        $('btnStop').style.display = 'none';
        // P0-5：一键发布（每日节奏）没有 getBatchStatus 轮询，用磁盘回流更新表格与进度
        startStatusPoll(state.selectedStores.slice());
        addLog('✅ 指令下发完成。发布在店铺页面后台运行，发布台可关闭或切换店铺', 'ok');
    }

    async function stopPublish() {
        state.publishing = false;
        stopStatusPoll();
        var _pc2 = $('progressCard'); if (_pc2) _pc2.style.display = 'none';
        addLog('⏹ 向各店铺发送停止指令...', 'warn');
        for (var i = 0; i < state.selectedStores.length; i++) {
            try {
                await evalOnStore(state.selectedStores[i], '(function(){try{window.kunPublish.stopBatchPublish();window.kunPublish.stopDailyPublish();return "ok";}catch(e){return "err";}})()');
                addLog('  ⏹ ' + state.selectedStores[i] + ' 已发送停止', 'dim');
            } catch(e) {
                addLog('  ⚠ ' + state.selectedStores[i] + ' 停止指令失败: ' + e.message, 'warn');
            }
        }
        $('btnPublishAll').style.display = '';
        $('btnStop').style.display = 'none';
    }

    // ===== 进度 UI =====
    function updateProgress(processed, total, label) {
        var pct = total > 0 ? Math.round(processed / total * 100) : 0;
        $('progressBar').style.width = pct + '%';
        $('progressLabel').textContent = label;
        $('progressCount').textContent = processed + '/' + total;
    }

    // ===== 日志 =====
    function addLog(msg, cls) {
        var time = new Date().toLocaleTimeString('zh-CN', { hour12: false });
        var html = '<span style="color:#666;">' + time + '</span> ' + esc(msg);
        var box = $('logBox');
        var boxLeft = $('logBoxLeft');
        if (box) { var d1 = document.createElement('div'); d1.className = cls || ''; d1.innerHTML = html; box.appendChild(d1); box.scrollTop = box.scrollHeight; }
        if (boxLeft) { var d2 = document.createElement('div'); d2.className = cls || ''; d2.innerHTML = html; boxLeft.appendChild(d2); boxLeft.scrollTop = boxLeft.scrollHeight; }
    }

    // ===== 工具 =====
    function esc(s) {
        if (!s) return '';
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    // ===== 启动 =====
    document.addEventListener('DOMContentLoaded', init);
})();
