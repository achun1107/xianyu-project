// 闲鱼批量发布 v2.1 - 核心引擎
(function() {
    'use strict';

    const STORAGE_KEY = 'kun_publish_v2';
    const STORES_KEY = 'kun_stores';
    const CUR_STORE_KEY = 'kun_cur_store';

    // ===== 商品分类模板库 =====
    const CATEGORY_TEMPLATES = {
        // 2026-11-11 加：线上实测 catId=50025461 / categoryId(channelCatId)=202285710
        '演出票代拍':     { categoryId: '202285710', catId: '50025461', catName: '演出票代拍' },
        '代购':           { categoryId: '201456914', catId: '50025461', catName: '代购' },
        '创业/副业培训': { categoryId: '202155826', catId: '50023914', catName: '创业/副业培训' },
        '技能类招工':     { categoryId: '202147361', catId: '',        catName: '技能类招工' },
        '互联网产品与运营技能培训': { categoryId: '50025963', catId: '127284048', catName: '互联网产品与运营技能培训' },
    };
    const DEFAULT_CATEGORY = '代购';

    // ===== 动态类目（从闲鱼 mtop 拉取，缓存 24h）=====
    var CATEGORY_CACHE_KEY = 'kun_categories_v2';
    var CAT_CACHE_TTL = 24 * 60 * 60 * 1000;

    function getHardcodedCategories() {
        return [
            { categoryId: '202285710', catId: '50025461', catName: '演出票代拍' },
            { categoryId: '201456914', catId: '50025461', catName: '代购' },
            { categoryId: '202155826', catId: '50023914', catName: '创业/副业培训' },
            { categoryId: '202147361', catId: '', catName: '技能类招工' },
            { categoryId: '50025963', catId: '127284048', catName: '互联网产品与运营技能培训' }
        ];
    }

    async function refreshCategories(mtop) {
        try {
            var raw = localStorage.getItem(CATEGORY_CACHE_KEY);
            if (raw) {
                var cached = JSON.parse(raw);
                if (cached && cached.time && (Date.now() - cached.time < CAT_CACHE_TTL) && cached.data && cached.data.length > 0) {
                    console.log('[kun] 类目缓存有效 (' + cached.data.length + ' 个)');
                    return cached.data;
                }
            }
        } catch(e) {}

        if (!mtop) {
            try { mtop = window.lib && window.lib.mtop && window.lib.mtop.request.bind(window.lib.mtop); } catch(e) {}
        }
        if (!mtop) {
            console.warn('[kun] mtop 不可用，用硬编码类目');
            return getHardcodedCategories();
        }

        try {
            var resp = await mtop({
                api: 'mtop.idle.pc.category.getChildren',
                v: '1.0',
                data: JSON.stringify({ parentId: '0' }),
                ecode: 0
            });
            var list = [];
            function walk(arr) {
                if (!arr || !Array.isArray(arr)) return;
                for (var i = 0; i < arr.length; i++) {
                    var n = arr[i];
                    list.push({
                        categoryId: String(n.id || n.categoryId || ''),
                        catId: String(n.spuCatId || n.catId || ''),
                        catName: String(n.name || n.catName || '')
                    });
                    if (n.children && n.children.length) walk(n.children);
                }
            }
            var root = (resp && resp.data && resp.data.categoryList) ? resp.data.categoryList : ((resp && resp.data) ? resp.data : []);
            walk(Array.isArray(root) ? root : []);

            if (list.length > 0) {
                localStorage.setItem(CATEGORY_CACHE_KEY, JSON.stringify({ time: Date.now(), data: list }));
                console.log('[kun] 已缓存 ' + list.length + ' 个真实类目');
                return list;
            }
        } catch(e) {
            console.warn('[kun] 拉取类目失败:', e.message);
        }
        return getHardcodedCategories();
    }

    // ===== 项目类型 =====
    var PROJECTS = {
        concert: { name: '演唱会代拍', defaultCategory: '代购' },
        recruit: { name: '招抢手', defaultCategory: '创业/副业培训' },
        yuxiaopu: { name: '鱼小铺', defaultCategory: '互联网产品与运营技能培训' }
    };

    // ===== 默认发布模板（标题/描述/价格） =====
    const DEFAULT_TEMPLATES = [
        { name: '招演唱会抢手', title: '【暑假可做】招演唱会抢手，适合大学生暑假做的',      price: '1',
          desc: '日常有各类演出场次资讯，空闲时间随手操作就能赚点奶茶零花钱\n收益看场次，单次收益可观，大学生、宝妈时间自由都能做\n无门槛不用相关经验，感兴趣直接私聊咨询\n点关注，0.01拍下发群渠道\n拍下后消息较多，会逐一回复，请稍等' },
        { name: '游戏代玩',     title: '王者/原神/吃鸡 代玩代练，快速上分',                    price: '1',
          desc: '专业代玩团队，多款热门游戏均可接单\n快速上分，价格优惠\n感兴趣直接私聊咨询\n点关注，0.01拍下发群渠道' },
        { name: '手工活外发',   title: '手工活外发加工，在家可做，时间自由',                    price: '1',
          desc: '正规手工活外发，无需押金\n计件结算，多劳多得\n适合宝妈、学生、上班族\n点关注，0.01拍下发群渠道' },
        { name: '问卷调查',      title: '线上问卷调查填写，一单一结，日结',                      price: '1',
          desc: '正规问卷调查平台对接\n手机电脑都能做，随时可做\n一单一结，日结工资\n点关注，0.01拍下发群渠道' },
    ];

    // ===== 演唱会代拍模板（含占位符）=====
    // 2026-10-04：2 款 → 6 款。老板要求「标题不需要场次」，
    // 所以每款的差异点放在【卖点/承诺】上，而不是重复写日期场次。
    // {场次类型} 承载的是【开票轮次】（首开/一开/二开…），不是具体场次；
    // 它的取值来自文件名关键词匹配 SESSION_TYPES（见 L137），
    // 文件名里没有该关键词 → 这里会替换成空，标题缺字且不报错。
    // 6 条 descPattern 完全相同（老板原话术，不要改）。
    // 替换后长度全部落在 fitTitle 的 30~40 区间，卡片标题不被正文渗入。
    var CONCERT_TEMPLATES = [
        {
            id: 1,
            name: '模板1·轮次代拍（原有）',
            titlePattern: '【{场次类型}代拍】{城市}{明星}{活动类型}接代拍{场次类型}代抢',
            descPattern: '高命中率，抢不到全额退款\n问价方式（日期➕票面➕几张）\n\n代拍流程\n1.需要提供您的账号或者您的身份证信息\n2.若抢到票后因买家个人原因退票，代拍费不退！只退扣完手续费的票钱！\n3. 成功率杠杠滴，战绩超丰富，有需要的姐妹快来咨询哦\n\n可以自己也一起抢，指定同一平台同一场次，自己抢到我退全款。\n因买家原因取消购买，开抢前大于四个小时收20%手续费，开抢前四个小时内收40%手续费',
            categoryName: '代购',
            price: '50',
            stock: '9999'
        },
        {
            id: 2,
            name: '模板2·必中秒付（原有）',
            titlePattern: '【代拍必中】{城市}{明星}{活动类型}接代拍{场次类型}代抢秒付必中',
            descPattern: '高命中率，抢不到全额退款\n问价方式（日期➕票面➕几张）\n\n代拍流程\n1.需要提供您的账号或者您的身份证信息\n2.若抢到票后因买家个人原因退票，代拍费不退！只退扣完手续费的票钱！\n3. 成功率杠杠滴，战绩超丰富，有需要的姐妹快来咨询哦\n\n可以自己也一起抢，指定同一平台同一场次，自己抢到我退全款。\n因买家原因取消购买，开抢前大于四个小时收20%手续费，开抢前四个小时内收40%手续费',
            categoryName: '代购',
            price: '50',
            stock: '9999'
        },
        {
            id: 3,
            name: '模板3·全额退款承诺',
            titlePattern: '【{城市}{明星}】{活动类型}{场次类型}代拍 抢不到全额退款 可看评价',
            descPattern: '高命中率，抢不到全额退款\n问价方式（日期➕票面➕几张）\n\n代拍流程\n1.需要提供您的账号或者您的身份证信息\n2.若抢到票后因买家个人原因退票，代拍费不退！只退扣完手续费的票钱！\n3. 成功率杠杠滴，战绩超丰富，有需要的姐妹快来咨询哦\n\n可以自己也一起抢，指定同一平台同一场次，自己抢到我退全款。\n因买家原因取消购买，开抢前大于四个小时收20%手续费，开抢前四个小时内收40%手续费',
            categoryName: '代购',
            price: '50',
            stock: '9999'
        },
        {
            id: 4,
            name: '模板4·全价位战绩可查',
            titlePattern: '{城市}{明星}{活动类型}代拍{场次类型} 全站全价位都可接 战绩可查',
            descPattern: '高命中率，抢不到全额退款\n问价方式（日期➕票面➕几张）\n\n代拍流程\n1.需要提供您的账号或者您的身份证信息\n2.若抢到票后因买家个人原因退票，代拍费不退！只退扣完手续费的票钱！\n3. 成功率杠杠滴，战绩超丰富，有需要的姐妹快来咨询哦\n\n可以自己也一起抢，指定同一平台同一场次，自己抢到我退全款。\n因买家原因取消购买，开抢前大于四个小时收20%手续费，开抢前四个小时内收40%手续费',
            categoryName: '代购',
            price: '50',
            stock: '9999'
        },
        {
            id: 5,
            name: '模板5·专业代拍团队',
            titlePattern: '【专业代拍】{城市}{明星}{活动类型}{场次类型}代抢 万人团队 高命中率',
            descPattern: '高命中率，抢不到全额退款\n问价方式（日期➕票面➕几张）\n\n代拍流程\n1.需要提供您的账号或者您的身份证信息\n2.若抢到票后因买家个人原因退票，代拍费不退！只退扣完手续费的票钱！\n3. 成功率杠杠滴，战绩超丰富，有需要的姐妹快来咨询哦\n\n可以自己也一起抢，指定同一平台同一场次，自己抢到我退全款。\n因买家原因取消购买，开抢前大于四个小时收20%手续费，开抢前四个小时内收40%手续费',
            categoryName: '代购',
            price: '50',
            stock: '9999'
        },
        {
            id: 6,
            name: '模板6·内场看台全接',
            titlePattern: '{明星}{城市}{活动类型}{场次类型}代抢 内场看台全接 秒付前排',
            descPattern: '高命中率，抢不到全额退款\n问价方式（日期➕票面➕几张）\n\n代拍流程\n1.需要提供您的账号或者您的身份证信息\n2.若抢到票后因买家个人原因退票，代拍费不退！只退扣完手续费的票钱！\n3. 成功率杠杠滴，战绩超丰富，有需要的姐妹快来咨询哦\n\n可以自己也一起抢，指定同一平台同一场次，自己抢到我退全款。\n因买家原因取消购买，开抢前大于四个小时收20%手续费，开抢前四个小时内收40%手续费',
            categoryName: '代购',
            price: '50',
            stock: '9999'
        }
    ];


    // ===== 招抢手模板 =====
    var RECRUIT_TEMPLATES = [
        { id: 1, name: '暑假档招抢手', desc: '动动手指抢票就可以了  单子多多\n每单佣金几十到上千不等\n中了就是你的   抢票的钱  我来出\n\n点关注 小刀0.01下单\n\n拍下后，不要着急  我会挨个回复的' },
        { id: 2, name: '暑假招抢手', desc: '暑假期间招收演唱会门票抢手，抢到了有米，至少2~3位数，热门明星甚至四位数\n\n点关注 小刀0.01下单\n\n拍下后，不要着急  我会挨个回复的' }
    ];
    // 开票轮次。这一份是【从文件名解析轮次】的匹配清单（见 L1141 附近），
    // 不只是下拉选项 —— 文件名里写了但这里没有，就解析不出来，
    // 结果是 {场次类型} 变空、标题缺字，而且【不报错】。
    // 2026-10-04：补「一开」；「捡漏回流」拆成「捡漏」「回流」两项。
    // 2026-10-06：加「回流捡漏」。它是 4 字词，sort 按长度降序后自动排最前，
    //   所以「杭州孙燕姿回流捡漏」优先命中它，不会被 2 字的「捡漏」先吃掉。
    // ⚠️ publish_dashboard.js 里还有一份副本，改这里必须同步改那里。
    var SESSION_TYPES = ['回流捡漏', '首开', '一开', '二开', '三开', '捡漏', '回流'];

    // ── 标题整形：必须【正好 30 字】────────────────────────────────
    // 闲鱼卡片标题 = fullDesc.slice(0,30)，而 fullDesc = title + "\n\n" + desc
    // （publishOne 的 itemTextDTO 用 titleDescSeparate:false，见 L638/L1230）。
    // 所以 title 短于 30 字 → 正文会被切进卡片标题。
    //
    // 【2026-09-28 改】TITLE_MAX 30 → 40，并把「截断上限」与「补足下限」拆开。
    //   为什么改 40：老板自己原有链接的标题就是 40 字
    //   （如「【代拍必中】孙燕姿广州站演唱会接代拍首开代抢孙燕姿演唱会代抢 广州孙燕姿秒付必中」），
    //   截到 30 会让新发的链接比店里老链接短一截，风格不一致。
    //   为什么补足只补到 TITLE_MIN(30)、而不是补到 40：
    //   模板中的短标题只有 21~23 字，补到 40 会变成
    //   「…（可看评价） 全站全价位都可接！！！！！！」一串感叹号，难看且不符老板风格。
    //   补到 30 的理由没变：卡片标题取前 30 字，标题不足 30 会让正文渗进卡片标题。
    // 与 D:\DSH\achun\publish-one.js 的 fitTitle 保持一致（两处逻辑必须同步）。
    // 【2026-10-11 改·实测】TITLE_MAX 40 → 30。闲鱼标题的【硬上限就是 30 字】，
    //   超出部分由平台【从尾部静默砍掉】—— 我们发出去时看不见，只有发布后回读才报 ❌ 标题。
    //   实测证据（mtop.idle.pc.idleitem.editdetail 读闲鱼侧【实存】标题）：
    //     发 36 → 存 30、发 38 → 存 30、发 33 → 存 30、发 31 → 存 30、发 30 → 存 30 完整
    //   所以 2026-09-28 那次「30 → 40」的前提是错的：那批老链接的 40 字标题本来就已被砍成 30，
    //   我们看到的 40 是【自己发出去的长度】，不是【平台存下来的长度】。
    //   历史事故形态：名字砍一半（…代抢周诗雨）、词砍一半（…门票代）、括号没闭合（…（可看评价）。
    //   ⚠️ 本文件与 D:\DSH\achun\lib\title.js 是同一套规则的【两份实现】——
    //      两个仓分开分发没法共用，所以【必须同改】：
    //      改这里就要同步 lib/title.js，并跑 test-publishjs-fittitle.js / verify-fittitle.js。
    var TITLE_MAX = 30;
    var TITLE_MIN = 30;
    // 补齐用的语义 filler（带前导空格，长度即整个串的长度），长的先试
    var TITLE_PAD = [' 全站全价位都可接', ' 全价位都能接', ' 高命中率', ' 全价位接', ' 可上号', ' 秒付前排', ' 稳中', ' 秒付', ' 包中'];
    // 中英文成对括号（截断后用来修「开了没闭」）
    var TITLE_BRACKETS = [['【', '】'], ['（', '）'], ['《', '》'], ['〈', '〉'], ['(', ')'], ['[', ']'], ['{', '}']];
    // 把截断后「开了没闭」的括号连同它后面残留的内容一起丢掉
    // 例：'…首开代拍 （可看评价' → '…首开代拍 '
    function closeBrackets(s) {
        var out = String(s == null ? '' : s);
        for (var _b = 0; _b < TITLE_BRACKETS.length; _b++) {
            var _o = TITLE_BRACKETS[_b][0], _c = TITLE_BRACKETS[_b][1];
            var _no = out.split(_o).length - 1, _nc = out.split(_c).length - 1;
            if (_no > _nc) out = out.slice(0, out.lastIndexOf(_o));
        }
        return out;
    }
    // 超长瘦身：尽量在不丢关键字的前提下收进 max
    function squeezeTitle(t, max) {
        var src = String(t == null ? '' : t);
        if (src.length <= max) return { text: src, how: '' };
        var noSpace = src.replace(/\s+/g, '');
        if (noSpace.length <= max) return { text: noSpace, how: '去掉空白' };
        // 「（可看评价）」是模板固定尾巴，去空格后再去它
        var tail = noSpace.replace(/[（(]可看评价[）)]$/, '');
        if (tail.length <= max) return { text: tail, how: '去掉「（可看评价）」尾巴' };
        // 实在收不进：硬截断，并保证括号闭合（宁可短，也不要「名字砍一半」）
        return { text: closeBrackets(noSpace.slice(0, max)), how: '硬截断到 ' + max + ' 字（已修括号）' };
    }
    function fitTitle(t) {
        t = String(t == null ? '' : t);
        // 超长：先做语义不变的瘦身（去空白 → 去「（可看评价）」尾巴），实在收不进才硬截断
        if (t.length > TITLE_MAX) t = squeezeTitle(t, TITLE_MAX).text;
        if (t.length < TITLE_MIN) {
            var gap = TITLE_MIN - t.length, best = '';
            for (var _i = 0; _i < TITLE_PAD.length; _i++) {
                var _f = TITLE_PAD[_i];
                if (_f.length <= gap && _f.length > best.length) best = _f;
            }
            t += best;
            // 余量用「！」补足：可见、不会被 trim，且不会有尾随空格被服务端吃掉导致正文漏进标题。
            // 最优 filler 与次优 filler 的长度差 ≤2，所以这里最多补 2 个。
            while (t.length < TITLE_MIN) t += '！';
        }
        return t;
    }

    function renderConcertTitle(templateId, star, city, sessionType, eventType) {
        if (!templateId) templateId = 1;
        var tpl = null;
        for (var i = 0; i < CONCERT_TEMPLATES.length; i++) {
            if (CONCERT_TEMPLATES[i].id === templateId) { tpl = CONCERT_TEMPLATES[i]; break; }
        }
        var ev = eventType || '演唱会';
        var _cfgTitle = loadStoreConfig(); var _tm2 = _cfgTitle.titleMode || 'placeholder'; if (!tpl) { var _raw = (city || '') + (star || '') + ev + (sessionType || '') + '代拍'; return fitTitle(_tm2 === 'random' ? tweakTitle(_raw) : _raw); }
        var _title = tpl.titlePattern
            .replace(/\{明星\}/g, star)
            .replace(/\{城市\}/g, city)
            .replace(/\{场次类型\}/g, sessionType)
            .replace(/\{活动类型\}/g, ev);
        // 注意顺序：先同义词微调（会改变长度），再整形到 30 字
        return fitTitle(_tm2 === 'random' ? tweakTitle(_title) : _title);
    }

    // 标题微调：随机替换同义词，避开判重，不改原意
    var _SYN = [
        // 鱼小铺
        ['开通', ['开启', '激活', '代办开通']],
        ['快速', ['极速', '迅速', '快捷']],
        ['极速', ['快速', '迅速', '光速']],
        ['入口', ['渠道', '通道', '直通车']],
        ['秒开', ['快开', '秒开通', '立即开']],
        ['100%', ['百分百', '必定', '100%成功']],
        ['百分百', ['100%', '全部', '必成']],
        ['失败包退', ['不过全退', '失败退款', '未开通退款']],
        ['官方邀约', ['平台邀约', '官方渠道', '正规邀约']],
        ['新老号', ['所有号', '新旧号', '全部账号']],
        ['三分钟', ['3分钟', '两三分钟', '几分钟']],
        ['2分钟', ['两分钟', '2-3分钟', '1分钟']],
        ['无二次收费', ['一次收费', '无额外费用', '无隐形消费']],
        ['标价开', ['标价即开', '标价就开', '拍下即开']],
        ['直接开', ['马上开', '立即开', '即刻开']],
        // 演唱会代拍
        ['接代拍', ['承接代拍', '可接代拍', '接下单代拍']],
        ['代拍', ['代抢', '代办', '代下']],
        ['必中', ['稳中', '必得', '包中']],
        ['秒付', ['速付', '极速付', '秒到付']],
        ['演唱会', ['演出', '巡演']],
        ['高命中率', ['高成功率', '高效率']],
        ['全额退款', ['全退', '原路退款']],
        ['抢不到', ['没抢到', '若未抢到']],
    ];
    function tweakTitle(title) {
        var avail = [];
        for (var i = 0; i < _SYN.length; i++) {
            if (title.indexOf(_SYN[i][0]) >= 0) avail.push(_SYN[i]);
        }
        if (avail.length === 0) return title;
        for (var j = avail.length - 1; j > 0; j--) {
            var k = Math.floor(Math.random() * (j + 1));
            var tmp = avail[j]; avail[j] = avail[k]; avail[k] = tmp;
        }
        var count = Math.min(avail.length, 1 + Math.floor(Math.random() * 2));
        avail.sort(function(a, b) { return b[0].length - a[0].length; });
        for (var p = 0; p < count; p++) {
            var alts = avail[p][1];
            title = title.replace(avail[p][0], alts[Math.floor(Math.random() * alts.length)]);
        }
        return title;
    }

    function renderConcertDesc(templateId) {
        if (!templateId) templateId = 1;
        for (var i = 0; i < CONCERT_TEMPLATES.length; i++) {
            if (CONCERT_TEMPLATES[i].id === templateId) return CONCERT_TEMPLATES[i].descPattern;
        }
        return '高命中率，抢不到全额退款';
    }

    // 随机选模板：本轮不重复，全部用完后重新洗牌轮回
    function pickRandomTemplateId() {
        var _seqKey = 'kun_tpl_rand_seq';
        var _seq = [];
        try { _seq = JSON.parse(localStorage.getItem(_seqKey)) || []; } catch(e) {}
        if (!_seq.length) {
            for (var _i = 0; _i < CONCERT_TEMPLATES.length; _i++) _seq.push(_i);
            for (var _j = _seq.length - 1; _j > 0; _j--) {
                var _k = Math.floor(Math.random() * (_j + 1));
                var _tmp = _seq[_j]; _seq[_j] = _seq[_k]; _seq[_k] = _tmp;
            }
        }
        var _pickIdx = _seq.shift();
        localStorage.setItem(_seqKey, JSON.stringify(_seq));
        return CONCERT_TEMPLATES[_pickIdx].id;
    }

    // ===== 每日任务存储（演唱会代拍用）=====
    var DAILY_TASK_KEY = 'kun_daily_tasks_v2';
    var DEFAULT_IMAGE_URL = 'https://img.alicdn.com/imgextra/i1/O1CN01qEXMPk2M6qHNluzsh_!!2214432689779-0-fleamarket.jpg';
    var IMAGES_FOLDER = 'C:/Users/43462/Desktop/闲鱼上架图片/';
    // 店铺专属图片目录：闲鱼上架图片/店铺名/
    function getStoreImagesFolder() {
        return IMAGES_FOLDER + (currentStore ? currentStore + '/' : '');
    }

    function loadDailyTasks() {
        try {
            var d = JSON.parse(localStorage.getItem(DAILY_TASK_KEY));
            if (d && typeof d === 'object') return d;
        } catch(e) {}
        return { templateId: 1, imageUrl: DEFAULT_IMAGE_URL, tasks: [] };
    }
    function saveDailyTasks(data) { localStorage.setItem(DAILY_TASK_KEY, JSON.stringify(data)); try { callNativeHost({ action: 'writeDailyTasks', store: currentStore, data: data }).catch(function(){}); } catch(e) {} }

    // ===== 自定义模板存储 =====
    var CUSTOM_TPL_KEY = 'kun_custom_templates';
    // 模板按店铺独立存储
    var GLOBAL_TPL_KEY = 'kun_tpl_global';
    function getTplKey() { return currentStore ? ('kun_tpl_' + currentStore) : GLOBAL_TPL_KEY; }
    function loadCustomTemplates() {
        try { var d = JSON.parse(localStorage.getItem(getTplKey()) || localStorage.getItem(CUSTOM_TPL_KEY));
            if (d && Array.isArray(d)) return d; }
        catch(e) {}
        return null;
    }
    function saveCustomTemplates(tpls) {
        var key = getTplKey();
        localStorage.setItem(key, JSON.stringify(tpls));
        // 同时持久化到磁盘（通过 Native Host）
        try { callNativeHost({ action: 'writeTemplates', data: { key: key, templates: tpls } }).catch(function(){}); } catch(e) {}
    }

    var _DEFAULT_TPL = JSON.parse(JSON.stringify(CONCERT_TEMPLATES));
    function reloadStoreTemplates() {
        var custom = loadCustomTemplates();
        CONCERT_TEMPLATES.length = 0;
        // 如果有自定义模板，完全用自定义的（不再恢复默认）
        if (custom && custom.length > 0) {
            for (var i = 0; i < custom.length; i++) {
                CONCERT_TEMPLATES.push(JSON.parse(JSON.stringify(custom[i])));
            }
            return;
        }
        // 没有自定义才用默认
        for (var i = 0; i < _DEFAULT_TPL.length; i++) CONCERT_TEMPLATES.push(JSON.parse(JSON.stringify(_DEFAULT_TPL[i])));
    }
    // 一次性迁移：把旧的按店铺存储的模板迁移到全局
    (function migrateGlobalTemplates() {
        if (localStorage.getItem(GLOBAL_TPL_KEY)) return;
        for (var i = 0; i < localStorage.length; i++) {
            var k = localStorage.key(i);
            if (k && k.indexOf('kun_tpl_') === 0 && k !== GLOBAL_TPL_KEY && k !== CUSTOM_TPL_KEY) {
                var data = localStorage.getItem(k);
                if (data) {
                    try { var arr = JSON.parse(data); if (Array.isArray(arr) && arr.length > 0) { localStorage.setItem(GLOBAL_TPL_KEY, data); console.log('[kun] 模板已迁移到全局（来源: ' + k + ', ' + arr.length + ' 个）'); break; } } catch(e) {}
                }
            }
        }
    })();
    reloadStoreTemplates();

    // 异步刷新类目（不阻塞启动，3秒后 mtop 可能就绪）
    setTimeout(function() {
        refreshCategories().catch(function(){});
    }, 3000);

    // 启动时从磁盘恢复模板和项目配置（防止 localStorage 丢失）
    (function initDiskSync() {
        setTimeout(async function() {
            try {
                // 0. 恢复每日任务（优先，确保用户数据不丢）
                var dr = await callNativeHost({ action: 'readDailyTasks', store: currentStore });
                if (dr && dr.ok && dr.data && dr.data.tasks && Array.isArray(dr.data.tasks) && dr.data.tasks.length > 0) {
                    localStorage.setItem(DAILY_TASK_KEY, JSON.stringify(dr.data));
                    console.log('[kun] 从磁盘加载每日任务 (' + dr.data.tasks.length + ' 个)');
                }
                // 1. 恢复自定义模板
                var r = await callNativeHost({ action: 'readTemplates' });
                if (r && r.ok && r.data) {
                    var tKey = getTplKey();
                    var tpls = r.data[tKey];
                    // Native Host 落盘的形状是 {key, templates}，不是 {店铺键: [...]}。
                    // 只有 key 与当前店铺一致才采用；不再"取第一个数组"兜底 ——
                    // 那会把上一家店的模板灌进当前店铺（2026-09-26 发现）。
                    if (!tpls && r.data.key === tKey && Array.isArray(r.data.templates)) tpls = r.data.templates;
                    if (tpls && Array.isArray(tpls) && tpls.length > 0) {
                        localStorage.setItem(tKey, JSON.stringify(tpls));
                        reloadStoreTemplates();
                        console.log('[kun] 从磁盘加载模板 (' + tpls.length + ' 个)');
                    }
                }
                // 2. 恢复项目配置
                var cr = await callNativeHost({ action: 'readProjectConfigs' });
                if (cr && cr.ok && cr.data) {
                    var cfg = cr.data;
                    if (cfg.configs && Object.keys(cfg.configs).length > 0) {
                        localStorage.setItem('kun_project_configs', JSON.stringify(cfg.configs));
                        console.log('[kun] 从磁盘加载项目配置');
                    }
                    if (cfg.storeProjects && Object.keys(cfg.storeProjects).length > 0) {
                        localStorage.setItem(STORE_PROJ_KEY, JSON.stringify(cfg.storeProjects));
                    }
                }
            } catch(e) { console.log('[kun] 磁盘加载跳过:', e.message); }
        }, 300);
    })();

    // 定期同步项目配置和每日任务到磁盘（每2分钟，捕获看板页面的修改）
    setInterval(function() { try { syncProjectConfigsToDisk(); syncDailyTasksToDisk(); } catch(e) {} }, 120000);

    // ===== 持久化 =====
    function loadData() {
        try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || { templates: DEFAULT_TEMPLATES, images: [], usedImages: [] }; }
        catch(e) { return { templates: DEFAULT_TEMPLATES, images: [], usedImages: [] }; }
    }
    function saveData(d) { localStorage.setItem(STORAGE_KEY, JSON.stringify(d)); }

    // ===== 店铺管理（可配置） =====
    var currentStore = localStorage.getItem(CUR_STORE_KEY) || '';

    function loadStores() {
        try {
            var s = JSON.parse(localStorage.getItem(STORES_KEY));
            return Array.isArray(s) && s.length > 0 ? s : ['店铺A', '店铺B', '店铺C', '店铺D', '店铺E'];
        } catch(e) { return ['店铺A', '店铺B', '店铺C', '店铺D', '店铺E']; }
    }
    function saveStores(list) { localStorage.setItem(STORES_KEY, JSON.stringify(list)); }

    function getStores() { return loadStores(); }
    function addStore(name) {
        if (!name || !name.trim()) return false;
        var list = loadStores();
        if (list.indexOf(name.trim()) >= 0) return false;
        list.push(name.trim());
        saveStores(list);
        return true;
    }
    function removeStore(name) {
        var list = loadStores();
        var idx = list.indexOf(name);
        if (idx < 0) return false;
        list.splice(idx, 1);
        saveStores(list);
        if (currentStore === name) { currentStore = ''; localStorage.removeItem(CUR_STORE_KEY); }
        return true;
    }
    function setStore(n) { currentStore = n; localStorage.setItem(CUR_STORE_KEY, n); reloadStoreTemplates(); }
    function getStore() { return currentStore; }

    // ===== 店铺默认配置（每店铺独立，10字段默认值）=====
    var STORE_CFG_PREFIX = 'kun_store_cfg_';
    function getStoreCfgKey() { return STORE_CFG_PREFIX + (currentStore || 'default'); }
    function getDefaultStoreConfig() {
        return {
            price: '',           // ④ 价格默认
            stock: '',           // ⑤ 库存默认
            category: '',        // ⑥ 分类默认
            shipMode: '',        // ⑦ 交付方式
            locationMode: 'city',// ⑧ 位置: fixed/city/random_tier1/random_any
            fixedCity: '',       //   固定位置-城市
            fixedDistrict: '',   //   固定位置-区域
            subImg: null,        // ⑨ 副图: true/false/null(未设=沿用项目配置)
            commitment: {        // ⑩ 承诺默认
                refundFull: false,
                refundPostage: false,
                fastShip: false
            }
        };
    }
    function loadStoreConfig() {
        try {
            var cfg = JSON.parse(localStorage.getItem(getStoreCfgKey()));
            if (cfg) {
                var def = getDefaultStoreConfig();
                cfg = Object.assign({}, def, cfg);
                cfg.commitment = Object.assign({}, def.commitment, cfg.commitment || {});
                return cfg;
            }
        } catch(e) {}
        return getDefaultStoreConfig();
    }
    function saveStoreConfig(cfg) {
        localStorage.setItem(getStoreCfgKey(), JSON.stringify(cfg));
    }
    // 位置解析（根据模式返回城市+区域）
    var TIER1_CITIES = ['北京','上海','广州','深圳'];
    // 【2026-09-29 加·老板定的规则】地址库里没有的城市，按就近原则落到国内城市：
    //   香港 → 广州 / 深圳        澳门 → 珠海 / 广州 / 深圳
    //   其它（国外：新加坡、吉隆坡…）→ 走下面的「随机一线城市」兜底
    // 只影响「宝贝所在地」；标题里的城市仍用原城市（task.city），例如「【稳中代拍】香港利淑元见面会代拍…」。
    var CITY_FALLBACK = {
        '香港': ['广州', '深圳'],
        '澳门': ['珠海', '广州', '深圳']
    };
    var ALL_CITIES = ['北京','上海','广州','深圳','杭州','成都','武汉','南京','苏州','重庆','长沙','青岛','天津','西安','郑州','宁波','厦门','福州','合肥','昆明','大连','沈阳','哈尔滨','济南','太原','贵阳','南昌','南宁','石家庄','兰州','海口','三亚'];
    function resolveLocation(storeCfg, taskCity) {
        var mode = storeCfg.locationMode || 'city';
        // 任务有城市时优先用任务城市（跟随标题）；但必须是闲鱼可用的国内城市，否则兜底国内城市
        if (taskCity) {
            // 【老板规则优先】香港/澳门即使地址库里有（实测 ADDRESS_DB 里香港/澳门各 4 条），
            // 也要按就近原则落到国内城市 —— 所以这一步必须在地址库判断【之前】。
            //   香港 → 广州 / 深圳      澳门 → 珠海 / 广州 / 深圳
            //   其它国外（新加坡/吉隆坡…）不在表里 → 走下面地址库/随机一线兜底
            var _near = CITY_FALLBACK[taskCity];
            if (_near && _near.length) return { city: _near[Math.floor(Math.random() * _near.length)], district: '' };
            if (typeof ADDRESS_DB !== 'undefined' && ADDRESS_DB.some(function(a){ return a.city===taskCity; })) {
                return { city: taskCity, district: '' };
            }
            // 任务城市不在地址库里（国外城市）→ 发布地址用店铺固定城市或随机一线城市；标题仍带原城市
            if (storeCfg.fixedCity) return { city: storeCfg.fixedCity, district: storeCfg.fixedDistrict || '' };
            return { city: TIER1_CITIES[Math.floor(Math.random()*TIER1_CITIES.length)], district: '' };
        }
        if (mode === 'fixed' && storeCfg.fixedCity) return { city: storeCfg.fixedCity, district: storeCfg.fixedDistrict || '' };
        if (mode === 'random_tier1') return { city: TIER1_CITIES[Math.floor(Math.random()*TIER1_CITIES.length)], district: '' };
        if (mode === 'random_any') return { city: ALL_CITIES[Math.floor(Math.random()*ALL_CITIES.length)], district: '' };
        return { city: taskCity || '广州', district: '' };
    }

    // ===== 店铺→项目 =====
    var STORE_PROJ_KEY = 'kun_store_projects';
    function getProjForStore(name) {
        try { var m = JSON.parse(localStorage.getItem(STORE_PROJ_KEY)) || {}; return m[name] || 'concert'; }
        catch(e) { return 'concert'; }
    }

    var DEFAULT_PROJECT_CONFIGS = { concert: { titleMode:'placeholder', category:'代购' }, recruit: { titleMode:'filename', category:'创业/副业培训' }, yuxiaopu: { titleMode:'placeholder', category:'互联网产品与运营技能培训' } };
    function getProjectConfig(projId) {
        try { var cfg = JSON.parse(localStorage.getItem('kun_project_configs')) || {}; return cfg[projId] || null; }
        catch(e) { return null; }
    }
    function setProjForStore(name, proj) {
        try { var m = JSON.parse(localStorage.getItem(STORE_PROJ_KEY)) || {}; m[name] = proj; localStorage.setItem(STORE_PROJ_KEY, JSON.stringify(m)); }
        catch(e) {}
        syncProjectConfigsToDisk();
    }

    // 将项目配置和店铺映射同步到磁盘
    function syncProjectConfigsToDisk() {
        try {
            var configs = {};
            try { configs = JSON.parse(localStorage.getItem('kun_project_configs')) || {}; } catch(e) {}
            var storeProjects = {};
            try { storeProjects = JSON.parse(localStorage.getItem(STORE_PROJ_KEY)) || {}; } catch(e) {}
            callNativeHost({ action: 'writeProjectConfigs', data: { configs: configs, storeProjects: storeProjects } }).catch(function(){});
        } catch(e) {}
    }

    // 每日任务同步到磁盘
    function syncDailyTasksToDisk() {
        try {
            var d = {};
            try { d = JSON.parse(localStorage.getItem(DAILY_TASK_KEY)) || {}; } catch(e) {}
            if (d.tasks && d.tasks.length > 0) {
                callNativeHost({ action: 'writeDailyTasks', store: currentStore, data: d }).catch(function(){});
            }
        } catch(e) {}
    }

    // 从磁盘拉取本店任务（发布台写盘后，店铺页面靠它同步最新任务）
    async function syncTasksFromDisk() {
        try {
            var r = await callNativeHost({ action: 'readDailyTasks', store: currentStore });
            if (r && r.ok && r.data && typeof r.data === 'object' && Array.isArray(r.data.tasks)) {
                localStorage.setItem(DAILY_TASK_KEY, JSON.stringify(r.data));
                console.log('[kun] 磁盘任务已同步 (' + r.data.tasks.length + ' 个)');
                return r.data;
            }
        } catch(e) { console.log('[kun] 磁盘同步失败: ' + e.message); }
        return loadDailyTasks();
    }

    // 页面关闭前同步
    window.addEventListener('beforeunload', function() { syncProjectConfigsToDisk(); syncDailyTasksToDisk(); });

    // ===== 地址查找 =====
    function findAddress(city, district) {
        if (typeof ADDRESS_DB === 'undefined') return null;
        var d = district || city, c = city;
        // 优先精确匹配城市+区（排除"市辖区"等通用名）
        var matches = ADDRESS_DB.filter(function(a){ return a.city===c && a.district===d && a.district!=='市辖区' && a.district!==c; });
        // 匹配城市下的具体区
        if (matches.length === 0) matches = ADDRESS_DB.filter(function(a){ return a.city===c && a.district!=='市辖区' && a.district!==c; });
        // 只匹配城市（含市辖区）
        if (matches.length === 0) matches = ADDRESS_DB.filter(function(a){ return a.city===c; });
        if (matches.length === 0) return null;
        var addr = Object.assign({}, matches[Math.floor(Math.random() * matches.length)]);
        // 如果还是"市辖区"，用城市名替代（闲鱼不认"市辖区"）
        if (addr.district === '市辖区') addr.district = addr.city;
        if (addr.district === addr.city) { var _better = ADDRESS_DB.filter(function(a){ return a.city===addr.city && a.district!==addr.city && a.district!=='市辖区'; }); if (_better.length>0) addr = Object.assign(addr, _better[Math.floor(Math.random()*_better.length)]); }
        // 地址库已全面修正：所有条目都有正确的区名+divisionId+POI地标，无需降级
        // GPS 精度修正：补到6位小数
        if (addr.gps) {
            var parts = addr.gps.split(',');
            var lat = parseFloat(parts[0]);
            var lng = parseFloat(parts[1]);
            addr.gps = (lat + (Math.random() - 0.5) * 0.01).toFixed(6) + ',' + (lng + (Math.random() - 0.5) * 0.01).toFixed(6);
        }
        return addr;
    }

    // ===== 获取分类配置 =====
    function getCategoryConfig(categoryName) {
        try {
            var raw = localStorage.getItem(CATEGORY_CACHE_KEY);
            if (raw) {
                var d = JSON.parse(raw);
                if (d && d.data) {
                    for (var i = 0; i < d.data.length; i++) {
                        if (d.data[i].catName === categoryName) return d.data[i];
                    }
                }
            }
        } catch(e) {}
        var cat = CATEGORY_TEMPLATES[categoryName || DEFAULT_CATEGORY];
        if (!cat) cat = CATEGORY_TEMPLATES[DEFAULT_CATEGORY];
        return cat;
    }
    function getCategoryList() {
        try {
            var raw = localStorage.getItem(CATEGORY_CACHE_KEY);
            if (raw) {
                var d = JSON.parse(raw);
                if (d && d.data && d.data.length > 0) {
                    return d.data.map(function(c) { return c.catName; });
                }
            }
        } catch(e) {}
        return Object.keys(CATEGORY_TEMPLATES);
    }

    // ===== Native Host 通信 =====
    var _nhReqId = 0;
    function callNativeHost(payload) {
        return new Promise(function(resolve, reject) {
            var reqId = ++_nhReqId;
            function handler(event) {
                if (event.data && event.data.type==='NATIVE_HOST_RESULT' && event.data.requestId===reqId) {
                    window.removeEventListener('message', handler);
                    if (event.data.success) resolve(event.data.data);
                    else reject(new Error(event.data.error || 'NativeHost fail'));
                }
            }
            window.addEventListener('message', handler);
            window.postMessage({ type: 'NATIVE_HOST', requestId: reqId, payload: payload }, '*');
            setTimeout(function(){ window.removeEventListener('message', handler); reject(new Error('timeout')); }, 30000);
        });
    }

    // ===== 商品规格（SKU）构造 =====
    // 字段结构源自真实抓包：mtop.idle.pc.idleitem.edit（样本见 console-tools/sku-structure-sample.json）
    // 价格单位是【分】(priceInCent)；真实库存在 itemSkuList[].quantity（数字），顶层 quantity 不生效。
    // 配置样例：{ enabled:true, propertyName:'代拍费', values:[{value:'看台', priceYuan:500, stock:9999}] }
    function buildSkuPayload(specCfg) {
        if (!specCfg || !specCfg.enabled) return null;
        var vals = specCfg.values || [];
        var valid = [];
        for (var i = 0; i < vals.length; i++) {
            var v = vals[i];
            if (!v) continue;
            var name = String(v.value || v.name || '').trim();
            if (!name) continue; // 过滤页面留下的空槽位（抓包样本里有 {propertyValue:''}）
            var yuan = Number(v.priceYuan != null ? v.priceYuan : v.price);
            if (!isFinite(yuan) || yuan <= 0) continue; // 没填价格的一档不生成 SKU
            valid.push({ name: name, cent: String(Math.round(yuan * 100)), qty: Number(v.stock || 9999) });
        }
        if (!valid.length) return null;
        var propName = String(specCfg.propertyName || '代拍费');
        return {
            itemProperties: [{
                propertyName: propName,
                supportImage: !!specCfg.supportImage,
                propertyValues: valid.map(function (x) { return { propertyValue: x.name }; })
            }],
            itemSkuList: valid.map(function (x) {
                return {
                    priceInCent: x.cent,
                    quantity: x.qty,
                    propertyList: [{ propertyText: propName, valueText: x.name }]
                };
            })
        };
    }

    // ===== 发布单个商品 =====
    // imageUrls: 单张 URL 或 URL 数组
    // specOverride: 任务级规格配置，优先于店铺配置（用于 xyup.py 下指令时临时指定各档价格）
    async function publishOne(title, desc, priceYuan, imageUrls, city, district, categoryName, stock, shipMode, commitment, origPriceYuan, specOverride) {
        if (!window.lib || !window.lib.mtop || !window.lib.mtop.request) throw new Error('mtop gone');
        var addr = findAddress(city, district);
        if (!addr) throw new Error('addr not found: ' + city + ' ' + district);

        // 官方定位：发布前向闲鱼接口拿账号记忆的 selectedPoi（平台自己认定的位置），
        // 避免提交编造地址被 INVALID_MAP_LOCATION 拒单；拿不到再回退本地地址库
        var officialAddr = null;
        try {
            var poiResp = await window.lib.mtop.request({ api: 'mtop.taobao.idle.local.poi.get', v: '1.0', data: { longitude: '120.6', latitude: '31.3' }, headers: { 'EagleEye-UserData': 'spm-cnt=a21ybx' }, type: 'GET' });
            var sp = poiResp && poiResp.data && poiResp.data.selectedPoi;
            if (sp && sp.city && sp.divisionId) {
                officialAddr = { area: sp.area || '', city: sp.city, divisionId: sp.divisionId, gps: (sp.latitude || '') + ',' + (sp.longitude || ''), poiId: '', poiName: '', prov: sp.prov || '' };
                console.log('[kun] 官方位置:', sp.city + '/' + sp.area + '/' + sp.divisionId);
            }
        } catch (e) { console.log('[kun] 官方位置获取失败，回退地址库:', (e && e.message) || e); }
        // 【2026-09-29 修】原来是 `var locAddr = officialAddr || addr;`
        // 官方 POI 无条件优先，而官方 POI 是【账号绑定】的（好易美代拍 = 广州），
        // 于是任务里的 city 只影响标题、完全不影响「宝贝所在地」——发常州周深得到的是广州。
        // 改成任务城市（经 address_db 解析出的 addr）优先，官方 POI 退为兜底。
        // 安全性：addr 来自 ADDRESS_DB，带真实行政区划码 + 经纬度，不是编造地址。
        var locAddr = addr || officialAddr;
        if (locAddr === addr && officialAddr) {
            console.log('[kun] 位置用任务城市 ' + addr.city + '/' + addr.area + '（官方 POI 是 ' + officialAddr.city + '）');
        }

        var priceNum = parseFloat(priceYuan || '50'); var pc = String(Math.round(priceNum * 100));
        var origNum = parseFloat(origPriceYuan || priceYuan || '50'); var dc = String(Math.round(origNum * 100)); var qty = String(parseInt(stock || '9999') || 1);

        if (!Array.isArray(imageUrls)) imageUrls = [imageUrls];
        imageUrls = imageUrls.filter(Boolean);
        if (imageUrls.length === 0) throw new Error('no image');

        var cat = getCategoryConfig(categoryName);

        var data = {
            freebies: false, itemTypeStr: 'b', quantity: qty, simpleItem: 'true',
            imageInfoDOList: imageUrls.map(function(url, idx) {
                return {
                    extraInfo: { isH: 'false', isT: 'false', raw: 'false' },
                    isQrCode: false,
                    url: url,
                    heightSize: 1280, widthSize: 1280,
                    major: idx === 0,
                    type: 0,
                    status: 'done'
                };
            }),
            itemTextDTO: { desc: desc, title: title, titleDescSeparate: false },
            itemLabelExtList: [{
                channelCateName: cat.catName,
                channelCateId: cat.categoryId,
                propertyName: '分类',
                propertyId: '-10000',
                text: cat.catName,
                properties: '-10000##分类:' + cat.categoryId + '##' + cat.catName,
                labelType: 'common',
                isUserClick: '1',
                from: 'newPublishChoice',
                labelFrom: 'newPublish'
            }],
            itemPriceDTO: { origPriceInCent: dc, priceInCent: pc },
            userRightsProtocols: (function(){
                var rights = [{ enable: false, serviceCode: 'SKILL_PLAY_NO_MIND' }];
                if (commitment) {
                    if (commitment.refundFull) rights.push({ enable: true, serviceCode: 'GUARANTEE_REFUND' });
                    if (commitment.refundPostage) rights.push({ enable: true, serviceCode: 'RETURN_POSTAGE' });
                    if (commitment.fastShip) rights.push({ enable: true, serviceCode: 'FAST_SHIP' });
                }
                return rights;
            })(),
            itemPostFeeDTO: (function(){ if(shipMode==='free')return{canFreeShipping:true,supportFreight:false,onlyTakeSelf:false,templateId:'0'}; if(shipMode==='distance')return{canFreeShipping:false,supportFreight:true,onlyTakeSelf:false,templateId:'0'}; if(shipMode==='fixed')return{canFreeShipping:false,supportFreight:true,onlyTakeSelf:false,templateId:'0',postage:1000}; return{canFreeShipping:false,supportFreight:false,onlyTakeSelf:false,templateId:'0'}; })(),
            itemAddrDTO: { area: locAddr.area || locAddr.district, city: locAddr.city, divisionId: locAddr.divisionId, gps: locAddr.gps, poiId: locAddr.poiId || '', poiName: locAddr.poiName || '', prov: locAddr.prov },
            defaultPrice: false,
            itemCatDTO: { catId: cat.catId, catName: cat.catName, channelCatId: cat.categoryId },
            uniqueCode: Date.now() + '_' + Math.random().toString(36).substring(2, 10),
            sourceId: 'pcMainPublish', bizcode: 'pcMainPublish', publishScene: 'pcMainPublish'
        };
        // ===== 商品规格：任务级 > 店铺级；启用后价格改由 SKU 决定 =====
        var _specCfg = specOverride || ((typeof loadStoreConfig === 'function' ? (loadStoreConfig() || {}) : {})).specs;
        var _specPayload = buildSkuPayload(_specCfg);
        if (_specPayload) {
            data.itemProperties = _specPayload.itemProperties;
            data.itemSkuList = _specPayload.itemSkuList;
            data.itemPriceDTO = {}; // 抓包样本：启用规格后顶层价格须置空，否则与规格价冲突
            console.log('[规格] 启用 ' + (_specCfg.propertyName || '代拍费') + '，共 ' + _specPayload.itemSkuList.length + ' 档：' +
                _specPayload.itemSkuList.map(function (s) { return s.propertyList[0].valueText + '￥' + (Number(s.priceInCent) / 100); }).join(' / '));
        }
        var r = await window.lib.mtop.request({ api: 'mtop.idle.pc.idleitem.publish', v: '1.0', data: data, type: 'POST' });
        if (!r || !r.ret || !r.ret[0] || !r.ret[0].startsWith('SUCCESS')) throw new Error(r && r.ret ? r.ret[0] : 'fail');
        var _ds = r.data || {};
        // 调试钩子：存最近一次真实发布响应，便于抓取定位 itemId 实际位置
        try { window.__lastPubResp = { ret: r.ret, data: _ds }; } catch(e) {}
        // 递归找 itemId：闲鱼发布响应里 itemId 字段位置会变，逐层找 (itemId / 数字长 id / redirectUrl.itemId)，避免"发布成功但解析不到 id"判成失败
        function _deepId(o, depth) {
            if (!o || typeof o !== 'object' || depth > 5) return '';
            if (o.itemId !== undefined && o.itemId) return String(o.itemId);
            if (o.id !== undefined && o.id && /^\d{6,}$/.test(String(o.id))) return String(o.id);
            if (typeof o.redirectUrl === 'string') { var m = o.redirectUrl.match(/itemId=(\d+)/); if (m) return m[1]; }
            for (var k in o) { if (typeof o[k] === 'object') { var v = _deepId(o[k], depth + 1); if (v) return v; } }
            return '';
        }
        var _id = _deepId(_ds, 0) || (_ds.redirectUrl ? ((_ds.redirectUrl.match(/itemId=(\d+)/) || ['', ''])[1]) : '') || '';
        console.log('[发布] itemId=' + _id + ' 返回data=' + JSON.stringify(_ds).slice(0, 320));
        return { itemId: _id || '', success: !!_id };
    }

    // ===== 图片 URL 清洗 =====
    function cleanImageUrl(src) {
        return src.replace(/_\d+x\d+.*$/i, '').replace(/^http:/, 'https:');
    }

    // ===== 收集页面图片 =====
    function collectPageImages() {
        var imgs = document.querySelectorAll('img[src*="alicdn"][src*="fleamarket"],img[src*="alicdn"][src*="mtopupload"]');
        var urls = [];
        for (var i = 0; i < imgs.length; i++) { var u = cleanImageUrl(imgs[i].src); if (urls.indexOf(u) < 0) urls.push(u); }
        var clean = [];
        for (var j = 0; j < urls.length; j++) { if (urls[j].indexOf('alicdn') >= 0 && urls[j].indexOf('logo') < 0 && urls[j].indexOf('tps-') < 0 && urls[j].match(/O1CN/)) clean.push(urls[j]); }
        var data = loadData(), added = 0;
        for (var k = 0; k < clean.length; k++) { if (data.images.indexOf(clean[k]) < 0) { data.images.push(clean[k]); added++; } }
        saveData(data);
        return added;
    }

    // ===== 图片 URL 缓存 =====
    var IMG_CACHE_KEY = 'kun_img_cache';
    function loadImageCache() {
        try { return JSON.parse(localStorage.getItem(IMG_CACHE_KEY)) || {}; }
        catch(e) { return {}; }
    }
    function saveImageCache(cache) {
        localStorage.setItem(IMG_CACHE_KEY, JSON.stringify(cache));
    }

    // ===== 单张图片上传（缓存 + API优先）=====
    // 路径归一化：统一分隔符+小写，用于「读到的是不是我要的那张」校验
    function normImgPath(p) {
        return String(p || '').replace(/\\/g, '/').replace(/\/+/g, '/').toLowerCase();
    }
    async function uploadLocalImage(filePath, opts) {
        var fileName = filePath.replace(/^.*[\\\/]/, '');

        console.log('[kun] 读取图片:', fileName);

        // 通过 Native Host 读取图片为 base64（同时拿到压缩后内容，用于内容级缓存）
        var result = await callNativeHost({ action: 'readImage', path: filePath });
        if (!result || result.error) throw new Error(result ? result.error : 'read failed');
        // ⚠ native host 在文件不存在时会去父目录的子目录里乱搜同名文件（native_host.py:526），
        //   会把别的分组/别的明星的同名图当命中返回。副图取值传 exact，避免静默拿错图。
        if (opts && opts.exact) {
            var _want = normImgPath(filePath), _got = normImgPath(result.path);
            if (_got && _want !== _got) throw new Error('路径不符(疑似串图): ' + result.path);
        }
        var b64 = result.base64 || result.data;
        if (!b64) throw new Error('no base64 data');

        // ⚠ 缓存键必须用【内容】而不是文件名：
        //   副图库每个分组下的文件都叫 1.jpg…8.jpg，用文件名做键会让后发的明星
        //   命中前一个明星的 URL（静默串图）；改成内容键后，换了图内容也会自动失效，
        //   不必再手动清 kun_img_cache。
        // ⚠ 键不能用 b64 前 32 位：所有 JPEG 的 base64 文件头（/9j/4AAQSkZJRgAB...）完全一致，
        //   前 32 位会导致任意 JPEG 互相撞键 → 静默串图（2026-09-17 周杰伦海报串成战绩图事故）。
        //   改用全内容 djb2 哈希 + 长度做键。
        var _h1 = 5381, _h2 = 52711;
        for (var _ci = 0; _ci < b64.length; _ci += 3) {
            _h1 = ((_h1 * 33) ^ b64.charCodeAt(_ci)) & 0x7fffffff;
            _h2 = ((_h2 * 31) ^ b64.charCodeAt(_ci)) & 0x7fffffff;
        }
        var cacheKey = 'b64v2_' + b64.length + '_' + _h1.toString(36) + _h2.toString(36);
        var cache = loadImageCache();
        if (cache[cacheKey]) {
            console.log('[kun] 内容缓存命中:', fileName, '→', cache[cacheKey]);
            return cache[cacheKey];
        }

        // 方案B: API 直传（stream-upload 最快）
        var url = await uploadViaApi(b64);
        if (!url) {
            // 回退：页面原生上传
            var rawBytes = atob(b64);
            var byteNumbers = new Array(rawBytes.length);
            for (var bni = 0; bni < rawBytes.length; bni++) { byteNumbers[bni] = rawBytes.charCodeAt(bni); }
            var file = new File([new Uint8Array(byteNumbers)], fileName, { type: 'image/jpeg' });
            url = await uploadViaPage(file);
        }
        if (!url) throw new Error('upload failed');

        // 存入缓存（键=内容哈希）
        cache[cacheKey] = url;
        saveImageCache(cache);
        console.log('[kun] 上传成功:', url);
        return url;
    }

    // ===== 副图取值（两条发布路径共用，避免"每日发布/单条发布"逻辑分叉）=====
    // 优先级（从细到粗，命中即返回）：
    //   ① 自定义副图/<明星>/<城市>/<场次>/N.*
    //   ② 自定义副图/<明星>/<城市>/N.*
    //   ③ 自定义副图/<明星>/<场次>/N.*
    //   ④ 自定义副图/<明星>/N.*
    //   ⑤ 自定义副图/N.*（发布台副图库，全店共享）
    //   ⑥ <店铺目录>/副图N.*（店铺专属）  ⑦ 根目录/副图N.*（兜底）
    // 扩展名兼容 jpg/jpeg/png —— 发布台上传的是 .jpeg，以前硬编码 .jpg 导致读不到
    var SUBIMG_EXTS = ['.jpg', '.jpeg', '.png'];
    async function uploadSubImage(sub, star, city, session, setNames) {
        var _logFrom = function (rel) { try { dailyLogToUI('  🖼 副图' + sub + ' ← ' + rel); } catch (e) {} };
        var _tryOne = async function (p) {
            try {
                // exact：要求真的读到这个路径，否则 native host 会在父目录子目录里乱搜同名文件
                var u = await uploadLocalImage(p, { exact: true });
                if (u && !u.startsWith("data:")) return u;
            } catch (e) {}
            return null;
        };
        // 【2026-09-30 加·任务级副图组】
        // 老板给了两套副图（第一组 / 第二组），要求轮着用。
        // 文件放在：<图片根>/<店铺>/<组名>/副图1.jpg … 副图8.jpg
        // 任务上写 task.subSet（字符串或数组），这里优先从这里取；取不到再走原来的分组/通用逻辑。
        var _setDirs = [];
        if (setNames) {
            var _arr = Array.isArray(setNames) ? setNames : [setNames];
            for (var _si = 0; _si < _arr.length; _si++) {
                if (!_arr[_si]) continue;
                _setDirs.push(IMAGES_FOLDER + (currentStore || '') + '/' + _arr[_si] + '/');
                _setDirs.push(IMAGES_FOLDER + _arr[_si] + '/');   // 也允许放在图片根目录下
            }
        }
        for (var _di = 0; _di < _setDirs.length; _di++) {
            for (var _ei2 = 0; _ei2 < SUBIMG_EXTS.length; _ei2++) {
                var _u2 = await _tryOne(_setDirs[_di] + '副图' + sub + SUBIMG_EXTS[_ei2]);
                if (_u2) { _logFrom(_setDirs[_di].substring(IMAGES_FOLDER.length) + '副图' + sub + SUBIMG_EXTS[_ei2]); return _u2; }
            }
        }
        var _pool = IMAGES_FOLDER + '自定义副图/';
        var _groups = [];
        if (star && city && session) _groups.push(_pool + star + '/' + city + '/' + session + '/');
        if (star && city) _groups.push(_pool + star + '/' + city + '/');
        if (star && session) _groups.push(_pool + star + '/' + session + '/');
        if (star) _groups.push(_pool + star + '/');
        _groups.push(_pool);
        var gi, ei, url;
        for (gi = 0; gi < _groups.length; gi++) {
            for (ei = 0; ei < SUBIMG_EXTS.length; ei++) {
                url = await _tryOne(_groups[gi] + sub + SUBIMG_EXTS[ei]);
                if (url) { _logFrom(_groups[gi].substring(IMAGES_FOLDER.length) + sub + SUBIMG_EXTS[ei]); return url; }
            }
        }
        var _folders = [];
        if (currentStore) _folders.push(IMAGES_FOLDER + currentStore + '/');
        _folders.push(IMAGES_FOLDER);
        for (gi = 0; gi < _folders.length; gi++) {
            for (ei = 0; ei < SUBIMG_EXTS.length; ei++) {
                url = await _tryOne(_folders[gi] + '副图' + sub + SUBIMG_EXTS[ei]);
                if (url) { _logFrom(_folders[gi].substring(IMAGES_FOLDER.length) + '副图' + sub + SUBIMG_EXTS[ei]); return url; }
            }
        }
        return null;
    }

    // ===== 页面原生上传（文件输入 + 拖拽）=====
    async function uploadViaPage(file) {
        var dt = new DataTransfer();
        dt.items.add(file);

        // 方式1: 找页面文件输入
        var inputs = document.querySelectorAll('input[type="file"]');
        for (var ii = 0; ii < inputs.length; ii++) {
            var inp = inputs[ii];
            if (!inp.offsetParent) continue;
            console.log('[kun] 触发 file input 上传...');
            inp.files = dt.files;
            inp.dispatchEvent(new Event('change', { bubbles: true }));
            var url = await waitForUploadedImage(25000);
            if (url) return url;
        }

        // 方式2: 拖拽到上传区
        var zones = document.querySelectorAll('[class*="upload" i], [class*="drop" i], [class*="drag" i], [class*="picker" i]');
        for (var dz = 0; dz < zones.length; dz++) {
            var zone = zones[dz];
            if (!zone.offsetParent) continue;
            console.log('[kun] 拖拽上传...');
            zone.dispatchEvent(new DragEvent('dragenter', { dataTransfer: dt, bubbles: true, cancelable: true }));
            zone.dispatchEvent(new DragEvent('dragover', { dataTransfer: dt, bubbles: true, cancelable: true }));
            zone.dispatchEvent(new DragEvent('drop', { dataTransfer: dt, bubbles: true, cancelable: true }));
            var url = await waitForUploadedImage(25000);
            if (url) return url;
        }

        return null;
    }

    // ===== 等待图片上传完成（监控 DOM + Network）=====
    function waitForUploadedImage(timeoutMs) {
        return new Promise(function(resolve) {
            var start = Date.now();
            var known = [];
            var imgs = document.querySelectorAll('img[src*="alicdn"], img[src*="mtopupload"]');
            for (var e = 0; e < imgs.length; e++) { known.push(imgs[e].src); }
            var entries = performance.getEntriesByType('resource');
            for (var ee = 0; ee < entries.length; ee++) { known.push(entries[ee].name); }

            function check() {
                // 检查新出现的 img
                var imgs2 = document.querySelectorAll('img[src*="alicdn"], img[src*="mtopupload"]');
                for (var i = 0; i < imgs2.length; i++) {
                    var src = imgs2[i].src;
                    if (src && known.indexOf(src) < 0) { console.log('[kun] 新图片:', src); resolve(src); return; }
                }
                // 检查 network
                var entries2 = performance.getEntriesByType('resource');
                for (var j = 0; j < entries2.length; j++) {
                    var name = entries2[j].name;
                    if (name.indexOf('alicdn') >= 0 && known.indexOf(name) < 0) {
                        console.log('[kun] 上传请求:', name);
                        resolve(name);
                        return;
                    }
                }
                if (Date.now() - start > timeoutMs) { resolve(null); return; }
                setTimeout(check, 500);
            }
            setTimeout(check, 2000);
        });
    }

    // ===== 调用闲鱼原生上传接口 =====
    async function uploadViaApi(b64) {
        // 方案1: stream-upload（闲鱼页面实际使用的上传接口）
        try {
            var rawBytes = atob(b64);
            var byteNumbers = new Array(rawBytes.length);
            for (var bni = 0; bni < rawBytes.length; bni++) { byteNumbers[bni] = rawBytes.charCodeAt(bni); }
            var blob = new Blob([new Uint8Array(byteNumbers)], { type: 'image/jpeg' });
            var fd = new FormData();
            fd.append('file', blob, 'upload.jpg');

            var uResp = await fetch('https://stream-upload.goofish.com/api/upload.api?floderId=0&appkey=fleamarket&_input_charset=utf-8', {
                method: 'POST',
                credentials: 'include',
                body: fd
            });
            if (uResp.ok) {
                var uResult = await uResp.json();
                var url = (uResult && uResult.object && uResult.object.url) || (uResult && uResult.url);
                if (url && url.indexOf('alicdn') >= 0) {
                    console.log('[kun] stream-upload成功:', url);
                    return url;
                }
                console.log('[kun] stream-upload返回:', JSON.stringify(uResult).substring(0, 200));
            } else {
                console.log('[kun] stream-upload失败 HTTP', uResp.status);
            }
        } catch(e) {
            console.log('[kun] stream-upload异常:', (e && e.message) || e);
        }

        // 方案2: MTOP API 回退
        if (window.lib && window.lib.mtop && window.lib.mtop.request) {
            var PICTURE_APIS = [
                { api: 'mtop.taobao.picture.upload', v: '1.0' },
                { api: 'mtop.idle.pc.picture.upload', v: '1.0' },
                { api: 'mtop.idle.picture.upload', v: '1.0' },
            ];
            for (var pi = 0; pi < PICTURE_APIS.length; pi++) {
                try {
                    var r = await window.lib.mtop.request({ api: PICTURE_APIS[pi].api, v: PICTURE_APIS[pi].v, data: { file: b64, fileType: 'jpg', space: 'fleamarket' } });
                    if (r && r.ret && r.ret[0] && r.ret[0].startsWith('SUCCESS') && r.data && r.data.url) {
                        return r.data.url;
                    }
                } catch(e) {}
            }
        }

        // 方案3: Python 代理
        try {
            var rr = await callNativeHost({ action: 'uploadToMtop', base64: b64, cookies: document.cookie });
            if (rr && rr.url) return rr.url;
        } catch(e) {}

        return null;
    }

    // ===== 多张图片上传 =====
    async function uploadMultipleImages(filePaths) {
        if (!Array.isArray(filePaths)) filePaths = [filePaths];
        filePaths = filePaths.filter(Boolean);
        if (filePaths.length === 0) throw new Error('no files to upload');

        var urls = [];
        for (var i = 0; i < filePaths.length; i++) {
            var url = await uploadLocalImage(filePaths[i]);
            urls.push(url);
            // 每张之间间隔 2s，避免页面处理冲突
            if (i < filePaths.length - 1) await new Promise(function(r) { setTimeout(r, 2000); });
        }
        return urls;
    }

    // ===== 公开的上传接口：base64 → CDN URL（通过页面自身上传，不走 Python）=====
    async function uploadBase64ToCdn(b64) {
        if (!b64) return null;
        // 先查缓存
        var cache = loadImageCache();
        // ⚠ 键不能用 b64 前 32 位：所有 JPEG 的 base64 文件头（/9j/4AAQSkZJRgAB...）完全一致，
        //   前 32 位会导致任意 JPEG 互相撞键 → 静默串图（2026-09-17 周杰伦海报串成战绩图事故）。
        //   改用全内容 djb2 哈希 + 长度做键。
        var _h1 = 5381, _h2 = 52711;
        for (var _ci = 0; _ci < b64.length; _ci += 3) {
            _h1 = ((_h1 * 33) ^ b64.charCodeAt(_ci)) & 0x7fffffff;
            _h2 = ((_h2 * 31) ^ b64.charCodeAt(_ci)) & 0x7fffffff;
        }
        var cacheKey = 'b64v2_' + b64.length + '_' + _h1.toString(36) + _h2.toString(36);
        if (cache[cacheKey]) return cache[cacheKey];

        var url = await uploadViaApi(b64);
        if (url) {
            cache[cacheKey] = url;
            saveImageCache(cache);
        }
        return url;
    }

    // 批量上传 base64 图片
    async function uploadBase64Batch(b64Array) {
        var urls = [];
        for (var i = 0; i < b64Array.length; i++) {
            var url = await uploadBase64ToCdn(b64Array[i]);
            urls.push(url);
            // 间隔 1.5s 避免 token 冲突
            if (i < b64Array.length - 1) await new Promise(function(r) { setTimeout(r, 1500); });
        }
        return urls;
    }

    // ===== 选取本地图片（返回文件名） =====
    async function pickLocalFile() {
        var result = await callNativeHost({ action: 'pickFile', filetypes: [['Image files', '*.jpg *.jpeg *.png *.gif *.webp']], title: '选择商品图片' });
        if (!result || result.error) throw new Error(result ? result.error : 'pick failed');
        if (!result.path) return '';
        // 只返回文件名
        return result.path.replace(/^.*[\\\/]/, '');
    }

    // ===== 选取多张本地图片（一次多选）=====
    async function pickLocalFiles() {
        var result = await callNativeHost({ action: 'pickFiles', filetypes: [['Image files', '*.jpg *.jpeg *.png *.gif *.webp']], title: '选择多张商品图片' });
        if (!result || result.error) throw new Error(result ? result.error : 'pick failed');
        if (!result.paths || result.paths.length === 0) return [];
        return result.paths.map(function(p) { return p.replace(/^.*[\\\/]/, ''); });
    }

    // ===== 读取本地图片 base64（用于预览） =====
    async function readLocalImageBase64(fileName) {
        var cleanName = fileName.replace(/^.*[\\\/]/, '');
        // 兼容文件名中的逗号/空格变体
        var altNames = [cleanName];
        if (cleanName.indexOf(',') >= 0) altNames.push(cleanName.replace(/,/g, ' '));
        if (cleanName.indexOf(' ') >= 0) altNames.push(cleanName.replace(/ /g, ','));
        // 直接用 fetch 调本地 API（绕过 postMessage）
        var API = 'http://localhost:8093/api/agent/native-host';
        var KEY = '';
        var store = currentStore || '';
        var paths = [];
        if (store) {
            for (var an = 0; an < altNames.length; an++) {
                paths.push(IMAGES_FOLDER + store + '/' + altNames[an]);
            }
        }
        for (var an = 0; an < altNames.length; an++) {
            paths.push(IMAGES_FOLDER + altNames[an]);
        }
        var hasExt = /\.(jpg|jpeg|png|gif|webp)$/i.test(cleanName);
        for (var pi = 0; pi < paths.length; pi++) {
            var tryPaths = [paths[pi]];
            if (!hasExt) { tryPaths.push(paths[pi] + '.jpg', paths[pi] + '.png'); }
            for (var tp = 0; tp < tryPaths.length; tp++) {
                try {
                    var resp = await fetch(API, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-API-Key': KEY }, body: JSON.stringify({ action: 'readImage', path: tryPaths[tp] }) });
                    var json = await resp.json();
                    if (json.ok && json.data && json.data.base64) return json.data.base64;
                } catch(e) {}
            }
        }
        return null;
    }

    // ===== 从文件名解析明星/城市/场次类型 =====
    function parseImageFileName(fileName) {
        var name = fileName.replace(/\.[^.]+$/, '');
        var sessionType = '';
        var types = SESSION_TYPES.slice().sort(function(a, b) { return b.length - a.length; });
        for (var t = 0; t < types.length; t++) {
            if (name.indexOf(types[t]) >= 0) {
                sessionType = types[t];
                name = name.replace(types[t], '');
                break;
            }
        }
        var city = '';
        var star = name;
        if (typeof ADDRESS_DB !== 'undefined' && ADDRESS_DB.length > 0) {
            var cities = [];
            for (var a = 0; a < ADDRESS_DB.length; a++) {
                if (cities.indexOf(ADDRESS_DB[a].city) < 0) cities.push(ADDRESS_DB[a].city);
            }
            cities.sort(function(a, b) { return b.length - a.length; });
            for (var c = 0; c < cities.length; c++) {
                if (name.indexOf(cities[c]) === 0) {
                    city = cities[c];
                    star = name.substring(city.length);
                    break;
                }
            }
        }
        return { star: star, city: city, sessionType: sessionType };
    }

    // ===== 每日任务自动发布（演唱会代拍用）=====
    var dailyRunning = false;
    var dailyTimer = null;
    var dailyCurrentIndex = -1;
    var dailyPhase = 'idle'; // idle | publish | wait_next
    var dailyTaskCount = 0;

    function dailyWait(ms) {
        return new Promise(function(resolve) {
            dailyTimer = setTimeout(resolve, ms);
        });
    }

    function dailyLogToUI(msg) {
        try {
            window.dispatchEvent(new CustomEvent('kun-daily-log', { detail: { msg: msg, time: new Date().toLocaleTimeString() } }));
        } catch(e) {}
        console.log('[kun] ' + msg);
    }

    async function doDailyTask(idx) {
        if (!dailyRunning) { dailyPhase = 'idle'; return; }
        var data = loadDailyTasks();
        var tasks = data.tasks || [];
        var task = tasks[idx];
        if (!task) { dailyLogToUI('⚠ 任务不存在'); dailyRunning = false; dailyPhase = 'idle'; return; }
        var storeCfg = loadStoreConfig() || {}; // P1-6：提前加载，避免 var 提升使 _subImg 读不到店铺副图开关

        // P1-7：发布前复查 itemId，已被其他运行/页面发布过的任务直接跳下一个，防重复上架
        if (task.itemId) {
            dailyLogToUI('⏭ 跳过已发布: ' + (task.star || '') + (task.city ? ' · ' + task.city : '') + (task.sessionType ? ' · ' + task.sessionType : ''));
            if (idx + 1 >= dailyTaskCount) { dailyRunning = false; dailyPhase = 'idle'; dailyLogToUI('✅ 当前店铺发布完成'); return; }
            var _skipInt = parseInt(data.publishInterval) || 60;
            dailyPhase = 'wait_next';
            dailyLogToUI('⏳ 等待 ' + _skipInt + ' 分钟后发布下一个...');
            await dailyWait(_skipInt * 60 * 1000);
            if (!dailyRunning) { dailyPhase = 'idle'; return; }
            return await doDailyTask(idx + 1);
        }

        dailyPhase = 'publish';
        dailyCurrentIndex = idx;
        dailyLogToUI('📤 发布第 ' + (idx + 1) + '/' + dailyTaskCount + ' 个: ' + task.star + ' · ' + task.city + ' · ' + task.sessionType);

        try {
            var projId = getProjForStore(currentStore);
            var projCfg2 = getProjectConfig(projId) || DEFAULT_PROJECT_CONFIGS[projId] || {};
            var _useTplId = data.templateId;
            var storeCfg3 = loadStoreConfig(); var _isRandom = storeCfg3.titleMode === 'random' || projCfg2.titleMode === 'random' || task.titleModeOverride === 'random';
            if (_isRandom && CONCERT_TEMPLATES.length > 0) {
                _useTplId = pickRandomTemplateId();
                var _rp = null; for (var _ri = 0; _ri < CONCERT_TEMPLATES.length; _ri++) { if (CONCERT_TEMPLATES[_ri].id === _useTplId) { _rp = CONCERT_TEMPLATES[_ri]; break; } }
                if (_rp) dailyLogToUI('🎲 随机模板: ' + _rp.name);
            }
            var title, desc;
            if (currentStore === 'casa家居' || task.directTitle) {
                title = task.star || '';
                desc = task.description || '';
            } else {
            title = renderConcertTitle(_useTplId, task.star, task.city, task.sessionType, task.eventType);
            desc = renderConcertDesc(_useTplId);
            var isFilenameTitle = (projCfg2.titleMode === 'filename') && !_isRandom;
            if (isFilenameTitle) {
                var imgFileName = (task.imageUrl || data.imageUrl || "").replace(/^.*[\\\/]/, "").replace(/\.[^.]+$/, "");
                title = imgFileName || '招抢手';
                var descs = (projCfg2.templates && projCfg2.templates.length > 0) ? projCfg2.templates : ['感兴趣直接私聊咨询'];
                desc = descs[Math.floor(Math.random() * descs.length)];
            }
            }
            var fullDesc = title + "\n\n" + desc;

                        // 收集每任务图片：优先 imageUrls 数组，退回到 imageUrl
            var imgList = (Array.isArray(task.imageUrls) && task.imageUrls.length > 0) ? task.imageUrls.slice() : [task.imageUrl || data.imageUrl || DEFAULT_IMAGE_URL];
            imgList = imgList.filter(Boolean);
            var allImages = [];
            for (var imgIdx = 0; imgIdx < imgList.length; imgIdx++) {
                var imgSrc = imgList[imgIdx];
                if (imgSrc.startsWith("http")) { allImages.push(imgSrc); continue; }
                var fn = imgSrc.replace(/^.*[\\\/]/, "");
                var lp = IMAGES_FOLDER + fn;
                dailyLogToUI("⏳ 上传图片(" + (imgIdx+1) + "/" + imgList.length + "): " + fn);
                try {
                    var upUrl = await uploadLocalImage(lp);
                    if (upUrl && !upUrl.startsWith("data:")) { allImages.push(upUrl); dailyLogToUI("  ✅ 已上传"); }
                    else { dailyLogToUI("  ⚠ 上传失败，跳过"); }
                } catch(e) { dailyLogToUI("  ⚠ 异常: " + ((e&&e.message)||e)); }
            }
            if (allImages.length === 0) {
                dailyLogToUI("❌ 无可用图片，跳过此任务");
                task.status = "failed"; task.error = "无可用图片";
                saveDailyTasks(data); dailyRunning = false; dailyPhase = "idle"; return;
            }

            // 上传副图1~8（店铺配置优先；casa家居跳过副图）
            // 【2026-09-30 修】同 publishOneTask：允许任务级 task.subImg 覆盖 directTitle 的强制关副图
            var _subImg = (typeof task.subImg === 'boolean') ? task.subImg : ((currentStore === 'casa家居' || task.directTitle) ? false : ((storeCfg && typeof storeCfg.subImg === 'boolean') ? storeCfg.subImg : (projCfg2 && projCfg2.subImg !== false)));
            if (_subImg) {
            for (var sub = 1; sub <= 8; sub++) {
                try {
                    // 统一取值：分组副图(明星/城市/场次) → 发布台副图库 → 店铺目录 → 根目录兜底
                    var _subUrl = await uploadSubImage(sub, task.star, task.city, task.sessionType, task.subSet);
                    if (_subUrl) allImages.push(_subUrl);  // 来源日志由 uploadSubImage 统一打
                } catch(e) {}
            }
            }

            // 分类/价格/库存：优先任务字段，退回到模板默认
            var tpl = null;
            for (var ti = 0; ti < CONCERT_TEMPLATES.length; ti++) { if (CONCERT_TEMPLATES[ti].id === _useTplId) { tpl = CONCERT_TEMPLATES[ti]; break; } }
            var proj = getProjForStore(currentStore);
            var defCat = (proj === 'recruit') ? '技能类招工' : (proj === 'yuxiaopu') ? '互联网产品与运营技能培训' : '代购';
            var catName = task.categoryName || storeCfg.category || (tpl && tpl.categoryName) || defCat;
            var priceVal = task.price || storeCfg.price || (tpl && tpl.price) || "50";
            var origPriceVal = task.origPrice || storeCfg.origPrice || (tpl && tpl.origPrice) || "";
            var stockVal = task.stock || storeCfg.stock || (tpl && tpl.stock) || "9999";

            var shipMode = task.shipMode || storeCfg.shipMode || (projCfg2 && projCfg2.shipMode) || 'nomail';
            var pubCity = task.city;
            if (isFilenameTitle && !pubCity) {
                var cities = ['广州','深圳','北京','上海','杭州','成都','武汉','南京','苏州','重庆','长沙','青岛'];
                pubCity = cities[Math.floor(Math.random() * cities.length)];
            }
            if (!pubCity) {
                var _ct = ['广州','深圳','北京','上海','杭州','成都','武汉','南京','苏州','重庆','西安','天津','长沙','青岛'];
                pubCity = _ct[Math.floor(Math.random() * _ct.length)];
            }
            var _loc = resolveLocation(storeCfg, pubCity);
            pubCity = _loc.city;
            var pubDistrict = _loc.district || '';
            // 逐条确认模式
            if (data.confirmMode && !confirm('确认发布？\n\n标题：' + title + '\n价格：¥' + priceVal + '\n分类：' + catName + '\n\n点确定=发布  点取消=跳过')) {
                dailyLogToUI('⏭ 跳过任务');
                task.status = 'pending';
                saveDailyTasks(data);
                return;
            }
            // auto-safe：发布失败自动换分类重试
            var catFallback = [catName].concat(Object.keys(CATEGORY_TEMPLATES).filter(function(c){return c!==catName}));
            var r = null, lastErr = '';
            for (var cf = 0; cf < catFallback.length; cf++) {
                try {
                    r = await publishOne(title, fullDesc, priceVal, allImages, pubCity, pubDistrict, catFallback[cf], stockVal, shipMode, storeCfg.commitment, origPriceVal, (task && task.specs));
                    if (r) break;
                } catch(e) {
                    var em = (e&&e.message) ? e.message : String(e);
                    lastErr = em;
                    if (em.indexOf('不支持')>=0 || em.indexOf('分类')>=0 || em.indexOf('CATEGORY')>=0) {
                        dailyLogToUI('🔄 分类 ' + catFallback[cf] + ' 不支持，换 ' + (catFallback[cf+1]||'无更多'));
                        continue;
                    }
                    throw e;
                }
            }
            if (!r) throw new Error(lastErr || '发布失败');
            task.status = 'done';
            task.itemId = r.itemId;
            saveDailyTasks(data);
            dailyLogToUI('✅ 发布成功! itemId=' + (r.itemId || '?'));

            // 自动开启超级擦亮（P0-3：读任务级参数，三档出价/计划数生效）
            if (r.itemId && data.autoPolish !== false && projCfg2.autoPolish !== false && !task.skipCampaign) {
                try {
                    dailyLogToUI('💨 正在开启超级擦亮...');
                    var cat = getCategoryConfig(catName);
                    var _opts = { bidPrice: task.bidPrice, maxDayBudget: task.maxDayBudget, bidTarget: task.bidTarget };
                    var _cCount = parseInt(task.campaignCount) || 1;
                    await startCampaignMultiple(r.itemId, cat.categoryId, parseFloat(priceVal), _opts, _cCount, task.campaignPlans);
                    dailyLogToUI('✅ 超级擦亮已开启');
                } catch(e) { dailyLogToUI('⚠ 擦亮失败: ' + ((e&&e.message)||e)); }
            }

            // 检查是否最后一个
            if (idx + 1 >= dailyTaskCount) {
                dailyRunning = false;
                dailyPhase = 'idle';
                dailyLogToUI('✅ 当前店铺发布完成');
                return;
            }

            // 发布间隔（可配置）
            var intervalMin = parseInt(data.publishInterval) || 60;
            dailyPhase = 'wait_next';
            dailyLogToUI('⏳ 等待 ' + intervalMin + ' 分钟后发布下一个...');
            await dailyWait(intervalMin * 60 * 1000);
            if (!dailyRunning) { dailyPhase = 'idle'; return; }

            // 下一个
            await doDailyTask(idx + 1);
        } catch(e) {
            var errMsg = (e && e.message) ? e.message : (e && e.ret ? e.ret[0] : String(e));
            task.status = 'failed';
            task.error = errMsg;
            saveDailyTasks(data);
            dailyLogToUI('❌ 发布失败: ' + errMsg + (errMsg==='' ? ' (空错误，可能是请求被拦截)' : ''));
            dailyRunning = false;
            dailyPhase = 'idle';
        }
    }


    // ===== 自动开启超级擦亮 =====
    async function startCampaign(itemId, catId, priceYuan, options) {
        options = options || {};
        var priceInCents = Math.round((parseFloat(priceYuan) || 50) * 100);
        var bidPrice = Math.round((parseFloat(options.bidPrice) || 13.6) * 100);
        var maxDayBudget = Math.round((parseFloat(options.maxDayBudget) || 50) * 100);
        var bidTarget = options.bidTarget || 'order';
        var data = {
            requestJson: JSON.stringify({
                entityType: 1,
                fromScene: "pc_campaign-manage",
                oldMember: true,
                entityList: [{ entityId: parseInt(itemId), catId: parseInt(catId) || 201456914, price: priceInCents, startTime: Date.now(), areaTarget: false }],
                customInfo: { bidPrice: bidPrice, maxDayBudget: maxDayBudget, budgetScheduleDurations: [8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23] },
                baseInfo: { productId: 1, promotionMode: "custom", bidType: "smart_bid", bidTarget: bidTarget, title: '¥' + (parseFloat(options.bidPrice) || 13.6) + '·' + (bidTarget === 'order' ? '订单' : '咨询') + '·' + (((options.city || '') + (options.star || '')) || '集合') },
                targetInfo: { divisionList: [] },
                clueInfo: { chatButton: true, bookButton: false, bookText: "" },
                extraFunctions: { creativeOptSwitch: true }
            })
        };
        var r = await window.lib.mtop.request({ api: "mtop.taobao.idle.ad.campaign.startV2", v: "1.0", data: data });
        if (!r || !r.ret || !r.ret[0] || !r.ret[0].startsWith("SUCCESS")) {
            throw new Error(r && r.ret ? r.ret[0] : "campaign start failed");
        }
        return r.data;
    }

    // 一个计划推多个链接（最多10个）
    async function startCampaignBatch(items, options) {
        options = options || {};
        if (items.length > 10) items = items.slice(0, 10);
        var bidPrice = Math.round((parseFloat(options.bidPrice) || 13.6) * 100);
        var maxDayBudget = Math.round((parseFloat(options.maxDayBudget) || 50) * 100);
        var bidTarget = options.bidTarget || 'order';
        var entityList = items.map(function(item) {
            return { entityId: parseInt(item.itemId), catId: parseInt(item.catId) || 201456914, price: Math.round((parseFloat(item.priceYuan) || 50) * 100), startTime: Date.now(), areaTarget: false };
        });
        var data = {
            requestJson: JSON.stringify({
                entityType: 1, fromScene: "pc_campaign-manage", oldMember: true,
                entityList: entityList,
                customInfo: { bidPrice: bidPrice, maxDayBudget: maxDayBudget, budgetScheduleDurations: [8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23] },
                baseInfo: { productId: 1, promotionMode: "custom", bidType: "smart_bid", bidTarget: bidTarget, title: '¥' + (parseFloat(options.bidPrice) || 13.6) + '·' + (bidTarget === 'order' ? '订单' : '咨询') + '·' + (((options.city || '') + (options.star || '')) || '集合') },
                targetInfo: { divisionList: [] },
                clueInfo: { chatButton: true, bookButton: false, bookText: "" },
                extraFunctions: { creativeOptSwitch: true }
            })
        };
        var r = await window.lib.mtop.request({ api: "mtop.taobao.idle.ad.campaign.startV2", v: "1.0", data: data });
        if (!r || !r.ret || !r.ret[0] || !r.ret[0].startsWith("SUCCESS")) throw new Error(r && r.ret ? r.ret[0] : "batch campaign failed");
        return r.data;
    }

    // 同个链接建多个计划
    async function startCampaignMultiple(itemId, catId, priceYuan, options, count, plans) {
        for (var i = 0; i < count; i++) {
            var opt = (plans && plans[i]) || options;
            try { await startCampaign(itemId, catId, priceYuan, opt); }
            catch(e) { if (i === 0) throw e; }
            if (i < count - 1) await new Promise(function(r) { setTimeout(r, 2000); });
        }
    }

    async function runDailyPublish() {
        if (!currentStore) { dailyLogToUI('⚠ 请先选择店铺'); return; }

        await syncTasksFromDisk();
        var data = loadDailyTasks();
        var tasks = data.tasks || [];
        if (tasks.length === 0) { dailyLogToUI('⚠ 没有每日任务，请先在表格添加'); return; }

        var expanded = expandSessions(tasks);
        tasks = expanded;

        // 优先发布排前面
        tasks.sort(function(a, b) {
            if (a.priority && !b.priority) return -1;
            if (!a.priority && b.priority) return 1;
            return 0;
        });

        // 重置未完成的任务状态
        var hasPending = false;
        for (var i = 0; i < tasks.length; i++) {
            if (tasks[i].status !== 'done' && tasks[i].status !== 'failed') {
                tasks[i].status = 'pending';
                hasPending = true;
            }
        }
        if (!hasPending) {
            for (var j = 0; j < tasks.length; j++) {
                tasks[j].status = 'pending';
                delete tasks[j].itemId;
                delete tasks[j].error;
            }
        }
        data.tasks = tasks;
        saveDailyTasks(data);

        dailyRunning = true;
        dailyTaskCount = tasks.length;

        var startIdx = -1;
        for (var k = 0; k < tasks.length; k++) {
            if (tasks[k].status === 'pending') { startIdx = k; break; }
        }
        if (startIdx < 0) { dailyLogToUI('✅ 所有任务已完成'); dailyRunning = false; return; }

        dailyCurrentIndex = startIdx;
        dailyLogToUI('🚀 开始每日发布，共 ' + dailyTaskCount + ' 个任务');
        await doDailyTask(startIdx);
    }

    // 展开多场次任务（公共函数）
    function expandSessions(tasks) {
        var result = [];
        for (var ei = 0; ei < tasks.length; ei++) {
            var t = tasks[ei];
            var sessions = (t.sessionType || '首开').split(/[,，]/).map(function(s){return s.trim()}).filter(Boolean);
            for (var es = 0; es < sessions.length; es++) {
                var nt = {}; for (var ek in t) nt[ek] = t[ek];
                nt.sessionType = sessions[es];
                nt.id = (t.id || 't_') + '_s' + es;
                nt.priority = t.priority || false;
                result.push(nt);
            }
        }
        return result;
    }

    function startDailyPublish() {
        if (dailyRunning) { dailyLogToUI('⚠ 已在运行中'); return; }
        runAllStores();
    }

    // 单店铺发布（由并行调度器调用，不会递归）
    // 统一店铺归属判断：优先 targetStore，兼容旧数据的 store 字段；两者都没有=未分配(商店通用)
    function _taskMatchStore(t, storeName) {
        var ts = t && (t.targetStore || t.store);
        if (!ts) return true;          // 未分配 → 商店通用
        return ts === storeName;
    }

    async function runOneStore(storeName) {
        if (dailyRunning) { dailyLogToUI('⚠ 每日发布已在运行中'); return; }
        setStore(storeName);
        var data = loadDailyTasks();
        // 只拿分配给本店或未分配的任务
        var tasks = (data.tasks || []).filter(function(t) {
            // itemId 已存在的任务永不重发；failed 无 itemId 会重试
            return t.status !== 'done' && !t.itemId && _taskMatchStore(t, storeName);
        });
        if (tasks.length === 0) { dailyLogToUI('  ⏭ ' + storeName + ' 无待发布任务，跳过'); return; }
        dailyTaskCount = tasks.length;
        data.tasks = tasks;
        saveDailyTasks(data);
        var expanded = expandSessions(tasks);
        tasks = expanded;
        tasks.sort(function(a, b) { if (a.priority && !b.priority) return -1; if (!a.priority && b.priority) return 1; return 0; });
        for (var i = 0; i < tasks.length; i++) { tasks[i].status = 'pending'; }
        data.tasks = tasks; saveDailyTasks(data);
        dailyTaskCount = tasks.length;
        var startIdx = -1;
        for (var k = 0; k < tasks.length; k++) { if (tasks[k].status === 'pending') { startIdx = k; break; } }
        if (startIdx < 0) { dailyLogToUI('  ⏭ 无待发布任务'); return; }
        dailyCurrentIndex = startIdx;
        dailyRunning = true;
        dailyLogToUI('🚀 发布 ' + storeName + '，共 ' + dailyTaskCount + ' 个任务');
        await doDailyTask(startIdx);
    }

    async function runAllStores() {
        var stores = getStores();
        if (stores.length === 0) { dailyLogToUI('⚠ 没有店铺'); dailyRunning = false; return; }
        dailyLogToUI('🏪 并行发布模式，共 ' + stores.length + ' 个店铺（同时发布）');
        var data = loadDailyTasks();
        var allTasks = data.tasks || [];
        // 过滤每个店铺的任务
        var storeTasks = {};
        var totalCount = 0;
        for (var si = 0; si < stores.length; si++) {
            var s = stores[si];
            var t = allTasks.filter(function(t) { return t.status !== 'done' && !t.itemId && _taskMatchStore(t, s); });
            storeTasks[s] = t;
            totalCount += t.length;
            dailyLogToUI('📋 ' + s + ': ' + t.length + ' 个任务');
        }
        if (totalCount === 0) { dailyLogToUI('⚠ 没有待发布任务'); dailyRunning = false; return; }
        // 并行启动所有店铺
        var API = 'http://localhost:8093/api/agent/eval-on-store';
        var KEY = '';
        var curStore = getStore();
        var promises = stores.map(function(s) {
            if (s === curStore) {
                // 当前店铺：本地运行
                return runOneStore(s);
            }
            var tasks = storeTasks[s];
            if (tasks.length === 0) return Promise.resolve();
            return fetch(API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-API-Key': KEY },
                body: JSON.stringify({ store: s, code: '(async function(){await window.kunPublish.runOneStore("' + s + '");return "done";})()' })
            }).catch(function(e) { dailyLogToUI('❌ ' + s + ' 远程启动失败: ' + e.message); });
        });
        await Promise.all(promises);
        dailyRunning = false;
        dailyPhase = 'idle';
        dailyLogToUI('🎉 所有店铺发布完成!');
    }

    function stopDailyPublish() {
        dailyRunning = false;
        if (dailyTimer) { clearTimeout(dailyTimer); dailyTimer = null; }
        dailyPhase = 'idle';
        dailyLogToUI('⏹ 已停止发布');
    }

    function getDailyStatus() {
        var data = loadDailyTasks();
        var tasks = data.tasks || [];
        var done = 0, failed = 0, pending = 0;
        for (var i = 0; i < tasks.length; i++) {
            if (tasks[i].status === 'done') done++;
            else if (tasks[i].status === 'failed') failed++;
            else pending++;
        }
        return {
            running: dailyRunning,
            currentIndex: dailyCurrentIndex,
            phase: dailyPhase,
            total: tasks.length,
            done: done,
            failed: failed,
            pending: pending
        };
    }

    
    // ===== 安全错误消息转换 =====
    function errMsg(e) {
        if (!e) return '未知错误';
        if (typeof e === 'string') return e;
        if (e.message && typeof e.message === 'string') return e.message;
        if (e.ret && Array.isArray(e.ret) && e.ret[0]) return String(e.ret[0]);
        if (e.ret && typeof e.ret === 'string') return e.ret;
        try { return JSON.stringify(e); } catch(_) { return String(e); }
    }

    // ===== 提取单任务发布逻辑（批量模式复用） =====
    async function publishOneTask(task, templateId) {
        var data = loadDailyTasks();
        var storeCfg = loadStoreConfig() || {}; // P1-6：提前加载，避免 var 提升使 _subImg 读不到店铺副图开关
        var projId = getProjForStore(currentStore);
        var projCfg2 = getProjectConfig(projId) || DEFAULT_PROJECT_CONFIGS[projId] || {};
        var isFilenameTitle = (projCfg2.titleMode === 'filename');
        
        var title, desc;
        if (currentStore === 'casa家居' || task.directTitle) {
            title = task.star || '';
            desc = task.description || '';
        } else {
        // 发布台传入的 titleMode：fixed=标题写死  placeholder=占位符替换
        var _tm = task.titleModeOverride || 'placeholder';
        if (_tm === 'random' && CONCERT_TEMPLATES.length > 0) {
            var _rid = pickRandomTemplateId();
            title = renderConcertTitle(_rid, task.star, task.city, task.sessionType, task.eventType);
            desc = renderConcertDesc(_rid);
        } else if (_tm === 'fixed') {
            var _t = null; for (var _ti = 0; _ti < CONCERT_TEMPLATES.length; _ti++) { if (CONCERT_TEMPLATES[_ti].id === templateId) { _t = CONCERT_TEMPLATES[_ti]; break; } }
            title = (_t && _t.titlePattern) || renderConcertTitle(templateId, task.star, task.city, task.sessionType, task.eventType);
            desc = renderConcertDesc(templateId);
        } else if (isFilenameTitle) {
            var imgFileName = (task.imageUrl || data.imageUrl || "").replace(/^.*[\\\/]/, "").replace(/\.[^.]+$/, "");
            title = imgFileName || '招抢手';
            var descs = (projCfg2.templates && projCfg2.templates.length > 0) ? projCfg2.templates : ['感兴趣直接私聊咨询'];
            desc = descs[Math.floor(Math.random() * descs.length)];
        } else {
            title = renderConcertTitle(templateId, task.star, task.city, task.sessionType, task.eventType);
            desc = renderConcertDesc(templateId);
        }
        }
        var fullDesc = title + "\n\n" + desc;
        
        // 收集图片
        var imgList = (Array.isArray(task.imageUrls) && task.imageUrls.length > 0) ? task.imageUrls.slice() : [task.imageUrl || data.imageUrl || DEFAULT_IMAGE_URL];
        imgList = imgList.filter(Boolean);
        var allImages = [];
        var storeFolder = getStoreImagesFolder();
        for (var imgIdx = 0; imgIdx < imgList.length; imgIdx++) {
            var imgSrc = imgList[imgIdx];
            if (imgSrc.startsWith("http")) { allImages.push(imgSrc); continue; }
            var fn = imgSrc.replace(/^.*[\\\/]/, "");
            // 先找店铺文件夹，找不到再找根目录
            var lp = storeFolder + fn;
            try {
                var upUrl = await uploadLocalImage(lp);
                if (upUrl && !upUrl.startsWith("data:")) { allImages.push(upUrl); continue; }
            } catch(e) {}
            // 回退到根目录
            lp = IMAGES_FOLDER + fn;
            try {
                var upUrl2 = await uploadLocalImage(lp);
                if (upUrl2 && !upUrl2.startsWith("data:")) { allImages.push(upUrl2); }
            } catch(e) { /* skip */ }
        }
        if (allImages.length === 0) return { ok: false, error: '无可用图片' };
        
        // 副图（店铺配置优先；casa家居跳过副图）
        // 【2026-09-30 修】原来 directTitle 会无条件把副图关掉，于是用 directTitle 指定完整标题的任务
        // 全都没有副图（踩到）。现在允许【任务级 task.subImg 覆盖】：不设这个字段时行为与原来完全一致。
        var _subImg = (typeof task.subImg === 'boolean') ? task.subImg : ((currentStore === 'casa家居' || task.directTitle) ? false : ((storeCfg && typeof storeCfg.subImg === 'boolean') ? storeCfg.subImg : (projCfg2 && projCfg2.subImg !== false)));
        if (_subImg) {
            for (var sub = 1; sub <= 8; sub++) {
                // 统一取值（与每日发布一致）：分组副图(明星/城市/场次) → 发布台副图库 → 店铺目录 → 根目录
                try {
                    var _subUrl = await uploadSubImage(sub, task.star, task.city, task.sessionType, task.subSet);
                    if (_subUrl) allImages.push(_subUrl);
                } catch(e) {}
            }
        }
        
        // 分类/价格/库存
        var tpl = null;
        for (var ti = 0; ti < CONCERT_TEMPLATES.length; ti++) { if (CONCERT_TEMPLATES[ti].id === templateId) { tpl = CONCERT_TEMPLATES[ti]; break; } }
        var defCat = (projId === 'recruit') ? '技能类招工' : (projId === 'yuxiaopu') ? '互联网产品与运营技能培训' : '代购';
        var catName = task.categoryName || storeCfg.category || (tpl && tpl.categoryName) || defCat;
        var priceVal = task.price || storeCfg.price || (tpl && tpl.price) || "50";
        var origPriceVal = task.origPrice || storeCfg.origPrice || (tpl && tpl.origPrice) || "";
        var stockVal = task.stock || storeCfg.stock || (tpl && tpl.stock) || "9999";
        var pubCity = task.city;
        if (isFilenameTitle && !pubCity) {
            var cities = ['广州','深圳','北京','上海','杭州','成都','武汉','南京','苏州','重庆','长沙','青岛'];
            pubCity = cities[Math.floor(Math.random() * cities.length)];
        }
        if (!pubCity) {
            var _ct2 = ['广州','深圳','北京','上海','杭州','成都','武汉','南京','苏州','重庆','西安','天津','长沙','青岛'];
            pubCity = _ct2[Math.floor(Math.random() * _ct2.length)];
        }
        var shipMode = task.shipMode || storeCfg.shipMode || (projCfg2 && projCfg2.shipMode) || 'nomail';
        var _loc = resolveLocation(storeCfg, pubCity);
        pubCity = _loc.city;
        var pubDistrict = _loc.district || '';
        
        // 分类回退
        var catFallback = [catName].concat(Object.keys(CATEGORY_TEMPLATES).filter(function(c){return c!==catName}));
        var r = null, lastErr = '';
        for (var cf = 0; cf < catFallback.length; cf++) {
            try {
                r = await publishOne(title, fullDesc, priceVal, allImages, pubCity, pubDistrict, catFallback[cf], stockVal, shipMode, storeCfg.commitment, origPriceVal, (task && task.specs));
                if (r) break;
            } catch(e) {
                var em = errMsg(e);
                lastErr = em;
                if (em.indexOf('不支持')>=0 || em.indexOf('分类')>=0 || em.indexOf('CATEGORY')>=0) continue;
                throw new Error(em);
            }
        }
        if (!r) throw new Error(lastErr || '发布失败');
        
        // 自动擦亮（task.skipCampaign=true 时跳过，合并推模式用）
        if (r.itemId && data.autoPolish !== false && projCfg2.autoPolish !== false && !task.skipCampaign) {
            try {
                var cat = getCategoryConfig(catName);
                var opts = { bidPrice: task.bidPrice, maxDayBudget: task.maxDayBudget, bidTarget: task.bidTarget, city: task.city, star: task.star };
                var cCount = parseInt(task.campaignCount) || 1;
                if (cCount > 1) {
                    await startCampaignMultiple(r.itemId, cat.categoryId, parseFloat(priceVal), opts, cCount, task.campaignPlans);
                } else {
                    await startCampaign(r.itemId, cat.categoryId, parseFloat(priceVal), opts);
                }
            } catch(e) {}
        }
        return r;
    }

    // ===== 批量发布（本店所有待发布任务） =====
    var batchRunning = false;
    var batchDone = 0;
    var batchFailed = 0;
    var batchTotal = 0;
    var batchCurrentIdx = -1;
    var batchFailedDetails = [];  // [{star, city, sessionType, error}]

    async function runBatchPublish(maxCount) {
        if (!currentStore) { dailyLogToUI('⚠ 请先选择店铺'); return; }
        if (batchRunning) { dailyLogToUI('⚠ 批量已在运行中'); return; }
        
        await syncTasksFromDisk();
        var data = loadDailyTasks();
        var templateId = data.templateId || 1;
        var tasks = (data.tasks || []).filter(function(t) {
            // itemId 已存在的任务永不重发（防陈旧状态回写导致重复上架）；需重发请先清掉 itemId
            // 同时按店铺归属过滤：磁盘文件可能混有其它店的任务，避免跨店误发
            return t.status !== 'done' && t.status !== 'failed' && !t.itemId && _taskMatchStore(t, currentStore);
        });
        if (maxCount && maxCount > 0) tasks = tasks.slice(0, maxCount);
        if (tasks.length === 0) { dailyLogToUI('⚠ 没有待发布任务'); return; }
        
        // 重置为 pending（skipCampaign 按发布台 autoPolish/合并推 决定，不再无条件跳过擦亮）
        var _autoOn = !(data.autoPolish === false);
        for (var i = 0; i < tasks.length; i++) { tasks[i].status = 'pending'; tasks[i].skipCampaign = !_autoOn || data.campaignMode === 'batch'; }
        // 【2026-09-29 修】这里原来是 `data.tasks = tasks;`，已删除。
        // tasks 是 data.tasks 过滤（只留本店、未发过）后【再按 maxCount 截断】的子集。
        // 把它写回等于「每发 1 条就把其余待发任务整批丢掉」——唤醒发布链传 maxCount=1，
        // 于是原定 12 条只发出 1 条、队列被清空（wake-publish.log 之后每轮都是 total=0）。
        // 原设计大概指望每轮 syncTasksFromDisk() 从磁盘补回来，但那条路依赖浏览器扩展的
        // native host 桥，Playwright 浏览器里没有扩展 → 补不回来。
        // 为什么不赋值也不会丢：tasks 里的对象本来就是 data.tasks 的元素（filter 返回同一批引用），
        // 上面那行改 status 已经改到 data.tasks 里了。删掉赋值反而保住了没被本次处理的任务。
        if (!Array.isArray(data.tasks) || data.tasks.length === 0) data.tasks = tasks;
        saveDailyTasks(data);
        
        batchRunning = true;
        batchDone = 0;
        batchFailed = 0;
        batchTotal = tasks.length;
        batchFailedDetails = [];
        var campaignItems = [];
        
        dailyLogToUI('🚀 批量发布开始，共 ' + batchTotal + ' 个任务');
        
        for (var i = 0; i < tasks.length; i++) {
            if (!batchRunning) { dailyLogToUI('⏹ 批量已停止'); break; }
            batchCurrentIdx = i;
            var task = tasks[i];
            dailyLogToUI('📤 [' + (i+1) + '/' + batchTotal + '] ' + (task.star || '?') + ' · ' + (task.city || '?') + ' · ' + (task.sessionType || '?') );
            
            try {
                var result = await publishOneTask(task, templateId);
                var _itm = (result && result.itemId) || '';
                if (!_itm) { task.status = 'failed'; task.error = (result && result.error) ? result.error : '发布未返回 itemId（可能未真正上架）'; batchFailed++; dailyLogToUI('  ❌ ' + (task.star||'?') + ' ' + task.error + ' [失败' + batchFailed + '/' + batchTotal + ']'); saveDailyTasks(data); continue; }
                task.status = 'done';
                task.itemId = _itm;
                batchDone++;
                dailyLogToUI('  ✅ 成功! [' + batchDone + '/' + batchTotal + '] itemId=' + _itm);
            } catch(e) {
                task.status = 'failed';
                task.error = errMsg(e);
                batchFailed++;
                batchFailedDetails.push({
                    star: task.star || '',
                    city: task.city || '',
                    sessionType: task.sessionType || '',
                    error: task.error
                });
                dailyLogToUI('  ❌ ' + task.error + ' [失败' + batchFailed + '/' + batchTotal + ']');
            }
            saveDailyTasks(data);
            // 发布间隔（分钟）读取任务配置 publishInterval；分段等待以支持随时停止
            if (i < tasks.length - 1 && batchRunning) {
                var _ivMin = parseInt(data.batchInterval || data.publishInterval) || 60; // 间隔(分钟)
                var _bs = (maxCount && maxCount > 0) ? tasks.length : (parseInt(data.batchSize) || 0); // 快速发布(maxCount) → 整批快发不间歇
                if (maxCount && maxCount > 0) _ivMin = 0; // 快速发布：不间隔
                if (_bs > 1) { // 分批：每批_bs个，批间等_ivMin，批内快速
                    if ((i + 1) % _bs === 0) {
                        dailyLogToUI('⏳ 已发 ' + _bs + ' 个，等 ' + _ivMin + ' 分钟后发下一批...');
                        var _waitMs = _ivMin * 60 * 1000; var _waited = 0;
                        while (batchRunning && _waited < _waitMs) { var _step = Math.min(5000, _waitMs - _waited); await new Promise(function(r) { setTimeout(r, _step); }); _waited += _step; }
                    } else { await new Promise(function(r) { setTimeout(r, 2000); }); }
                } else { // 原：每个任务间隔发布（保留）
                    dailyLogToUI('⏳ 等待 ' + _ivMin + ' 分钟后发布下一个...');
                    var _waitMs2 = _ivMin * 60 * 1000; var _waited2 = 0;
                    while (batchRunning && _waited2 < _waitMs2) { var _step2 = Math.min(5000, _waitMs2 - _waited2); await new Promise(function(r) { setTimeout(r, _step2); }); _waited2 += _step2; }
                }
            }
        }
        
        batchRunning = false;
        batchCurrentIdx = -1;
        dailyLogToUI('🎉 批量完成！成功 ' + batchDone + ' / 失败 ' + batchFailed + ' / 共 ' + batchTotal);
        if (campaignItems.length > 0) {
            var _t0 = tasks[0] || {};
            var _base = { bidPrice: _t0.bidPrice || data.bidPrice || 13.6, bidTarget: _t0.bidTarget || 'order', city: _t0.city, star: _t0.star, maxDayBudget: _t0.maxDayBudget };
            dailyLogToUI('🚀 合成推广开始：' + campaignItems.length + ' 条（每批≤10条）');
            for (var _ci = 0; _ci < campaignItems.length; _ci += 10) {
                var _chunk = campaignItems.slice(_ci, _ci + 10);
                var _opts = {};
                for (var _k in _base) _opts[_k] = _base[_k];
                if (!_opts.maxDayBudget) _opts.maxDayBudget = 100;
                try { await startCampaignBatch(_chunk, _opts); dailyLogToUI('  ✅ 合成推广成功：' + _chunk.length + ' 条'); }
                catch (e) { dailyLogToUI('  ❌ 合成推广失败：' + errMsg(e)); }
            }
        }
        // 批量完成后持久化失败详情到磁盘
        if (batchFailedDetails.length > 0) {
            try {
                var diskData = loadDailyTasks();
                saveDailyTasks(diskData);  // 同步磁盘（data.tasks 里的失败记录已有 error 字段）
            } catch(e) {}
        }
    }

    function stopBatchPublish() {
        batchRunning = false;
        dailyLogToUI('⏹ 正在停止...');
    }

    function getBatchStatus() {
        return {
            running: batchRunning,
            done: batchDone,
            failed: batchFailed,
            total: batchTotal,
            currentIdx: batchCurrentIdx,
            failedDetails: batchFailedDetails.slice()  // 复制一份避免外部修改
        };
    }

    // ===== 导出 API =====
    window.kunPublish = {
        EngineVer: '4',
        loadData: loadData, saveData: saveData,
        collectPageImages: collectPageImages,
        findAddress: findAddress,
        publishOne: publishOne,
        uploadLocalImage: uploadLocalImage,
        uploadMultipleImages: uploadMultipleImages,
        // 店铺管理
        getStores: getStores, addStore: addStore, removeStore: removeStore,
        get store() { return currentStore; },
        get currentStore() { return currentStore; },
        setStore: setStore, getStore: getStore,
        getStoreProject: getProjForStore,
        setStoreProject: setProjForStore,
        PROJECTS: PROJECTS,
        // 分类模板
        getCategoryConfig: getCategoryConfig,
        getCategoryList: getCategoryList,
        refreshCategories: refreshCategories,
        CATEGORY_TEMPLATES: CATEGORY_TEMPLATES,
        DEFAULT_TEMPLATES: DEFAULT_TEMPLATES,
        // 演唱会代拍每日任务
        CONCERT_TEMPLATES: CONCERT_TEMPLATES,
        RECRUIT_TEMPLATES: RECRUIT_TEMPLATES,
        SESSION_TYPES: SESSION_TYPES,
        renderConcertTitle: renderConcertTitle,
        renderConcertDesc: renderConcertDesc,
        runOneStore: runOneStore,
        loadDailyTasks: loadDailyTasks,
        saveDailyTasks: saveDailyTasks,
        syncTasksFromDisk: syncTasksFromDisk,
        startDailyPublish: startDailyPublish,
        stopDailyPublish: stopDailyPublish,
        getDailyStatus: getDailyStatus,
        get dailyRunning() { return dailyRunning; },
        get dailyPhase() { return dailyPhase; },
        get dailyCurrentIndex() { return dailyCurrentIndex; },
        // 批量发布
        publishOneTask: publishOneTask,
        runBatchPublish: runBatchPublish,
        startCampaignBatch: startCampaignBatch,
        stopBatchPublish: stopBatchPublish,
        getBatchStatus: getBatchStatus,
        get batchRunning() { return batchRunning; },
        // 选取本地图片（返回文件名）
        pickLocalFile: pickLocalFile,
        // 公开上传接口（供发布台调用）
        uploadBase64ToCdn: uploadBase64ToCdn,
        uploadBase64Batch: uploadBase64Batch,
        startCampaignBatch: startCampaignBatch,
        startCampaignMultiple: startCampaignMultiple,
        pickLocalFiles: pickLocalFiles,
        readLocalImageBase64: readLocalImageBase64,
        parseImageFileName: parseImageFileName,
        // 自定义模板
        loadCustomTemplates: loadCustomTemplates,
        saveCustomTemplates: saveCustomTemplates,
        reloadStoreTemplates: reloadStoreTemplates,
        // 店铺配置
        loadStoreConfig: loadStoreConfig,
        saveStoreConfig: saveStoreConfig,
        getDefaultStoreConfig: getDefaultStoreConfig,

    };
    // ===== 发布台外部命令处理 =====
    var pdRunning = false;
    var pdTimer = null;

    window.addEventListener('message', function(event) {
        if (!event.data || !event.data.type) return;

        // 准备发布：从独立操作台触发
        if (event.data.type === 'PD_PREPARE_PUBLISH') {
            console.log('[kun] 收到发布台命令:', event.data);
            executePanelPublish(event.data);
        }

        if (event.data.type === 'PD_STOP_PUBLISH') {
            console.log('[kun] 收到停止命令');
            stopPanelPublish();
        }
    });

    function reportProgress(phase, current, total, logMsg) {
        try {
            window.postMessage({
                type: 'PD_PROGRESS',
                phase: phase,
                current: current,
                total: total,
                log: logMsg
            }, '*');
        } catch(e) {}
    }

    async function executePanelPublish(cmd) {
        if (pdRunning) { reportProgress('error', 0, 0, '已有发布任务在运行'); return; }

        var store = cmd.store || '';
        var tasks = cmd.tasks || [];
        var imageUrls = cmd.imageUrls || [];
        var templateId = cmd.templateId || 1;
        var autoPolish = cmd.autoPolish !== false;
        var publishInterval = parseInt(cmd.publishInterval) || 60;
        var pubMode = cmd.pubMode || 'serial';
        var project = cmd.project || 'concert';

        if (!store) { reportProgress('error', 0, 0, '未指定店铺'); return; }
        if (tasks.length === 0) { reportProgress('error', 0, 0, '没有发布任务'); return; }

        // 切换到目标店铺
        setStore(store);

        pdRunning = true;
        var total = tasks.length;
        var done = 0;
        var failed = 0;

        reportProgress('start', 0, total, '开始发布 ' + total + ' 个任务，店铺: ' + store);

        for (var i = 0; i < tasks.length; i++) {
            if (!pdRunning) {
                reportProgress('stopped', done, total, '已停止，完成 ' + done + '/' + total);
                return;
            }

            var task = tasks[i];
            reportProgress('publishing', done, total, '发布中 ' + (i + 1) + '/' + total + ': ' + (task.star || task.title || '任务'));

            try {
                // 构造 publishOneTask 所需参数
                // task 应有: star, city, eventType, sessionType, categoryName, price, stock
                // imageUrls 用于图片
                var r = await publishOneExternalTask(task, templateId, imageUrls, autoPolish, project);
                done++;
                reportProgress('publishing', done, total, '✅ ' + (i + 1) + '/' + total + ' 成功: itemId=' + (r && r.itemId || '?'));
            } catch(e) {
                failed++;
                var errMsg = (e && e.message) ? e.message : String(e);
                reportProgress('publishing', done, total, '❌ ' + (i + 1) + '/' + total + ' 失败: ' + errMsg);
            }

            // 发布间隔
            if (i < tasks.length - 1 && pdRunning) {
                var intervalMs = publishInterval * 60 * 1000;
                reportProgress('waiting', done, total, '⏳ 等待 ' + publishInterval + ' 分钟后发布下一个...');
                await new Promise(function(resolve) {
                    pdTimer = setTimeout(resolve, intervalMs);
                });
            }
        }

        pdRunning = false;
        reportProgress('complete', done, total, '🎉 发布完成! 成功 ' + done + ', 失败 ' + failed);
    }

    function stopPanelPublish() {
        pdRunning = false;
        if (pdTimer) { clearTimeout(pdTimer); pdTimer = null; }
    }

    // 外部任务发布（复用 publishOneTask 的核心逻辑）
    async function publishOneExternalTask(task, templateId, imageUrls, autoPolish, project) {
        var projId = getProjForStore(currentStore) || project;
        var projCfg2 = getProjectConfig(projId) || DEFAULT_PROJECT_CONFIGS[projId] || {};
        var isFilenameTitle = (projCfg2.titleMode === 'filename');

        var title, desc;
        var _tm2 = task.titleModeOverride || 'placeholder';
        if (_tm2 === 'random' && CONCERT_TEMPLATES.length > 0) {
            var _rid2 = pickRandomTemplateId();
            title = renderConcertTitle(_rid2, task.star, task.city, task.sessionType, task.eventType);
            desc = renderConcertDesc(_rid2);
        } else if (_tm2 === 'fixed') {
            var _t2 = null; for (var _ti2 = 0; _ti2 < CONCERT_TEMPLATES.length; _ti2++) { if (CONCERT_TEMPLATES[_ti2].id === templateId) { _t2 = CONCERT_TEMPLATES[_ti2]; break; } }
            title = (_t2 && _t2.titlePattern) || renderConcertTitle(templateId, task.star, task.city, task.sessionType, task.eventType);
            desc = renderConcertDesc(templateId);
        } else if (isFilenameTitle) {
            var imgFileName = (task.imageUrl || imageUrls[0] || '').replace(/^.*[\\\/]/, '').replace(/\.[^.]+$/, '');
            title = imgFileName || '商品';
            var descs = (projCfg2.templates && projCfg2.templates.length > 0) ? projCfg2.templates : ['感兴趣直接私聊咨询'];
            desc = descs[Math.floor(Math.random() * descs.length)];
        } else {
            title = renderConcertTitle(templateId, task.star, task.city, task.sessionType, task.eventType);
            desc = renderConcertDesc(templateId);
        }
        var fullDesc = title + '\n\n' + desc;

        // 收集图片
        var allImages = (Array.isArray(imageUrls) && imageUrls.length > 0) ? imageUrls.slice() : [];
        if (task.imageUrl && allImages.indexOf(task.imageUrl) < 0) {
            allImages.unshift(task.imageUrl);
        }
        if (allImages.length === 0) throw new Error('无可用图片');

        // 分类/价格/库存
        var storeCfg = loadStoreConfig() || {};
        var defCat = (projId === 'recruit') ? '技能类招工' : (projId === 'yuxiaopu') ? '互联网产品与运营技能培训' : '代购';
        var catName = task.categoryName || storeCfg.category || defCat;
        var priceVal = task.price || storeCfg.price || '50';
        var origPriceVal = task.origPrice || storeCfg.origPrice || '';
        var stockVal = task.stock || storeCfg.stock || '9999';
        var pubCity = task.city;
        if (isFilenameTitle && !pubCity) {
            var cities = ['广州','深圳','北京','上海','杭州','成都','武汉','南京','苏州','重庆','长沙','青岛'];
            pubCity = cities[Math.floor(Math.random() * cities.length)];
        }
        var _loc = resolveLocation(storeCfg, pubCity);
        pubCity = _loc.city;
        var pubDistrict = _loc.district || '';
        var shipMode = task.shipMode || storeCfg.shipMode || (projCfg2 && projCfg2.shipMode) || 'nomail';

        // 分类回退
        var catFallback = [catName].concat(Object.keys(CATEGORY_TEMPLATES).filter(function(c){ return c !== catName; }));
        var r = null, lastErr = '';
        for (var cf = 0; cf < catFallback.length; cf++) {
            try {
                r = await publishOne(title, fullDesc, priceVal, allImages, pubCity, pubDistrict, catFallback[cf], stockVal, shipMode, storeCfg.commitment, origPriceVal, (task && task.specs));
                if (r) break;
            } catch(e) {
                var em = (e && e.message) ? e.message : String(e);
                lastErr = em;
                if (em.indexOf('不支持') >= 0 || em.indexOf('分类') >= 0 || em.indexOf('CATEGORY') >= 0) continue;
                throw new Error(em);
            }
        }
        if (!r) throw new Error(lastErr || '发布失败');

        // 自动擦亮
        if (r.itemId && autoPolish) {
            try {
                var cat = getCategoryConfig(catName);
                await startCampaign(r.itemId, cat.categoryId, parseFloat(priceVal), { bidPrice: task.bidPrice, maxDayBudget: task.maxDayBudget, bidTarget: task.bidTarget, city: task.city, star: task.star });
            } catch(e) {}
        }
        return r;
    }

    console.log('[kun] core v2.1 ready');
})();
