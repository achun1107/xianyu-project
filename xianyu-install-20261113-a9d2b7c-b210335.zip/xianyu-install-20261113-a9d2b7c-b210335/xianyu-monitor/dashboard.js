﻿// 闲鱼操作台 - v2
(function() {
    'use strict';
    let currentData = null, sortColumn = null, sortDesc = false, campCache = null;
    const TREND_KEY = 'kun_trend_db', FIELDS_KEY = 'kun_dashboard_fields';

    function setStatus(msg, isErr) {
        var el = document.getElementById('status');
        if (el) el.textContent = msg;
        var el2 = document.getElementById('statusLeft');
        if (el2) { el2.textContent = msg; el2.style.color = isErr ? '#e74c3c' : '#999'; }
    }

    function fetchFromDayu(dateStr) {
        return new Promise(function(resolve, reject) {
            chrome.runtime.sendMessage({
                type: 'FETCH_XIANYU_DATA',
                date: dateStr || new Date().toISOString().slice(0,10).replace(/-/g,'')
            }, function(resp) {
                if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                else if (resp && resp.error) reject(new Error(resp.error));
                else if (resp && resp.success && resp.data) resolve(resp.data);
                else reject(new Error('unknown'));
            });
        });
    }

    function discoverFields() {
        return new Promise(function(resolve, reject) {
            chrome.runtime.sendMessage({type:'DISCOVER_FIELDS'}, function(resp) {
                if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                else if (resp && resp.error) reject(new Error(resp.error));
                else if (resp && resp.success) resolve(resp.fields);
                else reject(new Error('unknown'));
            });
        });
    }

    function pick(obj, keys) {
        if (!obj) return null;
        for (var i = 0; i < keys.length; i++) {
            if (obj[keys[i]] !== undefined && obj[keys[i]] !== null) return obj[keys[i]];
        }
        return null;
    }

    function fmtMoney(v) { return (v === null || v === undefined) ? '-' : (v/100).toFixed(2); }
    function fmtNum(v) { return (v === null || v === undefined) ? '-' : String(v); }

    function render(data) {
        if (!data) return;
        currentData = data;
        var s = data.summary || {};
        var camps = data.campaigns || [];
        campCache = camps;

        // Summary
        var cost = pick(s, ['cost']) || 0;
        var click = pick(s,['clickPv']) || 0;
        var chat = pick(s,['chatPv']) || 0;
        var inquiry = pick(s,['inquiries']) || 0;
        var order = pick(s,['payPv','orderCount']) || 0;
        var costPerPay = pick(s,['costPerPay']);

        document.getElementById('summaryCards').innerHTML =
            '<div class="card"><div class="value cost">' + fmtMoney(cost) + '</div><div class="label">推广费</div></div>' +
            '<div class="card"><div class="value click">' + fmtNum(click) + '</div><div class="label">点击量</div></div>' +
            '<div class="card"><div class="value chat">' + fmtNum(chat) + '</div><div class="label">询单量</div></div>' +
            '<div class="card"><div class="value inquiry">' + fmtNum(inquiry) + '</div><div class="label">咨询数</div></div>' +
            '<div class="card"><div class="value order">' + fmtNum(order) + '</div><div class="label">下单笔数</div></div>' +
            '<div class="card"><div class="value ratio">' + (costPerPay !== null ? '¥' + fmtMoney(costPerPay) : '-') + '</div><div class="label">下单成本</div></div>';

        // Table
        renderTable(camps);

        // Trend
        drawTrend();
        setStatus('OK ' + data.date);
    }

    function renderTable(camps) {
        if (!camps || camps.length === 0) {
            document.getElementById('tableBody').innerHTML = '<div style="padding:40px;text-align:center;color:#999;">\u6682\u65e0\u5546\u54c1\u6570\u636e</div>';
            return;
        }

        var rows = camps.map(function(c) {
            var d = c.adDataDetailVO || c.adData || {};
            var name = c.title || (c.entityList && c.entityList[0] && c.entityList[0].title) || c.campaignName || c.name || 'ID:' + (c.campaignId || c.id || '?');
            return {
                name: name,
                cost: Number(d.cost || 0),
                click: Number(d.clickPv || 0),
                impression: Number(d.showPv || 0),
                chat: Number(d.chatPv || 0),
                inquiry: Number(d.inquiries || 0),
                order: Number(d.payPv || 0),
                chatCost: Number(d.chatPv) ? Number(d.cost)/Number(d.chatPv)/100 : null,
                inquiryCost: Number(d.inquiries) ? Number(d.cost)/Number(d.inquiries)/100 : null,
                orderCost: Number(d.payPv) ? Number(d.cost)/Number(d.payPv)/100 : null
            };
        });

        if (sortColumn) {
            rows.sort(function(a,b) {
                var va = a[sortColumn], vb = b[sortColumn];
                if (va === null || va === undefined) va = -1;
                if (vb === null || vb === undefined) vb = -1;
                return sortDesc ? vb - va : va - vb;
            });
        }

        function sortArrow(key) {
            if (sortColumn === key) return sortDesc ? '\u25bc' : '\u25b2';
            return '\u21c5';
        }

        var h =
            '<table style="width:100%;border-collapse:collapse;font-size:12px;"><thead><tr>' +
            '<th style="text-align:left;padding:8px;background:#f8f9fa;border-bottom:2px solid #eee;font-weight:600;white-space:nowrap;cursor:pointer;" data-sort="name">商品名 <span class="srt">' + sortArrow('name') + '</span></th>' +
            '<th style="text-align:right;padding:8px;background:#f8f9fa;border-bottom:2px solid #eee;font-weight:600;white-space:nowrap;cursor:pointer;" data-sort="cost">推广费 <span class="srt">' + sortArrow('cost') + '</span></th>' +
            '<th style="text-align:right;padding:8px;background:#f8f9fa;border-bottom:2px solid #eee;font-weight:600;white-space:nowrap;cursor:pointer;" data-sort="click">点击 <span class="srt">' + sortArrow('click') + '</span></th>' +
            '<th style="text-align:right;padding:8px;background:#f8f9fa;border-bottom:2px solid #eee;font-weight:600;white-space:nowrap;cursor:pointer;" data-sort="chat">询单 <span class="srt">' + sortArrow('chat') + '</span></th>' +
            '<th style="text-align:right;padding:8px;background:#f8f9fa;border-bottom:2px solid #eee;font-weight:600;white-space:nowrap;cursor:pointer;" data-sort="inquiry">咨询 <span class="srt">' + sortArrow('inquiry') + '</span></th>' +
            '<th style="text-align:right;padding:8px;background:#f8f9fa;border-bottom:2px solid #eee;font-weight:600;white-space:nowrap;cursor:pointer;" data-sort="order">下单 <span class="srt">' + sortArrow('order') + '</span></th>' +
            '<th style="text-align:right;padding:8px;background:#f8f9fa;border-bottom:2px solid #eee;font-weight:600;white-space:nowrap;cursor:pointer;" data-sort="orderCost">成本 <span class="srt">' + sortArrow('orderCost') + '</span></th>' +
            '</tr></thead><tbody>';

        rows.forEach(function(r) {
            h += '<tr style="border-bottom:1px solid #f0f0f0;">' +
                '<td style="padding:8px;font-weight:500;text-align:left;">' + r.name + '</td>' +
                '<td style="padding:8px;text-align:right;">' + fmtMoney(r.cost) + '</td>' +
                '<td style="padding:8px;text-align:right;">' + fmtNum(r.click) + '</td>' +
                '<td style="padding:8px;text-align:right;">' + fmtNum(r.impression) + '</td>' +
                '<td style="padding:8px;text-align:right;">' + fmtNum(r.chat) + '</td>' +
                '<td style="padding:8px;text-align:right;">' + fmtNum(r.inquiry) + '</td>' +
                '<td style="padding:8px;text-align:right;">' + fmtNum(r.order) + '</td>' +
                '<td style="padding:8px;text-align:right;">' + (r.orderCost !== null ? '¥' + r.orderCost.toFixed(2) : '-') + '</td>' +
                '</tr>';
        });
        h += '</tbody></table>';
        document.getElementById('tableBody').innerHTML = h;
    }

    function drawTrend() {
        try {
            var db = JSON.parse(localStorage.getItem(TREND_KEY));
            if (!db || Object.keys(db).length < 2) {
                document.getElementById('trendPlaceholder').style.display = 'block';
                document.getElementById('trendChart').style.display = 'none';
                return;
            }
            document.getElementById('trendPlaceholder').style.display = 'none';
            document.getElementById('trendChart').style.display = 'block';
            var dates = Object.keys(db).sort().slice(-7);
            var canvas = document.getElementById('trendCanvas');
            var ctx = canvas.getContext('2d');
            var rect = canvas.parentElement.getBoundingClientRect();
            canvas.width = rect.width * 2;
            canvas.height = 280 * 2;
            ctx.scale(2,2);
            var w = rect.width, h = 280, pad = {top:20,bottom:30,left:50,right:20};
            var cw = w-pad.left-pad.right, ch = h-pad.top-pad.bottom;
            ctx.clearRect(0,0,w,h);
            var data = dates.map(function(d) {
                var camps = db[d] || [];
                var total = 0;
                camps.forEach(function(c) { total += c.cost || 0; });
                return { date: d.slice(4,6)+'/'+d.slice(6,8), cost: total/100 };
            });
            if (data.length < 2) { document.getElementById('trendPlaceholder').style.display='block'; document.getElementById('trendChart').style.display='none'; return; }
            var maxVal = Math.ceil(Math.max.apply(null, data.map(function(d){return d.cost})) * 1.2) || 1;
            ctx.strokeStyle = '#eee';
            ctx.lineWidth = 1;
            for (var i = 0; i <= 4; i++) {
                var y = pad.top + ch * (1 - i/4);
                ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(w-pad.right, y); ctx.stroke();
                ctx.fillStyle = '#999'; ctx.font = '11px sans-serif'; ctx.textAlign = 'right';
                ctx.fillText('¥' + (maxVal*i/4).toFixed(0), pad.left-5, y+4);
            }
            var stepX = cw / (data.length-1);
            ctx.strokeStyle = '#4A90D9'; ctx.lineWidth = 2; ctx.beginPath();
            data.forEach(function(d,i) {
                var x = pad.left + i * stepX;
                var y = pad.top + ch * (1 - d.cost/maxVal);
                if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
            }); ctx.stroke();
            data.forEach(function(d,i) {
                var x = pad.left + i * stepX;
                var y = pad.top + ch * (1 - d.cost/maxVal);
                ctx.fillStyle = '#4A90D9'; ctx.beginPath(); ctx.arc(x,y,4,0,Math.PI*2); ctx.fill();
                ctx.fillStyle = '#333'; ctx.font = '11px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('¥' + d.cost.toFixed(0), x, y-10);
                ctx.fillStyle = '#999'; ctx.fillText(d.date, x, pad.top+ch+16);
            });
        } catch(e) { console.warn('trend',e); }
    }

    function exportCSV() {
        if (!currentData || !currentData.campaigns) return;
        var csv = 'name,cost,click,impression,chat,inquiry,order\n';
        currentData.campaigns.forEach(function(c){
            var d = c.adDataDetailVO||c.adData||{};
            var n = (c.title||c.campaignName||c.name||'?').replace(/,/g,';');
            csv += n + ',' + (d.cost||0) + ',' + (d.clickPv||0) + ',' + (d.showPv||0) + ',' + (d.chatPv||0) + ',' + (d.inquiries||0) + ',' + (d.payPv||0) + '\n';
        });
        var blob = new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8;'});
        var a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='data.csv'; a.click(); URL.revokeObjectURL(a.href);
    }

    function showFieldInspector() {
        var modal = document.getElementById('fieldModal');
        modal.classList.add('show');
        document.getElementById('fieldContent').innerHTML = '<div style="color:#999;padding:20px;">requesting...</div>';
        discoverFields().then(function(fields) {
            document.getElementById('fieldContent').innerHTML =
                '<h4>summary fields</h4><pre style="background:#1e1e1e;color:#d4d4d4;padding:12px;border-radius:6px;font-size:11px;overflow:auto;">' + JSON.stringify(fields.summary,null,2) + '</pre>' +
                '<h4>campaign fields</h4><pre style="background:#1e1e1e;color:#d4d4d4;padding:12px;border-radius:6px;font-size:11px;overflow:auto;">' + JSON.stringify(fields.campaign,null,2) + '</pre>';
        }).catch(function(err) {
            document.getElementById('fieldContent').innerHTML = '<div style="color:#e74c3c;">'+err.message+'</div>';
        });
    }



    function loadAlertConfig() {
        try { return JSON.parse(localStorage.getItem(ALERT_KEY)) || {
            fee: 0, chatCost: 0, orderCost: 0, feeIncrease: 0,
            webhook: '', pushDaily: true
        };} catch(e) { return {fee:0,chatCost:0,orderCost:0,feeIncrease:0,webhook:'',pushDaily:true}; }
    }

    function openAlertConfig() {
        var cfg = loadAlertConfig();
        document.getElementById('alertFee').value = cfg.fee || '';
        document.getElementById('alertChatCost').value = cfg.chatCost || '';
        document.getElementById('alertOrderCost').value = cfg.orderCost || '';
        document.getElementById('alertFeeIncrease').value = cfg.feeIncrease || '';
        document.getElementById('alertWebhook').value = cfg.webhook || '';
        document.getElementById('alertPushDaily').checked = cfg.pushDaily !== false;
        document.getElementById('alertModal').classList.add('show');
    }

    function saveAlertConfig() {
        var cfg = {
            fee: parseFloat(document.getElementById('alertFee').value) || 0,
            chatCost: parseFloat(document.getElementById('alertChatCost').value) || 0,
            orderCost: parseFloat(document.getElementById('alertOrderCost').value) || 0,
            feeIncrease: parseFloat(document.getElementById('alertFeeIncrease').value) || 0,
            webhook: document.getElementById('alertWebhook').value.trim() || '',
            pushDaily: document.getElementById('alertPushDaily').checked
        };
        localStorage.setItem(ALERT_KEY, JSON.stringify(cfg));
        try { chrome.storage.local.set({ kun_alert_config: cfg }); } catch(e) {}
        document.getElementById('alertModal').classList.remove('show');
        setStatus('alert config saved');
    }

    function checkAlerts(data) {
        var cfg = loadAlertConfig();
        if (!cfg.fee && !cfg.chatCost && !cfg.orderCost && !cfg.feeIncrease) return;
        var s = data.summary || {};
        var cost = Number(s.cost || 0) / 100;
        var msgs = [];
        if (cfg.fee && cost > cfg.fee) msgs.push('推广费 ¥' + cost.toFixed(2) + ' 超过阈值 ¥' + cfg.fee);
        if (cfg.chatCost) {
            var inquiry = Number(s.inquiries || 0);
            var ic = inquiry ? cost / inquiry : 0;
            if (ic > cfg.chatCost) msgs.push('单次咨询成本 ¥' + ic.toFixed(2) + ' 超过阈值 ¥' + cfg.chatCost);
        }
        if (cfg.orderCost) {
            var order = Number(s.payPv || 0);
            var oc = order ? cost / order : 0;
            if (oc > cfg.orderCost) msgs.push('单次下单成本 ¥' + oc.toFixed(2) + ' 超过阈值 ¥' + cfg.orderCost);
        }
        if (msgs.length > 0) {
            chrome.runtime.sendMessage({ type: 'SHOW_ALERT', messages: msgs });
        }
    }

    function sendAlertHistory() {
        chrome.runtime.sendMessage({ type: 'SEND_WEBHOOK' });
    }

    function init() {
        var today = new Date();
        document.getElementById('datePicker').value = today.toISOString().slice(0,10);

        document.getElementById('refreshBtn').onclick = function() {
            var btn = this; btn.disabled = true; btn.textContent = 'fetching...';
            setStatus('loading...');
            var dateStr = document.getElementById('datePicker').value.replace(/-/g,'');
            fetchFromDayu(dateStr).then(function(data){
                render(data);
                checkAlerts(data);
                btn.disabled = false; btn.textContent = 'refresh';
            }).catch(function(err){
                setStatus('error: '+err.message, true); btn.disabled = false; btn.textContent = 'refresh';
            });
        };

        // Sort via delegation (safe from CSP)
        document.getElementById('tableBody').addEventListener('click', function(e) {
            var t = e.target;
            while (t && t.tagName !== 'TH') t = t.parentNode;
            if (t && t.hasAttribute('data-sort') && campCache) {
                var key = t.getAttribute('data-sort');
                if (sortColumn === key) sortDesc = !sortDesc;
                else { sortColumn = key; sortDesc = true; }
                renderTable(campCache);
            }
        });

        document.getElementById('discoverBtn').onclick = showFieldInspector;
        document.getElementById('exportBtn').onclick = exportCSV;
        document.getElementById('alertConfigBtn').onclick = openAlertConfig;
        document.getElementById('alertCloseBtn').onclick = function() { document.getElementById('alertModal').classList.remove('show'); };
        document.getElementById('alertSaveBtn').onclick = saveAlertConfig;
        document.getElementById('fieldCloseBtn').onclick = function() {
            document.getElementById('fieldModal').classList.remove('show');
        };
        // Auto load
        setTimeout(function() { document.getElementById('refreshBtn').click(); }, 500);
        setTimeout(function() { sendAlertHistory(); }, 2000);

        // Tab switching
        var tabM = document.getElementById('tabMonitor');
        var tabC = document.getElementById('tabConfig');
        var panM = document.getElementById('panelMonitor');
        var panC = document.getElementById('panelConfig');
        if (tabM && tabC) {
            tabM.onclick = function(){ panM.style.display=''; panC.style.display='none'; tabM.style.background='#357ABD'; tabC.style.background='rgba(255,255,255,0.2)'; };
            tabC.onclick = function(){ panC.style.display=''; panM.style.display='none'; tabC.style.background='#357ABD'; tabM.style.background='rgba(255,255,255,0.2)'; renderConfig(); };
            if (location.hash === '#config') { if(panC){panC.style.display='';panM.style.display='none';tabC.style.background='#357ABD';tabM.style.background='rgba(255,255,255,0.2)';renderConfig();} }
        }
        // 发布台按钮
        var btnPD = document.getElementById('btnPublishDash');
        if (btnPD) { btnPD.onclick = function() { chrome.runtime.sendMessage({ type: 'OPEN_PUBLISH_DASHBOARD' }); }; }

        // Config buttons
        var saveBtn = document.getElementById('configSaveBtn');
        var addBtn = document.getElementById('configAddBtn');
        if (saveBtn) saveBtn.onclick = saveConfig;
        if (addBtn) addBtn.onclick = addProject;
    }

    // ===== 项目配置 =====
    function loadConfigs() {
        try { return JSON.parse(localStorage.getItem('kun_project_configs')) || {}; }
        catch(e) { return {}; }
    }
    function saveConfigs(cfgs) {
        localStorage.setItem('kun_project_configs', JSON.stringify(cfgs));
        // 同步到磁盘（通过 Express API → native_host）
        try {
            fetch('/api/agent/native-host', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-API-Key': '' },
                body: JSON.stringify({ action: 'writeProjectConfigs', data: { configs: cfgs, storeProjects: JSON.parse(localStorage.getItem('kun_store_projects') || '{}') } })
            }).catch(function(){});
        } catch(e) {}
    }

    function renderConfig() {
        var form = document.getElementById('configForm');
        if (!form) return;
        var cfgs = loadConfigs();
        if (!cfgs.concert) cfgs.concert = { name:'演唱会代拍', category:'代购', titleMode:'placeholder', defaultPrice:'50', defaultStock:'9999', autoPolish:'false', shipMode:'nomail', subImg:'true', descriptions:[] };
        if (!cfgs.recruit)  cfgs.recruit  = { name:'招抢手', category:'创业/副业培训', titleMode:'filename', defaultPrice:'10', defaultStock:'999', autoPolish:'false', shipMode:'nomail', subImg:'false', descriptions:[] };
        saveConfigs(cfgs);
        var keys = Object.keys(cfgs);
        var html = '';
        for (var i = 0; i < keys.length; i++) {
            var k = keys[i], p = cfgs[k];
            html += '<div style="border:1px solid #eee;border-radius:8px;padding:14px;margin-bottom:10px">';
            html += '<b style="font-size:14px;">' + (p.name||k) + '</b><span style="color:#999;font-size:10px;"> (' + k + ')</span>';
            html += '<button onclick="delCfg(this,\'' + k + '\')" style="float:right;background:#e74c3c;color:#fff;border:none;border-radius:4px;padding:4px 10px;cursor:pointer;font-size:11px;">✕</button>';
            html += '<div style="margin-top:8px;display:grid;grid-template-columns:80px 1fr;gap:6px 10px;font-size:12px;">';
            html += '<span>名称</span><input data-k="' + k + '" data-f="name" value="' + (p.name||'') + '" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;">';
            html += '<span>分类</span><input data-k="' + k + '" data-f="category" value="' + (p.category||'') + '" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;">';
            html += '<span>标题模式</span><select data-k="' + k + '" data-f="titleMode" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;"><option value="placeholder"' + (p.titleMode!=='filename'?' selected':'') + '>占位符模板</option><option value="filename"' + (p.titleMode==='filename'?' selected':'') + '>图片文件名</option></select>';
            html += '<span>价格(元)</span><input data-k="' + k + '" data-f="defaultPrice" value="' + (p.defaultPrice||'') + '" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;">';
            html += '<span>库存</span><input data-k="' + k + '" data-f="defaultStock" value="' + (p.defaultStock||'') + '" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;">';
            html += '<span>发货</span><select data-k="' + k + '" data-f="shipMode" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;"><option value="nomail"' + ((p.shipMode||'nomail')!=='free'?' selected':'') + '>无需邮寄</option><option value="free"' + (p.shipMode==='free'?' selected':'') + '>包邮</option></select>';
            html += '<span>擦亮</span><select data-k="' + k + '" data-f="autoPolish" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;"><option value="true"' + (p.autoPolish!=='false'?' selected':'') + '>是</option><option value="false"' + (p.autoPolish==='false'?' selected':'') + '>否</option></select>';
            html += '<span>副图</span><select data-k="' + k + '" data-f="subImg" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;"><option value="true"' + (p.subImg!=='false'?' selected':'') + '>是</option><option value="false"' + (p.subImg==='false'?' selected':'') + '>否</option></select>';
            html += '</div>';
            html += '<div style="margin-top:8px"><span style="font-size:11px;color:#666;">📝 ' + (p.titleMode==='filename'?'描述列表':'标题模板(每行一个, |分隔描述)') + '</span>';
            html += '<textarea data-k="' + k + '" data-f="templates" style="width:100%;height:80px;margin-top:4px;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:11px;font-family:monospace;">' + (p.templates||[]).join('\n') + '</textarea></div>';
            html += '</div>';
        }
        form.innerHTML = html || '<div style="color:#999">暂无项目</div>';
        window.delCfg = function(btn, id) {
            if (!confirm('删除「' + (cfgs[id]?cfgs[id].name:id) + '」？')) return;
            btn.parentElement.remove();
            delete cfgs[id];
            saveConfigs(cfgs);
        };
    }

    function saveConfig() {
        var cfgs = loadConfigs();
        var inputs = document.querySelectorAll('#configForm [data-k]');
        for (var i = 0; i < inputs.length; i++) {
            var el = inputs[i], k = el.getAttribute('data-k'), f = el.getAttribute('data-f');
            if (!cfgs[k]) cfgs[k] = {};
            if (f === 'templates') {
                cfgs[k].templates = el.value.split('\n').filter(function(s){return s.trim()});
            } else {
                cfgs[k][f] = el.value;
            }
            if (!cfgs[k].descriptions) cfgs[k].descriptions = [];
        }
        saveConfigs(cfgs);
        var msg = document.getElementById('configMsg');
        if (msg) { msg.textContent = '✅ 已保存'; setTimeout(function(){msg.textContent=''},2000); }
    }

    function addProject() {
        var id = prompt('项目ID（英文）：'); if (!id) return;
        var name = prompt('名称：'); if (!name) return;
        var cfgs = loadConfigs();
        cfgs[id] = { name:name, category:'代购', titleMode:'placeholder', defaultPrice:'50', defaultStock:'9999', autoPolish:'false', shipMode:'nomail', subImg:'false', descriptions:[] };
        saveConfigs(cfgs);
        renderConfig();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
