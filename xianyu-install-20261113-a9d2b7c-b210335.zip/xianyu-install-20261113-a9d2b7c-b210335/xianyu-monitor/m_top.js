// MTOP 桥接 - 仅此文件运行在 MAIN 世界，暴露 MTOP 给隔离世界的 monitor.js
(function() {
  'use strict';
  if (window.__kun_mtopReady) return;
  window.__kun_mtopReady = true;

  window.addEventListener('message', function(e) {
    if (!e.data || e.data.type !== 'KUN_MTOP') return;
    var id = e.data.id;
    var api = e.data.api;
    var data = e.data.data;
    if (!window.lib || !window.lib.mtop || !window.lib.mtop.request) {
      window.postMessage({ type: 'KUN_MTOP_RESULT', id: id, error: 'mtop not ready' }, '*');
      return;
    }
    window.lib.mtop.request({ api: api, v: '1.0', data: { requestJson: JSON.stringify(data) }, type: (e.data.method === 'POST' ? 'POST' : 'GET') })
      .then(function(resp) {
        if (resp && resp.ret && resp.ret[0] && resp.ret[0].startsWith('SUCCESS')) {
          window.postMessage({ type: 'KUN_MTOP_RESULT', id: id, data: resp.data }, '*');
        } else {
          window.postMessage({ type: 'KUN_MTOP_RESULT', id: id, error: resp && resp.ret ? resp.ret[0] : 'fail' }, '*');
        }
      })
      .catch(function(err) {
        window.postMessage({ type: 'KUN_MTOP_RESULT', id: id, error: err && err.ret ? err.ret[0] : (err && err.message || 'fail') }, '*');
      });
  });

  console.log('🔗 MTOP 桥接已就绪 (MAIN)');
})();
