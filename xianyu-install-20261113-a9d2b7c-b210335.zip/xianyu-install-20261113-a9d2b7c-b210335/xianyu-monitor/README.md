# xianyu-monitor

闲鱼监控与自动发布工具。

## 🚀 新电脑快速上手

### 前置要求

确保已安装以下基础软件：

| 软件 | 下载地址 |
|------|---------|
| Node.js (v18+) | https://nodejs.org |
| Git | https://git-scm.com |

### 安装步骤

**1. 拉取项目**

桌面空白处右键 → **Git Bash Here** → 输入：

```bash
git clone https://gitlab.com/hym-company/xianyu-monitor.git
```

**2. 一键安装**

进入 `xianyu-monitor` 文件夹，双击 **`一键安装.bat`**，它会自动：

- ✅ 拉取 Playwright 服务 (`xianyu-playwright-service`)
- ✅ 安装 npm 依赖
- ✅ 安装出图工具 `museav-cli`（全局）

**3. 手动配置**

- **加载浏览器扩展**：Chrome 打开 `chrome://extensions` → 开启「开发者模式」→「加载已解压的扩展程序」→ 选择 `xianyu-monitor` 文件夹
- **启动服务**：双击 `xianyu-playwright-service\start.bat`

### 控制台脚本

控制台工具在 `console-tools/` 目录下，包含发布、生命周期管理、批量发布等脚本。

---

## ⚠️ 扩展目录命名红线（踩过坑）

Chrome 加载已解压扩展时，**会拒绝任何以 `_` 开头的文件或目录**，报错：

```
Cannot load extension with file or directory name __pycache__.
Filenames starting with "_" are reserved for use by the system.
```

本项目根目录既是 Chrome 扩展根目录，又放着 Python 工具脚本，因此：

1. **禁止 `_` 开头的文件/目录出现在项目根**（含子目录）。曾经的坑：`clean_dupes.py` 导入 `check_assets` 时生成 `__pycache__`，扩展直接加载失败。
2. 已修复：`clean_dupes.py` 顶部设 `sys.dont_write_bytecode = True`；归档目录由 `_dupes_archived` 改为 `.dupes_archived`。
3. 手动跑 Python 脚本建议加 `-B`：`python -B check_assets.py ...`
4. 万一又出现该报错，只删这一个目录即可（**不要用 `git clean -fdX`**，会连本地账本 `ad_ledger.sqlite` 一起清掉）：
   ```powershell
   Remove-Item .\__pycache__ -Recurse -Force
   # 查还有没有别的 "_" 开头项
   Get-ChildItem -Force | Where-Object { $_.Name -like '_*' }
   ```

---

## 项目结构

```
xianyu-monitor/
├── background.js          # 扩展后台脚本
├── monitor.js             # 监控核心
├── publish.js             # 发布逻辑
├── api.js                 # API 封装
├── bridge.js              # 桥接通信
├── dashboard.html/js      # 控制面板
├── native_host.py/bat     # 本地服务桥接
├── manifest.json          # Chrome 扩展 Manifest
├── console-tools/         # 控制台工具集
├── 一键安装.bat           # 自动安装脚本
└── 批量发布模板.xlsx      # 发布模板
```
