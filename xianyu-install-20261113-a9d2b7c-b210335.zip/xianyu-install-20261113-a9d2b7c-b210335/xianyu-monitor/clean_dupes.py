#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""重复素材归档 —— 把「像素完全相同」的多余图片**移到归档目录**（不删除，可回滚）。

为什么是移动而不是删除：
  这些图是你花了 museav 积分生成的资产，且可能已被任务表引用。删掉不可逆；
  移到 _dupes_archived/ 之后随时能拿回来，同时发布链路扫不到它们。

保留规则：每组保留**文件名时间戳最新**的那张（时间戳在名尾，13 位毫秒）；
         没有时间戳的按文件修改时间；再相同则按文件名排序取第一个。
         —— 保留哪张不影响正确性（像素完全相同），选最新是为了和任务表里
            最近一次生成的那条对得上。

默认**演练**，只打印计划；加 --apply 才真正移动。

用法:
    python clean_dupes.py "C:/Users/43462/Desktop/闲鱼上架图片/好易美代拍"
    python clean_dupes.py "C:/Users/43462/Desktop/闲鱼上架图片/好易美代拍" --apply
"""
import argparse
import os
import re
import shutil
import sys

# 禁止生成 __pycache__：本目录是 Chrome 扩展根目录，
# 下划线开头的目录会让 Chrome 拒绝加载扩展（"Filenames starting with _ are reserved"）
sys.dont_write_bytecode = True

from datetime import datetime

import check_assets as ca

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

TS = re.compile(r"-(\d{13})$")


def keep_key(name, path):
    """排序键：优先文件名里的 13 位毫秒时间戳，其次 mtime。值越大越新。"""
    m = TS.search(os.path.splitext(name)[0])
    if m:
        return (1, int(m.group(1)))
    return (0, os.path.getmtime(path))


def main():
    ap = argparse.ArgumentParser(description="重复素材归档（默认演练）")
    ap.add_argument("dir")
    ap.add_argument("--apply", action="store_true", help="真正移动（不加则只演练）")
    ap.add_argument("--spec", help="规格 JSON（默认用内置阈值）")
    ap.add_argument("--tasks", help="任务表 JSON；**被任务引用的图片一律不归档**（防打断已上架任务的图片引用）")
    args = ap.parse_args()

    spec = dict(ca.DEFAULT_SPEC)
    if args.spec and os.path.exists(args.spec):
        import json
        with open(args.spec, encoding="utf-8") as f:
            spec.update(json.load(f))

    # 任务引用保护：被任何任务引用的图片名，即使像素重复也不归档
    protected = set()
    if args.tasks and os.path.exists(args.tasks):
        import json
        with open(args.tasks, encoding="utf-8") as f:
            tk = json.load(f)
        for t in (tk.get("tasks", []) if isinstance(tk, dict) else tk):
            if t.get("imageName"):
                protected.add(t["imageName"])

    d = os.path.abspath(args.dir)
    if not os.path.isdir(d):
        print(f"目录不存在：{d}", file=sys.stderr)
        return 2

    files = sorted(f for f in os.listdir(d) if os.path.isfile(os.path.join(d, f)) and not f.startswith("."))
    by_kind, by_pix = {}, {}
    for name in files:
        p = os.path.join(d, name)
        try:
            im = ca.Image.open(p)
            im.load()
            pix = ca.hashlib.md5(im.convert("RGB").resize((64, 64), ca.Image.LANCZOS).tobytes()).hexdigest()
        except Exception as e:
            print(f"  ⚠️ 跳过（无法解码）{name}: {e}")
            continue
        kind = ca.classify(name)
        by_kind.setdefault(kind, set()).add(pix)
        by_pix.setdefault((kind, pix), []).append(name)

    groups = {k: sorted(v) for k, v in by_pix.items() if len(v) > 1}
    if not groups:
        print("✅ 没有像素完全相同的重复图")
        return 0

    # 归档目录名必须以 "." 开头：若素材目录就在扩展根目录下，
    # "_dupes_archived" 这种下划线开头的目录会直接让 Chrome 加载扩展失败
    arch = os.path.join(os.path.dirname(d), ".dupes_archived", datetime.now().strftime("%Y%m%d_%H%M%S"))
    tag = {"main": "主图", "sub": "副图", "other": "其它"}
    total_moved = 0
    print(f"{'【演练】' if not args.apply else '【执行】'}共 {len(groups)} 组重复，目录：{d}")
    if args.apply:
        print(f"归档到：{arch}\n")

    for (kind, pix), members in sorted(groups.items(), key=lambda kv: -len(kv[1])):
        members = sorted(members, key=lambda n: keep_key(n, os.path.join(d, n)), reverse=True)
        keep, drop = members[0], members[1:]
        # 被任务引用的不归档（哪怕像素重复）—— 否则该任务重发时会找不到图
        skipped = [n for n in drop if n in protected]
        drop = [n for n in drop if n not in protected]
        if not drop:
            print(f"\n[{tag[kind]}] {len(members)} 张像素相同 → 全部被任务引用，跳过不动")
            for n in skipped:
                print(f"   🔒 保护：{n}")
            continue
        print(f"\n[{tag[kind]}] {len(members)} 张像素相同 → 保留 1 张，归档 {len(drop)} 张")
        print(f"   ✅ 保留：{keep}")
        for n in skipped:
            print(f"   🔒 保护（任务引用中，不动）：{n}")
        for n in drop:
            dst = os.path.join(arch, n)
            if args.apply:
                os.makedirs(arch, exist_ok=True)
                if os.path.exists(dst):
                    dst = dst + ".dup" + str(total_moved)
                shutil.move(os.path.join(d, n), dst)
            print(f"   📦 归档：{n}")
            total_moved += 1

    print(f"\n{'【演练完成】' if not args.apply else '【已执行】'} "
          f"{len(groups)} 组 / 归档 {total_moved} 张 / 保留 {len(groups)} 张")
    if not args.apply:
        print("→ 确认无误后加 --apply 真正执行（移动，不删除，可回滚）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
