// ============================================================
// 一句话：在 personal 页把「全部商品」扒出来（含完整分页）
//
// 为什么需要你手动做一次：
//   这个页面是 SPA，商品列表在我注入钩子之前就已经加载完了，
//   所以我抓不到它用的接口；而这页有 98 个宝贝、首屏只渲染 20 个。
//   你手动点一次「宝贝管理 → 在售」，就能把全部在售商品渲染出来。
//
// 用法：
//   1. 打开 https://www.goofish.com/personal （已登录卖家号）
//   2. F12 → Console → 粘贴本文件 → 回车
//   3. 点进「宝贝管理」→「在售」，并在列表里滚到底 / 翻到最后一页
//   4. 回到 Console 运行：  KUNITEMS.report()
//   5. 结果会自动复制到剪贴板，整段发我
//
// 只读：不点击任何"删除/下架/擦亮"，不发写请求。
// ============================================================
(function () {
  if (window.__kuitems) { console.log('[KUNITEMS] 已在收集。KUNITEMS.report()'); return; }

  var S = { since: new Date().toLocaleString(), page: location.href };

  S.collect = function () {
    var map = {}, order = [];
    var a = document.querySelectorAll('a[href*="item?id="]');
    for (var i = 0; i < a.length; i++) {
      var h = a[i].getAttribute('href') || '';
      var m = h.match(/[?&]id=(\d+)/);
      if (!m) continue;
      if (!map[m[1]]) { map[m[1]] = { id: m[1], texts: [] }; order.push(m[1]); }
      // 就近取标题/价格
      var card = a[i];
      for (var j = 0; j < 5 && card; j++) card = card.parentElement;
      var tx = card ? (card.textContent || '').replace(/\s+/g, ' ').trim() : '';
      if (tx && map[m[1]].texts.length < 2) map[m[1]].texts.push(tx.slice(0, 80));
    }
    return { order: order, map: map };
  };

  S.totals = function () {
    var body = document.body ? document.body.innerText : '';
    var re = /(宝贝\s*\d+|在售\s*\d+|已售出\s*\d+|共\s*\d+\s*件)/g, mm, out = [];
    while ((mm = re.exec(body)) !== null && out.length < 12) out.push(mm[0]);
    return out;
  };

  window.__kuitems = S;
  window.KUNITEMS = {
    report: function () {
      var c = S.collect();
      var res = {
        抓取时间: new Date().toLocaleString(),
        起始页: S.page,
        当前页: location.href,
        商品总数: c.order.length,
        页面数字文案: S.totals(),
        商品: c.order.map(function (id) {
          return { id: id, text: (c.map[id].texts[0] || '').slice(0, 70) };
        })
      };
      var s = JSON.stringify(res, null, 2);
      console.log(s);
      try { copy(s); console.log('%c已复制到剪贴板', 'color:#2c7;font-weight:bold'); } catch (e) {}
      return res;
    },
    count: function () { return S.collect().order.length; },
    totals: function () { return S.totals(); },
    // 只把 id 列表复制出来（便于我批量分析）
    ids: function () {
      var c = S.collect();
      var s = c.order.join('\n');
      console.log(c.order.length + ' 个商品 ID');
      try { copy(s); } catch (e) {}
      return c.order;
    }
  };
  console.log('%c[KUNITEMS] 就绪。点进「宝贝管理→在售」滚到底，然后运行 KUNITEMS.report()', 'color:#2c7;font-weight:bold');
})()
