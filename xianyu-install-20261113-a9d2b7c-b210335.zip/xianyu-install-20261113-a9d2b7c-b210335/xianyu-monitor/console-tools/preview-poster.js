#!/usr/bin/env node
/**
 * preview-poster.js — 只出图不发布：调 8093 出海报，存到本地并打印结果
 *
 * 用途：下指令前先看底图对不对（尤其大麦是否有该演出、是否被 AI 兜底）
 *
 * 用法:
 *   node preview-poster.js 广州 孙燕姿
 *   node preview-poster.js 常州 gapday damai_official
 *   node preview-poster.js 广州 孙燕姿 damai_official <templateId>
 *
 * 参数: <城市> <明星> [source] [templateId] [输出文件路径]
 *   source 默认 damai_official（大麦官方底图）；可选 search / ai / aigen / damai
 * 输出: 默认存到 %TEMP%\poster-<明星>-<时间戳>.png
 *
 * 注意: source=damai_official 时，明星名必须能在**大麦**搜到（艺人口径≠大麦项目名会静默降级成 AI 图）
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

let [, , city, star, source = 'damai_official', templateId = '', outArg = ''] = process.argv;

// PowerShell 会丢弃空字符串参数，导致后面的参数前移；用 "-" 占位表示"本项留空"
if (templateId === '-') templateId = '';
if (outArg === '-') outArg = '';

if (!city || !star) {
  console.log('用法: node preview-poster.js <城市> <明星> [source] [templateId| -] [输出路径|-]');
  console.log('例:   node preview-poster.js 广州 孙燕姿');
  console.log('      node preview-poster.js 广州 孙燕姿 damai_official - D:\\out.png');
  process.exit(2);
}

const body = { city, star, source, ratio: '3:4' };
if (templateId) body.templateId = templateId;
const payload = JSON.stringify(body);

const req = http.request({
  host: '127.0.0.1', port: 8093, path: '/api/poster/make', method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload),
    'x-api-key': '',
  },
}, (res) => {
  let buf = '';
  res.on('data', (c) => (buf += c));
  res.on('end', () => {
    let j;
    try { j = JSON.parse(buf); } catch (e) {
      console.log('HTTP ' + res.statusCode + ' 非 JSON: ' + buf.slice(0, 300));
      process.exit(1);
    }
    if (!j.ok || !j.imageB64) {
      console.log('出图失败: ' + (j.error || '未知错误'));
      process.exit(1);
    }
    const out = outArg || path.join(process.env.TEMP, 'poster-' + star + '-' + Date.now() + '.png');
    fs.writeFileSync(out, Buffer.from(j.imageB64, 'base64'));
    const kb = Math.round(fs.statSync(out).size / 1024);
    console.log('OK  ' + city + ' / ' + star + ' / source=' + source + (templateId ? ' / tpl=' + templateId : ''));
    console.log('图: ' + out + '  (' + kb + 'KB)');
    console.log('返回字段: ' + Object.keys(j).join(', '));
  });
});
req.on('error', (e) => { console.log('请求失败: ' + e.message); process.exit(1); });
req.write(payload);
req.end();
