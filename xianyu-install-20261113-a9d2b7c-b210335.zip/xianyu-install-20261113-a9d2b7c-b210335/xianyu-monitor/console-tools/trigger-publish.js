#!/usr/bin/env node
/**
 * trigger-publish.js — 远程触发某店铺开始发布（无需打开发布台手动点按钮）
 *
 * 原理：调 8093 的 /api/agent/eval-on-store，在目标店铺页里执行
 *       window.kunPublish.runOneStore("<店铺全名>")。
 *       该方法会捡起该店任务盘里所有 status=pending 的任务逐个发布。
 *
 * 用法:
 *   node trigger-publish.js 好易美代拍
 *   node trigger-publish.js 好易美娱乐 --wait
 *
 * 参数:
 *   第1个：店铺全名（好易美代拍 / 好易美娱乐 / 超能水手代拍 / casa家居）
 *   --wait  等待 runOneStore 跑完再返回（默认立即返回，发布在页面后台继续）
 *
 * 注意:
 *   - runOneStore 开头有 `if (dailyRunning) return`，若该店已在发布中会被静默跳过
 *   - 发布进度看任务盘 ~/.xianyu-daily-tasks-<店铺>.json 里 status 与 itemId
 */
const http = require('http');
const os = require('os');
const fs = require('fs');
const path = require('path');

const KEY = '';
const args = process.argv.slice(2);
const store = args[0];
const wait = args.includes('--wait');

if (!store) {
  console.log('用法: node trigger-publish.js <店铺全名> [--wait]');
  process.exit(2);
}

const safeName = store.replace(/[\\/:*?"<>|]/g, '_');
const taskFile = path.join(os.homedir(), '.xianyu-daily-tasks-' + safeName + '.json');

// 用 JSON.stringify 包一层，避免店铺名里的引号破坏注入的代码
const s = JSON.stringify(store);

// 【关键】必须先 syncTasksFromDisk()：
// publish.js 的 loadDailyTasks() 读的是 localStorage，而 xyup.py / native_host 写的是磁盘文件。
// 不同步的话 runOneStore 会读到旧列表，判定「无待发布任务」直接返回（表现为触发了但一直 pending）。
// 2026-09-14 首次全自动发布踩到，务必保留这一步。
const inner = wait
  ? `(async function(){ await window.kunPublish.syncTasksFromDisk(); await window.kunPublish.runOneStore(${s}); return "done"; })()`
  : `(async function(){ await window.kunPublish.syncTasksFromDisk();
       if (window.kunPublish.dailyRunning) return "already-running";
       window.kunPublish.runOneStore(${s}); return "started"; })()`;

const payload = JSON.stringify({ store, code: inner });

const req = http.request({
  host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload),
    'x-api-key': KEY,
  },
}, (res) => {
  let b = '';
  res.on('data', (c) => (b += c));
  res.on('end', () => {
    let j;
    try { j = JSON.parse(b); } catch (e) {
      console.log('HTTP ' + res.statusCode + ' 非 JSON: ' + b.slice(0, 300));
      return;
    }
    console.log('触发结果: ' + JSON.stringify(j));
    if (j.ok) {
      console.log('→ 已向「' + store + '」发出发布指令');
      if (j.result === 'already-running') console.log('  （该店当前已在发布中，本次未重复触发）');
    }
    // 顺手报告任务盘里的待发数量
    try {
      const d = JSON.parse(fs.readFileSync(taskFile, 'utf8'));
      const ts = d.tasks || [];
      const pend = ts.filter((t) => t.status === 'pending').length;
      const done = ts.filter((t) => t.status === 'done').length;
      const failed = ts.filter((t) => t.status === 'failed').length;
      console.log('任务盘: 共 ' + ts.length + ' 条 | pending ' + pend + ' / done ' + done + ' / failed ' + failed);
    } catch (e) {
      console.log('（读任务盘失败: ' + e.message + '）');
    }
  });
});
req.on('error', (e) => console.log('请求失败: ' + e.message));
req.write(payload);
req.end();
