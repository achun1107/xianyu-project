// 闲鱼全生命周期管理 - 控制台工具
// 用法：到闲鱼 PC 端 (goofish.com) → F12 → Console → 粘贴全部代码 → 回车
// 看到 "🐟 工具已就绪" 后，输入 XY.help() 查看所有命令

(async function() {
  'use strict';
  if (window.XY) { console.log('✅ XY 已加载，输入 XY.help() 查看命令'); return; }

  const mtop = window.lib.mtop.request.bind(window.lib.mtop);

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ========== 1. 查看已上架宝贝列表 ==========
  async function list(pageNum, pageSize) {
    pageNum = pageNum || 1;
    pageSize = pageSize || 20;
    console.log('⏳ 正在拉取宝贝列表...');

    const apis = [
      { api: 'mtop.idle.pc.idleitem.seller.query', data: { pageNum, pageSize } },
      { api: 'mtop.idle.pc.idleitem.list', data: { pageNum, pageSize } }
    ];

    for (const cfg of apis) {
      try {
        const r = await mtop({ api: cfg.api, v: '1.0', data: cfg.data });
        if (r && r.ret && r.ret[0] && r.ret[0].startsWith('SUCCESS')) {
          const items = r.data.itemList || r.data.list || r.data.items || r.data || [];
          const arr = Array.isArray(items) ? items : [items];
          console.log('✅ 共 ' + arr.length + ' 件在售宝贝（API: ' + cfg.api + '）：');
          if (arr.length > 0) {
            console.table(arr.map(function(it, i) {
              var id = it.itemId || it.id || '';
              var title = (it.title || it.itemName || '').slice(0, 40);
              var price = it.price || (it.priceInCent ? it.priceInCent / 100 : '?');
              return { '#': i + 1, itemId: id, '标题': title, '价格': price + '元' };
            }));
          }
          return arr;
        }
        console.log('  API ' + cfg.api + ' 返回:', r && r.ret ? r.ret[0] : '无响应');
      } catch(e) {
        console.log('  API ' + cfg.api + ' 异常:', (e && e.ret ? e.ret[0] : '') || (e && e.message) || e);
      }
    }
    console.log('❌ 所有 API 都失败了。请在闲鱼"我发布的"页面运行，或联系 achun');
    return [];
  }

  // ========== 2. 查看宝贝详情 ==========
  async function detail(itemId) {
    console.log('⏳ 正在获取详情...');
    try {
      const r = await mtop({
        api: 'mtop.idle.pc.idleitem.detail',
        v: '1.0',
        data: { itemId: String(itemId) }
      });
      if (r && r.ret && r.ret[0] && r.ret[0].startsWith('SUCCESS')) {
        const d = r.data;
        console.log('📦 宝贝详情：');
        console.log('  itemId:', d.itemId || itemId);
        console.log('  标题:', d.title);
        console.log('  描述:', (d.description || d.desc || '').slice(0, 200));
        console.log('  价格:', (d.price || (d.priceInCent ? d.priceInCent / 100 : '?')) + '元');
        console.log('  --- 完整数据 ---');
        console.log(d);
        return d;
      }
      console.log('❌ 返回异常:', r && r.ret ? r.ret[0] : '无响应');
      return null;
    } catch(e) {
      console.log('❌ 请求失败:', (e && e.ret ? e.ret[0] : '') || (e && e.message) || e);
      return null;
    }
  }

  // ========== 3. 编辑宝贝 ==========
  async function edit(itemId, changes) {
    if (!changes || !Object.keys(changes).length) {
      console.log('⚠ 请提供要修改的字段');
      console.log('  例: XY.edit("123456", { title: "新标题", desc: "新描述" })');
      return;
    }
    console.log('⏳ 正在获取当前数据...');
    const current = await detail(itemId);
    if (!current) {
      // 没有详情也直接尝试编辑
      console.log('⚠ 无法获取详情，直接用传入的数据尝试编辑...');
    }

    var data = current ? Object.assign({}, current, changes, { itemId: String(itemId) }) : Object.assign({ itemId: String(itemId) }, changes);
    console.log('⏳ 正在保存...');
    try {
      const r = await mtop({ api: 'mtop.idle.pc.idleitem.update', v: '1.0', data: data });
      if (r && r.ret && r.ret[0] && r.ret[0].startsWith('SUCCESS')) {
        console.log('✅ 编辑成功！');
        return r.data;
      }
      console.log('❌', r && r.ret ? r.ret[0] : '无响应');
      return null;
    } catch(e) {
      console.log('❌', (e && e.ret ? e.ret[0] : '') || (e && e.message) || e);
      return null;
    }
  }

  // ========== 4. 下架宝贝 ==========
  async function off(itemId) {
    console.log('⏳ 正在下架 ' + itemId + ' ...');
    var apis = [
      { api: 'mtop.idle.pc.idleitem.off.shelf', data: { itemId: String(itemId) } },
      { api: 'mtop.idle.pc.idleitem.delete', data: { itemId: String(itemId) } }
    ];
    for (var i = 0; i < apis.length; i++) {
      try {
        var r = await mtop({ api: apis[i].api, v: '1.0', data: apis[i].data });
        if (r && r.ret && r.ret[0] && r.ret[0].startsWith('SUCCESS')) {
          console.log('✅ 已下架！（API: ' + apis[i].api + '）');
          return true;
        }
        console.log('  API ' + apis[i].api + ' 返回:', r && r.ret ? r.ret[0] : '无响应');
      } catch(e) {
        console.log('  API ' + apis[i].api + ' 异常:', (e && e.ret ? e.ret[0] : '') || (e && e.message) || e);
      }
    }
    console.log('❌ 下架失败，所有 API 都未成功');
    return false;
  }

  // ========== 5. 重新上架 ==========
  async function on(itemId) {
    console.log('⏳ 正在重新上架 ' + itemId + ' ...');
    var apis = [
      { api: 'mtop.idle.pc.idleitem.on.shelf', data: { itemId: String(itemId) } },
      { api: 'mtop.idle.pc.idleitem.reshelf', data: { itemId: String(itemId) } }
    ];
    for (var i = 0; i < apis.length; i++) {
      try {
        var r = await mtop({ api: apis[i].api, v: '1.0', data: apis[i].data });
        if (r && r.ret && r.ret[0] && r.ret[0].startsWith('SUCCESS')) {
          console.log('✅ 已重新上架！（API: ' + apis[i].api + '）');
          return true;
        }
        console.log('  API ' + apis[i].api + ' 返回:', r && r.ret ? r.ret[0] : '无响应');
      } catch(e) {
        console.log('  API ' + apis[i].api + ' 异常:', (e && e.ret ? e.ret[0] : '') || (e && e.message) || e);
      }
    }
    console.log('❌ 重新上架失败，所有 API 都未成功');
    return false;
  }

  // ========== 6. 一键批量下架 ==========
  async function offAll() {
    var items = await list();
    if (!items || items.length === 0) { console.log('⚠ 没有在售宝贝'); return; }
    console.log('⏳ 即将下架 ' + items.length + ' 件宝贝...');
    var ok = 0, fail = 0;
    for (var i = 0; i < items.length; i++) {
      var id = items[i].itemId || items[i].id;
      var title = (items[i].title || '').slice(0, 20);
      var result = await off(id);
      if (result) { ok++; console.log('  ✅ [' + ok + '/' + items.length + '] ' + title); }
      else { fail++; console.log('  ❌ [' + (ok+fail) + '/' + items.length + '] ' + title); }
      await sleep(500);
    }
    console.log('🏁 完成：成功 ' + ok + '，失败 ' + fail);
  }

  // ========== 帮助 ==========
  function help() {
    console.log([
      '',
      '╔══════════════════════════════════════════╗',
      '║      🐟 闲鱼全生命周期管理工具            ║',
      '╠══════════════════════════════════════════╣',
      '║  XY.help()        显示此帮助             ║',
      '║  XY.list()        查看在售宝贝列表        ║',
      '║  XY.detail(id)    查看宝贝详情            ║',
      '║  XY.edit(id, {})  编辑宝贝               ║',
      '║  XY.off(id)       下架宝贝               ║',
      '║  XY.on(id)        重新上架               ║',
      '║  XY.offAll()      一键批量下架            ║',
      '╠══════════════════════════════════════════╣',
      '║  用法示例：                              ║',
      '║  XY.list()                               ║',
      '║  XY.detail("1234567890")                 ║',
      '║  XY.edit("1234567890", {                 ║',
      '║    title: "新标题"                       ║',
      '║  })                                      ║',
      '║  XY.off("1234567890")                    ║',
      '║  XY.on("1234567890")                     ║',
      '╚══════════════════════════════════════════╝',
      ''
    ].join('\n'));
  }

  window.XY = { list: list, detail: detail, edit: edit, off: off, on: on, offAll: offAll, help: help };
  console.log('🐟 闲鱼全生命周期工具已就绪！输入 XY.help() 查看所有命令');
})();
