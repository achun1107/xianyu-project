// 闲鱼批量发布闭环 - 控制台工具
// 用法：F12 → Console → 粘贴全部代码 → 回车
// 看到 "🐟 批量发布工具已就绪" 后使用

(async function() {
  'use strict';
  if (window.XP) { console.log('✅ XP 已加载'); return; }

  var mtop = window.lib.mtop.request.bind(window.lib.mtop);
  var LOG_KEY = 'kun_publish_log';

  function loadLog() { try { return JSON.parse(localStorage.getItem(LOG_KEY)) || []; } catch(e) { return []; } }
  function saveLog(log) { localStorage.setItem(LOG_KEY, JSON.stringify(log)); }
  function sleep(ms) { return new Promise(function(r) { setTimeout(r, ms); }); }

  // ===== 1. 批量发布 =====
  async function batch(items, delayMs) {
    delayMs = delayMs || 2000;
    if (!items || !items.length) { console.log('⚠ 请提供商品列表'); return; }

    console.log('⏳ 即将发布 ' + items.length + ' 件...间隔 ' + (delayMs/1000) + '秒');
    var log = loadLog();
    var ok = 0, fail = 0;

    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var title = (item.title || '无标题').slice(0, 25);
      var idx = '[' + (i+1) + '/' + items.length + ']';

      try {
        var data = buildData(item);
        var r = await mtop({ api: 'mtop.idle.pc.idleitem.publish', v: '1.0', data: data });
        if (r && r.ret && r.ret[0] && r.ret[0].startsWith('SUCCESS')) {
          var itemId = (r.data && r.data.redirectUrl ? r.data.redirectUrl.match(/itemId=(\d+)/) : null) || ['', ''];
          itemId = itemId[1] || '';
          ok++;
          console.log('✅ ' + idx + ' ' + title + '  itemId=' + itemId);
          log.push({ title: item.title, itemId: itemId, time: new Date().toISOString(), ok: true });
        } else {
          fail++;
          var errMsg = (r && r.ret ? r.ret[0] : '未知错误');
          console.log('❌ ' + idx + ' ' + title + '  ' + errMsg);
          log.push({ title: item.title, time: new Date().toISOString(), ok: false, error: errMsg, data: item });
        }
      } catch(e) {
        fail++;
        var err = (e && e.ret ? e.ret[0] : '') || (e && e.message) || '请求失败';
        console.log('❌ ' + idx + ' ' + title + '  ' + err);
        log.push({ title: item.title, time: new Date().toISOString(), ok: false, error: err, data: item });
      }

      saveLog(log);
      if (i < items.length - 1) await sleep(delayMs);
    }

    console.log('🏁 完成！成功 ' + ok + ' / 失败 ' + fail + ' / 共 ' + items.length);
    return { ok: ok, fail: fail };
  }

  // ===== 2. 构建发布数据 =====
  function buildData(opt) {
    return {
      freebies: false,
      itemTypeStr: 'b',
      quantity: String(opt.quantity || 9999),
      simpleItem: 'true',
      imageInfoDOList: (opt.images || [
        'https://img.alicdn.com/imgextra/i1/O1CN01qEXMPk2M6qHNluzsh_!!2214432689779-0-fleamarket.jpg'
      ]).map(function(url, i) {
        return {
          extraInfo: { isH: 'false', isT: 'false', raw: 'false' },
          isQrCode: false,
          url: url,
          heightSize: 1280,
          widthSize: 1280,
          major: i === 0,
          type: 0,
          status: 'done'
        };
      }),
      itemTextDTO: {
        desc: opt.desc || '',
        title: opt.title || '',
        titleDescSeparate: false
      },
      itemLabelExtList: [{
        channelCateName: opt.catName || '创业/副业培训',
        channelCateId: opt.catId || '202155826',
        propertyName: '分类',
        propertyId: '-10000',
        text: opt.catName || '创业/副业培训',
        properties: '-10000##分类:' + (opt.catId || '202155826') + '##' + (opt.catName || '创业/副业培训'),
        labelType: 'common',
        isUserClick: '1',
        from: 'newPublishChoice',
        labelFrom: 'newPublish'
      }],
      itemPriceDTO: {
        origPriceInCent: String((opt.origPrice || 2) * 100),
        priceInCent: String((opt.price || 1) * 100)
      },
      userRightsProtocols: [{ enable: false, serviceCode: 'SKILL_PLAY_NO_MIND' }],
      itemPostFeeDTO: { canFreeShipping: false, supportFreight: false, onlyTakeSelf: false, templateId: '0' },
      itemAddrDTO: opt.addr || { area: '番禺区', city: '广州', divisionId: 440113, gps: '22.952159,113.340741', poiId: 'B0FFMB0OVQ', poiName: '原创设计电商区(勤艺珠宝商业大厦店)', prov: '广东' },
      defaultPrice: false,
      itemCatDTO: {
        catId: opt.deepCatId || '50023914',
        catName: opt.catName || '创业/副业培训',
        channelCatId: opt.catId || '202155826'
      },
      uniqueCode: Date.now() + '_' + Math.random().toString(36).substring(2, 10),
      sourceId: 'pcMainPublish',
      bizcode: 'pcMainPublish',
      publishScene: 'pcMainPublish'
    };
  }

  // ===== 3. 单件发布 =====
  async function one(opt) {
    console.log('⏳ 发布中...');
    var data = buildData(opt);
    try {
      var r = await mtop({ api: 'mtop.idle.pc.idleitem.publish', v: '1.0', data: data });
      if (r && r.ret && r.ret[0] && r.ret[0].startsWith('SUCCESS')) {
        var itemId = (r.data && r.data.redirectUrl ? r.data.redirectUrl.match(/itemId=(\d+)/) : null) || ['', ''];
        console.log('✅ 发布成功! itemId=' + (itemId[1] || '?'));
        return itemId[1];
      }
      console.log('❌ ' + (r && r.ret ? r.ret[0] : ''));
    } catch(e) {
      console.log('❌ ' + ((e && e.ret ? e.ret[0] : '') || (e && e.message) || '失败'));
    }
  }

  // ===== 4. 查看发布记录 =====
  function history() {
    var log = loadLog();
    if (!log.length) { console.log('📭 暂无发布记录'); return; }

    var okCount = 0, failCount = 0;
    for (var i = 0; i < log.length; i++) { log[i].ok ? okCount++ : failCount++; }

    console.log('📋 发布记录（成功 ' + okCount + ' / 失败 ' + failCount + ' / 共 ' + log.length + '）：');
    console.table(log.map(function(l, i) {
      return {
        '#': i + 1,
        '时间': (l.time || '').slice(0, 19).replace('T', ' '),
        '标题': (l.title || '').slice(0, 30),
        'itemId': l.itemId || '—',
        '结果': l.ok ? '✅' : '❌ ' + (l.error || '')
      };
    }));
    return log;
  }

  // ===== 5. 重试失败 =====
  async function retry(delayMs) {
    var log = loadLog();
    var failed = [];
    for (var i = 0; i < log.length; i++) { if (!log[i].ok && log[i].data) failed.push(log[i].data); }
    if (!failed.length) { console.log('✅ 没有失败的记录'); return; }
    console.log('⏳ 重试 ' + failed.length + ' 件失败记录...');
    return await batch(failed, delayMs);
  }

  // ===== 6. 清空记录 =====
  function clear() {
    localStorage.removeItem(LOG_KEY);
    console.log('🗑 发布记录已清空');
  }

  // ===== 7. 快速创建商品模板 =====
  function template(title, desc, count) {
    count = count || 1;
    var items = [];
    for (var i = 0; i < count; i++) {
      items.push({
        title: title + (count > 1 ? ' ' + (i+1) : ''),
        desc: desc
      });
    }
    return items;
  }

  // ===== 帮助 =====
  function help() {
    console.log([
      '',
      '╔══════════════════════════════════════════╗',
      '║     🐟 闲鱼批量发布闭环工具              ║',
      '╠══════════════════════════════════════════╣',
      '║  XP.help()           帮助               ║',
      '║  XP.one({...})       发布1件            ║',
      '║  XP.batch([...])     批量发布            ║',
      '║  XP.history()        查看记录            ║',
      '║  XP.retry()          重试失败            ║',
      '║  XP.clear()          清空记录            ║',
      '║  XP.template(t,d,n)  生成模板            ║',
      '╠══════════════════════════════════════════╣',
      '║  示例：                                  ║',
      '║  var items = XP.template("标题","描述",5) ║',
      '║  XP.batch(items)                         ║',
      '║  XP.history()                            ║',
      '║  XP.retry()                              ║',
      '╚══════════════════════════════════════════╝',
      ''
    ].join('\n'));
  }

  window.XP = {
    one: one,
    batch: batch,
    history: history,
    retry: retry,
    clear: clear,
    template: template,
    help: help
  };
  console.log('🐟 批量发布工具已就绪！输入 XP.help() 查看命令');
  console.log('💡 快速开始：var items = XP.template("标题","描述",3); XP.batch(items);');
})();
