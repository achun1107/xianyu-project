// ============================================================
// 闲鱼页面探针 —— 找出"全部商品列表"用的是哪个 mtop 接口
//
// 用法：
//   1. 在 Chrome 里打开你的闲鱼店铺页（已登录卖家号）
//      https://www.goofish.com/personal
//   2. F12 打开 DevTools → Console
//   3. 粘贴本文件全部内容 → 回车
//   4. 在页面上点进「我发布的 / 宝贝管理」等能看到全部商品的入口，
//      翻一页、点一次筛选（目的是让页面发请求）
//   5. 回到 Console 运行：  KUNMTOP.report()
//   6. 把打印出来的 JSON 整段发我
//
// 说明：本探针只监听、只读，不发送任何写请求，不修改你的商品或计划。
// ============================================================
(function () {
  if (window.__kmtop) {
    console.log('[KUNMTOP] 已在监听。累计 ' + window.__kmtop.log.length + ' 条。直接 KUNMTOP.report()');
    return;
  }
  if (!window.lib || !window.lib.mtop || !window.lib.mtop.request) {
    console.error('[KUNMTOP] 这个页面没有 window.lib.mtop —— 请在 goofish.com 页面上运行');
    return;
  }

  var S = {
    active: true,
    since: new Date().toLocaleString(),
    page: location.href,
    log: [],
    orig: window.lib.mtop.request
  };

  window.lib.mtop.request = function (opts) {
    var rec = {
      api: (opts && opts.api) || '(none)',
      type: (opts && opts.type) || 'GET',
      dataKeys: opts && opts.data ? Object.keys(opts.data) : []
    };
    var p;
    try { p = S.orig.apply(this, arguments); }
    catch (e) { rec.thrown = String((e && e.message) || e); S.log.push(rec); throw e; }
    try {
      Promise.resolve(p).then(function (r) {
        rec.ret = (r && r.ret) || null;
        rec.ok = !!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0);
        rec.dataKeys = (r && r.data) ? Object.keys(r.data) : null;
        S.log.push(rec);
      }, function (e) {
        rec.thrown = String((e && e.message) || e);
        S.log.push(rec);
      });
    } catch (e) { rec.thrown = String((e && e.message) || e); S.log.push(rec); }
    return p;
  };

  // 顺便数一下当前页面 DOM 里出现的商品卡片
  S.domItems = function () {
    var out = [], seen = {};
    try {
      var a = document.querySelectorAll('a[href*="item?id="], a[href*="/item/"]');
      for (var i = 0; i < a.length; i++) {
        var href = a[i].getAttribute('href') || '';
        var m = href.match(/id=(\d+)/) || href.match(/\/item\/(\d+)/);
        if (!m || seen[m[1]]) continue;
        seen[m[1]] = 1;
        out.push({ itemId: m[1], href: href });
      }
    } catch (e) { S.domErr = String((e && e.message) || e); }
    return out;
  };

  window.__kmtop = S;
  window.KUNMTOP = {
    report: function () {
      var counts = {};
      S.log.forEach(function (r) { counts[r.api] = (counts[r.api] || 0) + 1; });
      var okApis = Object.keys(counts).filter(function (k) {
        return S.log.some(function (r) { return r.api === k && r.ok; });
      });
      var res = {
        page: S.page,
        nowPage: location.href,
        since: S.since,
        total: S.log.length,
        接口调用次数: counts,
        成功过的接口: okApis,
        DOM商品数: S.domItems().length,
        DOM商品: S.domItems().slice(0, 30),
        明细: S.log
      };
      var s = JSON.stringify(res, null, 2);
      console.log(s);
      try { copy(s); console.log('%c已复制到剪贴板，直接粘贴发给 DSH 即可', 'color:#2c7;font-weight:bold'); } catch (e) {}
      return res;
    },
    dom: function () { return S.domItems(); },
    clear: function () { S.log = []; return 'cleared'; }
  };

  console.log('%c[KUNMTOP] 已开始监听。', 'color:#2c7;font-weight:bold');
  console.log('下一步：在页面上进入「我发布的 / 宝贝管理」并翻页/筛选，然后运行  KUNMTOP.report()');
})()
