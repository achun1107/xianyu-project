(async()=>{
  function d(off){var x=new Date(Date.now()-off*86400000);return x.getFullYear()+String(x.getMonth()+1).padStart(2,'0')+String(x.getDate()).padStart(2,'0');}
  var out={};
  for(var i=0;i<3;i++){
    var day=d(i);
    try{
      var r=await window.lib.mtop.request({api:'mtop.taobao.idle.ad.member.data.query',v:'1.0',type:'GET',
        data:{requestJson:JSON.stringify({startDate:day,endDate:day,includeEndDate:true})}});
      var dd=(r.data&&r.data.data)||{};
      out[day]={花费元:Math.round(Number(dd.cost)||0)/100,曝光:Number(dd.showPv)||0,成交:Number(dd.payPv)||0,成交额元:Math.round(Number(dd.payAmount)||0)/100};
    }catch(e){out[day]='ERR:'+(e&&e.message);}
  }
  return JSON.stringify(out);
})()
