/**
 * capture-sku.js —— 抓取闲鱼发布/编辑接口的真实 payload（用于反推「商品规格」字段结构）
 *
 * 背景：发布是页面内直调 mtop（publish.js:634 `mtop.idle.pc.idleitem.publish`），
 *       不走 DOM 表单，所以要加规格就得往 payload 里塞 SKU 结构。
 *       但 SKU 字段名/层级各家不同，猜不得，必须抓一次真实请求。
 *
 * 用法（在闲鱼页面的 DevTools Console 粘贴运行）：
 *   1. 直接用编辑页 URL 进入（见下方「坑1」）：https://www.goofish.com/publish?itemId=<商品ID>
 *   2. 粘贴本文件全部内容回车（挂上监听）
 *   3. 在页面上手动设置规格（代拍费：多人可组团优化 / 看台 / 内场）、库存 999、各档价格
 *   4. 点「发布」（编辑页的保存按钮文案就是「发布」）
 *   5. 运行 KUNSKU.dump() 查看，或 KUNSKU.copy() 复制到剪贴板
 *
 * ── 2026-09-14 实测踩坑记录 ──
 * 坑1：PC 端「我发布的」(goofish.com/personal) 已无商品编辑入口，
 *      商品卡片上只有「编辑资料」和「宝贝管理」，没有「编辑」。
 *      但后台路由仍可用：https://www.goofish.com/publish?itemId=xxx 能正常进入编辑态
 *      （标题/描述/价格/规格全部回填）。所以别在 personal 页找按钮。
 * 坑2：描述里含 emoji（如 ➕）会被前端校验拦截 ——
 *      点了「发布」完全不发请求、不跳转、也不报错到控制台，只在页面底部显示
 *      「商品描述不能包含emoji」。表现得像"点了没反应"，极易误判为脚本失效。
 *      先把 emoji 换成普通字符（➕ → +）再点。
 * 坑3：mtop.idle.pc.idleitem.detail / idleitem.seller.query 在非对应路由下调用
 *      会返回 ABORT::接口异常退出（风控上下文），不是参数问题。
 *      商品详情页 /item?id=xxx 是纯 CSR 渲染，HTML 里也搜不到 sku 数据。
 *      → 所以只能靠 hook 真实提交请求来拿 SKU 结构。
 *
 * 注意：
 *   - 页面跳转后监听会失效，但记录已写入 localStorage['kun_captured_sku']，
 *     新页面里运行 KUNSKU.load() 可以取回。
 *   - 只 hook publish/update 两个 api，不影响其它请求。
 */
(function () {
  if (window.__kunSkuHooked) { console.log('[KUNSKU] 已在监听，直接 KUNSKU.dump() 即可'); return; }
  if (!window.lib || !window.lib.mtop || !window.lib.mtop.request) {
    console.error('[KUNSKU] 当前页面没有 window.lib.mtop，请在闲鱼页面运行');
    return;
  }
  window.__kunSkuHooked = true;

  var orig = window.lib.mtop.request.bind(window.lib.mtop);
  window.__kunCaptured = (function () {
    try { return JSON.parse(localStorage.getItem('kun_captured_sku') || '[]'); } catch (e) { return []; }
  })();

  window.lib.mtop.request = function (opts) {
    var api = (opts && opts.api) || '';
    if (/idleitem\.(publish|update|edit)/.test(api)) {
      try {
        var rec = { api: api, at: new Date().toISOString(), data: opts && opts.data };
        window.__kunCaptured.push(rec);
        console.log('[KUNSKU] 捕获 ' + api, opts && opts.data);
        try { localStorage.setItem('kun_captured_sku', JSON.stringify(window.__kunCaptured)); } catch (e) {}
      } catch (e) { console.warn('[KUNSKU] 记录失败', e); }
    }
    return orig(opts);
  };

  window.KUNSKU = {
    dump: function () {
      var list = window.__kunCaptured || [];
      console.log('[KUNSKU] 共 ' + list.length + ' 条');
      console.log(JSON.stringify(list, null, 2));
      // 只打印可能跟规格相关的字段，方便一眼定位
      list.forEach(function (rec, i) {
        var d = rec.data || {};
        var keys = Object.keys(d).filter(function (k) { return /sku|prop|spec|price|quant|stock/i.test(k); });
        console.log('--- 第 ' + (i + 1) + ' 条 ' + rec.api + ' 规格相关字段 ---', keys, keys.map(function (k) { return d[k]; }));
      });
      return list;
    },
    load: function () {
      try {
        window.__kunCaptured = JSON.parse(localStorage.getItem('kun_captured_sku') || '[]');
        console.log('[KUNSKU] 已从 localStorage 载入 ' + window.__kunCaptured.length + ' 条');
      } catch (e) { console.warn(e); }
      return window.__kunCaptured;
    },
    copy: function () {
      var s = JSON.stringify(window.__kunCaptured || [], null, 2);
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(s).then(function () { console.log('[KUNSKU] 已复制到剪贴板'); });
      } else { console.log(s); }
      return s;
    },
    clear: function () {
      window.__kunCaptured = [];
      try { localStorage.removeItem('kun_captured_sku'); } catch (e) {}
      console.log('[KUNSKU] 已清空');
    }
  };

  console.log('%c[KUNSKU] 已挂上 mtop 监听', 'color:#8e44ad;font-weight:bold');
  console.log('现在去设置规格并提交，然后运行 KUNSKU.dump()（或 KUNSKU.copy()）');
})();
