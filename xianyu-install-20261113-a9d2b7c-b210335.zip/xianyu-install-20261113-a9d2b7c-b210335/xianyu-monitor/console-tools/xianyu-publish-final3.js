// 闲鱼自动上架 - 含地址版
(async function(){
    let m = window.lib.mtop.request.bind(window.lib.mtop);
    let data = {
        freebies: false, itemTypeStr: 'b', quantity: '1', simpleItem: 'true',
        imageInfoDOList: [{extraInfo: {isH: 'false', isT: 'false', raw: 'false'}, isQrCode: false, url: 'https://img.alicdn.com/imgextra/i1/O1CN01qEXMPk2M6qHNluzsh_!!2214432689779-0-fleamarket.jpg', heightSize: 1280, widthSize: 1280, major: true, type: 0, status: 'done'}],
        itemTextDTO: {desc: '日常有各类演出场次资讯，空闲时间随手操作就能赚点奶茶零花钱\n收益看场次，单次收益可观，大学生、宝妈时间自由都能做\n无门槛不用相关经验，感兴趣直接私聊咨询\n点关注，0.01拍下发群渠道\n拍下后消息较多，会逐一回复，请稍等', title: '【暑假可做】招演唱会抢手，适合大学生暑假做的', titleDescSeparate: false},
        itemLabelExtList: [{channelCateName: '创业/副业培训', channelCateId: '202155826', propertyName: '分类', propertyId: '-10000', text: '创业/副业培训', properties: '-10000##分类:202155826##创业/副业培训', labelType: 'common', isUserClick: '1', from: 'newPublishChoice', labelFrom: 'newPublish'}],
        itemPriceDTO: {origPriceInCent: '200', priceInCent: '100'},
        userRightsProtocols: [{enable: false, serviceCode: 'SKILL_PLAY_NO_MIND'}],
        itemPostFeeDTO: {canFreeShipping: false, supportFreight: false, onlyTakeSelf: false, templateId: '0'},
        itemAddrDTO: {area: '番禺区', city: '广州', divisionId: 440113, gps: '22.952159,113.340741', poiId: 'B0FFMB0OVQ', poiName: '原创设计电商区(勤艺珠宝商业大厦店)', prov: '广东'},
        defaultPrice: false,
        itemCatDTO: {catId: '50023914', catName: '创业/副业培训', channelCatId: '202155826'},
        uniqueCode: Date.now() + '_' + Math.random().toString(36).substring(2, 10),
        sourceId: 'pcMainPublish', bizcode: 'pcMainPublish', publishScene: 'pcMainPublish'
    };
    console.log('⏳ 发布中...');
    try {
        let r = await m({api: 'mtop.idle.pc.idleitem.publish', v: '1.0', data});
        if(r?.ret?.[0]?.startsWith('SUCCESS')) console.log('✅ 发布成功!');
        else console.log('❌', r?.ret?.[0]);
    } catch(e) {
        console.log(e?.ret?.[0]);
    }
})();
