#!/usr/bin/env node
/**
 * eval-store.js — 在指定店铺页面里执行一段 JS（走 8093 /api/agent/eval-on-store）
 *
 * 用途：调试、查店铺页内部状态（window.kunPublish.*）、调 mtop 接口
 *
 * 用法:
 *   node eval-store.js 好易美代拍 code.js
 *   node eval-store.js 好易美代拍 -e "window.kunPublish.getDailyStatus()"
 *
 * 说明:
 *   - 推荐用 code.js 文件传代码，避免命令行引号转义问题
 *   - 结果如果是对象会被 JSON 化后打印
 */
const http = require('http');
const fs = require('fs');

const KEY = '';
const [store, arg2] = process.argv.slice(2);

if (!store || !arg2) {
  console.log('用法: node eval-store.js <店铺全名> <code文件路径| -e "代码">');
  process.exit(2);
}

let code;
if (arg2 === '-e') {
  code = process.argv.slice(4).join(' ');
} else {
  code = fs.readFileSync(arg2, 'utf8');
}

const payload = JSON.stringify({ store, code });

const req = http.request({
  host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload),
    'x-api-key': KEY,
  },
}, (res) => {
  let b = '';
  res.on('data', (c) => (b += c));
  res.on('end', () => {
    let j;
    try { j = JSON.parse(b); } catch (e) { console.log('非 JSON: ' + b.slice(0, 400)); return; }
    if (!j.ok) { console.log('执行失败: ' + j.error); return; }
    const r = j.result;
    console.log(typeof r === 'string' ? r : JSON.stringify(r, null, 2));
  });
});
req.on('error', (e) => console.log('请求失败: ' + e.message));
req.write(payload);
req.end();
