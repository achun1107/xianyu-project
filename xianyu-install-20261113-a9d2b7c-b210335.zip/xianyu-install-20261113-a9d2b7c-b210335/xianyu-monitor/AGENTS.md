# AGENTS.md — 给任何 AI agent 的项目约束

本目录**既是 Chrome 扩展根目录，又放着 Python 工具脚本**。这条双重身份制造了几条
反直觉的红线。**动任何文件之前先读第 0 节。**

---

## 0. 绝对红线：不要在这里新建 `_` 开头的文件或目录

Chrome 在解析清单**之前**扫描目录，遇到任何 `_` 开头的文件或目录就拒绝加载**整个扩展**：

```
Cannot load extension with file or directory name _xxx.
Filenames starting with "_" are reserved for use by the system.
无法加载清单。
```

**后果不是某个功能失效，而是整份扩展报废**，且报错信息指向 manifest，极易误判方向。

| 不要做 | 应该做 |
|---|---|
| 新建 `_ad_probe.js`、`_tmp.js`、`_debug.js` | 用 `ad-probe.js` / `tmp-debug.js`（不用下划线前缀） |
| 让 Python 在本目录生成 `__pycache__` | 脚本顶部 `sys.dont_write_bytecode = True`，或运行时加 `-B` |
| 新建 `_scratch/` 之类的临时目录 | 临时产物放本目录**之外** |

**已踩过的两次事故**（别再犯第三次）：

- `__pycache__`：`clean_dupes.py` 导入 `check_assets` 时生成 → 扩展加载失败
- `_ad_probe.js`（2026-09-20）：agent 生成的擦亮探针脚本 → 扩展加载失败，靠人工发现

注意 `.gitignore` 里的 `_*.json` / `_*.txt` / `__pycache__/` / `_*.js` **只是兜底**，
不是许可——被 git 忽略 ≠ Chrome 会放行。

**排查命令**（扩展突然加载失败时先跑这个）：

```powershell
Get-ChildItem . -Recurse -Force | Where-Object { $_.Name -like '_*' }
```

---

## 1. 临时脚本不要留在扩展根目录

本目录的 `.js` 都会被 Chrome 当作扩展资源。探针、一次性脚本、调试代码应：
写入**项目外**（如工作区），或用完删除。**不要**为了"待会儿还要用"而留在根目录。

---

## 2. 商品规格（SKU）与价格的硬约束

这些是抓包实测出来的，猜不得：

| 事实 | 含义 |
|---|---|
| 启用规格后**必须把顶层 `itemPriceDTO` 置空** | 否则与规格价冲突 |
| 价格单位是**分**（`priceInCent`） | 不是元 |
| 真实库存在 `itemSkuList[].quantity` | **顶层 `quantity` 在 SKU 模式下不生效** |
| **闲鱼取最低档作展示价** | 漏掉一档 = 列表展示价被改变 |
| 没填价格的档**不生成 SKU** | `buildSkuPayload` 会静默跳过 |

**因此：任何会改变档位集合的改动，都必须同时考虑展示价是否被改变，并给出提示。**
静默跳过档位是本项目最危险的一类 bug——它悄悄改了对外价格。

## 3. 配置的四级兜底（别只看一层）

```
价格/库存：任务 → 店铺配置(kun_store_cfg_<店>) → 模板 → 项目默认
规格：    任务 task.specs → 店铺配置 .specs → （无）
擦亮开关：界面 setAutoPolish && 项目配置 kun_project_configs[*].autoPolish && !task.skipCampaign
```

三者都要为真才会开擦亮——只关一处不生效。数据存在 `localStorage`，不在磁盘。

## 4. 擦亮（超级擦亮）删除必须经人工审批

`mtop.taobao.idle.ad.campaign.delete` 是**不可恢复**操作。

**纪律：所有删除必须走 `monitor.js` 里的唯一审批出口**
（`deleteCampaignsWithApproval` / `confirmCampaignDelete`），
它负责弹框**逐条列出**将被删除的计划标题与 ID，默认取消。

**不要在按钮处理函数里直接写 `campaign.delete`。** 新增删除入口时接入该守卫，
以保持"全项目只有一处 delete 调用"这一可审计性质。

暂停/重启（`campaign.pause`）是可恢复操作，不纳入审批。

## 5. 改动纪律（沿用 hym-admin AGENTS.md 的既有标准）

- 单文件 ≤400 行；超了就拆
- **禁止静默吞错**：`catch(e){}` 一律消灭；写盘类失败必须让用户看见
- **SSOT**：任务数据以磁盘为唯一权威源，页面持工作副本；不要新增第二套读写路径
- 禁止店铺/机器专属硬编码（个人目录路径、店铺名判断）——进配置
- `api()` 统一检查 `res.ok`

## 6. 已知安全面（改动时不要扩大）

- `publish.js` / `publish_dashboard.js` 等前端源码里有**硬编码 API Key**（已事实泄漏）
- `/api/agent/eval-on-store` 可在店铺页执行**任意 JS** —— 与上面的 Key 组合是本机 RCE 面。
  新增功能时不要依赖或扩大它
- message 监听普遍缺 origin 校验；`document.cookie` 整包外传（含 alipay）

## 7. 验证方式

本目录的源码是 **Chrome 扩展 + Python 脚本**混合体，没有构建步骤。改动后请：

```powershell
# JS 语法（node 可用 WorkBuddy 自带的）
node --check <file>
# 红线自查
Get-ChildItem . -Recurse -Force | Where-Object { $_.Name -like '_*' }
```

**不要**用 `git clean -fdX`——会连本地账本 `ad_ledger.sqlite` 一起清掉。
