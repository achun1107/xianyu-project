// ==UserScript==
// @name         闲鱼超级擦亮 - 数据监控面板
// @namespace    http://kun.app/
// @version      1.5
// @description  自动抓取闲鱼超级擦亮商品数据，同步到好易美后台
// @author       Kun
// @match        https://dayu.goofish.com/*
// ==/UserScript==

(function() {
    'use strict';

    if (document.getElementById('kun-trigger-btn')) return;

    const CONFIG = { refreshInterval: 60, pageSize: 50 };
    const TREND_KEY = 'kun_trend_db';
    let monitorData = [], historyData = [];

        function mtopRequest(api, data = {}, method) {
        return new Promise((resolve, reject) => {
            var id = Date.now() + '_' + Math.random().toString(36).substring(2,8);
            function handler(e) {
                if (!e.data || e.data.type !== 'KUN_MTOP_RESULT' || e.data.id !== id) return;
                window.removeEventListener('message', handler);
                if (e.data.error) reject(e.data.error);
                else resolve(e.data.data);
            }
            window.addEventListener('message', handler);
            window.postMessage({ type: 'KUN_MTOP', id: id, api: api, data: data, method: method || 'GET' }, '*');
            setTimeout(function() { window.removeEventListener('message', handler); reject('timeout'); }, 30000);
        });
    }

    async function fetchDateData(dateStr) {
        let s = {};
        try { const m = await mtopRequest('mtop.taobao.idle.ad.member.data.query', { startDate: dateStr, endDate: dateStr, includeEndDate: true }); s = m?.data || {}; } catch(e) {}
        let c = [], p = 1, h = true;
        while (h) {
            try {
                const r = await mtopRequest('mtop.taobao.idle.ad.campaign.search', { pageNum: p, pageSize: CONFIG.pageSize, startDate: dateStr, endDate: dateStr, includeEndDate: true, campaignStatus: [-6,-5,-4,-3,-2,1,2,3,4,6,99], statusGroup: [] });
                if (r && r.result) { c = c.concat(r.result); h = r.nextPage === true; p++; } else h = false;
            } catch(e) { h = false; }
        }
        if (c.length > 0) saveCampaignData(dateStr, c);
        return { date: dateStr, time: new Date().toLocaleTimeString(), summary: s, campaigns: c };
    }

    async function fetchTodayData() {
        const d = new Date().toISOString().slice(0, 10).replace(/-/g, '');
        return fetchDateData(d);
    }

    function getCampaignName(camp) {
        return camp.title || (camp.entityList && camp.entityList[0] && camp.entityList[0].title) || camp.campaignName || camp.name || '未知商品';
    }

    function fmt(v) { return (v === undefined || v === null) ? '0.00' : (v / 100).toFixed(2); }
    function getExp(d) { return d.impressionPv || d.pv || d.exposurePv || 0; }
    function cc(cur, prev) { if (prev === undefined || prev === null) return { d: 0, p: '0%' }; const d = cur - prev; const p = prev !== 0 ? (d / prev * 100).toFixed(1) + '%' : '∞'; return { d, p }; }
    function fc(d, p) { if (d > 0) return '↑' + d + ' (' + p + ')'; if (d < 0) return '↓' + Math.abs(d) + ' (' + p + ')'; return '- (' + p + ')'; }

    // ===== 面板渲染 =====
    function renderPanel(data) {
        let old = document.getElementById('kun-monitor-panel'); if (old) old.remove();
        const pnl = document.createElement('div');
        pnl.id = 'kun-monitor-panel';
        pnl.style.cssText = 'position:fixed;top:60px;right:12px;z-index:99998;background:#fff;border:1px solid #ddd;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,0.15);width:560px;max-height:80vh;overflow-y:auto;font-family:system-ui,sans-serif;font-size:13px;';
        const lr = historyData.length > 0 ? historyData[historyData.length - 1] : null;

        let body = '';
        if (data.summary) {
            const s = data.summary;
            body += '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:12px;background:#f0f7ff;border-radius:8px;margin-bottom:12px;">'
                + '<div style="text-align:center"><div style="font-size:18px;font-weight:bold;color:#e67e22">' + fmt(s.cost) + '</div><div style="font-size:11px;color:#666">推广费(元)</div></div>'
                + '<div style="text-align:center"><div style="font-size:18px;font-weight:bold;color:#2980b9">' + (s.clickPv||0) + '</div><div style="font-size:11px;color:#666">点击量</div></div>'
                + '<div style="text-align:center"><div style="font-size:18px;font-weight:bold;color:#8e44ad">' + (s.chatPv||0) + '</div><div style="font-size:11px;color:#666">询单量</div></div>'
                + '<div style="text-align:center"><div style="font-size:18px;font-weight:bold;color:#16a085">' + (s.inquiries||0) + '</div><div style="font-size:11px;color:#666">咨询数</div></div></div>';
        }

        if (data.campaigns && data.campaigns.length > 0) {
            data.campaigns.forEach(camp => {
                const d = camp.adDataDetailVO || camp.adData || {};
                const pc = lr?.campaigns?.find(c => (c.campaignId || c.id) === (camp.campaignId || camp.id));
                const pd = pc ? (pc.adDataDetailVO || pc.adData || {}) : {};
                const c1 = cc(d.cost||0, pd.cost||0), c2 = cc(d.clickPv||0, pd.clickPv||0), c5 = cc(getExp(d), getExp(pd)), c3 = cc(d.chatPv||0, pd.chatPv||0), c4 = cc(d.inquiries||0, pd.inquiries||0);
                body += '<div style="border:1px solid #eee;border-radius:6px;padding:8px;margin-bottom:6px;background:#fafafa;">'
                    + '<div style="font-weight:600;color:#333;margin-bottom:4px;font-size:12px;">' + getCampaignName(camp) + '</div>'
                    + '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:4px;font-size:11px;">'
                    + '<div><span style="color:#e67e22">' + fmt(d.cost) + '</span><br><span style="color:' + (c1.d>0?'#e74c3c':c1.d<0?'#27ae60':'#999') + ';font-size:10px">' + fc(c1.d,c1.p) + '</span></div>'
                    + '<div><span style="color:#2980b9">' + (d.clickPv||0) + '</span><br><span style="color:' + (c2.d>0?'#e74c3c':c2.d<0?'#27ae60':'#999') + ';font-size:10px">' + fc(c2.d,c2.p) + '</span></div>'
                    + '<div><span style="color:#9b59b6">' + getExp(d) + '</span><br><span style="color:' + (c5.d>0?'#e74c3c':c5.d<0?'#27ae60':'#999') + ';font-size:10px">' + fc(c5.d,c5.p) + '</span></div>'
                    + '<div><span style="color:#8e44ad">' + (d.chatPv||0) + '</span><br><span style="color:' + (c3.d>0?'#27ae60':c3.d<0?'#e74c3c':'#999') + ';font-size:10px">' + fc(c3.d,c3.p) + '</span></div>'
                    + '<div><span style="color:#16a085">' + (d.inquiries||0) + '</span><br><span style="color:' + (c4.d>0?'#27ae60':c4.d<0?'#e74c3c':'#999') + ';font-size:10px">' + fc(c4.d,c4.p) + '</span></div></div></div>';
            });
        } else {
            body += '<div style="padding:20px;text-align:center;color:#999;">暂无商品数据</div>';
        }

        pnl.innerHTML = '<div style="padding:16px;background:linear-gradient(135deg,#4A90D9,#357ABD);color:#fff;border-radius:12px 12px 0 0;display:flex;flex-direction:column;">'
            + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">'
            + '<div><span style="font-size:16px;font-weight:bold;">📊 超级擦亮监控</span><span style="font-size:11px;margin-left:12px;opacity:0.8">' + data.date + ' ' + data.time + '</span></div>'
            + '<button id="kcb" style="background:none;border:none;color:#fff;cursor:pointer;font-size:18px;">✕</button></div>'
            + '<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:6px;">'
            + '<button id="krb" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:#fff;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;">🔄 刷新</button>'
            + '<button id="kcb4" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:#fff;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;">📋 汇总</button>'
            + '<button id="kcb2" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:#fff;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;">📋 今日</button>'
            + '<button id="kcb3" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:#fff;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;">📋 昨日</button>'
            + '<button id="kcb7" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:#fff;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;">📋 7天</button>'
            + '<button id="kcb30" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:#fff;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;">📋 30天</button>'
            + '<button id="ktr" style="background:#ffe60f;border:none;color:#1f1f1f;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:500;">📈 趋势</button>'
            + '<button id="ksync" style="background:#ffe60f;border:none;color:#1f1f1f;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:500;">🔄 同步后台</button>'
            + '<button id="kdb" style="background:#4A90D9;border:none;color:#fff;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:500;">📊 操作台</button>'
            + '<button id="keb" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:#fff;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;">📥 导出</button>'
            + '<button id="kcam" style="background:#e67e22;border:none;color:#fff;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:500;">💨 计划</button>'
            + '<button id="kfetchAccts" style="background:#27ae60;border:none;color:#fff;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:500;">🔑 拉取账户</button>'
            + '</div>'
            + '<div style="display:flex;align-items:center;gap:6px;background:rgba(255,255,255,0.1);border-radius:6px;padding:6px 10px;">'
            + '<span style="color:#fff;font-size:12px;white-space:nowrap;">📅 自定义</span>'
            + '<input id="kdateStart" type="date" style="flex:1;min-width:0;padding:4px 6px;border-radius:4px;border:none;font-size:12px;background:#fff;color:#333;">'
            + '<span style="color:#fff;font-size:12px;">→</span>'
            + '<input id="kdateEnd" type="date" style="flex:1;min-width:0;padding:4px 6px;border-radius:4px;border:none;font-size:12px;background:#fff;color:#333;">'
            + '<button id="kcbCustom" style="background:#ffe60f;border:none;color:#1f1f1f;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:12px;font-weight:500;">📋 复制</button>'
            + '<button id="ksyncCustom" style="background:#4A90D9;border:none;color:#fff;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:12px;font-weight:500;">⏫ 同步</button>'
            + '</div>'
            + '</div>'
            + '<div style="padding:12px;">' + body + '</div>';

        document.body.appendChild(pnl);
        document.getElementById('krb').onclick = () => refreshData();
        document.getElementById('kcb').onclick = () => { pnl.style.display = 'none'; };
        document.getElementById('keb').onclick = exportCSV;
        document.getElementById('kcb2').onclick = copyTable;
        document.getElementById('kcb3').onclick = copyYesterdayTable;
        document.getElementById('kcb4').onclick = copySummary;
        document.getElementById('kcb7').onclick = async function(){ await copyRangeSummary(7); };
        document.getElementById('kcb30').onclick = async function(){ await copyRangeSummary(30); };
        document.getElementById('ksync').onclick = syncToBackend;
        document.getElementById('ktr').onclick = showTrend;
        document.getElementById('kdb').onclick = function() {
            console.log('[kun] clicking dashboard button');
            window.postMessage({ type: 'OPEN_DASHBOARD' }, '*');
        };
        document.getElementById('kfetchAccts').onclick = fetchXianyuAccounts;
        document.getElementById('kcam').onclick = showCampaignManager;
        document.getElementById('ksyncCustom').onclick = syncCustomToBackend;
        document.getElementById('kcbCustom').onclick = copyCustomRange;
        return pnl;
    }

    // ===== 擦亮计划管理 =====
    // 优先 window.lib.mtop（data 用 requestJson 包装 + 校验 ret 是否 SUCCESS）；fallback postMessage mtopRequest
    async function mtopR(api, body, method) {
        if (window.lib && window.lib.mtop) {
            var r = await window.lib.mtop.request({ api: api, v: '1.0', data: { requestJson: JSON.stringify(body) }, type: (method || 'GET') });
            var ret = r && r.ret && r.ret[0];
            if (!ret || ret.indexOf('SUCCESS') !== 0) throw new Error(ret || ('接口失败: ' + api));
            return r.data;
        }
        return mtopRequest(api, body, method);
    }
    async function getAllCampaigns() {
        let all = [], p = 1;
        while (true) {
            try {
                const r = await mtopR('mtop.taobao.idle.ad.campaign.search', { pageNum: p, pageSize: 50, startDate: '2026-08-01', endDate: '2026-08-25', includeEndDate: true, campaignStatus: [-6,-5,-4,-3,-2,1,2,3,4,6,99], statusGroup: [] });
                const list = (r && r.result) || [];
                if (!list.length) break;
                list.forEach(c => all.push(c));
                if (!r.nextPage) break;
                p++;
            } catch(e) { break; }
        }
        return all;
    }
    function stName(s) { return ({1:'投放中',2:'暂停',3:'结束',4:'暂停',6:'投放中',99:'结束'}[s] || ('状态'+s)); }
    // ===== 擦亮删除的唯一审批出口（owner 要求：所有不可恢复的删除都必须经人工审批）=====
    // 纪律：任何调用 mtop.taobao.idle.ad.campaign.delete 的代码都必须走这里，
    // 不要把 delete 直接写在按钮处理函数里 —— 否则审批会被绕过。
    // 暂停/重启是可恢复操作，不纳入本审批。
    function campaignTitleOf(c) { return (c && c.entityList && c.entityList[0] && c.entityList[0].title) || (c && c.campaignName) || (c && c.adGroupId) || ''; }

    /** 弹框列出将被删除的具体计划，逐条列出标题与 ID；默认取消。返回 true 才允许删除。 */
    function confirmCampaignDelete(campaigns) {
        var list = [].concat(campaigns || []);
        if (!list.length) return false;
        var lines = list.map(function (c, i) {
            var id = String((c && (c.campaignId || c.id)) || '');
            var t = campaignTitleOf(c) || '(无标题)';
            return '  ' + (i + 1) + '. ' + t + '  [ID ' + id + ']';
        });
        var msg = '⚠ 即将【删除】' + list.length + ' 个超级擦亮计划（不可恢复）\n\n'
            + lines.slice(0, 20).join('\n')
            + (list.length > 20 ? '\n  …还有 ' + (list.length - 20) + ' 个，共 ' + list.length + ' 个' : '')
            + '\n\n删除后无法恢复，确认要删除吗？';
        return window.confirm(msg);
    }

    /**
     * 删除擦亮计划的唯一通道。
     * @param campaigns 计划对象数组（用于弹框展示）；若元素是字符串/数字则视为只有 ID、无标题
     * @returns { approved, ok, fail }
     */
    async function deleteCampaignsWithApproval(campaigns) {
        var list = [].concat(campaigns || []);
        if (!list.length) return { approved: false, ok: 0, fail: 0 };
        if (!confirmCampaignDelete(list)) return { approved: false, ok: 0, fail: 0 };
        var ok = 0, fail = 0;
        for (var i = 0; i < list.length; i++) {
            var c = list[i];
            var cid = (c && typeof c === 'object') ? String(c.campaignId || c.id || '') : String(c || '');
            if (!cid) { fail++; continue; }
            try {
                await mtopR('mtop.taobao.idle.ad.campaign.delete', { campaignId: cid }, 'POST');
                ok++;
            } catch (e) {
                fail++;
                console.log('[擦亮] delete 失败 cid=' + cid + ' ret=', e);
            }
        }
        return { approved: true, ok: ok, fail: fail };
    }
    async function showCampaignManager() {
        const ex = document.getElementById('kun-campaign-mgr'); if (ex) ex.remove();
        const m = document.createElement('div'); m.id = 'kun-campaign-mgr';
        m.style.cssText = 'position:fixed;top:80px;right:16px;width:460px;max-height:74vh;background:#fff;border:1px solid #ddd;border-radius:10px;box-shadow:0 4px 18px rgba(0,0,0,0.18);z-index:99999;padding:10px;font-size:12px;color:#333;display:flex;flex-direction:column;';
        m.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;"><b>💨 擦亮计划管理</b><button id="kcmc" style="border:none;background:none;cursor:pointer;font-size:16px;">✕</button></div>'
            + '<div style="display:flex;gap:4px;margin-bottom:8px;">'
            + '<button id="kcmlist" style="flex:1;background:#4A90D9;color:#fff;border:none;padding:6px;border-radius:5px;cursor:pointer;">📋 列出</button>'
            + '<button id="kcmpause" style="flex:1;background:#e67e22;color:#fff;border:none;padding:6px;border-radius:5px;cursor:pointer;">⏹ 全部暂停</button>'
            + '<button id="kcmstart" style="flex:1;background:#27ae60;color:#fff;border:none;padding:6px;border-radius:5px;cursor:pointer;">▶ 全部重启</button>'
            + '</div>'
            + '<div style="display:flex;gap:4px;margin-bottom:8px;">'
            + '<button id="kcmpausesel" style="flex:1;background:#8e44ad;color:#fff;border:none;padding:6px;border-radius:5px;cursor:pointer;">☑停选中</button>'
            + '<button id="kcmsttsel" style="flex:1;background:#16a085;color:#fff;border:none;padding:6px;border-radius:5px;cursor:pointer;">▶启选中</button>'
            + '<button id="kcmdelsel" style="flex:1;background:#c0392b;color:#fff;border:none;padding:6px;border-radius:5px;cursor:pointer;">✕删选中</button>'
            + '</div>'
            + '<div style="display:flex;gap:4px;margin-bottom:8px;align-items:center;">'
            + '<input id="kcmsearch" placeholder="搜索计划（如：孙燕姿）" style="flex:1;padding:6px;border:1px solid #ddd;border-radius:5px;font-size:12px;">'
            + '<button id="kcmsearchbtn" style="background:#4A90D9;color:#fff;border:none;padding:6px 10px;border-radius:5px;cursor:pointer;font-size:12px;">🔍搜索</button>'
            + '<button id="kcmstopkw" style="background:#e67e22;color:#fff;border:none;padding:6px 10px;border-radius:5px;cursor:pointer;font-size:12px;">⏹停搜到的</button>'
            + '<button id="kcmstartkw" style="background:#27ae60;color:#fff;border:none;padding:6px 10px;border-radius:5px;cursor:pointer;font-size:12px;">▶启搜到的</button>'
            + '</div>'
            + '<div style="display:flex;gap:4px;margin-bottom:8px;">'
            + '<button id="kcmrename" style="flex:1;background:#2c3e50;color:#fff;border:none;padding:6px;border-radius:5px;cursor:pointer;">🔧 批量改名(¥出价·订单·城市明星)</button>'
            + '</div>'
            + '<div id="kcmlistbox" style="border-top:1px solid #eee;padding-top:6px;overflow:auto;flex:1;">加载中…</div>';
        document.body.appendChild(m);
        m.querySelector('#kcmc').onclick = () => m.remove();
        m.querySelector('#kcmlist').onclick = async () => { await refreshCampaignList(m); };
        m.querySelector('#kcmpause').onclick = async () => { await pauseAllCampaigns(m); };
        m.querySelector('#kcmstart').onclick = async () => { await restartAllCampaigns(m); };
        m.querySelector('#kcmpausesel').onclick = async () => { await selectedCampaigns(m, 'pause'); };
        m.querySelector('#kcmsttsel').onclick = async () => { await selectedCampaigns(m, 'restore'); };
        m.querySelector('#kcmdelsel').onclick = async () => { await selectedCampaigns(m, 'delete'); };
        m.querySelector('#kcmsearchbtn').onclick = async () => { await refreshCampaignList(m); };
        m.querySelector('#kcmstopkw').onclick = async () => { await pauseByKeyword(m); };
        m.querySelector('#kcmstartkw').onclick = async () => { await restartByKeyword(m); };
        m.querySelector('#kcmrename').onclick = async () => { await renameAllCampaigns(m); };
        await refreshCampaignList(m);
    }
    async function refreshCampaignList(m) {
        m.querySelector('#kcmlistbox').innerHTML = '加载中…';
        let list = [];
        try { list = await getAllCampaigns(); } catch(e) {}
        const box = m.querySelector('#kcmlistbox');
        const kw = (m.querySelector('#kcmsearch') && m.querySelector('#kcmsearch').value || '').trim();
        if (kw) list = list.filter(function(c){ const t = (((c.entityList && c.entityList[0] && c.entityList[0].title) || c.adGroupId) || '') + '|' + (c.campaignName || c.title || '') ; return t.indexOf(kw) >= 0; });
        if (!list.length) { box.innerHTML = '<div style="color:#999;text-align:center;padding:12px;">' + (kw ? '无匹配「' + kw + '」的计划' : '计划列表为空') + '</div>'; return; }
        box.innerHTML = '<div style="margin-bottom:6px;">共 <b>' + list.length + '</b> 个计划</div>' + list.map((c, i) => {
            const id = String(c.campaignId || c.id);
            const title = (c.entityList && c.entityList[0] && c.entityList[0].title) || c.adGroupId || id;
            const rm = (c.bidTarget || '');
            const btn = '<input type="checkbox" class="campaign-cb" data-cid="' + id + '" title="勾选批量操作" style="margin-right:6px;">'
                + '<button data-cid="' + id + '" data-act="del" style="background:#e74c3c;border:none;color:#fff;padding:2px 7px;border-radius:4px;cursor:pointer;font-size:10px;">删</button> '
                + '<button data-cid="' + id + '" data-act="paus" style="background:#e67e22;border:none;color:#fff;padding:2px 7px;border-radius:4px;cursor:pointer;font-size:10px;">停</button> '
                + '<button data-cid="' + id + '" data-act="start" style="background:#27ae60;border:none;color:#fff;padding:2px 7px;border-radius:4px;cursor:pointer;font-size:10px;">启</button>';
            return '<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;padding:4px 2px;border-bottom:1px solid #f3f3f3;">'
                + '<div style="min-width:0;flex:1;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;">' + (title || id) + '</div>'
                + '<div style="font-size:10px;color:#999;">ID:' + id + ' · ' + stName(c.status) + ' · ' + rm + '</div></div>' + btn + '</div>';
        }).join('');
        box.querySelectorAll('button').forEach(b => b.onclick = async function() {
            const cid = this.getAttribute('data-cid'), act = this.getAttribute('data-act');
            const label = act === 'del' ? '删除' : (act === 'start' ? '重启' : '暂停');
            if (act === 'del') {
                // 删除走唯一审批出口：弹框列出该计划标题与 ID，默认取消
                const _c = (list || []).filter(x => String(x.campaignId || x.id) === cid)[0];
                const _r = await deleteCampaignsWithApproval([_c || cid]);
                if (!_r.approved) return;                       // 用户取消：什么都不做
                if (_r.fail) alert('操作失败：' + _r.fail + ' 个未删除');
                else alert('✅ 删除 ' + cid);
                await refreshCampaignList(m);
                return;
            }
            if (!confirm(label + '计划 ' + cid + '？')) return;   // 暂停/重启可恢复，保持原确认
            try {
                await mtopR('mtop.taobao.idle.ad.campaign.pause', { campaignIds: [Number(cid)], pauseStatus: act === 'start' ? 0 : 1 }, 'POST');
                alert('✅ ' + label + ' ' + cid);
            } catch(e) { alert('操作失败: ' + (e && e.message ? e.message : e)); }
            await refreshCampaignList(m);
        });
    }
    async function pauseAllCampaigns(m) {
        let list = []; try { list = await getAllCampaigns(); } catch(e) {}
        const ids = list.map(c => String(c.campaignId || c.id)).filter(Boolean);
        if (!ids.length) { alert('无计划'); return; }
        if (!confirm('确认暂停全部 ' + ids.length + ' 个计划？')) return;
        let ok = 0, fail = 0;
        for (let i = 0; i < ids.length; i += 20) {
            const batch = ids.slice(i, i + 20);
            try { await mtopR('mtop.taobao.idle.ad.campaign.pause', { campaignIds: batch.map(Number), pauseStatus: 1 }, 'POST'); ok += batch.length; }
            catch(e) { console.log('[擦亮] pause失败 ret=', e); fail += batch.length; }
        }
        alert('✅ 已暂停 ' + ok + ' 个，失败 ' + fail);
        await refreshCampaignList(m);
    }
    async function restartAllCampaigns(m) {
        let list = []; try { list = await getAllCampaigns(); } catch(e) {}
        const ids = list.map(c => String(c.campaignId || c.id)).filter(Boolean);
        if (!ids.length) { alert('无计划'); return; }
        if (!confirm('确认重启全部 ' + ids.length + ' 个计划？')) return;
        let ok = 0, fail = 0;
        for (let i = 0; i < ids.length; i += 20) {
            const batch = ids.slice(i, i + 20);
            try { await mtopR('mtop.taobao.idle.ad.campaign.pause', { campaignIds: batch.map(Number), pauseStatus: 0 }, 'POST'); ok += batch.length; }
            catch(e) { console.log('[擦亮] start失败 ret=', e); fail += batch.length; }
        }
        alert('✅ 已重启 ' + ok + ' 个，失败 ' + fail);
        await refreshCampaignList(m);
    }
    // 勾选批量：pause(停)/restore(启)/delete(删)
    async function selectedCampaigns(m, op) {
        const cbs = m.querySelectorAll('.campaign-cb:checked');
        const ids = [].slice.call(cbs).map(cb => cb.getAttribute('data-cid')).filter(Boolean);
        if (!ids.length) { alert('请先勾选计划'); return; }

        // 删除：唯一审批出口，弹框逐条列出标题与 ID，默认取消
        if (op === 'delete') {
            let all = []; try { all = await getAllCampaigns(); } catch(e) {}
            const picked = ids.map(id => all.filter(c => String(c.campaignId || c.id) === id)[0] || id);
            const r = await deleteCampaignsWithApproval(picked);
            if (!r.approved) return;
            alert('✅ 已删除 ' + r.ok + ' 个，失败 ' + r.fail);
            await refreshCampaignList(m);
            return;
        }

        const label = op === 'pause' ? '暂停' : '重启';
        if (!confirm('确认' + label + '选中 ' + ids.length + ' 个计划？')) return;
        let okc = 0, fail = 0;
        for (let i = 0; i < ids.length; i += 20) {
            const batch = ids.slice(i, i + 20);
            try {
                await mtopR('mtop.taobao.idle.ad.campaign.pause', { campaignIds: batch.map(Number), pauseStatus: op === 'pause' ? 1 : 0 }, 'POST');
                okc += batch.length;
            } catch(e) { console.log('[擦亮] ' + op + '失败 ret=', e); fail += batch.length; }
        }
        alert('✅ ' + label + '选中 ' + okc + ' 个，失败 ' + fail);
        await refreshCampaignList(m);
    }
    // 搜索关键词 → 停掉所有标题含该词的计划（如：孙燕姿）
    async function pauseByKeyword(m) {
        const kw = (m.querySelector('#kcmsearch') && m.querySelector('#kcmsearch').value || '').trim();
        if (!kw) { alert('请输入关键词（如：孙燕姿）'); return; }
        let list = []; try { list = await getAllCampaigns(); } catch(e) {}
        const matched = list.filter(function(c){ const t = (((c.entityList && c.entityList[0] && c.entityList[0].title) || '') + '|' + (c.campaignName || c.title || '')); return t.indexOf(kw) >= 0; });
        if (!matched.length) { alert('没有找到含「' + kw + '」的计划'); return; }
        const ids = matched.map(c => String(c.campaignId || c.id)).filter(Boolean);
        if (!confirm('确认停掉含「' + kw + '」的 ' + ids.length + ' 个计划？')) return;
        let ok = 0, fail = 0;
        for (let i = 0; i < ids.length; i += 20) {
            const batch = ids.slice(i, i + 20);
            try { await mtopR('mtop.taobao.idle.ad.campaign.pause', { campaignIds: batch.map(Number), pauseStatus: 1 }, 'POST'); ok += batch.length; }
            catch(e) { console.log('[擦亮] 停关键词失败 ret=', e); fail += batch.length; }
        }
        alert('✅ 已停 ' + ok + ' 个含「' + kw + '」的计划，失败 ' + fail);
        await refreshCampaignList(m);
    }
    // 搜索关键词 → 启用所有标题含该词的计划（如：孙燕姿）
    async function restartByKeyword(m) {
        const kw = (m.querySelector('#kcmsearch') && m.querySelector('#kcmsearch').value || '').trim();
        if (!kw) { alert('请输入关键词（如：孙燕姿）'); return; }
        let list = []; try { list = await getAllCampaigns(); } catch(e) {}
        const matched = list.filter(function(c){ const t = (((c.entityList && c.entityList[0] && c.entityList[0].title) || '') + '|' + (c.campaignName || c.title || '')); return t.indexOf(kw) >= 0; });
        if (!matched.length) { alert('没有找到含「' + kw + '」的计划'); return; }
        const ids = matched.map(c => String(c.campaignId || c.id)).filter(Boolean);
        if (!confirm('确认启用含「' + kw + '」的 ' + ids.length + ' 个计划？')) return;
        let ok = 0, fail = 0;
        for (let i = 0; i < ids.length; i += 20) {
            const batch = ids.slice(i, i + 20);
            try { await mtopR('mtop.taobao.idle.ad.campaign.pause', { campaignIds: batch.map(Number), pauseStatus: 0 }, 'POST'); ok += batch.length; }
            catch(e) { console.log('[擦亮] 启关键词失败 ret=', e); fail += batch.length; }
        }
        alert('✅ 已启用 ' + ok + ' 个含「' + kw + '」的计划，失败 ' + fail);
        await refreshCampaignList(m);
    }
    // 批量改名：¥{出价}·{订单/咨询}·{城市明星}（campaign.edit itemCampaigns.title）
    async function renameAllCampaigns(m) {
        let list = []; try { list = await getAllCampaigns(); } catch(e) {}
        const ids = list.map(c => String(c.campaignId || c.id)).filter(Boolean);
        if (!ids.length) { alert('无计划'); return; }
        if (!confirm('确认把 ' + ids.length + ' 个计划改成「¥出价·订单/咨询·城市明星」？')) return;
        let ok = 0, fail = 0, errs = [];
        for (let i = 0; i < list.length; i++) {
            const c = list[i]; const cid = String(c.campaignId || c.id);
            const bidYuan = ((c.infoTab && c.infoTab.bidPrice) ? (c.infoTab.bidPrice / 100) : ((c.bidPrice || 13.6) / 100));
            const bidTarget = c.bidTarget || 'order';
            const title = ((c.entityList && c.entityList[0] && c.entityList[0].title) || '') || c.title || c.campaignName;
            const _t = (title || '').replace(/【[^】]*】/g, '').replace(/[¥￥·\-_0-9\s]/g, '').replace(/订单量|集合全站明星|全站明星|集合|专业团队|订单|咨询|演唱会|音乐会|接代拍|代拍|代抢|首开|二开|三开|场次|代购|擦亮宝贝|巡回|巡演|抢票|接代抢/g, '').trim();
            const _city = (_t.match(/[\u4e00-\u9fa5]{2,5}站/) || [''])[0];
            const _rest = _t.replace(_city, '');
            const _star = (_rest.match(/[\u4e00-\u9fa5]{2,4}/) || [''])[0];
            var cityStar = (_city + _star).replace(/(.+?)\1+/g, '$1');
            if (!cityStar) cityStar = '集合';
            const newTitle = '¥' + bidYuan + '·' + (bidTarget === 'order' ? '订单' : '咨询') + '·' + cityStar;
            try {
                const body = { itemCampaigns: [{ campaignId: Number(cid), feedEntityType: 1, targetInfo: { divisionList: [], empty: true }, title: newTitle }] };
                await mtopR('mtop.taobao.idle.ad.campaign.edit', body, 'POST'); ok++;
            } catch(e) { fail++; errs.push(cid + ':' + (e && e.message ? e.message : e)); }
        }
        alert('✅ 已改名 ' + ok + '，失败 ' + fail + (errs.length ? '\n失败:' + errs.slice(0,3).join(',') : ''));
        await refreshCampaignList(m);
    }

    // ===== 复制功能 =====
    function copySummary() {
        if (!monitorData || !monitorData.summary) return alert('暂无数据，请先刷新');
        const s = monitorData.summary;
        doCopy(fmt(s.cost) + '\t' + (s.clickPv||0) + '\t' + (s.chatPv||0) + '\t' + (s.inquiries||0), 1);
    }

    function buildTableRows(data) {
        const rows = [];
        if (data.summary) {
            const s = data.summary;
            rows.push(fmt(s.cost) + '\t' + (s.clickPv||0) + '\t' + (s.chatPv||0) + '\t' + (s.inquiries||0));
        }
        return rows.join('\n');
    }

    function copyTable() {
        if (!monitorData || !monitorData.campaigns || monitorData.campaigns.length === 0) return alert('暂无数据，请先刷新');
        doCopy(buildTableRows(monitorData), 1);
    }

    async function copyYesterdayTable() {
        try {
            const yesterday = new Date(); yesterday.setDate(yesterday.getDate() - 1);
            const d = yesterday.toISOString().slice(0, 10).replace(/-/g, '');
            const btn = document.getElementById('kcb3'); if (btn) btn.textContent = '⏳ 加载中...';
            const data = await fetchDateData(d);
            if (!data.campaigns || data.campaigns.length === 0) { if (btn) btn.textContent = '📋 昨日'; return alert(d + ' 暂无数据'); }
            doCopy(buildTableRows(data), 1); if (btn) btn.textContent = '📋 昨日';
        } catch(e) { console.error(e); const btn = document.getElementById('kcb3'); if (btn) btn.textContent = '❌ 失败'; setTimeout(() => { if(btn) btn.textContent = '📋 昨日'; }, 2000); }
    }

    async function copyRangeSummary(days) {
        const btn = document.getElementById('kcb' + (days === 7 ? '7' : '30'));
        if (btn) btn.textContent = '⏳ 加载中...';
        try {
            const end = new Date(), start = new Date(); start.setDate(start.getDate() - days + 1);
            const rows = []; let d = new Date(start); const endD = new Date(end);
            while (d <= endD) {
                const dateStr = d.toISOString().slice(0, 10).replace(/-/g, '');
                try {
                    const m = await mtopRequest('mtop.taobao.idle.ad.member.data.query', { startDate: dateStr, endDate: dateStr, includeEndDate: true });
                    if (m && m.data) rows.push(fmt(m.data.cost) + '\t' + (m.data.clickPv||0) + '\t' + (m.data.chatPv||0) + '\t' + (m.data.inquiries||0));
                    else rows.push('0.00\t0\t0\t0');
                } catch(e) { rows.push('0.00\t0\t0\t0'); }
                d.setDate(d.getDate() + 1);
            }
            doCopy(rows.join('\n'), days); if (btn) btn.textContent = '📋 ' + days + '天';
        } catch(e) { console.error(e); if (btn) btn.textContent = '❌ 失败'; setTimeout(() => { if(btn) btn.textContent = '📋 ' + days + '天'; }, 2000); }
    }

    async function copyCustomRange() {
        const startInput = document.getElementById('kdateStart'), endInput = document.getElementById('kdateEnd');
        if (!startInput.value || !endInput.value) return alert('请选择开始和结束日期');
        const btn = document.getElementById('kcbCustom'); if (btn) btn.textContent = '⏳ 加载中...';
        try {
            const rows = []; let d = new Date(startInput.value); const endD = new Date(endInput.value);
            while (d <= endD) {
                const dateStr = d.toISOString().slice(0, 10).replace(/-/g, '');
                try {
                    const m = await mtopRequest('mtop.taobao.idle.ad.member.data.query', { startDate: dateStr, endDate: dateStr, includeEndDate: true });
                    if (m && m.data) rows.push(fmt(m.data.cost) + '\t' + (m.data.clickPv||0) + '\t' + (m.data.chatPv||0) + '\t' + (m.data.inquiries||0));
                    else rows.push('0.00\t0\t0\t0');
                } catch(e) { rows.push('0.00\t0\t0\t0'); }
                d.setDate(d.getDate() + 1);
            }
            const count = Math.floor((endD - new Date(startInput.value)) / 86400000) + 1;
            doCopy(rows.join('\n'), count); if (btn) btn.textContent = '📋 复制';
        } catch(e) { console.error(e); if (btn) btn.textContent = '❌ 失败'; setTimeout(() => { if(btn) btn.textContent = '📋 复制'; }, 2000); }
    }

    // ===== 同步功能（仅4个字段） =====
    function buildSyncPayload(data, dateStr) {
        const fmtDate = dateStr.slice(0,4) + '-' + dateStr.slice(4,6) + '-' + dateStr.slice(6,8);
        return [{
            campaign_id: 'summary', name: '** 合计 **', date: fmtDate,
            cost: Number(data.cost) || 0, clickPv: Number(data.clickPv) || 0,
            chatPv: Number(data.chatPv) || 0, inquiries: Number(data.inquiries) || 0
        }];
    }

    // ===== 拉取闲鱼账户（从后台 API） =====
    async function fetchXianyuAccounts() {
        const btn = document.getElementById('kfetchAccts');
        if (btn) btn.textContent = '⏳ 拉取中...';
        try {
            const result = await new Promise((resolve, reject) => {
                const handler = (event) => {
                    if (event.data && event.data.type === 'FETCH_XIANYU_ACCOUNTS_RESULT') {
                        window.removeEventListener('message', handler);
                        if (event.data.success) resolve(event.data.data);
                        else reject(new Error(event.data.message));
                    }
                };
                window.addEventListener('message', handler);
                window.postMessage({ type: 'FETCH_XIANYU_ACCOUNTS' }, '*');
                setTimeout(() => { window.removeEventListener('message', handler); reject(new Error('超时')); }, 10000);
            });
            if (btn) btn.textContent = `✅ ${result.length} 账户`;
            alert(`已拉取 ${result.length} 个闲鱼账户：\n${result.map(a => `• ${a.name} (${a.username})`).join('\n')}`);
            setTimeout(() => { if(btn) btn.textContent = '🔑 拉取账户'; }, 3000);
        } catch(e) {
            if (btn) btn.textContent = '❌ 失败';
            alert('拉取账户失败: ' + e.message);
            setTimeout(() => { if(btn) btn.textContent = '🔑 拉取账户'; }, 3000);
        }
    }

    async function postSync(payload, btn, btnText, timeout) {
        window.postMessage({ type: 'SYNC_XIANYU_DATA', payload: payload }, '*');
        const result = await new Promise((resolve) => {
            const handler = (event) => {
                if (event.data && event.data.type === 'SYNC_XIANYU_RESULT') {
                    window.removeEventListener('message', handler); resolve(event.data);
                }
            };
            window.addEventListener('message', handler);
            setTimeout(() => { window.removeEventListener('message', handler); resolve({ success: false, message: '请求超时' }); }, timeout || 15000);
        });
        if (result.success) { if (btn) btn.textContent = '✅ 同步成功'; setTimeout(() => { if(btn) btn.textContent = btnText; }, 3000); }
        else throw new Error(result.message || '同步失败');
    }

    async function syncToBackend() {
        if (!monitorData || !monitorData.summary) return alert('暂无数据，请先刷新');
        const btn = document.getElementById('ksync'); if (btn) btn.textContent = '⏳ 同步中...';
        try {
            const s = monitorData.summary, dateStr = monitorData.date;
            const payload = buildSyncPayload(s, dateStr);
            await postSync(payload, btn, '🔄 同步后台', 15000);
        } catch(e) { console.error(e); if (btn) btn.textContent = '❌ 失败'; setTimeout(() => { if(btn) btn.textContent = '🔄 同步后台'; }, 3000); }
    }

    async function syncCustomToBackend() {
        const startInput = document.getElementById('kdateStart'), endInput = document.getElementById('kdateEnd');
        if (!startInput.value || !endInput.value) return alert('请选择开始和结束日期');
        const btn = document.getElementById('ksyncCustom'); if (btn) btn.textContent = '⏳ 同步中...';
        try {
            const campaigns = []; let d = new Date(startInput.value); const endD = new Date(endInput.value);
            while (d <= endD) {
                const dateStr = d.toISOString().slice(0, 10).replace(/-/g, '');
                try {
                    const m = await mtopRequest('mtop.taobao.idle.ad.member.data.query', { startDate: dateStr, endDate: dateStr, includeEndDate: true });
                    if (m && m.data) campaigns.push(buildSyncPayload(m.data, dateStr)[0]);
                } catch(e) {}
                d.setDate(d.getDate() + 1);
            }
            if (campaigns.length === 0) { if (btn) btn.textContent = '❌ 无数据'; setTimeout(() => { if(btn) btn.textContent = '⏫ 同步'; }, 2000); return; }
            window.postMessage({ type: 'SYNC_XIANYU_DATA', payload: campaigns }, '*');
            const result = await new Promise((resolve) => {
                const handler = (event) => {
                    if (event.data && event.data.type === 'SYNC_XIANYU_RESULT') { window.removeEventListener('message', handler); resolve(event.data); }
                };
                window.addEventListener('message', handler);
                setTimeout(() => { window.removeEventListener('message', handler); resolve({ success: false, message: '请求超时' }); }, 30000);
            });
            if (result.success) { if (btn) btn.textContent = '✅ ' + campaigns.length + '天同步成功'; setTimeout(() => { if(btn) btn.textContent = '⏫ 同步'; }, 3000); }
            else throw new Error(result.message || '同步失败');
        } catch(e) { console.error(e); if (btn) btn.textContent = '❌ 失败'; setTimeout(() => { if(btn) btn.textContent = '⏫ 同步'; }, 3000); }
    }

    // ===== 监听自动同步消息 =====
    window.addEventListener('message', async (event) => {
        if (event.data && event.data.type === 'AUTO_SYNC_YESTERDAY') {
            const yesterday = new Date(); yesterday.setDate(yesterday.getDate() - 1);
            const dateStr = yesterday.toISOString().slice(0, 10).replace(/-/g, '');
            try {
                const m = await mtopRequest('mtop.taobao.idle.ad.member.data.query', { startDate: dateStr, endDate: dateStr, includeEndDate: true });
                if (m && m.data) {
                    const payload = buildSyncPayload(m.data, dateStr);
                    window.postMessage({ type: 'SYNC_XIANYU_DATA', payload }, '*');
                }
            } catch(e) { console.log('自动同步失败:', e); }
        }
    });

    // ===== 操作台远程取数（通过 bridge.js 中转） =====
    window.addEventListener('message', async (event) => {
        const msg = event.data;
        if (msg && msg.type === 'FETCH_DATA') {
            try {
                const dateStr = msg.date || new Date().toISOString().slice(0, 10).replace(/-/g, '');
                const data = await fetchDateData(dateStr);
                window.postMessage({ type: 'FETCH_DATA_RESULT', requestId: msg.requestId, success: true, data: data }, '*');
            } catch(e) {
                window.postMessage({ type: 'FETCH_DATA_RESULT', requestId: msg.requestId, success: false, error: e.message || e }, '*');
            }
        }
        if (msg && msg.type === 'DISCOVER_FIELDS') {
            try {
                const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
                const raw = await mtopRequest('mtop.taobao.idle.ad.member.data.query', { startDate: dateStr, endDate: dateStr, includeEndDate: true });
                const campaigns = [];
                let page = 1, hasMore = true;
                while (hasMore) {
                    const r = await mtopRequest('mtop.taobao.idle.ad.campaign.search', { pageNum: page, pageSize: 10, startDate: dateStr, endDate: dateStr, includeEndDate: true, campaignStatus: [-6,-5,-4,-3,-2,1,2,3,4,6,99], statusGroup: [] });
                    if (r && r.result) { campaigns.push(...r.result); hasMore = r.nextPage === true; page++; } else hasMore = false;
                }
                const summaryFields = raw?.data ? Object.keys(raw.data) : [];
                const campaignFields = {};
                campaigns.forEach(c => {
                    const d = c.adDataDetailVO || c.adData || {};
                    Object.keys(d).forEach(k => { campaignFields[k] = (campaignFields[k] || 0) + 1; });
                });
                window.postMessage({ type: 'FETCH_DATA_RESULT', requestId: msg.requestId, success: true, fields: { summary: summaryFields, campaign: Object.entries(campaignFields).sort((a,b) => b[1]-a[1]).map(e => e[0]) } }, '*');
            } catch(e) {
                window.postMessage({ type: 'FETCH_DATA_RESULT', requestId: msg.requestId, success: false, error: e.message || e }, '*');
            }
        }
    });

    // ===== 其他工具函数 =====
    function showCopyTip(count) {
        const el = document.createElement('div');
        el.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#27ae60;color:#fff;padding:20px 32px;border-radius:12px;font-size:16px;z-index:999999;box-shadow:0 4px 20px rgba(0,0,0,0.3);font-family:system-ui,sans-serif;';
        el.textContent = '✅ 已复制 ' + count + ' 条数据，去WPS按 Ctrl+V 粘贴';
        document.body.appendChild(el); setTimeout(() => el.remove(), 2500);
    }

    function doCopy(text, count) {
        const tip = () => showCopyTip(count);
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(tip).catch(() => { const ta = document.createElement('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;left:-9999px;top:0;'; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); tip(); });
        } else { const ta = document.createElement('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;left:-9999px;top:0;'; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); tip(); }
    }

    function exportCSV() {
        if (historyData.length === 0) return alert('暂无历史数据');
        let csv = '日期,推广费(元),点击量,询单量,咨询数\n';
        historyData.forEach(r => { (r.campaigns||[]).forEach(camp => { const d = camp.adData||{}; csv += r.date + ',' + fmt(d.cost) + ',' + (d.clickPv||0) + ',' + (d.chatPv||0) + ',' + (d.inquiries||0) + '\n'; }); });
        const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = '闲鱼数据_' + new Date().toISOString().slice(0,10) + '.csv'; link.click(); URL.revokeObjectURL(link.href);
    }


    function saveCampaignData(dateStr, campaigns) {
        try {
            let db = JSON.parse(localStorage.getItem(TREND_KEY)) || {};
            db[dateStr] = (campaigns||[]).map(c => ({
                id: c.campaignId || c.id,
                name: getCampaignName(c),
                cost: ((c.adDataDetailVO||c.adData||{}).cost||0),
                clickPv: ((c.adDataDetailVO||c.adData||{}).clickPv||0),
                impressionPv: getExp(c.adDataDetailVO||c.adData||{}),
                chatPv: ((c.adDataDetailVO||c.adData||{}).chatPv||0),
                inquiries: ((c.adDataDetailVO||c.adData||{}).inquiries||0)
            }));
            let keys = Object.keys(db).sort();
            if (keys.length > 30) {
                let newDb = {}; keys.slice(-30).forEach(k => { newDb[k] = db[k]; });
                db = newDb;
            }
            localStorage.setItem(TREND_KEY, JSON.stringify(db));
        } catch(e) { console.warn('save trend fail', e); }
    }

    function showTrend() {
        try {
            let db = JSON.parse(localStorage.getItem(TREND_KEY)) || {};
            let dates = Object.keys(db).sort();
            if (dates.length === 0) { alert('暂无历史数据，请先刷新获取今日数据'); return; }

            let products = {};
            dates.forEach(d => {
                (db[d]||[]).forEach(c => {
                    if (!products[c.id]) products[c.id] = { name: c.name, days: {} };
                    products[c.id].days[d] = c;
                });
            });

            let html = '<div style="padding:16px;">';
            html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">';
            html += '<span style="font-size:16px;font-weight:bold;">&#x1F4C8; 商品趋势（近' + dates.length + '天）</span>';
            html += '<button id="ktb" style="background:none;border:none;cursor:pointer;font-size:18px;color:#999;">&#x2715;</button></div>';
            html += '<div style="overflow-x:auto;max-height:65vh;overflow-y:auto;">';
            html += '<table style="width:100%;border-collapse:collapse;font-size:11px;white-space:nowrap;">';
            html += '<tr style="background:#4A90D9;color:#fff;">';
            html += '<th style="padding:6px;text-align:left;position:sticky;top:0;background:#4A90D9;min-width:120px;">商品</th>';
            html += '<th style="padding:6px;text-align:center;position:sticky;top:0;background:#4A90D9;">指标</th>';
            dates.forEach(d => {
                html += '<th style="padding:6px;text-align:center;position:sticky;top:0;background:#4A90D9;">' + d.slice(4,6) + '/' + d.slice(6,8) + '</th>';
            });
            html += '<th style="padding:6px;text-align:center;position:sticky;top:0;background:#4A90D9;">趋势</th>';
            html += '</tr>';

            const metrics = [
                { key: 'cost', label: '推广费', fmt: function(v) { return (v/100).toFixed(2); }, color: '#e67e22' },
                { key: 'clickPv', label: '点击', fmt: function(v) { return v; }, color: '#2980b9' },
                { key: 'impressionPv', label: '曝光', fmt: function(v) { return v; }, color: '#9b59b6' },
                { key: 'chatPv', label: '询单', fmt: function(v) { return v; }, color: '#8e44ad' },
                { key: 'inquiries', label: '咨询', fmt: function(v) { return v; }, color: '#16a085' },
            ];

            Object.keys(products).sort().forEach(pid => {
                let p = products[pid];
                metrics.forEach((m, mi) => {
                    html += '<tr style="border-bottom:1px solid #eee;';
                    if (mi === 0) html += 'border-top:2px solid #ddd;';
                    html += '">';
                    if (mi === 0) {
                        html += '<td style="padding:6px;font-weight:600;" rowspan="' + metrics.length + '">' + (p.name || pid) + '</td>';
                    }
                    html += '<td style="padding:4px 6px;text-align:center;color:' + m.color + ';">' + m.label + '</td>';
                    let vals = [];
                    dates.forEach(d => {
                        let v = p.days[d] ? p.days[d][m.key] || 0 : null;
                        vals.push(v);
                        html += '<td style="padding:4px 6px;text-align:right;">';
                        if (v !== null) html += m.fmt(v);
                        else html += '<span style="color:#ccc;">-</span>';
                        html += '</td>';
                    });
                    let first = vals.find(function(v) { return v !== null; });
                    let last = vals.slice().reverse().find(function(v) { return v !== null; });
                    html += '<td style="padding:4px 6px;text-align:center;font-weight:500;">';
                    if (first !== undefined && last !== undefined && first !== null && last !== null && first !== 0) {
                        let change = ((last - first) / first * 100).toFixed(1);
                        let icon = change > 0 ? '\ud83d\udcc8' : change < 0 ? '\ud83d\udcc9' : '\u27a1';
                        let color = change > 0 ? '#e74c3c' : change < 0 ? '#27ae60' : '#999';
                        html += '<span style="color:' + color + ';">' + icon + ' ' + (change > 0 ? '+' : '') + change + '%</span>';
                    } else {
                        html += '<span style="color:#ccc;">-</span>';
                    }
                    html += '</td></tr>';
                });
            });

            html += '</table></div></div>';

            let oldPnl = document.getElementById('kun-monitor-panel');
            if (oldPnl) {
                oldPnl.innerHTML = html;
                document.getElementById('ktb').onclick = function() { oldPnl.style.display = 'none'; };
            }
        } catch(e) {
            alert('趋势加载失败: ' + e.message);
            console.error(e);
        }
    }

    function saveHistory(data) {
        const cmp = { date: data.date, time: data.time, summary: { cost: data.summary?.cost, clickPv: data.summary?.clickPv, impressionPv: getExp(data.summary), chatPv: data.summary?.chatPv, inquiries: data.summary?.inquiries }, campaigns: (data.campaigns||[]).map(c => ({ campaignId: c.campaignId||c.id, adData: c.adDataDetailVO||c.adData||{} })) };
        const last = historyData.length > 0 ? historyData[historyData.length - 1] : null;
        if (last && last.date === cmp.date && last.time === cmp.time) historyData[historyData.length - 1] = cmp;
        else historyData.push(cmp);
        if (historyData.length > 500) historyData = historyData.slice(-500);
    }

    let isLoading = false;
    async function refreshData() {
        if (isLoading) return; isLoading = true;
        const btn = document.getElementById('krb'); if (btn) btn.textContent = '⏳ 加载中...';
        try {
            const data = await fetchTodayData();
            const pnl = renderPanel(data); pnl.style.display = 'block';
            saveHistory(data); monitorData = data; if (btn) btn.textContent = '🔄 刷新';
        } catch(e) { console.error(e); if (btn) btn.textContent = '❌ 失败'; setTimeout(() => { if(btn) btn.textContent = '🔄 刷新'; }, 2000); }
        isLoading = false;
    }

    const trigger = document.createElement('div');
    trigger.id = 'kun-trigger-btn';
    trigger.style.cssText = 'position:fixed !important;top:60px !important;right:20px !important;z-index:2147483647 !important;background:#ff6600 !important;color:#fff !important;padding:12px 24px !important;border-radius:8px !important;font-size:15px !important;cursor:pointer !important;box-shadow:0 6px 20px rgba(0,0,0,0.5) !important;font-family:system-ui,sans-serif !important;font-weight:700 !important;border:3px solid #fff !important;';
    trigger.textContent = '📊 数据监控';
    trigger.onclick = function() {
        const pnl = document.getElementById('kun-monitor-panel');
        if (pnl) { if (pnl.style.display === 'none') { pnl.style.display = 'block'; if (monitorData.length === 0) refreshData(); } else pnl.style.display = 'none'; }
        else refreshData();
    };
    document.body.appendChild(trigger);

    let retries = 0;
    const check = setInterval(() => {
        if (window.lib && window.lib.mtop && window.lib.mtop.request) {
            clearInterval(check); console.log('✅ 闲鱼监控已就绪');
        } else { retries++; if (retries > 30) { clearInterval(check); trigger.textContent = '❌ 加载失败，刷新重试'; } }
    }, 1000);
})();
