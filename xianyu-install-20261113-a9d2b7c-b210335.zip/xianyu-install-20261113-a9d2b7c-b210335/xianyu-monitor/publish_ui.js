// 闲鱼演唱会代拍每日发布 - UI v2.2
(function() {
'use strict';
// 移除旧的按钮，允许重新初始化
var oldBtn = document.getElementById('kun-publish-btn');
if (oldBtn) { oldBtn.remove(); }
var oldPanel = document.getElementById('kun-publish-panel');
if (oldPanel) { oldPanel.remove(); }
var P = null;

function wait(fn, n) {
 n = n || 0;
 if (window.kunPublish) { P = window.kunPublish; fn(); return; }
 if (n > 80) return;
 setTimeout(function() { wait(fn, n + 1); }, 150);
}
wait(function() { init(); });

function init() {
 var btn = document.createElement('div');
 btn.id = 'kun-publish-btn';
 btn.textContent = '🎫 每日发布';
 btn.style.cssText = 'position:fixed;top:80px;right:12px;z-index:99999;background:linear-gradient(135deg,#E67E22,#D35400);color:#fff;padding:12px 20px;border-radius:50px;font-size:14px;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.3);font-family:system-ui,sans-serif;font-weight:500;';

 var panel = document.createElement('div');
 panel.id = 'kun-publish-panel';
 panel.style.cssText = 'position:fixed;top:140px;right:12px;z-index:99998;background:#fff;border:1px solid #ddd;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,0.15);width:580px;max-height:85vh;overflow-y:auto;font-family:system-ui,sans-serif;font-size:13px;display:none;padding:16px;';

 document.body.appendChild(btn);
 document.body.appendChild(panel);

 btn.onclick = function() {
  if (panel.style.display === 'none') { show(); panel.style.display = 'block'; }
  else panel.style.display = 'none';
 };
}

async function show() {
 var panel = document.getElementById('kun-publish-panel');
 if (!panel || !P) return;

 // 监听日志事件
 if (!window._kunLogListener) {
  window._kunLogListener = true;
  window.addEventListener('kun-daily-log', function(e) {
   if (e.detail) appendLog(e.detail.msg, e.detail.time);
  });
 }

 renderPanel(panel);
 refreshStatus();
}

function renderPanel(panel) {
 var data = P.loadDailyTasks();
 var store = P.currentStore;
 var stores = P.getStores();
 var isRecruit = (P.getStoreProject(store) === 'recruit');
 var isYuxiaopu = (P.getStoreProject(store) === 'yuxiaopu');
 var isCasa = store && store.indexOf('casa') === 0;
 var isSimple = true; // 统一简化面板
 var activeTemplate = data.templateId || 1;
 var tpls = isRecruit ? (P.DEFAULT_TEMPLATES || []) : P.CONCERT_TEMPLATES;

 panel.innerHTML =
  '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">' +
   '<span style="font-size:16px;font-weight:bold;">🏪 店铺管理</span>' +
   '<button id="kp-close" style="background:none;border:none;cursor:pointer;font-size:18px;color:#999;">✕</button>' +
  '</div>' +

  // === 项目选择 ===
  '<div style="margin-bottom:10px;background:#fef9f0;border-radius:8px;padding:10px;">' +
   '<div style="display:flex;align-items:center;gap:8px;">' +
    '<span style="font-size:13px;font-weight:500;">📁 项目：</span>' +
    '<select id="kp-project" style="padding:6px 8px;border:1px solid #ddd;border-radius:4px;font-size:12px;">' +
     '<option value="concert"' + (!isRecruit ? ' selected' : '') + '>演唱会代拍</option>' +
     '<option value="recruit"' + (isRecruit ? ' selected' : '') + '>招抢手</option>' +
     '<option value="yuxiaopu"' + (isYuxiaopu ? ' selected' : '') + '>鱼小铺</option>' +
    '</select>' +
   '</div>' +
  '</div>' +

  // === 店铺 ===
  '<div style="margin-bottom:10px;background:#f0f7ff;border-radius:8px;padding:10px;">' +
   '<div style="font-weight:500;margin-bottom:6px;">🏪 当前店铺</div>' +
   '<div style="display:flex;gap:6px;">' +
    '<select id="kp-store" style="flex:1;min-width:100px;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:13px;">' +
     stores.map(function(s) { return '<option value="' + s + '"' + (store === s ? ' selected' : '') + '>' + s + '</option>'; }).join('') +
     '<option value="" disabled>── 管理 ──</option>' +
     '<option value="__add__">➕ 新增店铺</option>' +
    '</select>' +
    '<button id="kp-save-store" style="background:#4A90D9;color:#fff;border:none;border-radius:6px;padding:8px 12px;cursor:pointer;font-size:12px;">保存</button>' +
    '<button id="kp-rename-store" style="background:#f0ad4e;color:#fff;border:none;border-radius:6px;padding:8px 10px;cursor:pointer;font-size:11px;">✏️ 重命名</button>' +
    '<button id="kp-del-store" style="background:#e74c3c;color:#fff;border:none;border-radius:6px;padding:8px 10px;cursor:pointer;font-size:11px;">🗑 删除</button>' +
    '<button id="kp-store-cfg" style="background:#8e44ad;color:#fff;border:none;border-radius:6px;padding:8px 10px;cursor:pointer;font-size:11px;">⚙️ 配置</button>' +
    '<button id="kp-reply-cfg" style="background:#16a085;color:#fff;border:none;border-radius:6px;padding:8px 10px;cursor:pointer;font-size:11px;">💬 回复</button>' +
   '</div>' +
   '<div id="kp-store-hint" style="margin-top:4px;font-size:11px;color:#999;display:none;"></div>' +
   '<div id="kp-store-account" style="margin-top:2px;font-size:10px;color:#999;"></div>' +
   '<div style="margin-top:4px;"><button id="kp-save-cookie" style="background:#f0ad4e;color:#fff;border:none;border-radius:4px;padding:3px 8px;cursor:pointer;font-size:10px;">💾 保存登录</button>' +
   '<button id="kp-load-cookie" style="background:#4A90D9;color:#fff;border:none;border-radius:4px;padding:3px 8px;margin-left:4px;cursor:pointer;font-size:10px;">📂 切换账号</button></div>' +
  '</div>' +

  '<div style="background:#fef9f0;border-radius:8px;padding:10px;font-size:11px;color:#8a6d3b;">📌 任务、图片、搬运、发布等操作请到「🚀 闲鱼发布台」操作（localhost:8093/publish_dashboard.html）</div>';

 // === 渲染表格行（面板精简后无表格，函数内部有判空保护） ===
 renderTaskRows(data.tasks || [], isRecruit, isSimple);
 fetchAccountInfo(store);
 bindCookieBtns();

 // === 精简面板事件绑定 ===
 document.getElementById('kp-close').onclick = function() { panel.style.display = 'none'; };

 // 选店铺 → 加载目标店铺Cookie → 刷新
 document.getElementById('kp-store').onchange = function() {
  var v = this.value;
  if (!v || v.startsWith('__')) return;
  var hint = document.getElementById('kp-store-hint');
  hint.textContent = '⏳ 切换中...'; hint.style.display = 'block';
  P.setStore(v);
  window.addEventListener('message', function loadHandler(e) {
   if (e.data && e.data.type === 'LOAD_COOKIE_RESULT') {
    window.removeEventListener('message', loadHandler);
    if (e.data.ok) {
     hint.textContent = '✅ 已切换，刷新中...';
     setTimeout(function(){ location.reload(); }, 500);
    } else {
     hint.textContent = '⚠ 该店铺未保存登录，请手动登录后点 💾保存登录';
     setTimeout(function(){ hint.style.display = 'none'; }, 5000);
    }
   }
  });
  window.postMessage({ type: 'LOAD_COOKIE', store: v }, '*');
 };

 // 自动切换：选项目 → 找对应店铺；无匹配则提示新增
 document.getElementById('kp-project').onchange = function() {
  var proj = this.value;
  var stores = P.getStores();
  var matchedStore = null;
  for (var si = 0; si < stores.length; si++) {
   if (P.getStoreProject(stores[si]) === proj) { matchedStore = stores[si]; break; }
  }
  if (matchedStore) {
   P.setStore(matchedStore);
   show();
  } else {
   var projName = proj === 'concert' ? '演唱会代拍' : proj === 'recruit' ? '招抢手' : proj === 'yuxiaopu' ? '鱼小铺' : proj;
   var name = prompt('没有店铺绑定「' + projName + '」\n输入店铺名称（新名称或已有店铺名）：');
   if (name && name.trim()) {
    var nm = name.trim();
    P.setStoreProject(nm, proj);
    P.addStore(nm);
    P.setStore(nm);
    show();
   }
  }
 };

 document.getElementById('kp-save-store').onclick = function() {
  var sel = document.getElementById('kp-store').value;
  var hint = document.getElementById('kp-store-hint');
  if (sel === '__add__') {
   var name = prompt('输入新店铺名称：');
   if (name && name.trim()) {
    var proj = prompt('选项目：\n1 = 演唱会代拍\n2 = 招抢手\n3 = 鱼小铺\n\n输入数字后回车', '1');
    P.setStoreProject(name.trim(), proj === '2' ? 'recruit' : proj === '3' ? 'yuxiaopu' : 'concert');
    if (P.addStore(name.trim())) { hint.textContent = '✅ 已添加「' + name.trim() + '」'; hint.style.display = 'block'; }
    else { hint.textContent = '⚠ 已存在或名称无效'; hint.style.display = 'block'; }
   }
   show();
  } else {
   P.setStore(sel);
   hint.textContent = '⏳ 切换中...'; hint.style.display = 'block';
   window.addEventListener('message', function loadHandler(e) {
    if (e.data && e.data.type === 'LOAD_COOKIE_RESULT') {
     window.removeEventListener('message', loadHandler);
     if (e.data.ok) {
      hint.textContent = '✅ 已切换，刷新中...';
      setTimeout(function(){ location.reload(); }, 500);
     } else {
      hint.textContent = '⚠ 该店铺未保存登录，请手动登录后点 💾保存登录';
      setTimeout(function(){ hint.style.display = 'none'; }, 5000);
     }
    }
   });
   window.postMessage({ type: 'LOAD_COOKIE', store: sel }, '*');
  }
 };

 document.getElementById('kp-rename-store').onclick = function() {
  var hint = document.getElementById('kp-store-hint');
  var curStore = document.getElementById('kp-store').value;
  if (!curStore || curStore.startsWith('__')) { hint.textContent = '⚠ 请先选择店铺'; hint.style.display = 'block'; return; }
  var newName = prompt('重命名「' + curStore + '」为：', curStore);
  if (newName && newName.trim() && newName.trim() !== curStore) {
   var list = P.getStores(); var idx = list.indexOf(curStore);
   if (idx >= 0) { list[idx] = newName.trim(); P.setStore(newName.trim()); }
   localStorage.setItem('kun_stores', JSON.stringify(list));
   hint.textContent = '✅ 已重命名「' + curStore + '」→「' + newName.trim() + '」'; hint.style.display = 'block';
   show();
  }
 };

 document.getElementById('kp-del-store').onclick = function() {
  var hint = document.getElementById('kp-store-hint');
  var curStore = document.getElementById('kp-store').value;
  if (!curStore || curStore.startsWith('__')) { hint.textContent = '⚠ 请先选择店铺'; hint.style.display = 'block'; return; }
  if (confirm('确定删除店铺「' + curStore + '」？')) {
   P.removeStore(curStore);
   hint.textContent = '🗑 已删除「' + curStore + '」'; hint.style.display = 'block';
   show();
  }
 };

 var _scBtn = document.getElementById('kp-store-cfg');
 if (_scBtn) _scBtn.onclick = function() { showStoreConfig(); };
 var _rcBtn = document.getElementById('kp-reply-cfg');
 if (_rcBtn) _rcBtn.onclick = function() { showReplyConfig(); };

 return; // 面板已精简，跳过下方旧版块的绑定

 // === 以下为旧版绑定（面板精简后不再执行） ===
 // === 渲染表格行 ===
 renderTaskRows(data.tasks || [], isRecruit, isSimple);
 fetchAccountInfo(store);
 bindCookieBtns();

 // === 事件绑定 ===
 document.getElementById('kp-close').onclick = function() { panel.style.display = 'none'; };

 // 店铺
 // 选店铺 → 加载目标店铺Cookie → 刷新
 document.getElementById('kp-store').onchange = function() {
  var v = this.value;
  if (v === '__add__') return;
  if (!v || v.startsWith('__')) return;
  var hint = document.getElementById('kp-store-hint');
  hint.textContent = '⏳ 切换中...'; hint.style.display = 'block';
  P.setStore(v);
  window.addEventListener('message', function loadHandler(e) {
   if (e.data && e.data.type === 'LOAD_COOKIE_RESULT') {
    window.removeEventListener('message', loadHandler);
    if (e.data.ok) {
     hint.textContent = '✅ 已切换，刷新中...';
     setTimeout(function(){ location.reload(); }, 500);
    } else {
     hint.textContent = '⚠ 该店铺未保存登录，请手动登录后点 💾保存登录';
     setTimeout(function(){ hint.style.display = 'none'; }, 5000);
    }
   }
  });
  window.postMessage({ type: 'LOAD_COOKIE', store: v }, '*');
 };
  // 自动切换：选项目 → 找对应店铺；无匹配则提示新增
 document.getElementById('kp-project').onchange = function() {
  var proj = this.value;
  var stores = P.getStores();
  var matchedStore = null;
  // 找第一个绑定此项目的店铺
  for (var si = 0; si < stores.length; si++) {
   if (P.getStoreProject(stores[si]) === proj) { matchedStore = stores[si]; break; }
  }
  if (matchedStore) {
   // 找到 → 切过去
   P.setStore(matchedStore);
   show();
  } else {
   // 没有店铺绑定此项目 → 提示新增
   var projName = proj === 'concert' ? '演唱会代拍' : proj === 'recruit' ? '招抢手' : proj === 'yuxiaopu' ? '鱼小铺' : proj;
   var name = prompt('没有店铺绑定「' + projName + '」\n输入店铺名称（新名称或已有店铺名）：');
   if (name && name.trim()) {
    var nm = name.trim();
    P.setStoreProject(nm, proj);
    P.addStore(nm); // 新则添加，已存在则忽略
    P.setStore(nm);
    show();
   }
  }
 };
 document.getElementById('kp-save-store').onclick = function() {
  var sel = document.getElementById('kp-store').value;
  var hint = document.getElementById('kp-store-hint');
  if (sel === '__add__') {
   var name = prompt('输入新店铺名称：');
   if (name && name.trim()) {
    var proj = prompt('选项目：\n1 = 演唱会代拍\n2 = 招抢手\n3 = 鱼小铺\n\n输入数字后回车', '1');
    P.setStoreProject(name.trim(), proj === '2' ? 'recruit' : proj === '3' ? 'yuxiaopu' : 'concert');
    if (P.addStore(name.trim())) { hint.textContent = '✅ 已添加「' + name.trim() + '」'; hint.style.display = 'block'; }
    else { hint.textContent = '⚠ 已存在或名称无效'; hint.style.display = 'block'; }
   }
   show();
  } else {
   P.setStore(sel);
   hint.textContent = '⏳ 切换中...'; hint.style.display = 'block';
   window.addEventListener('message', function loadHandler(e) {
    if (e.data && e.data.type === 'LOAD_COOKIE_RESULT') {
     window.removeEventListener('message', loadHandler);
     if (e.data.ok) {
      hint.textContent = '✅ 已切换，刷新中...';
      setTimeout(function(){ location.reload(); }, 500);
     } else {
      hint.textContent = '⚠ 该店铺未保存登录，请手动登录后点 💾保存登录';
      setTimeout(function(){ hint.style.display = 'none'; }, 5000);
     }
    }
   });
   window.postMessage({ type: 'LOAD_COOKIE', store: sel }, '*');
  }
 };

 document.getElementById('kp-rename-store').onclick = function() {
  var hint = document.getElementById('kp-store-hint');
  var curStore = document.getElementById('kp-store').value;
  if (!curStore || curStore.startsWith('__')) { hint.textContent = '⚠ 请先选择店铺'; hint.style.display = 'block'; return; }
  var newName = prompt('重命名「' + curStore + '」为：', curStore);
  if (newName && newName.trim() && newName.trim() !== curStore) {
   var list = P.getStores(); var idx = list.indexOf(curStore);
   if (idx >= 0) { list[idx] = newName.trim(); P.setStore(newName.trim()); }
   localStorage.setItem('kun_stores', JSON.stringify(list));
   hint.textContent = '✅ 已重命名「' + curStore + '」→「' + newName.trim() + '」'; hint.style.display = 'block';
   show();
  }
 };

 document.getElementById('kp-del-store').onclick = function() {
  var hint = document.getElementById('kp-store-hint');
  var curStore = document.getElementById('kp-store').value;
  if (!curStore || curStore.startsWith('__')) { hint.textContent = '⚠ 请先选择店铺'; hint.style.display = 'block'; return; }
  if (confirm('确定删除店铺「' + curStore + '」？')) {
   P.removeStore(curStore);
   hint.textContent = '🗑 已删除「' + curStore + '」'; hint.style.display = 'block';
   show();
  }
 };

 // 模板选择（点击 label 触发 radio）
 var templateRadios = document.querySelectorAll('input[name="kp-template"]');
 for (var i = 0; i < templateRadios.length; i++) {
  (function(radio) {
   radio.parentNode.onclick = function(e) {
    if (e.target.tagName !== 'INPUT') { radio.checked = true; saveForm(); updateTemplateStyle(); }
   };
  })(templateRadios[i]);
 }

 function updateTemplateStyle() {
  var radios = document.querySelectorAll('input[name="kp-template"]');
  for (var j = 0; j < radios.length; j++) {
   radios[j].parentNode.style.background = radios[j].checked ? '#E67E22' : '#eee';
   radios[j].parentNode.style.color = radios[j].checked ? '#fff' : '#333';
  }
  saveForm();
 }

 // 模板编辑按钮
 document.getElementById('kp-edit-template').onclick = function() { showTemplateEditor(); };
 document.getElementById('kp-config-project').onclick = function() { window.postMessage({ type: 'OPEN_DASHBOARD' }, '*'); };
 var _scBtn = document.getElementById('kp-store-cfg');
 if (_scBtn) _scBtn.onclick = function() { showStoreConfig(); };

 // 图片 URL 保存
 document.getElementById('kp-image-url').onchange = function() { saveForm(); renderImgChips(); };
 document.getElementById('kp-image-url').oninput = renderImgChips;
 renderImgChips();

 // 上传本地图片
 document.getElementById('kp-upload-img').onclick = async function() {
  try {
   if (typeof P.pickLocalFile !== 'function') { log('⚠ 上传功能不可用'); return; }
   log('⏳ 选择图片...');
   var fileName = await P.pickLocalFile();
   if (!fileName) { log('⚠ 未选择文件'); return; }
   // 尝试自动添加到表格
   var dt = P.loadDailyTasks();
   if (!dt.tasks) dt.tasks = [];
   // 检查重复
   var _topStore = (typeof P.currentStore === 'function') ? P.currentStore() : P.currentStore;
   if (!_topStore) { try { _topStore = localStorage.getItem('kun_cur_store') || ''; } catch(e){} }
   {
     var _fn = fileName.replace(/^.*[\\/]/, '').trim();
     for (var _ci = 0; _ci < dt.tasks.length; _ci++) {
       var _cim = dt.tasks[_ci].imageUrls || [dt.tasks[_ci].imageUrl || ''];
       for (var _cj = 0; _cj < _cim.length; _cj++) {
         if ((_cim[_cj]||'').replace(/^.*[\\/]/, '').trim() === _fn) {
           log('⚠ 图片「' + _fn + '」已被使用，跳过');
           alert('⚠ 图片「' + _fn + '」已被使用，不可重复');
           return;
         }
       }
     }
   }
   if (typeof P.parseImageFileName === 'function') {
     var parsed = P.parseImageFileName(fileName);
     dt.tasks.push({ id: 't_' + Date.now() + '_' + Math.random().toString(36).substring(2,6), star: parsed.star || '', city: parsed.city || '', sessionType: parsed.sessionType || '首开', eventType: '演唱会', categoryName: '代购', price: '50', stock: '9999', imageUrl: fileName, status: 'pending', targetStore: P.currentStore || '' });
     P.saveDailyTasks(dt);
     show();
     log('✅ 已添加: ' + fileName);
   } else {
     document.getElementById('kp-image-url').value = fileName;
     saveForm();
     log('✅ 已选文件: ' + fileName);
   }
  } catch(e) {
   log('❌ 选图失败: ' + (e.message || e));
  }
 };

 // 批量上传：一次多选图片
 document.getElementById('kp-batch-upload').onclick = async function() {
  try {
   if (typeof P.pickLocalFiles !== 'function') { log('⚠ 批量功能不可用'); return; }
   var files = await P.pickLocalFiles();
   if (!files || files.length === 0) { log('⚠ 未选择文件'); return; }
   if (files.length > 10) files = files.slice(0, 10);
   var dt = P.loadDailyTasks();
   if (!dt.tasks) dt.tasks = [];
   log('📁 批量导入 ' + files.length + ' 张图片...');
   for (var k = 0; k < files.length; k++) {
    var fileName = files[k];
    // 跳过重复图片
    var _batchStore = (typeof P.currentStore === 'function') ? P.currentStore() : P.currentStore;
    if (!_batchStore) { try { _batchStore = localStorage.getItem('kun_cur_store') || ''; } catch(e){} }
    {
      var _bfn = fileName.replace(/^.*[\\/]/, '').trim();
      var _dup = false;
      // 检查已有任务
      for (var _bi = 0; _bi < dt.tasks.length; _bi++) {
        var _bim = dt.tasks[_bi].imageUrls || [dt.tasks[_bi].imageUrl || ''];
        for (var _bj = 0; _bj < _bim.length; _bj++) {
          if ((_bim[_bj]||'').replace(/^.*[\\/]/, '').trim() === _bfn) { _dup = true; break; }
        }
        if (_dup) break;
      }
      // 检查本轮已添加
      if (!_dup) {
        for (var _bk = 0; _bk < k; _bk++) {
          if (files[_bk].replace(/^.*[\\/]/, '').trim() === _bfn) { _dup = true; break; }
        }
      }
      if (_dup) { log('  ⚠ ' + _bfn + ' 已存在，跳过'); continue; }
    }
    if (typeof P.parseImageFileName === 'function') {
      var parsed = P.parseImageFileName(fileName);
      dt.tasks.push({ id: 't_' + Date.now() + '_' + k, star: parsed.star || '', city: parsed.city || '', sessionType: parsed.sessionType || '首开', eventType: '演唱会', categoryName: '代购', price: '50', stock: '9999', imageUrl: fileName, status: 'pending', targetStore: P.currentStore || '' });
      log('  ✅ ' + fileName);
    }
   }
   P.saveDailyTasks(dt); show(); log('🎉 批量导入完成，共 ' + files.length + ' 个任务');
  } catch(e) { log('❌ 失败: ' + (e.message || e)); }
 };

 
 // 添加/删除/清空行
 document.getElementById('kp-add-row').onclick = function() {
  var data = P.loadDailyTasks();
  if (!data.tasks) data.tasks = [];
  var _sc = (P.loadStoreConfig ? P.loadStoreConfig() : {});
  data.tasks.push({ id: 't_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6), star: '', city: '', sessionType: '首开', eventType: '演唱会', categoryName: _sc.category || '代购', price: _sc.price || '50', stock: _sc.stock || '9999', status: 'pending', targetStore: P.currentStore || '' });
  P.saveDailyTasks(data);
  renderTaskRows(data.tasks);
  renderImgChips();
  updateTaskCount();
 };

 document.getElementById('kp-del-row').onclick = function() {
  var data = P.loadDailyTasks();
  if (!data.tasks || data.tasks.length === 0) return;
  data.tasks.pop();
  P.saveDailyTasks(data);
  renderTaskRows(data.tasks);
  renderImgChips();
  updateTaskCount();
 };

 document.getElementById('kp-clear-tasks').onclick = function() {
  try {
   var data = P.loadDailyTasks();
   if (!data) data = {};
   data.tasks = [];
   P.saveDailyTasks(data);
   renderTaskRows(data.tasks);
   renderImgChips();
   updateTaskCount();
   log('🗑 已清空所有任务');
  } catch(e) { log('❌ 清空失败: ' + (e.message || e)); }
 };
 document.getElementById('kp-clear-tasks').style.cssText += ';background:#e74c3c !important;color:#fff !important;padding:6px 14px !important;font-size:12px !important;';

 // CASA搬运
 var _casaXy = document.getElementById('kp-casa-xianyu');
 var _casaTm = document.getElementById('kp-casa-tmall');
 var _casaSt = document.getElementById('kp-casa-status');
 function casaLog(m){if(_casaSt)_casaSt.textContent=m;}
 
 if (_casaXy) _casaXy.onclick = async function() {
  var url = document.getElementById('kp-casa-url').value.trim();
  if (!url) { casaLog('请输入闲鱼店铺地址'); return; }
  casaLog('正在抓取闲鱼店铺...');
  try {
   var r = await (await fetch('http://127.0.0.1:8093/api/agent/scrape-shop', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({store:P.currentStore,url:url,mode:'xianyu',limit:20})})).json();
   if (r.ok && r.items) {
    var dt = P.loadDailyTasks(); if (!dt.tasks) dt.tasks = [];
    for (var i=0;i<r.items.length;i++) {
     var it=r.items[i],ft='casa家居'+(it.title||''),st=ft.length>30?ft.substring(0,30):ft;
     dt.tasks.push({star:st,description:ft.length>30?'[完整标题:'+ft+']\n\n'+(it.description||''):(it.description||''),price:String(it.price||''),origPrice:'',imageUrls:it.images||(it.image?[it.image]:[]),city:'',categoryName:'',shipMode:'free',stock:'999'});
    }
    P.saveDailyTasks(dt); renderTaskRows();
    casaLog('抓取完成，'+r.items.length+' 个商品已添加');
   } else { casaLog('失败: '+(r.error||'未知')); }
  } catch(e) { casaLog('错误: '+(e.message||e)); }
 };
 
 if (_casaTm) _casaTm.onclick = async function() {
  var url = document.getElementById('kp-casa-url').value.trim();
  if (!url) { casaLog('请输入淘宝/天猫店铺地址'); return; }
  var mult = parseFloat(document.getElementById('kp-casa-mult').value) || 1;
  casaLog('正在抓取淘宝天猫店铺...');
  try {
   var r = await (await fetch('http://127.0.0.1:8093/api/agent/scrape-shop', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({store:P.currentStore,url:url,mode:'tmall',limit:20})})).json();
   if (r.ok && r.items) {
    var dt = P.loadDailyTasks(); if (!dt.tasks) dt.tasks = [];
    var descText='这款不是正品，是casa工厂代工，品牌的做工品质！\n\n有需要的咨询~';
    var tier1=['北京','上海','广州','深圳','杭州','成都','武汉','南京','重庆'];
    for (var i=0;i<r.items.length;i++) {
     var it=r.items[i],ft='CASA家居'+(it.title||''),st=ft.length>30?ft.substring(0,30):ft,fp=Math.round((it.price||0)*mult),rc=tier1[Math.floor(Math.random()*tier1.length)];
     dt.tasks.push({star:st,description:ft.length>30?'[完整标题:'+ft+']\n\n'+descText:descText,price:String(fp),origPrice:String(it.price||''),imageUrls:it.images||(it.image?[it.image]:[]),city:rc,categoryName:'装饰灯',shipMode:'free',stock:'999'});
    }
    P.saveDailyTasks(dt); renderTaskRows();
    casaLog('抓取完成，'+r.items.length+' 个商品已添加（价格x'+mult+'）');
   } else { casaLog('失败: '+(r.error||'未知')); }
  } catch(e) { casaLog('错误: '+(e.message||e)); }
 };

 // 海报生成
 var _posterMake = document.getElementById('kp-poster-make');
 var _posterAdd = document.getElementById('kp-poster-add');
 var _posterSt = document.getElementById('kp-poster-status');
 var _posterPv = document.getElementById('kp-poster-preview');
 var _lastPoster = null;
 function posterLog(m) { if (_posterSt) _posterSt.textContent = m; }
 if (_posterMake) _posterMake.onclick = async function() {
  var city = document.getElementById('kp-poster-city').value.trim();
  var star = document.getElementById('kp-poster-star').value.trim();
  if (!city || !star) { posterLog('请输入城市和明星'); return; }
  var variant = document.getElementById('kp-poster-variant').value;
  var date = document.getElementById('kp-poster-date').value.trim();
  var venue = document.getElementById('kp-poster-venue').value.trim();
  var price = document.getElementById('kp-poster-price').value.trim();
  var posterUrl = document.getElementById('kp-poster-url').value.trim();
  var source = document.getElementById('kp-poster-source').value;
  posterLog('⏳ 正在搜索海报并合成...');
  try {
   var r = await (await fetch('http://127.0.0.1:8093/api/poster/make', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({city:city,star:star,variant:variant,date:date,venue:venue,price:price,posterUrl:posterUrl,store:P.currentStore||'',source:source})})).json();
   if (r.ok && r.imageB64) {
    _lastPoster = r.imageB64;
    if (_posterPv) _posterPv.innerHTML = '<img src="data:image/jpeg;base64,' + r.imageB64 + '" style="max-width:180px;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,.25);">';
    if (_posterAdd) _posterAdd.style.display = '';
    posterLog('✅ 生成完成['+r.mode+']，点「加入任务」上架');
   } else posterLog('❌ ' + (r.error || '生成失败'));
  } catch(e) { posterLog('❌ 错误: ' + (e.message || e)); }
 };
 if (_posterAdd) _posterAdd.onclick = async function() {
  if (!_lastPoster) return;
  posterLog('⏳ 上传闲鱼图床...');
  try {
   var url = await P.uploadBase64ToCdn(_lastPoster);
   if (!url) { posterLog('❌ 上传失败'); return; }
   var city = document.getElementById('kp-poster-city').value.trim();
   var star = document.getElementById('kp-poster-star').value.trim();
   var variant = document.getElementById('kp-poster-variant').value;
   var dt = P.loadDailyTasks(); if (!dt.tasks) dt.tasks = [];
   dt.tasks.push({ id: 't_' + Date.now() + '_' + Math.random().toString(36).substring(2,6), star: star, city: city, sessionType: variant, eventType: '演唱会', categoryName: '代购', price: '50', stock: '9999', imageUrls: [url], status: 'pending', targetStore: P.currentStore || '' });
   P.saveDailyTasks(dt); renderTaskRows();
   posterLog('✅ 已加入任务列表');
   // 推送飞书卡片（CDN上传后才有公网图片URL）
   try {
    var date2 = document.getElementById('kp-poster-date').value.trim();
    var venue2 = document.getElementById('kp-poster-venue').value.trim();
    var price2 = document.getElementById('kp-poster-price').value.trim();
    var nr = await (await fetch('http://127.0.0.1:8093/api/poster/notify', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({city:city,star:star,variant:variant,date:date2,venue:venue2,price:price2,store:P.currentStore||'',imageUrl:url})})).json();
    if (nr.ok) posterLog('✅ 已加入任务 · 📮 飞书卡片已推送');
    else posterLog('✅ 已加入任务 · 📮 飞书推送失败: ' + (nr.error||''));
   } catch(e2) { posterLog('✅ 已加入任务 · 📮 飞书推送异常: ' + (e2.message||e2)); }
  } catch(e) { posterLog('❌ 错误: ' + (e.message || e)); }
 };

 // 开始/停止
 document.getElementById('kp-interval').onchange = function() { var d = P.loadDailyTasks(); d.publishInterval = parseInt(this.value); P.saveDailyTasks(d); };
 document.getElementById('kp-pubmode').onchange = function() { var d = P.loadDailyTasks(); d.pubMode = this.value; P.saveDailyTasks(d); };
 document.getElementById('kp-confirm-mode').onchange = function() { var d = P.loadDailyTasks(); d.confirmMode = this.checked; P.saveDailyTasks(d); };
 document.getElementById('kp-start').onclick = function() {
  // 保存当前表单
  saveForm();
  if (P.dailyRunning) { log('⚠ 已在运行中'); return; }
  P.startDailyPublish();
  refreshStatus();
  document.getElementById('kp-start').style.display = 'none';
  document.getElementById('kp-stop').style.display = 'block';
 };

 // 批量发布
 document.getElementById('kp-batch').onclick = function() {
  saveForm();
  if (!P) return;
  if (typeof P.runBatchPublish !== 'function') { log('⚠ 需刷新页面加载新版'); return; }
  if (P.batchRunning) { log('⚠ 批量已在运行中'); return; }
  log('🚀 启动批量发布...');
  P.runBatchPublish();
  refreshBatchStatus();
 };

 document.getElementById('kp-stop').onclick = function() {
  P.stopDailyPublish();
  if (typeof P.stopBatchPublish === 'function') P.stopBatchPublish();
  document.getElementById('kp-start').style.display = 'block';
  document.getElementById('kp-stop').style.display = 'none';
  refreshStatus();
 };

 updateTaskCount();
}

// ===== 渲染表格行 =====
function renderTaskRows(tasks, isRecruit, isSimple) {
 var container = document.getElementById('kp-task-rows');
 if (!container) return;
 if (typeof isRecruit === 'undefined') isRecruit = (P.getStoreProject(P.currentStore) === 'recruit');
 if (typeof isSimple === 'undefined') isSimple = true;
 if (!tasks || tasks.length === 0) {
  container.innerHTML = '<div style="text-align:center;padding:20px;color:#ccc;font-size:12px;">点击「➕ 添加」开始填写</div>';
  return;
 }

 var html = '';
 for (var i = 0; i < tasks.length; i++) {
  var t = tasks[i];
  var statusIcon = t.status === 'done' ? '✅' : (t.status === 'failed' ? '❌' : (t.status === 'pending' || !t.status ? '⬜' : '🔄'));

  if (isSimple) {
   html += '<div style="display:grid;grid-template-columns:180px 1fr 20px 20px 20px;gap:4px;margin-bottom:4px;align-items:center;">' +
    '<select class="kp-task-star" data-idx="' + i + '" style="padding:6px;border:1px solid #ddd;border-radius:4px;font-size:11px;">' +
     (P.CONCERT_TEMPLATES||[]).map(function(dt){return '<option value="'+dt.name+'"'+(t.star==dt.name?' selected':'')+'>'+dt.name+'</option>';}).join('') +
    '</select>' +
    '<div style="display:flex;gap:2px;">' +
     '<input class="kp-task-img" data-idx="' + i + '" value="' + escHtml(Array.isArray(t.imageUrls) ? t.imageUrls.join(',') : (t.imageUrl || '')) + '" placeholder="图片名 空格分隔" style="flex:1;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:11px;min-width:0;">' +
     '<button class="kp-row-upload" data-idx="' + i + '" style="background:#27ae60;color:#fff;border:none;border-radius:4px;padding:4px 6px;cursor:pointer;font-size:10px;" title="选本地图片上传">🖥</button>' +
     '<button class="kp-row-multi" data-idx="' + i + '" style="background:#8e44ad;color:#fff;border:none;border-radius:4px;padding:4px 6px;cursor:pointer;font-size:10px;margin-left:1px;" title="多选图片">📸</button>' +
    '</div>' +
    '<button class="kp-row-preview" data-idx="' + i + '" style="background:none;border:none;cursor:pointer;font-size:14px;padding:2px;" title="预览">👁</button>' +
    '<span class="kp-task-priority" data-idx="' + i + '" style="font-size:12px;cursor:pointer;user-select:none;opacity:' + (t.priority ? '1' : '0.3') + '" title="优先发布">⭐</span>' +
    (t.status === 'failed' ? '<button class="kp-row-retry" data-idx="' + i + '" style="font-size:13px;background:none;border:1px solid #e74c3c;border-radius:4px;cursor:pointer;padding:1px 4px;color:#e74c3c;">🔄</button>' : '<span style="font-size:14px;text-align:center;cursor:help;" title="' + (t.error || t.status || '') + '">' + statusIcon + '</span>') +
   '</div>';
   continue;
  }

  html += '<div style="display:grid;grid-template-columns:55px 50px 50px 55px 50px 45px 40px 1fr 18px 18px;gap:4px;margin-bottom:4px;align-items:center;">' +
   (isRecruit ? '<select class="kp-task-star" data-idx="' + i + '" style="padding:6px;border:1px solid #ddd;border-radius:4px;font-size:11px;">' + (P.DEFAULT_TEMPLATES||[]).map(function(dt,di){return '<option value="'+di+'"'+(t.star==dt.name?' selected':'')+'>'+dt.name+'</option>'}).join('') + '</select>' : '<input class="kp-task-star" data-idx="' + i + '" value="' + escHtml(t.star || '') + '" placeholder="明星" style="padding:6px;border:1px solid #ddd;border-radius:4px;font-size:12px;">') +
   '<input class="kp-task-city" data-idx="' + i + '" value="' + escHtml(t.city || '') + '" placeholder="城市" style="padding:6px;border:1px solid #ddd;border-radius:4px;font-size:12px;">' +
   '<select class="kp-task-event" data-idx="' + i + '" style="padding:6px;border:1px solid #ddd;border-radius:4px;font-size:11px;">' +
    ['演唱会','脱口秀','音乐节','戏剧','周年庆','音乐会','电竞赛事','动漫展','粉丝见面会','总决赛'].map(function(e) {
     return '<option value="' + e + '"' + ((t.eventType || '演唱会') === e ? ' selected' : '') + '>' + e + '</option>';
    }).join('') +
    '<option value="__custom__">自定义...</option>' +
   '</select>' +
   '<input class="kp-task-type" data-idx="' + i + '" value="' + escHtml(t.sessionType || '首开') + '" placeholder="场次(逗号分隔)" style="padding:6px;border:1px solid #ddd;border-radius:4px;font-size:11px;">' +
   '<input class="kp-task-cat" data-idx="' + i + '" value="' + escHtml(t.categoryName || '') + '" placeholder="分类" style="padding:6px;border:1px solid #ddd;border-radius:4px;font-size:11px;">' +
   '<input class="kp-task-price" data-idx="' + i + '" value="' + escHtml(t.price || '') + '" placeholder="价格" style="padding:6px;border:1px solid #ddd;border-radius:4px;font-size:11px;">' +
   '<input class="kp-task-stock" data-idx="' + i + '" value="' + escHtml(t.stock || '') + '" placeholder="库存" style="padding:6px;border:1px solid #ddd;border-radius:4px;font-size:11px;">' +
   '<div style="display:flex;gap:2px;">' +
    '<input class="kp-task-img" data-idx="' + i + '" value="' + escHtml(Array.isArray(t.imageUrls) ? t.imageUrls.join(',') : (t.imageUrl || '')) + '" placeholder="图片名 空格分隔" style="flex:1;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:11px;min-width:0;">' +
    '<button class="kp-row-upload" data-idx="' + i + '" style="background:#27ae60;color:#fff;border:none;border-radius:4px;padding:4px 6px;cursor:pointer;font-size:10px;" title="选本地图片上传">🖥</button>' +
   '<button class="kp-row-multi" data-idx="' + i + '" style="background:#8e44ad;color:#fff;border:none;border-radius:4px;padding:4px 6px;cursor:pointer;font-size:10px;margin-left:1px;" title="多选图片">📸</button>' +
   '</div>' +
   '<button class="kp-row-preview" data-idx="' + i + '" style="background:none;border:none;cursor:pointer;font-size:14px;padding:2px;" title="预览">👁</button>' +
   '<span class="kp-task-priority" data-idx="' + i + '" style="font-size:12px;cursor:pointer;user-select:none;opacity:' + (t.priority ? '1' : '0.3') + '" title="优先发布">⭐</span>' +
   (t.status === 'failed' ? '<button class="kp-row-retry" data-idx="' + i + '" style="font-size:13px;background:none;border:1px solid #e74c3c;border-radius:4px;cursor:pointer;padding:1px 4px;color:#e74c3c;">🔄</button>' : '<span style="font-size:14px;text-align:center;cursor:help;" title="' + (t.error || t.status || '') + '">' + statusIcon + '</span>') +
  '</div>';
 }
 container.innerHTML = html;

 // 绑定输入事件 - 实时保存
 var stars = container.querySelectorAll('.kp-task-star');
 var cities = container.querySelectorAll('.kp-task-city');
 var events = container.querySelectorAll('.kp-task-event');
 var types = container.querySelectorAll('.kp-task-type');
 var imgs = container.querySelectorAll('.kp-task-img');
 var cats = container.querySelectorAll('.kp-task-cat');
 var prices = container.querySelectorAll('.kp-task-price');
 var stocks = container.querySelectorAll('.kp-task-stock');
 var rowUploads = container.querySelectorAll('.kp-row-upload');
 var priorities = container.querySelectorAll(".kp-task-priority");
 var rowPreviews = container.querySelectorAll('.kp-row-preview');
 var retryBtns = container.querySelectorAll('.kp-row-retry');

 for (var i = 0; i < stars.length; i++) {
  (function(idx) {
   stars[idx].oninput = function() { saveForm(); };
   if (cities[idx]) cities[idx].oninput = function() { saveForm(); };
   if (events[idx]) events[idx].oninput = function() { saveForm(); };
   if (types[idx]) types[idx].oninput = function() { saveForm(); };
   imgs[idx].oninput = function() { saveForm(); };
   if (cats[idx]) cats[idx].oninput = function() { saveForm(); };
   if (prices[idx]) prices[idx].oninput = function() { saveForm(); };
   if (stocks[idx]) stocks[idx].oninput = function() { saveForm(); };
   // 行内上传图片
   rowUploads[idx].onclick = async function() {
    try {
     if (typeof P.pickLocalFile !== 'function') { log('⚠ 上传功能不可用'); return; }
     var fileName = await P.pickLocalFile();
     if (!fileName) return;
     // DEBUG: 确认代码在跑
     var _dbgStore = (typeof P.currentStore === 'function') ? P.currentStore() : P.currentStore;
     if (!_dbgStore) { try { _dbgStore = localStorage.getItem('kun_cur_store') || ''; } catch(e){} }
     console.log('[DEBUG] rowUpload clicked, store=' + _dbgStore + ' fileName=' + fileName);
     // 检查图片是否已被其他任务使用
     var _curStore = (typeof P.currentStore === 'function') ? P.currentStore() : P.currentStore;
     if (!_curStore) { try { _curStore = localStorage.getItem('kun_cur_store') || ''; } catch(e){} }
     {
       var _allTasks = (P.loadDailyTasks().tasks || []);
       var _fn = (fileName.replace(/^.*[\\/]/, '') || '').trim();
       var _dupRow = -1;
       for (var _oi = 0; _oi < _allTasks.length; _oi++) {
         if (_oi === idx) continue;
         var _oimgs = _allTasks[_oi].imageUrls || [_allTasks[_oi].imageUrl || ''];
         for (var _oj = 0; _oj < _oimgs.length; _oj++) {
           var _cmp = (_oimgs[_oj] || '').replace(/^.*[\\/]/, '').trim();
           if (_cmp && _cmp === _fn) { _dupRow = _oi; break; }
         }
         if (_dupRow >= 0) break;
       }
       if (_dupRow >= 0) {
         log('⚠ 图片「' + _fn + '」已被行 ' + (_dupRow+1) + ' 使用，跳过');
         alert('⚠ 图片「' + _fn + '」已被行 ' + (_dupRow+1) + ' 使用，不可重复');
         return;
       }
     }
     var curVal = imgs[idx].value.trim();
     imgs[idx].value = curVal ? curVal + ' ' + fileName : fileName;
     // 从文件名解析明星/城市/场次类型
     if (typeof P.parseImageFileName === 'function') {
       var parsed = P.parseImageFileName(fileName);
       if (parsed.star && stars[idx]) stars[idx].value = parsed.star;
       if (parsed.city && cities[idx]) cities[idx].value = parsed.city;
       if (parsed.sessionType && types[idx]) { types[idx].value = parsed.sessionType; }
     }
     saveForm();
     renderTaskRows(P.loadDailyTasks().tasks || []);
     log('✅ 行 ' + (idx + 1) + ' 已选: ' + fileName);
    } catch(e) {
     log('❌ 选图失败: ' + (e.message || e));
    }
   };
   // 行内预览按钮
   // 多图按钮
   var rowMultis = container.querySelectorAll('.kp-row-multi');
   if (rowMultis[idx]) {
    rowMultis[idx].onclick = async function() {
     try {
      if (typeof P.pickLocalFiles !== 'function') { log('⚠ 多图功能不可用'); return; }
      var files = await P.pickLocalFiles();
      if (!files || files.length === 0) return;
      // 过滤掉已被其他任务使用的图片
      var _multiStore = (typeof P.currentStore === 'function') ? P.currentStore() : P.currentStore;
      if (!_multiStore) { try { _multiStore = localStorage.getItem('kun_cur_store') || ''; } catch(e){} }
      {
        var _allTasks2 = P.loadDailyTasks().tasks || [];
        var _usedNames = {};
        for (var _ai = 0; _ai < _allTasks2.length; _ai++) {
          if (_ai === idx) continue;
          var _aim = _allTasks2[_ai].imageUrls || [_allTasks2[_ai].imageUrl || ''];
          for (var _aj = 0; _aj < _aim.length; _aj++) { if (_aim[_aj]) _usedNames[_aim[_aj].replace(/^.*[\\/]/, '')] = true; }
        }
        var _filtered = [];
        for (var _fi = 0; _fi < files.length; _fi++) {
          var _fn2 = files[_fi].replace(/^.*[\\/]/, '');
          if (_usedNames[_fn2]) { log('⚠ 图片「' + _fn2 + '」已被其他任务使用，跳过'); continue; }
          _filtered.push(files[_fi]);
        }
        files = _filtered;
        if (files.length === 0) return;
      }
      var curVal = imgs[idx].value.trim();
      imgs[idx].value = curVal ? curVal + ' ' + files.join(' ') : files.join(' ');
      if (files.length > 0 && typeof P.parseImageFileName === 'function') {
        var parsed = P.parseImageFileName(files[0]);
        if (parsed.star && stars[idx] && !stars[idx].value) stars[idx].value = parsed.star;
        if (parsed.city && cities[idx] && !cities[idx].value) cities[idx].value = parsed.city;
        if (parsed.sessionType && types[idx] && !types[idx].value) types[idx].value = parsed.sessionType;
      }
      saveForm();
      renderTaskRows(P.loadDailyTasks().tasks || []);
      log('📸 行 ' + (idx+1) + ' 已选 ' + files.length + ' 张图');
     } catch(e) { log('❌ 多图失败: ' + (e.message || e)); }
    };
   }

   priorities[idx].onclick = function() {
    var data = P.loadDailyTasks();
    var tasks = data.tasks || [];
    if (tasks[idx]) { tasks[idx].priority = !tasks[idx].priority; P.saveDailyTasks(data); renderTaskRows(tasks); }
   };
   rowPreviews[idx].onclick = function() {
    var data = P.loadDailyTasks();
    var tasks = data.tasks || [];
    var task = tasks[idx];
    if (!task) return;
    previewTask(task, data.templateId);
   };
   if (retryBtns[idx]) retryBtns[idx].onclick = async function() {
    this.textContent = '⏳'; this.style.color = '#f39c12';
    var d = P.loadDailyTasks();
    var task = d.tasks[idx];
    if (!task) return;
    task.status = 'pending';
    delete task.error;
    P.saveDailyTasks(d);
    renderTaskRows();
    try {
     var result = await P.publishOneTask(task, d.templateId || 1);
     task.status = 'done';
     task.itemId = (result && result.itemId) || '';
     log('✅ 重新发布成功');
    } catch(e) {
     task.status = 'failed';
     task.error = (e && e.message) || String(e);
     log('❌ 重新发布失败: ' + task.error);
    }
    P.saveDailyTasks(d);
    renderTaskRows();
   };
  })(i);
 }
 renderImgChips();
}

function escHtml(s) {
 return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function renderProjectHeader(isRecruit) {
  var hdr = document.getElementById('kp-task-header');
  if (!hdr) return;
  if (isRecruit) {
    hdr.innerHTML = '<div style="display:grid;grid-template-columns:80px 70px 50px 45px 1fr 20px 20px;gap:4px;margin-bottom:4px;padding:0 4px;">' +
     '<div style="font-size:11px;color:#666;font-weight:500;">模板</div>' +
     '<div style="font-size:11px;color:#666;font-weight:500;">分类</div>' +
     '<div style="font-size:11px;color:#666;font-weight:500;">价格</div>' +
     '<div style="font-size:11px;color:#666;font-weight:500;">库存</div>' +
     '<div style="font-size:11px;color:#666;font-weight:500;">图片</div>' +
     '<div style="font-size:11px;color:#666;font-weight:500;"></div>' +
     '<div style="font-size:11px;color:#666;font-weight:500;"></div>' +
    '</div>';
  }
};

// ===== 底图标签列表（直接映射 tasks 行）=====
function renderImgChips() {
 var box = document.getElementById('kp-img-chips');
 if (!box) return;
 var isSimple = true;
 var imgs = [];
 if (isSimple) {
  var dt = P.loadDailyTasks();
  var tasks = dt.tasks || [];
  for (var ti = 0; ti < tasks.length; ti++) {
   var iu = Array.isArray(tasks[ti].imageUrls) ? tasks[ti].imageUrls[0] : (tasks[ti].imageUrl || '');
   imgs.push(iu);
  }
  // 同步文本框，保持底图管理和任务一致
  var urlInput = document.getElementById('kp-image-url');
  if (urlInput) urlInput.value = imgs.filter(Boolean).join(' ');
 } else {
  var input = document.getElementById('kp-image-url');
  if (input) imgs = input.value.trim().split(/\s+/).filter(Boolean);
 }
 imgs = imgs.filter(Boolean);
 if (imgs.length === 0) { box.innerHTML = ''; return; }
 var html = '';
 for (var i = 0; i < imgs.length; i++) {
  var name = imgs[i].replace(/^.*[\\/]/, '');
  html += '<div style="display:inline-flex;align-items:center;gap:4px;background:#eef;border:1px solid #ccd;border-radius:6px;padding:3px 6px 3px 8px;font-size:11px;">' +
   '<span style="max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">🖼 ' + escHtml(name) + '</span>' +
   '<button data-chip-idx="' + i + '" style="background:#e74c3c;color:#fff;border:none;border-radius:50%;width:16px;height:16px;font-size:10px;cursor:pointer;line-height:1;padding:0;flex-shrink:0;">✕</button>' +
  '</div>';
 }
 box.innerHTML = html;
 // 用委托事件替代 onclick（绕 CSP）
 box.querySelectorAll('[data-chip-idx]').forEach(function(btn) {
  btn.addEventListener('click', function() { removeImgChip(parseInt(this.getAttribute('data-chip-idx'))); });
 });
}
function removeImgChip(idx) {
 var isSimple = true;
 if (isSimple) {
  var dt = P.loadDailyTasks();
  if (!dt.tasks || idx < 0 || idx >= dt.tasks.length) return;
  dt.tasks.splice(idx, 1);
  P.saveDailyTasks(dt);
  renderTaskRows(dt.tasks, (P.getStoreProject(P.currentStore) === 'recruit'), true);
  renderImgChips();
  updateTaskCount();
  return;
 }
 var input = document.getElementById('kp-image-url');
 if (!input) return;
 var imgs = input.value.trim().split(/\s+/).filter(Boolean);
 if (idx < 0 || idx >= imgs.length) return;
 imgs.splice(idx, 1);
 input.value = imgs.join(' ');
 saveForm();
 renderImgChips();
}

// ===== 保存表单 =====
function saveForm() {
 var data = P.loadDailyTasks();

 // 模板
 var radios = document.querySelectorAll('input[name="kp-template"]');
 for (var i = 0; i < radios.length; i++) {
  if (radios[i].checked) { data.templateId = parseInt(radios[i].value); break; }
 }

 // 图片 URL
 var imgInput = document.getElementById('kp-image-url');
 if (imgInput) data.imageUrl = imgInput.value.trim() || P.DEFAULT_IMAGE_URL;

 // 表格行
 var rows = document.getElementById('kp-task-rows');
 if (rows) {
  var starInputs = rows.querySelectorAll('.kp-task-star');
  var cityInputs = rows.querySelectorAll('.kp-task-city');
  var eventInputs = rows.querySelectorAll('.kp-task-event');
  var typeSelects = rows.querySelectorAll('.kp-task-type');
  var imgInputs = rows.querySelectorAll('.kp-task-img');
  var catInputs = rows.querySelectorAll('.kp-task-cat');
  var priceInputs = rows.querySelectorAll('.kp-task-price');
  var stockInputs = rows.querySelectorAll('.kp-task-stock');
  if (!data.tasks) data.tasks = [];

  for (var i = 0; i < starInputs.length; i++) {
   if (!data.tasks[i]) data.tasks[i] = { id: 't_' + Date.now() + '_' + i, status: 'pending' };
   data.tasks[i].star = starInputs[i].value.trim();
   data.tasks[i].city = cityInputs[i] ? cityInputs[i].value.trim() : (data.tasks[i].city || '');
   data.tasks[i].eventType = eventInputs[i] ? (eventInputs[i].value === '__custom__' ? (prompt('输入活动类型：','演唱会')||'演唱会') : (eventInputs[i].value.trim() || '演唱会')) : (data.tasks[i].eventType || '演唱会');
   data.tasks[i].sessionType = typeSelects[i] ? typeSelects[i].value.trim() : (data.tasks[i].sessionType || '');
   data.tasks[i].imageUrl = imgInputs[i].value.trim();
   data.tasks[i].imageUrls = imgInputs[i].value.trim().split(/\s+/).filter(Boolean);
   data.tasks[i].categoryName = catInputs[i] ? catInputs[i].value.trim() : (data.tasks[i].categoryName || '');
   data.tasks[i].price = priceInputs[i] ? priceInputs[i].value.trim() : (data.tasks[i].price || '');
   data.tasks[i].stock = stockInputs[i] ? stockInputs[i].value.trim() : (data.tasks[i].stock || '');
  }
 }

 P.saveDailyTasks(data);
}

function updateTaskCount() {
 var el = document.getElementById('kp-task-count');
 if (!el) return;
 var data = P.loadDailyTasks();
 var tasks = data.tasks || [];
 el.textContent = '(' + tasks.length + ' 个)';
}

// ===== 状态刷新 =====
// ===== 预览弹窗 =====
function previewTask(task, templateId) {
  var uid = 'kp_' + Date.now() + '_' + Math.random().toString(36).slice(2,6);
  var title = P.renderConcertTitle(templateId, task.star, task.city, task.sessionType, task.eventType);
  var desc = P.renderConcertDesc(templateId);
  var fullDesc = title + '\n\n' + desc;
  var imgUrls = (Array.isArray(task.imageUrls) && task.imageUrls.length > 0) ? task.imageUrls.slice() : (task.imageUrl ? [task.imageUrl] : []);

  var overlay = document.createElement('div');
  overlay.id = uid + '-ov';
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:999999;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;';
  overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };

  var imgHtml = '';
  if (imgUrls.length > 0) {
    imgHtml = '<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px;">';
    for (var im = 0; im < imgUrls.length; im++) {
      var u = imgUrls[im];
      if (u && (u.startsWith('http') || u.startsWith('data:'))) {
        imgHtml += '<img src="' + escHtml(u) + '" style="max-width:45%;max-height:200px;border-radius:8px;border:2px solid #27ae60;">';
      } else {
        imgHtml += '<div style="width:45%;min-height:80px;border:2px dashed #E67E22;border-radius:8px;display:flex;align-items:center;justify-content:center;text-align:center;"><div><img id="' + uid + '-main' + im + '" src="" style="max-width:100%;max-height:150px;border-radius:6px;display:none;"><div style="font-size:11px;color:#E67E22;">📁 ' + escHtml(u) + '</div></div></div>';
      }
    }
    imgHtml += '</div>';
  } else {
    imgHtml = '<div style="color:#ccc;font-size:12px;">暂无图片</div>';
  }
  imgHtml += '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:4px;margin:8px 0;">';
  for (var si = 1; si <= 8; si++) {
    imgHtml += '<div style="background:#f5f5f5;border-radius:4px;aspect-ratio:1;display:flex;align-items:center;justify-content:center;overflow:hidden;"><span id="' + uid + '-s' + si + 'l" style="font-size:10px;color:#ccc;">副图' + si + '</span><img id="' + uid + '-s' + si + '" src="" style="width:100%;height:100%;object-fit:cover;display:none;"></div>';
  }
  imgHtml += '</div>';

  overlay.innerHTML = '<div style="background:#fff;border-radius:12px;padding:20px;max-width:480px;width:90%;max-height:80vh;overflow-y:auto;box-shadow:0 8px 32px rgba(0,0,0,0.2);font-family:system-ui,sans-serif;">' +
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;"><span style="font-size:16px;font-weight:bold;">👁 发布预览</span><button data-act="pvclose" style="background:none;border:none;cursor:pointer;font-size:20px;color:#999;">✕</button></div>' +
    imgHtml +
    '<div style="background:#f8f9fa;border-radius:8px;padding:12px;font-size:13px;line-height:1.6;white-space:pre-wrap;">' + escHtml(fullDesc) + '</div>' +
    '<div style="margin-top:12px;display:flex;gap:8px;"><span style="font-size:11px;color:#999;background:#eee;padding:4px 8px;border-radius:4px;">📌 ' + escHtml(task.city||'?') + '</span><span style="font-size:11px;color:#999;background:#eee;padding:4px 8px;border-radius:4px;">⭐ ' + escHtml(task.star||'?') + '</span><span style="font-size:11px;color:#999;background:#eee;padding:4px 8px;border-radius:4px;">🎫 ' + (task.sessionType||'?') + '</span></div>' +
  '</div>';
  document.body.appendChild(overlay);

  if (typeof P.readLocalImageBase64 === 'function') {
    for (var li = 0; li < imgUrls.length; li++) {
      (function(fn, idx) {
        P.readLocalImageBase64(fn).then(function(b64) {
          if (b64) { var m = document.getElementById(uid + '-main' + idx); if (m) { m.src = 'data:image/jpeg;base64,' + b64; m.style.display = 'block'; } }
        }).catch(function(){});
      })(imgUrls[li], li);
    }
  }
  (function load(idx) {
    if (idx > 8) return;
    if (typeof P.readLocalImageBase64 !== 'function') return;
    P.readLocalImageBase64('副图' + idx + '.jpg').then(function(b64) {
      if (b64) { var e = document.getElementById(uid + '-s' + idx); var l = document.getElementById(uid + '-s' + idx + 'l'); if (e) { e.src = 'data:image/jpeg;base64,' + b64; e.style.display = 'block'; } if (l) l.style.display = 'none'; }
    }).catch(function(){}).then(function() { setTimeout(function(){ load(idx+1); }, 200); });
  })(1);
}

var statusTimer = null;

function refreshStatus() {
 if (statusTimer) clearInterval(statusTimer);
 updateStatusOnce();
 if (P.dailyRunning) statusTimer = setInterval(updateStatusOnce, 1000);
}

// ===== 批量发布状态刷新 =====
var _batchTimer = null;
function refreshBatchStatus() {
 if (_batchTimer) clearInterval(_batchTimer);
 updateBatchOnce();
 if (P.batchRunning) _batchTimer = setInterval(updateBatchOnce, 1000);
}
function updateBatchOnce() {
 var area = document.getElementById('kp-status-area');
 var text = document.getElementById('kp-status-text');
 var prog = document.getElementById('kp-status-progress');
 var bar = document.getElementById('kp-status-bar');
 var detail = document.getElementById('kp-status-detail');
 var startBtn = document.getElementById('kp-start');
 var stopBtn = document.getElementById('kp-stop');
 if (!area || !text) return;
 var bs = P.getBatchStatus ? P.getBatchStatus() : null;
 if (!bs || !bs.running) {
  if (_batchTimer) { clearInterval(_batchTimer); _batchTimer = null; }
  if (!P.dailyRunning) { area.style.display = bs && bs.total > 0 ? 'block' : 'none'; startBtn.style.display = 'block'; stopBtn.style.display = 'none'; }
  return;
 }
 area.style.display = 'block';
 startBtn.style.display = 'none';
 stopBtn.style.display = 'none';
 text.textContent = '📦 批量发布中...';
 text.style.color = '#8e44ad';
 prog.textContent = (bs.done + bs.failed) + '/' + bs.total;
 bar.style.width = (bs.total > 0 ? ((bs.done + bs.failed) / bs.total * 100) : 0) + '%';
 bar.style.background = 'linear-gradient(90deg,#8e44ad,#6c3483)';
 detail.textContent = '成功 ' + bs.done + ' | 失败 ' + bs.failed;
}

function updateStatusOnce() {
 var area = document.getElementById('kp-status-area');
 var text = document.getElementById('kp-status-text');
 var prog = document.getElementById('kp-status-progress');
 var bar = document.getElementById('kp-status-bar');
 var detail = document.getElementById('kp-status-detail');
 var startBtn = document.getElementById('kp-start');
 var stopBtn = document.getElementById('kp-stop');

 if (!area || !text) return;

 var s = P.getDailyStatus();
 if (!s || s.total === 0) { area.style.display = 'none'; return; }

 if (s.running) {
  area.style.display = 'block';
  startBtn.style.display = 'none';
  stopBtn.style.display = 'block';

  var phaseText = '';
  switch (s.phase) {
   case 'publish': phaseText = '📤 发布中...'; break;
   case 'wait_next': phaseText = '⏳ 等待下一轮...'; break;
   default: phaseText = '⏳ 处理中...';
  }
  text.textContent = '第 ' + (s.currentIndex + 1) + '/' + s.total + ' 个 | ' + phaseText;
  prog.textContent = s.done + '/' + s.total;
  bar.style.width = (s.total > 0 ? (s.done / s.total * 100) : 0) + '%';

  // 显示当前任务详情
  var data = P.loadDailyTasks();
  var tasks = data.tasks || [];
  var curTask = tasks[s.currentIndex];
  if (curTask && s.phase !== 'idle') {
   detail.textContent = '当前: ' + (curTask.star || '?') + ' · ' + (curTask.city || '?') + ' · ' + (curTask.sessionType || '?');
  } else {
   detail.textContent = '';
  }
 } else {
  area.style.display = s.done > 0 || s.failed > 0 ? 'block' : 'none';
  startBtn.style.display = 'block';
  stopBtn.style.display = 'none';

  if (s.done + s.failed === s.total && s.total > 0) {
   text.textContent = '🎉 全部完成！';
   text.style.color = '#27ae60';
  } else {
   text.textContent = '⏸ 已停止';
   text.style.color = '#999';
  }
  prog.textContent = s.done + '/' + s.total;
  bar.style.width = (s.total > 0 ? (s.done / s.total * 100) : 0) + '%';
  bar.style.background = 'linear-gradient(90deg,#27ae60,#2ecc71)';
  detail.textContent = '成功 ' + s.done + ' | 失败 ' + s.failed + ' | 剩余 ' + s.pending;
 }
}

// ===== 日志 =====
var logs = [];

function appendLog(msg, t) {
 if (!t) t = new Date().toLocaleTimeString();
 logs.unshift({ t: t, m: msg });
 if (logs.length > 100) logs.length = 100;
 renderLog();
}

function log(msg) {
 appendLog(msg);
}

function renderLog() {
 var el = document.getElementById('kp-log');
 var cnt = document.getElementById('kp-log-count');
 if (!el) return;
 el.innerHTML = logs.slice(0, 30).map(function(l) {
  return '<div><span style="color:#888;">' + l.t + '</span> ' + l.m + '</div>';
 }).join('');
 el.scrollTop = 0;
 if (cnt) cnt.textContent = '(' + logs.length + '条)';
}

// ===== 模板编辑弹窗 =====
function showProjectConfig() {
  var projects = {};
  try { projects = JSON.parse(localStorage.getItem("kun_project_configs") || "{}"); } catch(e) {}
  if (!projects.concert) {
    projects.concert = { name:'演唱会代拍', category:'代购', titleMode:'placeholder', descMode:'template', defaultPrice:'50', defaultStock:'9999', columns:'star,city,event,session,cat,price,stock,img', subImg:true, autoPolish:false };
  }
  if (!projects.recruit) {
    projects.recruit = { name:'招抢手', category:'创业/副业培训', titleMode:'filename', descMode:'random', defaultPrice:'10', defaultStock:'999', columns:'tpl,cat,price,stock,img', subImg:false, autoPolish:false };
  }
  localStorage.setItem("kun_project_configs", JSON.stringify(projects));
  
  var overlay = document.createElement("div");
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:999999;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;';
  overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };
  
  var box = document.createElement("div");
  box.style.cssText = 'background:#fff;border-radius:12px;padding:20px;max-width:560px;width:92%;max-height:85vh;overflow-y:auto;';
  
  var html = '<h3 style="margin:0 0 12px">⚙️ 项目管理</h3>';
  var keys = Object.keys(projects);
  for (var pi = 0; pi < keys.length; pi++) {
    var k = keys[pi], p = projects[k];
    html += '<div style="border:1px solid #eee;border-radius:8px;padding:12px;margin-bottom:8px">';
    html += '<b>📁 ' + escHtml(p.name) + '</b> <span style="color:#999;font-size:11px">(' + k + ')</span><br>';
    html += '<span style="font-size:11px">分类:' + (p.category||'?') + ' | 标题:' + (p.titleMode==='filename'?'文件名':'占位符') + ' | 价格:¥' + (p.defaultPrice||'?') + ' | 库存:' + (p.defaultStock||'?') + '</span>';
    html += ' <button data-act="projedit" style="background:#f0ad4e;color:#fff;border:none;border-radius:4px;padding:2px 8px;font-size:10px;cursor:pointer">编辑</button>';
    html += ' <button data-act="projdel" style="background:#e74c3c;color:#fff;border:none;border-radius:4px;padding:2px 8px;font-size:10px;cursor:pointer">删除</button>';
    html += '</div>';
  }
  html += '<button data-act="projadd" style="width:100%;border:1px dashed #4a90d9;color:#4a90d9;background:#f0f7ff;border-radius:6px;padding:8px;cursor:pointer;font-size:12px">➕ 新增项目</button>';
  html += '<div style="margin-top:8px;font-size:10px;color:#999">配置会自动保存到本地。新增项目后需重新选择店铺绑定项目。</div>';
  
  box.innerHTML = html;
  overlay.appendChild(box);
  document.body.appendChild(overlay);
  
  window.addNewProject = function() {
    var id = prompt('项目ID（英文，如：ticket）：');
    if (!id) return;
    var name = prompt('项目名称（如：票务代拍）：');
    if (!name) return;
    var cat = prompt('默认分类（如：代购）：','代购');
    var titleMode = confirm('标题模式：点确定=占位符模板(用{明星}{城市})  点取消=图片文件名') ? 'placeholder' : 'filename';
    var price = prompt('默认价格(元)：','50');
    var stock = prompt('默认库存：','9999');
    projects[id] = { name:name, category:cat, titleMode:titleMode, descMode:"template", defaultPrice:price, defaultStock:stock, columns:"star,city,event,session,cat,price,stock,img", subImg:true, autoPolish:false };
    localStorage.setItem("kun_project_configs", JSON.stringify(projects));
    overlay.remove(); showProjectConfig();
  };
  window.editProject = function(id) {
    window.postMessage({ type: 'OPEN_DASHBOARD' }, '*');
    overlay.remove();
  };
  window.deleteProject = function(id) {
    if (!confirm('删除项目「' + (projects[id]?projects[id].name:id) + '」？只是删配置，不会影响已发布的商品。')) return;
    if (Object.keys(projects).length <= 1) { alert("至少保留一个项目"); return; }
    delete projects[id];
    localStorage.setItem("kun_project_configs", JSON.stringify(projects));
    overlay.remove(); showProjectConfig();
  };
};

function fetchAccountInfo(store) {
  if (!store) return;
  window.addEventListener('message', function handler(e) {
    if (e.data && e.data.type === 'FETCH_ACCOUNTS_RESULT') {
      window.removeEventListener('message', handler);
      var el = document.getElementById('kp-store-account');
      if (!el || !e.data.data || !e.data.data.ok) return;
      var accounts = e.data.data.data || [];
      var match = null;
      for (var i = 0; i < accounts.length; i++) {
        if (accounts[i].name === store) { match = accounts[i]; break; }
      }
      if (match) {
        el.textContent = '👤 ' + match.name + ' (' + match.username + ')';
      }
    }
  });
  window.postMessage({ type: 'FETCH_ACCOUNTS' }, '*');
};

function bindCookieBtns() {
  var saveBtn = document.getElementById('kp-save-cookie');
  var loadBtn = document.getElementById('kp-load-cookie');
  if (!saveBtn || !loadBtn) return;
  saveBtn.onclick = function() {
    var store = P.currentStore;
    if (!store) return;
    var hint = document.getElementById('kp-store-hint');
    hint.textContent = '⏳ 保存中...'; hint.style.display = 'block';
    window.addEventListener('message', function handler(e) {
      if (e.data && e.data.type === 'SAVE_COOKIE_RESULT') {
        window.removeEventListener('message', handler);
        hint.textContent = e.data.ok ? '✅ 已保存登录态' : '❌ 保存失败: ' + (e.data.error || '未知');
        setTimeout(function(){ hint.style.display = 'none'; }, 2000);
      }
    });
    window.postMessage({ type: 'SAVE_COOKIE', store: store }, '*');
  };
  loadBtn.onclick = function() {
    var store = P.currentStore;
    if (!store) return;
    var hint = document.getElementById('kp-store-hint');
    hint.textContent = '⏳ 切换中...'; hint.style.display = 'block';
    window.addEventListener('message', function handler(e) {
      if (e.data && e.data.type === 'LOAD_COOKIE_RESULT') {
        window.removeEventListener('message', handler);
        if (e.data.ok) {
          hint.textContent = '✅ 已切换，刷新页面';
          setTimeout(function(){ location.reload(); }, 1000);
        } else {
          hint.textContent = '❌ ' + (e.data.error || '未保存过登录');
        }
      }
    });
    window.postMessage({ type: 'LOAD_COOKIE', store: store }, '*');
  };
};
function showStoreConfig() {
  var cfg = (P.loadStoreConfig ? P.loadStoreConfig() : P.getDefaultStoreConfig()) || {};
  var cats = P.getCategoryList();
  var overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:999999;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;';
  overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };

  var box = document.createElement('div');
  box.style.cssText = 'background:#fff;border-radius:12px;padding:20px;max-width:480px;width:92%;max-height:85vh;overflow-y:auto;box-shadow:0 8px 32px rgba(0,0,0,0.2);font-family:system-ui,sans-serif;';

  var catOpts = cats.map(function(c) { return '<option value="' + c + '"' + (cfg.category === c ? ' selected' : '') + '>' + c + '</option>'; }).join('');
  var locModes = [{v:'city',t:'跟随标题城市'},{v:'fixed',t:'固定位置'},{v:'random_tier1',t:'随机一线城市'},{v:'random_any',t:'随机任意城市'}];
  var locOpts = locModes.map(function(m) { return '<option value="' + m.v + '"' + (cfg.locationMode === m.v ? ' selected' : '') + '>' + m.t + '</option>'; }).join('');
  var cm = cfg.commitment || {};

  box.innerHTML =
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">' +
      '<span style="font-size:16px;font-weight:bold;">⚙️ 店铺默认配置</span>' +
      '<span style="font-size:12px;color:#999;">' + (P.currentStore || '未选择') + '</span>' +
      '<button id="ksc-close" style="background:none;border:none;cursor:pointer;font-size:18px;color:#999;">✕</button>' +
    '</div>' +
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">' +
      '<div><label style="font-size:11px;color:#666;">价格（元）</label><input id="ksc-price" value="' + escHtml(cfg.price||'') + '" placeholder="留空=跟随模板" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;box-sizing:border-box;"></div>' +
      '<div><label style="font-size:11px;color:#666;">库存</label><input id="ksc-stock" value="' + escHtml(cfg.stock||'') + '" placeholder="留空=跟随模板" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;box-sizing:border-box;"></div>' +
    '</div>' +
    '<div style="margin-bottom:8px;"><label style="font-size:11px;color:#666;">分类</label><select id="ksc-category" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;box-sizing:border-box;"><option value="">-- 跟随模板/项目 --</option>' + catOpts + '</select></div>' +
    '<div style="margin-bottom:8px;"><label style="font-size:11px;color:#666;">🏷 标题生成方式</label><select id="ksc-titlemode" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;box-sizing:border-box;">' +
      '<option value=""' + (!cfg.titleMode ? ' selected' : '') + '>-- 项目默认 --</option>' +
      '<option value="placeholder"' + (cfg.titleMode==='placeholder'?' selected':'') + '>占位符替换（{城市}{明星}）</option>' +
      '<option value="filename"' + (cfg.titleMode==='filename'?' selected':'') + '>主图文件名</option>' +
      '<option value="random"' + (cfg.titleMode==='random'?' selected':'') + '>随机改写（防判重）</option>' +
    '</select></div>' +
    '<div style="margin-bottom:8px;"><label style="font-size:11px;color:#666;">交付方式</label><select id="ksc-ship" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;box-sizing:border-box;">' +
      '<option value=""' + (!cfg.shipMode ? ' selected' : '') + '>-- 跟随项目 --</option>' +
      '<option value="nomail"' + (cfg.shipMode==='nomail'?' selected':'') + '>不包邮</option>' +
      '<option value="free"' + (cfg.shipMode==='free'?' selected':'') + '>包邮</option>' +
      '<option value="distance"' + (cfg.shipMode==='distance'?' selected':'') + '>按距离</option>' +
    '</select></div>' +
    '<div style="margin-bottom:8px;border:1px solid #eee;border-radius:8px;padding:10px;">' +
      '<div style="font-weight:500;margin-bottom:6px;font-size:13px;">📍 所在位置</div>' +
      '<select id="ksc-locmode" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:12px;margin-bottom:6px;">' + locOpts + '</select>' +
      '<div id="ksc-loc-fixed" style="display:none;gap:6px;">' +
        '<input id="ksc-city" value="' + escHtml(cfg.fixedCity||'') + '" placeholder="城市" style="flex:1;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:12px;">' +
        '<input id="ksc-district" value="' + escHtml(cfg.fixedDistrict||'') + '" placeholder="区域(可选)" style="flex:1;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:12px;">' +
      '</div>' +
    '</div>' +
    '<div style="margin-bottom:8px;display:flex;align-items:center;gap:8px;">' +
      '<label style="font-size:13px;cursor:pointer;"><input type="checkbox" id="ksc-subimg"' + (cfg.subImg===true?' checked':'') + '> 上传副图</label>' +
      '<span style="font-size:11px;color:#999;">不勾选=无副图</span>' +
      '<button id="ksc-subimg-reset" style="font-size:10px;color:#999;background:none;border:none;cursor:pointer;text-decoration:underline;">重置为跟随项目</button>' +
    '</div>' +
    '<div style="margin-bottom:12px;border:1px solid #eee;border-radius:8px;padding:10px;">' +
      '<div style="font-weight:500;margin-bottom:6px;font-size:13px;">🔒 承诺（默认开关）</div>' +
      '<div style="display:flex;flex-direction:column;gap:4px;">' +
        '<label style="cursor:pointer;font-size:12px;"><input type="checkbox" id="ksc-c1"' + (cm.refundFull?' checked':'') + '> 描述不符全额退</label>' +
        '<label style="cursor:pointer;font-size:12px;"><input type="checkbox" id="ksc-c2"' + (cm.refundPostage?' checked':'') + '> 描述不符包邮退</label>' +
        '<label style="cursor:pointer;font-size:12px;"><input type="checkbox" id="ksc-c3"' + (cm.fastShip?' checked':'') + '> 10分钟发货</label>' +
      '</div>' +
    '</div>' +
    '<button id="ksc-save" style="width:100%;background:#8e44ad;color:#fff;border:none;border-radius:6px;padding:10px;cursor:pointer;font-size:14px;font-weight:bold;">✅ 保存配置</button>' +
    '<div style="margin-top:6px;font-size:10px;color:#999;text-align:center;">配置仅影响当前店铺，发布时仍可在任务中逐条覆盖</div>';

  overlay.appendChild(box);
  document.body.appendChild(overlay);
  document.getElementById('ksc-close').onclick = function() { overlay.remove(); };

  var locSel = document.getElementById('ksc-locmode');
  var locFixed = document.getElementById('ksc-loc-fixed');
  function toggleLoc() { locFixed.style.display = (locSel.value === 'fixed') ? 'flex' : 'none'; }
  locSel.onchange = toggleLoc;
  toggleLoc();

  var subimgCb = document.getElementById('ksc-subimg');
  if (cfg.subImg === null || cfg.subImg === undefined) subimgCb.indeterminate = true;
  document.getElementById('ksc-subimg-reset').onclick = function() { subimgCb.checked = false; subimgCb.indeterminate = true; };

  document.getElementById('ksc-save').onclick = function() {
    var subVal = subimgCb.indeterminate ? null : subimgCb.checked;
    P.saveStoreConfig({
      titleMode: document.getElementById('ksc-titlemode').value,
      price: document.getElementById('ksc-price').value.trim(),
      stock: document.getElementById('ksc-stock').value.trim(),
      category: document.getElementById('ksc-category').value,
      shipMode: document.getElementById('ksc-ship').value,
      locationMode: locSel.value,
      fixedCity: document.getElementById('ksc-city').value.trim(),
      fixedDistrict: document.getElementById('ksc-district').value.trim(),
      subImg: subVal,
      commitment: {
        refundFull: document.getElementById('ksc-c1').checked,
        refundPostage: document.getElementById('ksc-c2').checked,
        fastShip: document.getElementById('ksc-c3').checked
      }
    });
    log('✅ 店铺配置已保存');
    overlay.remove();
    show();
  };
}

// 💬 自动回复设置（关键词→默认 两级；保存到 kun_reply_rules_[店名]，未选店铺=全局）
function showReplyConfig() {
  var store = P.currentStore || '';
  var key = 'kun_reply_rules_' + (store || 'default');
  var cfg = {};
  try { cfg = JSON.parse(localStorage.getItem(key)) || {}; } catch(e) {}
  if (!cfg.rules) cfg.rules = [];

  var overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:999999;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;';
  overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };

  var box = document.createElement('div');
  box.style.cssText = 'background:#fff;border-radius:12px;padding:20px;max-width:520px;width:94%;max-height:85vh;overflow-y:auto;box-shadow:0 8px 32px rgba(0,0,0,0.2);font-family:system-ui,sans-serif;';

  var rulesHtml = cfg.rules.map(function(r, i) {
    return '<div class="krc-row" style="border:1px solid #eee;border-radius:8px;padding:8px;margin-bottom:8px;">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">' +
        '<span style="font-size:11px;color:#666;">规则 ' + (i + 1) + '（从上到下，先命中先回复）</span>' +
        '<button class="krc-del" style="background:#e74c3c;color:#fff;border:none;border-radius:4px;padding:2px 8px;cursor:pointer;font-size:11px;">删除</button>' +
      '</div>' +
      '<div style="margin-bottom:4px;"><label style="font-size:11px;color:#666;">关键词（逗号分隔，支持 /正则/i）</label>' +
        '<input class="krc-kw" value="' + escHtml((r.keywords || []).join('，')) + '" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;box-sizing:border-box;"></div>' +
      '<div><label style="font-size:11px;color:#666;">回复内容</label>' +
        '<textarea class="krc-reply" rows="2" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;box-sizing:border-box;">' + escHtml(r.reply || '') + '</textarea></div>' +
    '</div>';
  }).join('');

  box.innerHTML =
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">' +
      '<span style="font-size:16px;font-weight:bold;">💬 自动回复设置</span>' +
      '<span style="font-size:12px;color:#999;">' + (store || '全局') + '</span>' +
      '<button id="krc-close" style="background:none;border:none;cursor:pointer;font-size:18px;color:#999;">✕</button>' +
    '</div>' +
    '<div style="margin-bottom:8px;display:flex;align-items:center;gap:8px;">' +
      '<label style="font-size:13px;cursor:pointer;"><input type="checkbox" id="krc-enabled"' + (cfg.enabled === false ? '' : ' checked') + '> 启用自动回复</label>' +
      '<span style="font-size:11px;color:#999;">取消勾选 = IM 页不再自动回复</span>' +
    '</div>' +
    '<div style="margin-bottom:8px;"><label style="font-size:11px;color:#666;">默认回复（无关键词命中时使用）</label>' +
      '<textarea id="krc-default" rows="2" placeholder="留空 = 使用内置默认话术" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;box-sizing:border-box;">' + escHtml(cfg.defaultReply || '') + '</textarea></div>' +
    '<div id="krc-rules" style="margin-bottom:8px;">' + rulesHtml + '</div>' +
    '<button id="krc-add" style="width:100%;background:#ecf0f1;color:#333;border:1px dashed #ccc;border-radius:6px;padding:8px;cursor:pointer;font-size:13px;margin-bottom:12px;">➕ 添加关键词规则</button>' +
    '<button id="krc-save" style="width:100%;background:#16a085;color:#fff;border:none;border-radius:6px;padding:10px;cursor:pointer;font-size:14px;font-weight:bold;">✅ 保存设置</button>' +
    '<div style="margin-top:6px;font-size:10px;color:#999;text-align:center;">保存到：' + (store ? '当前店铺「' + store + '」' : '全局（所有店铺）') + '；IM 页面自动回复时生效；不配规则 = 只回默认话术</div>';

  overlay.appendChild(box);
  document.body.appendChild(overlay);
  document.getElementById('krc-close').onclick = function() { overlay.remove(); };

  function bindDel(row) {
    var b = row.querySelector('.krc-del');
    if (b) b.onclick = function() { row.remove(); };
  }
  box.querySelectorAll('.krc-row').forEach(bindDel);

  document.getElementById('krc-add').onclick = function() {
    var div = document.createElement('div');
    div.className = 'krc-row';
    div.style.cssText = 'border:1px solid #eee;border-radius:8px;padding:8px;margin-bottom:8px;';
    div.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">' +
        '<span style="font-size:11px;color:#666;">新规则</span>' +
        '<button class="krc-del" style="background:#e74c3c;color:#fff;border:none;border-radius:4px;padding:2px 8px;cursor:pointer;font-size:11px;">删除</button>' +
      '</div>' +
      '<div style="margin-bottom:4px;"><label style="font-size:11px;color:#666;">关键词（逗号分隔，支持 /正则/i）</label>' +
        '<input class="krc-kw" placeholder="如：发货,卡密,在吗" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;box-sizing:border-box;"></div>' +
      '<div><label style="font-size:11px;color:#666;">回复内容</label>' +
        '<textarea class="krc-reply" rows="2" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;box-sizing:border-box;"></textarea></div>';
    document.getElementById('krc-rules').appendChild(div);
    bindDel(div);
  };

  function collectRules() {
    var out = [];
    box.querySelectorAll('.krc-row').forEach(function(row) {
      var kw = (row.querySelector('.krc-kw').value || '').split(/[,，]/).map(function(x) { return x.trim(); }).filter(Boolean);
      var reply = (row.querySelector('.krc-reply').value || '').trim();
      if (kw.length && reply) out.push({ keywords: kw, reply: reply });
    });
    return out;
  }

  document.getElementById('krc-save').onclick = function() {
    var next = {
      enabled: document.getElementById('krc-enabled').checked,
      defaultReply: document.getElementById('krc-default').value.trim(),
      rules: collectRules()
    };
    localStorage.setItem(key, JSON.stringify(next));
    log('✅ 回复设置已保存（' + (store || '全局') + '）');
    overlay.remove();
  };
}

function showTemplateEditor() {
  var tpls = P.CONCERT_TEMPLATES;
  var overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:999999;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;';
  overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };

  var box = document.createElement('div');
  box.style.cssText = 'background:#fff;border-radius:12px;padding:20px;max-width:520px;width:92%;max-height:85vh;overflow-y:auto;box-shadow:0 8px 32px rgba(0,0,0,0.2);font-family:system-ui,sans-serif;';

  var html = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">' +
    '<span style="font-size:16px;font-weight:bold;">✏️ 编辑模板</span>' +
    '<button id="kpte-close" style="background:none;border:none;cursor:pointer;font-size:20px;color:#999;">✕</button>' +
   '</div>';

  var locModes = [{v:'city',t:'跟随标题城市'},{v:'fixed',t:'固定位置'},{v:'random_tier1',t:'随机一线城市'},{v:'random_any',t:'随机任意城市'}];
  function locOptsHTML(selected) {
    return locModes.map(function(m){return '<option value="'+m.v+'"'+(selected===m.v?' selected':'')+'>'+m.t+'</option>';}).join('');
  }
  function commitHTML(prefix, cm) {
    cm = cm || {};
    return '<div style="margin-top:6px;border-top:1px solid #f0f0f0;padding-top:6px;">' +
      '<div style="font-size:11px;color:#999;margin-bottom:4px;">🔒 承诺</div>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;">' +
       '<label style="cursor:pointer;font-size:11px;"><input type="checkbox" id="'+prefix+'-cf"'+(cm.refundFull?' checked':'')+'> 全额退</label>' +
       '<label style="cursor:pointer;font-size:11px;"><input type="checkbox" id="'+prefix+'-cp"'+(cm.refundPostage?' checked':'')+'> 包邮退</label>' +
       '<label style="cursor:pointer;font-size:11px;"><input type="checkbox" id="'+prefix+'-cs"'+(cm.fastShip?' checked':'')+'> 10分钟发货</label>' +
      '</div></div>';
  }

  for (var i = 0; i < tpls.length; i++) {
    html += '<div style="margin-bottom:14px;border:1px solid #eee;border-radius:8px;padding:12px;">' +
      '<div style="display:flex;align-items:center;gap:4px;margin-bottom:6px;">' +
       '<input id="kpte-name-' + tpls[i].id + '" value="' + escHtml(tpls[i].name) + '" style="flex:1;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;font-weight:500;box-sizing:border-box;">' +
       '<button data-act="tpldel" data-tid="' + tpls[i].id + '" style="background:#e74c3c;color:#fff;border:none;border-radius:4px;padding:4px 8px;cursor:pointer;font-size:11px;flex-shrink:0;">🗑</button>' +
      '</div>' +
      '<div style="font-size:11px;color:#999;margin-bottom:4px;">标题模板（可用占位符: {明星} {城市} {场次类型}）</div>' +
      '<textarea id="kpte-title-' + tpls[i].id + '" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;font-size:12px;box-sizing:border-box;min-height:50px;resize:vertical;">' + escHtml(tpls[i].titlePattern) + '</textarea>' +
      '<div style="font-size:11px;color:#999;margin-top:6px;margin-bottom:4px;">描述正文</div>' +
      '<textarea id="kpte-desc-' + tpls[i].id + '" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;font-size:12px;box-sizing:border-box;min-height:120px;resize:vertical;">' + escHtml(tpls[i].descPattern) + '</textarea>' +
      '<div style="display:flex;gap:6px;margin-top:6px;">' +
       '<input id="kpte-cat-' + tpls[i].id + '" value="' + escHtml(tpls[i].categoryName || '') + '" placeholder="分类" style="flex:1;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:12px;box-sizing:border-box;">' +
       '<input id="kpte-price-' + tpls[i].id + '" value="' + escHtml(tpls[i].price || '50') + '" placeholder="价格" style="width:70px;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:12px;box-sizing:border-box;">' +
       '<input id="kpte-stock-' + tpls[i].id + '" value="' + escHtml(tpls[i].stock || '9999') + '" placeholder="库存" style="width:80px;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:12px;box-sizing:border-box;">' +
      '</div>' +
      '<div style="display:flex;gap:6px;margin-top:6px;align-items:center;">' +
       '<select id="kpte-loc-' + tpls[i].id + '" style="flex:1;padding:4px;border:1px solid #ddd;border-radius:4px;font-size:11px;">' + locOptsHTML(tpls[i].locationMode) + '</select>' +
       '<label style="cursor:pointer;font-size:11px;white-space:nowrap;"><input type="checkbox" id="kpte-subimg-' + tpls[i].id + '"' + (tpls[i].subImg !== false ? ' checked' : '') + '> 副图</label>' +
      '</div>' +
      commitHTML('kpte-' + tpls[i].id, tpls[i].commitment) +
     '</div>';
  }

  html += '<div style="display:flex;gap:8px;margin-bottom:8px;">' +
    '<button id="kpte-save" style="flex:1;background:#E67E22;color:#fff;border:none;border-radius:6px;padding:10px;cursor:pointer;font-size:13px;font-weight:bold;">✅ 保存</button>' +
    '<button id="kpte-reset" style="background:#eee;color:#666;border:none;border-radius:6px;padding:10px;cursor:pointer;font-size:13px;">↺ 恢复默认</button>' +
   '</div>' +
   '<button id="kpte-add" style="width:100%;background:#f0f7ff;color:#4A90D9;border:1px dashed #4A90D9;border-radius:6px;padding:8px;cursor:pointer;font-size:12px;">➕ 新增模板</button>';

  box.innerHTML = html;
  overlay.appendChild(box);
  document.body.appendChild(overlay);

  document.getElementById('kpte-close').onclick = function() { overlay.remove(); };

  // 新增模板
  document.getElementById('kpte-add').onclick = function() {
    var maxId = 0;
    for (var ti = 0; ti < tpls.length; ti++) { if (tpls[ti].id > maxId) maxId = tpls[ti].id; }
    var newId = maxId + 1;
    var newName = '模板' + newId;
    var section = document.createElement('div');
    section.style.cssText = 'margin-bottom:14px;border:1px solid #4A90D9;border-radius:8px;padding:12px;';
    section.innerHTML =
      '<input id="kpte-name-' + newId + '" value="' + newName + '" style="width:100%;padding:6px;border:1px solid #4A90D9;border-radius:4px;font-size:13px;font-weight:500;box-sizing:border-box;margin-bottom:6px;">' +
      '<div style="font-size:11px;color:#999;margin-bottom:4px;">标题模板</div>' +
      '<textarea id="kpte-title-' + newId + '" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;font-size:12px;box-sizing:border-box;min-height:50px;resize:vertical;"></textarea>' +
      '<div style="font-size:11px;color:#999;margin-top:6px;margin-bottom:4px;">描述正文</div>' +
      '<textarea id="kpte-desc-' + newId + '" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;font-size:12px;box-sizing:border-box;min-height:120px;resize:vertical;"></textarea>' +
      '<div style="display:flex;gap:6px;margin-top:6px;">' +
       '<input id="kpte-cat-' + newId + '" value="" placeholder="分类" style="flex:1;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:12px;box-sizing:border-box;">' +
       '<input id="kpte-price-' + newId + '" value="50" placeholder="价格" style="width:70px;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:12px;box-sizing:border-box;">' +
       '<input id="kpte-stock-' + newId + '" value="9999" placeholder="库存" style="width:80px;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:12px;box-sizing:border-box;">' +
      '</div>' +
      '<div style="display:flex;gap:6px;margin-top:6px;align-items:center;">' +
       '<select id="kpte-loc-' + newId + '" style="flex:1;padding:4px;border:1px solid #ddd;border-radius:4px;font-size:11px;">' + locOptsHTML('city') + '</select>' +
       '<label style="cursor:pointer;font-size:11px;white-space:nowrap;"><input type="checkbox" id="kpte-subimg-' + newId + '" checked> 副图</label>' +
      '</div>' +
      commitHTML('kpte-' + newId, {});
    // 插入到保存按钮前
    var saveBtn = document.getElementById('kpte-save');
    saveBtn.parentNode.parentNode.insertBefore(section, saveBtn.parentNode);
    // 加入模板列表以便保存
    tpls.push({ id: newId, name: newName, titlePattern: '', descPattern: '', price: '50', stock: '9999', locationMode: 'city', subImg: true, commitment: {} });
    // name will be read from input on save
  };

  document.getElementById('kpte-save').onclick = function() {
    var updated = [];
    for (var j = 0; j < tpls.length; j++) {
      var tid = tpls[j].id;
      var catEl = document.getElementById('kpte-cat-' + tid);
      var priceEl = document.getElementById('kpte-price-' + tid);
      var stockEl = document.getElementById('kpte-stock-' + tid);
      var locEl = document.getElementById('kpte-loc-' + tid);
      var subEl = document.getElementById('kpte-subimg-' + tid);
      var cfEl = document.getElementById('kpte-' + tid + '-cf');
      var cpEl = document.getElementById('kpte-' + tid + '-cp');
      var csEl = document.getElementById('kpte-' + tid + '-cs');
      updated.push({
        id: tid,
        name: document.getElementById('kpte-name-' + tid).value,
        titlePattern: document.getElementById('kpte-title-' + tid).value,
        descPattern: document.getElementById('kpte-desc-' + tid).value,
        categoryName: catEl ? catEl.value : '',
        price: priceEl ? priceEl.value : '50',
        stock: stockEl ? stockEl.value : '9999',
        locationMode: locEl ? locEl.value : 'city',
        subImg: subEl ? subEl.checked : true,
        commitment: {
          refundFull: cfEl ? cfEl.checked : false,
          refundPostage: cpEl ? cpEl.checked : false,
          fastShip: csEl ? csEl.checked : false
        }
      });
    }
    P.saveCustomTemplates(updated);
    // 同步更新内存中的模板
    for (var si = 0; si < updated.length; si++) {
      for (var sj = 0; sj < P.CONCERT_TEMPLATES.length; sj++) {
        if (updated[si].id === P.CONCERT_TEMPLATES[sj].id) {
          P.CONCERT_TEMPLATES[sj].name = updated[si].name;
          P.CONCERT_TEMPLATES[sj].titlePattern = updated[si].titlePattern;
          P.CONCERT_TEMPLATES[sj].descPattern = updated[si].descPattern;
          if (updated[si].categoryName) P.CONCERT_TEMPLATES[sj].categoryName = updated[si].categoryName;
          if (updated[si].price) P.CONCERT_TEMPLATES[sj].price = updated[si].price;
          if (updated[si].stock) P.CONCERT_TEMPLATES[sj].stock = updated[si].stock;
          break;
        }
      }
    }
    log('✅ 模板已保存，已生效');
    overlay.remove();
    show();
  };

  document.getElementById('kpte-reset').onclick = function() {
    if (!confirm('确定恢复默认模板？自定义修改会丢失。')) return;
    P.saveCustomTemplates(null);
    overlay.remove();
    log('↺ 已恢复默认模板');
    show();
  };
}

console.log('[kun] 演唱会导致发布 UI v2.2 已就绪');

// ===== CSP-safe event delegation =====
document.addEventListener('click', function(e) {
  var el = e.target.closest('[data-act]');
  if (!el) return;
  var act = el.getAttribute('data-act');

  if (act === 'pvclose') {
    // Find parent overlay and remove
    var ov = el.closest('[id$="-ov"]') || el.closest('.overlay');
    if (ov) { ov.remove(); return; }
    // Fallback: find any fixed overlay
    var parent = el.parentElement;
    while (parent && parent.tagName !== 'BODY') {
      if (parent.style && parent.style.position === 'fixed') { parent.remove(); return; }
      parent = parent.parentElement;
    }
  }

  if (act === 'projedit') {
    // Trigger dashboard open
    window.postMessage({ type: 'OPEN_DASHBOARD' }, '*');
    var o = el.closest('[style*="position:fixed"]');
    if (o) o.remove();
    return;
  }

  if (act === 'projdel') {
    // Read project key from sibling text
    var pk = el.getAttribute('data-pk');
    if (!pk) {
      var box = el.parentElement;
      var span = box.querySelector('span');
      if (span) pk = span.textContent.match(/\(([^)]+)\)/);
      if (pk) pk = pk[1];
    }
    if (pk && confirm('删除项目配置？')) {
      var cfg = {};
      try { cfg = JSON.parse(localStorage.getItem('kun_project_configs') || '{}'); } catch(e) {}
      delete cfg[pk];
      localStorage.setItem('kun_project_configs', JSON.stringify(cfg));
      var ov = el.closest('[style*="position:fixed"]');
      if (ov) ov.remove();
      if (typeof showProjectConfig === 'function') showProjectConfig();
    }
    return;
  }

  if (act === 'projadd') {
    var id = prompt('项目ID（英文）：');
    if (!id) return;
    var name = prompt('项目名称：');
    if (!name) return;
    var cfg2 = {};
    try { cfg2 = JSON.parse(localStorage.getItem('kun_project_configs') || '{}'); } catch(e) {}
    cfg2[id] = { name: name, category: '代购', titleMode: 'placeholder', descMode: 'template', defaultPrice: '50', defaultStock: '9999', columns: 'star,city,event,session,cat,price,stock,img', subImg: true, autoPolish: false };
    localStorage.setItem('kun_project_configs', JSON.stringify(cfg2));
    var ov2 = el.closest('[style*="position:fixed"]');
    if (ov2) ov2.remove();
    if (typeof showProjectConfig === 'function') showProjectConfig();
    return;
  }

  if (act === 'tpldel') {
    var tid = el.getAttribute('data-tid');
    if (tid && confirm('删除此模板？')) {
      var tpls = [];
      try { tpls = JSON.parse(localStorage.getItem('kun_tpl_global') || '[]'); } catch(e) {}
      for (var di = 0; di < tpls.length; di++) {
        if (String(tpls[di].id) === String(tid)) { tpls.splice(di, 1); break; }
      }
      if (typeof P !== 'undefined' && P.saveCustomTemplates) {
        P.saveCustomTemplates(tpls);
      } else {
        localStorage.setItem('kun_tpl_global', JSON.stringify(tpls));
      }
      var ov3 = el.closest('[style*="position:fixed"]');
      if (ov3) ov3.remove();
      if (typeof showTemplateEditor === 'function') showTemplateEditor();
    }
    return;
  }
});

})();


