// raise150-verify.js —— 从 API 复核 20 个计划的最终出价/预算
const http = require('http');
const fs = require('fs');
const { SVC, STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const NAV = 'https://www.goofish.com/personal';

function ev(code) {
  return new Promise((resolve) => {
    const payload = JSON.stringify({ store: STORE, code });
    const req = http.request({ host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      res => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: b.slice(0, 300) }); } }); });
    req.on('error', e => resolve({ ok: false, error: e.message })); req.write(payload); req.end();
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

const WANT = [
  ['95962377', '单明星-侯明昊-订单120', 70],
  ['94688535', '单明星-侯明昊-订单130', null],
  ['95283163', '单明星-侯明昊-咨询120', null],
  ['95299021', '单明星-刘宇-订单120', 70],
  ['95373021', '单明星-刘宇-订单130', null],
  ['95761455', '单明星-刘宇-咨询120', null],
  ['95235397', '单明星-孙燕姿-订单120', 70],
  ['95809297', '单明星-孙燕姿-订单130', null],
  ['94712218', '单明星-孙燕姿-咨询120', null],
  ['95285374', '单明星-王力宏-订单120', 70],
  ['96559366', '单明星-王力宏-咨询120', null],
  ['95309358', '单明星-许嵩-订单120', 70],
  ['95317370', '单明星-许嵩-订单130', null],
  ['95761439', '单明星-许嵩-咨询120', null],
  ['96559506', '单明星-周杰伦-订单120', 70],
  ['96116473', '单明星-周杰伦-订单130', null],
  ['95259165', '单明星-周杰伦-咨询120', null],
  ['94744199', '热销-汪苏泷广州-咨询130', null],
  ['95309260', '热销-Capper北京-咨询130', null],
  ['95291265', '热销-断眉广州-咨询130', null],
];

const READ = fs.readFileSync(__dirname + '\\ad-today-perplan.js', 'utf8');

(async () => {
  let r = await ev(`(function(){location.href=${JSON.stringify(NAV)};return 'nav'})()`);
  if (!r.ok) { console.log('跳转失败 ' + r.error); process.exit(1); }
  await sleep(14000);
  r = await ev(READ);
  if (!r.ok) { console.log('读取失败 ' + r.error); process.exit(1); }
  const raw = typeof r.result === 'string' ? r.result : JSON.stringify(r.result);
  let d; try { d = JSON.parse(raw); } catch (e) { console.log('解析失败:\n' + raw.slice(0, 600)); process.exit(1); }
  if (d.err) { console.log('API 错误: ' + JSON.stringify(d.err)); process.exit(1); }

  const byId = {};
  d.计划.forEach(p => { byId[String(p.id)] = p; });
  fs.writeFileSync('D:\\DSH\\achun\\raise150-verify.json', JSON.stringify(d, null, 1), 'utf8');

  console.log(`快照 ${d.时刻}   全店计划 ${d.计划数} 个\n`);
  console.log('计划'.padEnd(26) + '出价'.padEnd(9) + '预算'.padEnd(9) + '目标'.padEnd(8) + '商品数');
  console.log('─'.repeat(70));
  let bad = [];
  for (const [id, name, bud] of WANT) {
    const p = byId[id];
    if (!p) { console.log(name.padEnd(26) + '❌ 未找到 ' + id); bad.push(name + ' 未找到'); continue; }
    const okB = bud === null || Math.abs(p.budget - bud) < 0.01;
    if (!okB) bad.push(`${name} 预算 ${p.budget} ≠ ${bud}`);
    console.log(
      name.padEnd(24) +
      ('¥' + p.cpm).padEnd(9) +
      (('¥' + p.budget) + (okB ? '' : ' ⚠')).padEnd(10) +
      String(p.target).padEnd(8) +
      p.商品数
    );
  }
  console.log('─'.repeat(70));
  console.log(bad.length ? '⚠ 异常:\n  ' + bad.join('\n  ') : '✅ 20 个计划全部核对一致');

  // 全店总盘
  const t = d.计划.reduce((a, p) => ({ 预算: a.预算 + p.budget, 花费: a.花费 + p.成本, 曝光: a.曝光 + p.曝光, 咨询: a.咨询 + p.咨询, 下单: a.下单 + p.下单 }), { 预算: 0, 花费: 0, 曝光: 0, 咨询: 0, 下单: 0 });
  console.log(`\n全店: 日预算 ¥${t.预算.toFixed(0)} / 今日花费 ¥${t.花费.toFixed(2)} / 曝光 ${t.曝光} / 咨询 ${t.咨询} / 下单 ${t.下单}`);
  const cat = {};
  d.计划.forEach(p => { cat[p.类别] = cat[p.类别] || { n: 0, b: 0, cost: 0, chat: 0, pay: 0 }; const c = cat[p.类别]; c.n++; c.b += p.budget; c.cost += p.成本; c.chat += p.咨询; c.pay += p.下单; });
  for (const k in cat) { const c = cat[k]; console.log(`  ${k.padEnd(10)} ${String(c.n).padStart(2)}个  预算¥${String(c.b.toFixed(0)).padStart(5)}  花费¥${c.cost.toFixed(2).padStart(7)}  咨询${String(c.chat).padStart(3)}  下单${c.pay}`); }
  console.log('\n已存 D:\\DSH\\achun\\raise150-verify.json');
})().catch(e => { console.error('FAIL ' + e.message); process.exit(1); });
