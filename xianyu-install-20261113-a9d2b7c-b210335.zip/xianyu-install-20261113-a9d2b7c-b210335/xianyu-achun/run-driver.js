/**
 * run-driver.js —— 通用浏览器驱动器：跳到一个 URL（可选）→ 注入 cfg → 跑驱动脚本 → 原样打印 JSON
 *
 * 为什么需要它：现有的 run-cfgs.js / ad-editor-run.js / ad-creative-run.js 都把目标 URL
 *   写死成广告后台。而「读 IM 会话列表」这类需求要去的是别的页面，
 *   驱动脚本本身没法自己跳转（一跳转，evaluate 的执行上下文就没了，返回值也拿不回来）。
 *
 * 用法:
 *   DRIVER=im-dump.js URL="https://www.goofish.com/im" node run-driver.js
 *   DRIVER=some.js CFG_JSON=cfg.json GLOBAL=window.__MYCFG node run-driver.js
 *
 * 环境变量:
 *   DRIVER    必填，仓库根目录或任意路径下的 .js，内容是一段返回字符串的表达式/IIFE
 *   URL       可选，先跳到这里再跑（不给就原地跑）
 *   CFG_JSON  可选，注入用的 JSON 文件
 *   GLOBAL    注入到哪个全局名，默认 window.__RUNDRV_CFG
 *   WAIT_MS   可选，跳转后至少等多久（默认 6000；之后还会轮询等页面渲染）
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { SVC, STORE } = require('./lib/env');

const DRIVER_FILE = process.env.DRIVER;
if (!DRIVER_FILE) { console.log('用法: DRIVER=<驱动.js> [URL=<页面>] [CFG_JSON=<配置>] node run-driver.js'); process.exit(2); }
const DRIVER_PATH = path.isAbsolute(DRIVER_FILE) ? DRIVER_FILE : path.join(__dirname, DRIVER_FILE);
const DRIVER = fs.readFileSync(DRIVER_PATH, 'utf8');
const URL_ = process.env.URL || '';
const GLOBAL_NAME = process.env.GLOBAL || 'window.__RUNDRV_CFG';
const CFG = process.env.CFG_JSON ? JSON.parse(fs.readFileSync(process.env.CFG_JSON, 'utf8')) : null;
const WAIT_MS = Number(process.env.WAIT_MS || 6000);

function ev(code, timeoutMs) {
  return new Promise((resolve) => {
    const payload = JSON.stringify({ store: STORE, code });
    const req = http.request({ host: '127.0.0.1', port: SVC.port, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': SVC.apiKey } },
      (res) => { let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: b.slice(0, 300) }); } }); });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.setTimeout(timeoutMs || 300000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const unpack = (r) => { let d = r && r.result; if (typeof d === 'string') { try { d = JSON.parse(d); } catch (e) {} } return d; };

(async () => {
  if (URL_) {
    console.log('跳转: ' + URL_);
    await ev(`(function(){location.href=${JSON.stringify(URL_)};return 'nav'})()`, 90000).catch(() => {});
    await sleep(WAIT_MS);
    // 等到页面真的渲染出内容（不能只靠 sleep —— 同仓库已被这个坑咬过两次）
    for (let i = 0; i < 20; i++) {
      const r = await ev(`JSON.stringify({href:location.href,ready:document.readyState,len:(document.body.innerText||'').length})`, 30000);
      const s = unpack(r);
      if (s && s.ready === 'complete' && s.len > 300) { console.log('  已渲染: ' + s.href + '  (' + s.len + ' 字)'); break; }
      await sleep(1500);
    }
  }
  if (CFG !== null) {
    const rc = await ev(`${GLOBAL_NAME}=${JSON.stringify(CFG)}; 'set'`);
    if (!rc.ok) { console.log('cfg 注入失败 ' + rc.error); process.exit(1); }
  }
  console.log('驱动器: ' + DRIVER_PATH + '\n');
  const rd = await ev(DRIVER, 300000);
  if (!rd.ok) { console.log('driver 失败 ' + rd.error); process.exit(1); }
  const out = unpack(rd);
  console.log(typeof out === 'string' ? out : JSON.stringify(out, null, 1));
})().catch((e) => { console.error('FAIL ' + ((e && e.stack) || e)); process.exit(1); });
