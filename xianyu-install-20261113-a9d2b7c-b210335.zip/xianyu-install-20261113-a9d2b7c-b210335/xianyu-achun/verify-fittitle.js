/**
 * verify-fittitle.js — 从 publish.js 里抽出【真实的】 fitTitle 跑端到端验证
 * 断言：卡片标题（= (title+"\n\n"+desc).slice(0,30)）必须恰好等于我们想要的标题
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { PATHS } = require('./lib/env');

const SRC = fs.readFileSync(path.join(PATHS.xianyuMonitor, 'publish.js'), 'utf8');

// 抽出真实的 fitTitle 与它的常量（不复制粘贴，避免测的不是线上那份）
// 【2026-10-11 改】原来只抽 TITLE_MAX + TITLE_PAD + fitTitle 三段。
//   现在 fitTitle 会调用同文件里的 squeezeTitle / closeBrackets（超长瘦身），
//   少抽一个函数就是 ReferenceError —— 所以改成【从 var TITLE_MAX 抽到 fitTitle 结束】整段。
const BLOCK = (() => {
  const i = SRC.indexOf('var TITLE_MAX');
  if (i < 0) throw new Error('publish.js 里找不到 var TITLE_MAX');
  const j = SRC.indexOf('function fitTitle(t)', i);
  if (j < 0) throw new Error('publish.js 里找不到 function fitTitle(t)');
  let k = SRC.indexOf('{', j), d = 0, e = k;
  for (; e < SRC.length; e++) { const c = SRC[e]; if (c === '{') d++; else if (c === '}') { d--; if (d === 0) break; } }
  return SRC.slice(i, e + 1);
})();
console.log('已从 publish.js 抽出整段（TITLE_MAX / TITLE_PAD / closeBrackets / squeezeTitle / fitTitle），共 ' + BLOCK.split('\n').length + ' 行');
const fitTitle = new Function(BLOCK + '\nreturn fitTitle;')();

// 线上真实模板
const TPL = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.xianyu-templates.json'), 'utf8'));
const DESC = TPL.templates[0].descPattern;

const STARS = ['那英', '许嵩', '张杰', '徐良', '刘宇', '断眉', '周深', '周杰伦', '孙燕姿', '王力宏',
  '刘宪华', '汪苏泷', '华晨宇', '宋雨琦', '侯明昊', '陈都灵', 'Capper', '凤凰传奇', '易烊千玺', '许巍'];
const CITIES = ['杭州', '北京', '呼和浩特', '乌鲁木齐', '三亚', '成都', '常州', '石家庄'];
const SESSION = '一开', EV = '演唱会';

function render(p, s, c) {
  return p.replace(/\{明星\}/g, s).replace(/\{城市\}/g, c)
    .replace(/\{场次类型\}/g, SESSION).replace(/\{活动类型\}/g, EV);
}

let total = 0, bad = [], padStats = { exact: 0, padded: 0, cut: 0 };
for (const tpl of TPL.templates) {
  // 【2026-10-11 改】内容断言原来是"一刀切"，对模板 5/6 长期误报 320 条：
  //   模板5「【超强捡漏】{城市}{明星}{活动类型}{场次类型}」标题里本来就没有「代拍」二字；
  //   模板6「【全明星场次】均可代拍代抢，大麦/猫眼/…」压根没有 {明星}{城市} 占位符。
  //   改成【按模板自己的占位符/用词】推导期望，模板换代时不会再误报 ——
  //   误报会把真问题淹掉（这次修标题上限，320 条噪音把"长度/括号有没有坏"盖住了）。
  const P = String(tpl.titlePattern);
  const wantStar = P.indexOf('{明星}') >= 0;
  const wantCity = P.indexOf('{城市}') >= 0;
  const wantDaipai = /代拍|代抢/.test(P);
  for (const s of STARS) for (const c of CITIES) {
    total++;
    const raw = render(tpl.titlePattern, s, c);
    const title = fitTitle(raw);
    // 端到端：提交的 desc = title + "\n\n" + 正文；卡片标题 = 它的前 30 字
    const fullDesc = title + '\n\n' + DESC;
    const cardTitle = fullDesc.slice(0, 30);
    const problems = [];
    if (title.length !== 30) problems.push('fitTitle 后不是 30 字(' + title.length + ')');
    if (cardTitle !== title) problems.push('卡片标题 ≠ 目标标题（正文串进来了）');
    if (wantStar && title.indexOf(s) < 0) problems.push('无明星（模板有 {明星} 位）');
    if (wantCity && title.indexOf(c) < 0 && title.indexOf('全站') < 0) problems.push('无城市（模板有 {城市} 位）');
    if (wantDaipai && !/代拍|代抢/.test(title)) problems.push('无代拍（模板含代拍/代抢字样）');
    // 括号必须配对、开头【】必须闭合 —— 这两条是「截断把括号砍一半」的直接哨兵
    const nOpen = (title.match(/[（(【《〈\[]/g) || []).length;
    const nClose = (title.match(/[）)】》〉\]]/g) || []).length;
    if (nOpen !== nClose) problems.push('括号不配对(' + nOpen + '开/' + nClose + '闭)');
    if (!/^【[^】]*】/.test(title)) problems.push('开头【】不完整');
    if (problems.length) bad.push({ id: tpl.id, s, c, raw: raw.length, title, cardTitle, problems });
    else if (raw.length === 30) padStats.exact++;
    else if (raw.length < 30) padStats.padded++;
    else padStats.cut++;
  }
}

console.log('\n测试: ' + TPL.templates.length + ' 个模板 × ' + (STARS.length * CITIES.length) + ' 组合 = ' + total);
console.log('  fitTitle 前恰好 30 字: ' + padStats.exact);
console.log('  fitTitle 前不足 30 字（补了 filler/空格）: ' + padStats.padded);
console.log('  fitTitle 前超过 30 字（被截断）: ' + padStats.cut);
console.log('  断言失败: ' + bad.length);

if (bad.length) {
  console.log('\n❌ 失败明细（前 10 条）:');
  bad.slice(0, 10).forEach(b => console.log('  模板' + b.id + ' ' + b.s + '/' + b.c + ' 原始' + b.raw + '字  → ' + b.problems.join(';') + '\n      title=' + JSON.stringify(b.title) + '\n      card =' + JSON.stringify(b.cardTitle)));
} else {
  console.log('\n✅ 全部组合：fitTitle 后恰好 30 字，且卡片标题 100% 等于目标标题（正文不会串进标题）');
}

// 展示几个真实样例
console.log('\n样例（原始长度 → 整形后卡片标题）:');
[['那英', '杭州'], ['Capper', '呼和浩特'], ['凤凰传奇', '北京']].forEach(([s, c]) => {
  TPL.templates.forEach(t => {
    const raw = render(t.titlePattern, s, c);
    const title = fitTitle(raw);
    console.log('  模板' + t.id + ' ' + s + '/' + c + '  原始 ' + String(raw.length).padStart(2) + ' 字  →  ' + JSON.stringify(title));
  });
});

// 用旧模板（35/36 字）也测一遍，确认 fitTitle 对超长同样有效
console.log('\n对【旧模板】(35/36 字) 的兜底效果:');
[['【接代拍】{明星}{城市}站{活动类型}接代拍{场次类型}代抢{明星}{活动类型}代抢{城市}{明星}秒付前排', '旧模板1'],
['【{城市}{明星}代拍】{城市}{明星}{活动类型}接抢票{明星}{活动类型}代拍{场次类型}代抢{明星}{活动类型}代买', '旧模板2']].forEach(([p, n]) => {
  const raw = render(p, '那英', '杭州');
  const title = fitTitle(raw);
  console.log('  ' + n + '  原始 ' + raw.length + ' 字 → ' + JSON.stringify(title) + '  (' + title.length + ' 字)');
});
