/**
 * publish-quanzhou-xuliang.js — 上架「泉州 徐良」到一店（好易美代拍）
 *
 * 为什么要这个启动器：PowerShell 传中文参数会被吃掉（OEM 936 编码问题），
 * 所以参数在这里写死，再 require publish-one.js（它读 process.argv）。
 *
 * 前置条件（必须先做，否则会报「店铺未启动」/「店铺未就绪」）：
 *   POST /api/agent/open-all-stores   —— 把三个店铺的 context 预热进 agent.stores
 *   原因：upload-image 和 eval-on-store 都直接读 agent.stores[store]，不会自动切换。
 *   （agent 现在改成懒启动 + 空闲 20 分钟回收，所以每次发布前都要预热一次。）
 *
 * 用法: node publish-quanzhou-xuliang.js [--dry]
 */
const DRY = process.argv.includes('--dry');
process.argv[2] = '泉州';
process.argv[3] = '徐良';
if (DRY) process.argv[4] = '--dry';
require('./publish-one.js');
