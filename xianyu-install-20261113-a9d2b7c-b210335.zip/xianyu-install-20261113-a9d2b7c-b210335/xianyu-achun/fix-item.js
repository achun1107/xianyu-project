/**
 * fix-item.js — 用 mtop.idle.pc.idleitem.update 编辑已发布商品：
 *   ① 把描述换成正确排版（原始 \n 直存）
 *   ② 加「代拍费」单档规格 ¥50 + 库存 9999（顶层 quantity 不生效，真实库存在 itemSkuList[].quantity）
 *
 * 之所以拿 1086173442802（网页发的、排版挤、库存1）当靶子：改坏了也没损失。
 *
 * 用法: node fix-item.js <itemId> [--go]
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const { SVC, STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const ITEM = process.argv[2];
const GO = process.argv.indexOf('--go') >= 0;
if (!ITEM) { console.log('用法: node fix-item.js <itemId> [--go]'); process.exit(2); }

const CITY = '杭州', STAR = '那英', EVENT = '演唱会', SESSION = '首开';

function post(p, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 300))); } }); });
    req.on('error', reject);
    req.setTimeout(timeoutMs || 300000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}

const TITLE_MAX = 30;
const TITLE_PAD = [' 全站全价位都可接', ' 全价位都能接', ' 高命中率', ' 全价位接', ' 可上号', ' 秒付前排', ' 稳中', ' 秒付', ' 包中'];
function fitTitle(t) {
  t = String(t == null ? '' : t);
  if (t.length > TITLE_MAX) return t.slice(0, TITLE_MAX);
  if (t.length < TITLE_MAX) {
    const gap = TITLE_MAX - t.length; let best = '';
    for (const f of TITLE_PAD) if (f.length <= gap && f.length > best.length) best = f;
    t += best; while (t.length < TITLE_MAX) t += '！';
  }
  return t;
}

const T = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.xianyu-templates.json'), 'utf8'));
const cand = T.templates[0];
const title = fitTitle(cand.titlePattern.replace(/\{明星\}/g, STAR).replace(/\{城市\}/g, CITY)
  .replace(/\{场次类型\}/g, SESSION).replace(/\{活动类型\}/g, EVENT));
const fullDesc = title + '\n\n' + cand.descPattern;

console.log('目标商品: ' + ITEM);
console.log('标题(' + title.length + '): ' + title);
console.log('全文 ' + fullDesc.length + ' 字 / ' + (fullDesc.match(/\n/g) || []).length + ' 个换行');
console.log('规格: 代拍费 / 标准  ¥50  库存 9999');

(async () => {
  const inner = `(async function(){
  var out = { itemId: ${JSON.stringify(ITEM)} };
  if (!window.lib || !window.lib.mtop) return Object.assign(out, { err: 'no lib.mtop' });
  var sp = null;
  try {
    var pr = await window.lib.mtop.request({ api: 'mtop.taobao.idle.local.poi.get', v: '1.0', data: { longitude: '120.6', latitude: '31.3' }, headers: { 'EagleEye-UserData': 'spm-cnt=a21ybx' }, type: 'GET' });
    sp = pr && pr.data && pr.data.selectedPoi;
  } catch (e) { out.poiErr = (e && (e.ret || e.message)) || String(e); }
  if (!sp || !sp.city) return Object.assign(out, { err: '拿不到定位' });
  var data = {
    itemId: ${JSON.stringify(ITEM)},
    itemTextDTO: { desc: ${JSON.stringify(fullDesc)}, title: ${JSON.stringify(title)}, titleDescSeparate: false },
    itemProperties: [{
      propertyName: '代拍费', supportImage: false,
      propertyValues: [{ propertyValue: '标准' }]
    }],
    itemSkuList: [{
      priceInCent: '5000', quantity: 9999,
      propertyList: [{ propertyText: '代拍费', valueText: '标准' }]
    }],
    itemPriceDTO: {},
    defaultPrice: false,
    itemAddrDTO: { area: sp.area || '', city: sp.city, divisionId: sp.divisionId, gps: (sp.latitude || '') + ',' + (sp.longitude || ''), poiId: '', poiName: '', prov: sp.prov || '' },
    itemCatDTO: { catId: '50025461', catName: '代购', channelCatId: '201456914' },
    itemLabelExtList: [{
      channelCateName: '代购', channelCateId: '201456914',
      propertyName: '分类', propertyId: '-10000', text: '代购',
      properties: '-10000##分类:201456914##代购',
      labelType: 'common', isUserClick: '1', from: 'newPublishChoice', labelFrom: 'newPublish'
    }],
    itemPostFeeDTO: { canFreeShipping: false, supportFreight: false, onlyTakeSelf: false, templateId: '0' },
    sourceId: 'pcMainPublish', bizcode: 'pcMainPublish', publishScene: 'pcMainPublish'
  };
  try {
    var r = await window.lib.mtop.request({ api: 'mtop.idle.pc.idleitem.update', v: '1.0', data: data, type: 'POST' });
    out.ret = r && r.ret;
    out.dataSample = JSON.stringify(r && r.data).slice(0, 400);
  } catch (e) { out.updateErr = (e && (e.ret || e.message)) || String(e); }
  return out;
})()`;

  console.log('\n' + (GO ? '执行编辑...' : '[未加 --go] 只预览，不执行'));
  if (!GO) return;
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/"; "ok"' }, 60000);
  await new Promise(z => setTimeout(z, 9000));
  const res = await post('/api/agent/eval-on-store', { store: STORE, code: inner }, 300000);
  console.log(JSON.stringify(res, null, 2));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
