// probe-budget-dom.js —— 探 96129660 编辑抽屉里的预算控件 DOM
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  function setNative(el, val) {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    d.set.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const out = {};
  // 用 ID 筛选定位
  const box = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
  if (box) {
    setNative(box, '96129660'); await sleep(500);
    box.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
    await sleep(4000);
  }
  const row = [].slice.call(document.querySelectorAll('tbody tr')).find(r => /孙燕姿广州-订单120/.test(r.innerText || ''));
  out.找到行 = !!row;
  if (!row) return JSON.stringify(out, null, 1);
  click1([].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑'));
  let od = null;
  for (let i = 0; i < 15; i++) { await sleep(1000); od = [].slice.call(document.querySelectorAll('.ant-drawer-content')).filter(d => d.getBoundingClientRect().width > 200).find(d => /编辑计划/.test(d.innerText || '')); if (od) break; }
  out.抽屉打开 = !!od;
  if (!od) return JSON.stringify(out, null, 1);

  // 目标类型（更想获得）的选中态
  out.目标 = [].slice.call(od.querySelectorAll('input[type=radio]'))
    .filter(r => ['exposure', 'click', 'follow_collect', 'chat', 'order'].indexOf(r.value) >= 0)
    .map(r => r.value + (r.checked ? '(选中)' : '') + (r.disabled ? '(禁用)' : ''));
  out.出价 = (od.querySelector('input[placeholder*="出价"]') || {}).value;

  // 预算组
  let grp = od.querySelector('[class*=radioGroup--eEugUXoZ]');
  out.主选择器命中 = !!grp;
  if (!grp) {
    const cand = [].slice.call(od.querySelectorAll('div')).filter(d => /自定义/.test(d.innerText || '') && d.querySelectorAll('[class*=radio--]').length >= 2);
    grp = cand.sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length)[0];
  }
  out.预算组class = grp ? String(grp.className).slice(0, 60) : null;
  if (grp) {
    const bx = [].slice.call(grp.querySelectorAll('[class*=radio--]'));
    out.档位 = bx.map(e => ({ txt: (e.innerText || '').trim(), cls: String(e.className).slice(0, 70), 内含input: e.querySelectorAll('input').length }));
    out.组内input = [].slice.call(grp.querySelectorAll('input')).map(e => ({ val: e.value, ph: e.placeholder || '', type: e.type, cls: String(e.className).slice(0, 40) }));
    // 点自定义槽再探
    const custom = bx[bx.length - 1];
    click1(custom); await sleep(2500);
    out.点自定义后_档位 = [].slice.call(grp.querySelectorAll('[class*=radio--]')).map(e => (e.innerText || '').trim());
    out.点自定义后_组内input = [].slice.call(grp.querySelectorAll('input')).map(e => ({ val: e.value, ph: e.placeholder || '', type: e.type }));
    out.点自定义后_全抽屉input = [].slice.call(od.querySelectorAll('input')).map(e => ({ val: String(e.value).slice(0, 12), ph: e.placeholder || '', type: e.type })).slice(0, 12);
  }
  return JSON.stringify(out, null, 1);
})()
