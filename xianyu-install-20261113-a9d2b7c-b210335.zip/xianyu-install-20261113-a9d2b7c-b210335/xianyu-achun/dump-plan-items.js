// dump-plan-items.js —— 只读：打开指定计划的编辑抽屉，列出其中的宝贝标题
// window.__DP = ['97682524','96129660']
(async () => {
  const IDS = window.__DP || [];
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  function setNative(el, val) {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    d.set.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const drawers = () => [].slice.call(document.querySelectorAll('.ant-drawer-content')).filter(d => d.getBoundingClientRect().width > 200);
  const outer = () => drawers().find(d => /编辑计划/.test(d.innerText || ''));
  const out = [];

  // 清「计划ID」筛选框残留
  const idFilter = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
  if (idFilter && String(idFilter.value || '').trim() !== '') {
    setNative(idFilter, ''); await sleep(500);
    idFilter.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
    await sleep(3200);
  }

  for (const pid of IDS) {
    const R = { planId: pid };
    try {
      // 切到「计划」tab
      const tab = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn')).find(e => /^计划\(\d+\)$/.test((e.innerText || '').trim()));
      if (tab) { click1(tab); await sleep(3200); }

      const box = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
      if (box) {
        setNative(box, String(pid)); await sleep(700);
        box.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
        box.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
        await sleep(4200);
      }
      const rows = () => [].slice.call(document.querySelectorAll('tbody tr'));
      let row = null;
      for (let i = 0; i < 12 && !row; i++) { await sleep(1000); row = rows()[0]; }
      if (!row) throw new Error('筛选后没有行');
      R.行文字 = (row.innerText || '').replace(/\n+/g, ' | ').slice(0, 220);

      click1([].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑'));
      let od = null;
      for (let i = 0; i < 18; i++) { await sleep(1000); od = outer(); if (od && od.querySelector('[class*=goodsTitle]')) break; }
      if (!od) throw new Error('编辑抽屉没打开');

      R.已选宝贝badge = ((od.innerText || '').match(/已选宝贝\(([^)]*)\)/) || [])[1];
      const items = [].slice.call(od.querySelectorAll('[class*=goodsItem]'));
      R.宝贝数 = items.length;
      R.宝贝 = items.map(it => {
        const t = ((it.querySelector('[class*=goodsTitle]') || {}).innerText || '').trim();
        const sub = ((it.querySelector('[class*=goodsSubTitle]') || {}).innerText || '').trim();
        const hasClear = !!it.querySelector('[class*=clearItemBtn]');
        return { 标题: t, 副标题: sub, 有移除按钮: hasClear };
      });
      R.抽屉全文片段 = (od.innerText || '').replace(/\n+/g, ' | ').slice(0, 400);

      // 关抽屉（不保存）
      const wrap = od.closest('.ant-drawer');
      const close = wrap && wrap.querySelector('.ant-drawer-close');
      if (close) { click1(close); await sleep(2500); }
      else { const cancel = wrap && [].slice.call(wrap.querySelectorAll('.ant-drawer-footer div,.ant-drawer-footer span,.ant-drawer-footer button')).find(e => /^取\s*消$/.test((e.innerText || '').trim())); if (cancel) { click1(cancel); await sleep(2500); } }
      R.已关抽屉 = !outer();
    } catch (e) { R.fatal = e.message; }
    out.push(R);
    await sleep(2000);
  }
  return JSON.stringify(out, null, 1);
})()
