// im-dump.js —— 只读：摊开闲鱼网页版 IM 的会话列表，看每个会话能不能对应到【商品】
//
// 目的：广告后台只有【计划级】数据，而老板要的是「每个商品实际来了多少咨询」。
//   真实来源是 IM 会话 —— 每个会话都挂在某条商品上。这个脚本先摸清列表里
//   到底有没有商品标识（itemId / 商品标题 / 商品图），有的话才能按商品计数。
//
// 由 run-driver.js 驱动：DRIVER=im-dump.js URL="https://www.goofish.com/im" node run-driver.js
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();

  for (let i = 0; i < 20; i++) {
    if ((document.body.innerText || '').length > 400) break;
    await sleep(800);
  }
  await sleep(2500);

  // 会话行的候选选择器：闲鱼 web IM 换过几版，尽量多试几个，别只认一个
  const sels = ['[class*=conversation]', '[class*=session]', '[class*=chatItem]', '[class*=chat-item]',
    '[class*=messageItem]', '[class*=contact]', 'li[class*=item]', '[class*=listItem]'];
  const cand = {};
  sels.forEach(s => { try { const n = document.querySelectorAll(s).length; if (n) cand[s] = n; } catch (e) {} });

  // 通用兜底：左栏里「像一行会话」的元素 —— 含 O1CN 图 或 含时间样式文本，且高度合理
  const rows = [];
  [].slice.call(document.querySelectorAll('div,li,a')).forEach(e => {
    const r = e.getBoundingClientRect();
    if (r.width < 120 || r.height < 40 || r.height > 140) return;
    if (r.left > window.innerWidth * 0.55) return;          // 只看左栏
    const t = norm(e.innerText);
    if (t.length < 4 || t.length > 160) return;
    const img = e.querySelector('img');
    rows.push({ el: e, t, img: img ? String(img.currentSrc || img.src || '') : '' });
  });
  // 去掉祖先（同一行会被 div/li/a 命中多次）：文本更短的优先，且互不包含
  rows.sort((a, b) => a.t.length - b.t.length);
  const picked = [];
  rows.forEach(r => { if (!picked.some(p => p.t.indexOf(r.t) >= 0)) picked.push(r); });

  const out = {
    时刻: new Date().toLocaleString('zh-CN'),
    href: location.href,
    title: document.title,
    正文前300: norm(document.body.innerText).slice(0, 300),
    选择器命中: cand,
    候选行数: picked.length,
    行样例: picked.slice(0, 14).map((r, i) => {
      // 行里能不能捞到商品标识？
      const html = r.el.outerHTML || '';
      const ids = (html.match(/\b\d{13}\b/g) || []);           // 闲鱼 itemId 是 13 位
      const o1cn = (html.match(/O1CN[A-Za-z0-9]+/g) || []);
      const hrefs = [].slice.call(r.el.querySelectorAll('a[href]')).map(a => a.getAttribute('href'));
      return {
        i,
        文本: r.t.slice(0, 120),
        商品图: r.img ? r.img.slice(0, 120) : '(无)',
        图O1CN: o1cn.slice(0, 2),
        // ⚠ 键名不能以数字开头（写成 13位数字 会直接 SyntaxError: Invalid or unexpected token）
        数字13位: ids.slice(0, 4),
        href: hrefs.slice(0, 3),
        类名: String(r.el.className).slice(0, 60),
      };
    }),
  };
  return JSON.stringify(out, null, 1);
})()
