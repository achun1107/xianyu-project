const { userIdOf } = require('./lib/user-id');
const USER_ID = userIdOf();   // 在 Node 侧求值，模板里用 ${JSON.stringify(USER_ID)} 传下去
// xy-snapshot.js —— 每日快照（想要 实时 + 数据罗盘 T+1）
// 商品列表：全部商品（在售+已售）→ 想要/价格/状态/排名
// 数据罗盘：有流量的商品 → 曝光/浏览人数/浏览/成交/支付额/转化率/上架天数
(async () => {
  const num = v => { const n = Number(v); return isFinite(n) ? n : 0; };
  const out = { 采集时刻: new Date().toLocaleString('zh-CN'), ts: Date.now(), url: location.href, 错误: [] };

  // ---------- A. 商品列表（想要）----------
  const API = 'mtop.idle.web.xyh.item.list';
  const BASE = { needGroupInfo: false, userId: USER_ID, pageSize: 20, groupName: '综合', groupId: 52785096, defaultGroup: true };
  const items = {};
  try {
    for (let p = 1; p <= 12; p++) {
      let r;
      try { r = await window.lib.mtop.request({ api: API, v: '1.0', type: 'POST', data: Object.assign({}, BASE, { pageNumber: p }) }); }
      catch (e) { out.错误.push('商品列表第' + p + '页: ' + (e && e.message)); break; }
      if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0)) { out.错误.push('商品列表第' + p + '页 ret=' + JSON.stringify(r && r.ret)); break; }
      const cards = (r.data && r.data.cardList) || [];
      if (!cards.length) break;
      let added = 0;
      cards.forEach(c => {
        const cd = c.cardData || {};
        const id = String(cd.id || '');
        if (!id || items[id]) return;
        added++;
        const hits = [];
        const walk = (o, dep) => {
          if (!o || typeof o !== 'object' || dep > 7) return;
          if (Array.isArray(o)) { o.forEach(x => walk(x, dep + 1)); return; }
          if (typeof o.content === 'string') hits.push(o.content);
          Object.keys(o).forEach(k => walk(o[k], dep + 1));
        };
        walk(cd.itemLabelDataVO, 0);
        let want = null, rank = null, pubAgo = null;
        hits.forEach(t => {
          let m;
          if ((m = t.match(/^(\d+)人想要$/))) want = Math.max(want || 0, parseInt(m[1], 10));
          else if (/^(热销|复购)第\d+名$/.test(t)) rank = t;
          else if (/小时内发布|一周内发布|天内发布/.test(t)) pubAgo = t;
        });
        items[id] = {
          itemId: id,
          标题: String(cd.title || '').replace(/,/g, '，').slice(0, 60),
          价格: cd.priceInfo ? num(cd.priceInfo.price) / (num(cd.priceInfo.price) > 1000 ? 100 : 1) : null,
          状态: cd.itemStatus,
          想要: want,
          排名: rank,
          发布时效: pubAgo,
        };
      });
      if (!added) break;
    }
  } catch (e) { out.错误.push('商品列表: ' + (e && e.message)); }
  out.商品数 = Object.keys(items).length;

  // ---------- B. 数据罗盘（曝光/浏览/成交）----------
  const ui = (window.__PC_SELLER_WORKBENCH__ || {}).userInfo || {};
  const h = {};
  if (ui.idle_site_biz_code) h.idle_site_biz_code = ui.idle_site_biz_code;
  if (ui.idle_user_group_member_id) h.idle_user_group_member_id = ui.idle_user_group_member_id;
  const dc = {};
  try {
    let range = null, total = null;
    for (let p = 1; p <= 6; p++) {
      const r = await window.lib.mtop.request({
        api: 'mtop.alibaba.idle.seller.pc.datacompass.item.list', v: '1.0', type: 'POST',
        data: { dateType: 'recent7d', pageNo: p, pageSize: 50 },
        appKey: '34839810', accountSite: 'xianyu', dataType: 'json', timeout: 20000,
        needLogin: false, sessionOption: 'AutoLoginOnly', ecode: 0, ext_headers: h, headers: h,
      });
      if (!range) range = (((r.data || {}).extendInfo || {}).realDateRange) || null;
      const d = (r.data || {}).data || {};
      if (total === null) total = d.total;
      const list = d.list || [];
      list.forEach(it => {
        dc[String(it.itmId)] = {
          曝光: num(it.showPv), 浏览人数: num(it.ipvUv), 浏览: num(it.ipv),
          成交: num(it.payOrdCnt), 支付额: num(it.payAmt),
          转化率: it.ipvPayUcvr, 上架天数: num(it.daysOnShelf),
        };
      });
      if (list.length < 50) break;
    }
    out.罗盘区间 = range;
    out.罗盘总数 = total;
    out.罗盘条数 = Object.keys(dc).length;
  } catch (e) { out.错误.push('数据罗盘: ' + (e && e.message)); }

  // ---------- C. 左连接 ----------
  out.商品 = Object.keys(items).map(id => {
    const a = items[id], b = dc[id] || {};
    return {
      itemId: id, 标题: a.标题, 价格: a.价格, 状态: a.状态, 想要: a.想要, 排名: a.排名, 发布时效: a.发布时效,
      曝光: b.曝光 !== undefined ? b.曝光 : null,
      浏览人数: b.浏览人数 !== undefined ? b.浏览人数 : null,
      成交: b.成交 !== undefined ? b.成交 : null,
      支付额: b.支付额 !== undefined ? b.支付额 : null,
      转化率: b.转化率 !== undefined ? b.转化率 : null,
      上架天数: b.上架天数 !== undefined ? b.上架天数 : null,
      有罗盘数据: !!b.曝光 || b.曝光 === 0,
    };
  });
  // 罗盘里有但商品列表没抓到的（已删除/不在综合分组）
  out.仅罗盘有 = Object.keys(dc).filter(id => !items[id]).map(id => ({ itemId: id, ...dc[id] }));
  return JSON.stringify(out);
})()
