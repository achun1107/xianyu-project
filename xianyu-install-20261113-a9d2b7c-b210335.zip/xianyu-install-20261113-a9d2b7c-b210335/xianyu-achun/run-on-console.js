/** run-on-console.js — 在店铺页执行「先设 window.__XX，再跑某个代码文件」的组合 */
const http = require('http'), fs = require('fs');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const [, , setVar, codeFile] = process.argv;
if (!setVar || !codeFile) { console.log('用法: node run-on-console.js "<设置语句>" <代码文件>'); process.exit(2); }

function ev(code) {
  return new Promise(r => {
    const p = JSON.stringify({ store: STORE, code });
    const q = http.request({ host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(p), 'x-api-key': KEY } },
      res => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { r(JSON.parse(b)); } catch (e) { r({ ok: false, error: b.slice(0, 400) }); } }); });
    q.on('error', e => r({ ok: false, error: e.message })); q.write(p); q.end();
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await ev(`(function(){location.href='https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage';return 'n'})()`);
  await sleep(16000);
  const s = await ev(setVar);
  console.log('设置变量: ' + JSON.stringify(s).slice(0, 200));
  const r = await ev(fs.readFileSync(codeFile, 'utf8'));
  if (!r.ok) { console.log('ERR ' + r.error); process.exit(1); }
  const d = typeof r.result === 'string' ? (() => { try { return JSON.parse(r.result); } catch (e) { return r.result; } })() : r.result;
  console.log(typeof d === 'string' ? d : JSON.stringify(d, null, 1));
  fs.writeFileSync('D:\\DSH\\achun\\console-out-' + Date.now() + '.json', typeof d === 'string' ? d : JSON.stringify(d, null, 1), 'utf8');
})();
