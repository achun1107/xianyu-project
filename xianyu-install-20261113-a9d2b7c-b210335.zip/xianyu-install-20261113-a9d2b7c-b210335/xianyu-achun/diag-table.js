// diag-table.js —— 管理页表格实际长什么样
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const out = { 时刻: new Date().toLocaleString('zh-CN'), url: location.href };
  out.tabs = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn')).map(e => (e.innerText || '').replace(/\s+/g, ' ').trim()).slice(0, 6);
  out.tr数 = document.querySelectorAll('tbody tr').length;
  const rows = [].slice.call(document.querySelectorAll('tbody tr'));
  out.前5行 = rows.slice(0, 5).map(r => (r.innerText || '').replace(/\s+/g, ' ').slice(0, 70));
  out.含孙燕姿的行 = rows.filter(r => /孙燕姿/.test(r.innerText || '')).map(r => (r.innerText || '').replace(/\s+/g, ' ').slice(0, 70));
  const pg = document.querySelector('.ant-pagination');
  out.分页 = pg ? [].slice.call(pg.querySelectorAll('.ant-pagination-item')).map(e => (e.getAttribute('title') || e.innerText || '').trim()) : null;
  out.所有分页组数 = document.querySelectorAll('.ant-pagination').length;
  out.搜索输入框 = [].slice.call(document.querySelectorAll('input')).map(e => ({ ph: e.placeholder || '', val: String(e.value || '').slice(0, 20) })).filter(x => x.ph).slice(0, 8);
  // 页面上任何地方出现计划名的位置
  const t = (document.body.innerText || '').replace(/\s+/g, ' ');
  const idx = t.indexOf('孙燕姿广州-订单120');
  out.正文里出现位置 = idx;
  out.正文附近 = idx >= 0 ? t.slice(Math.max(0, idx - 80), idx + 120) : null;
  // 是不是所有计划都在（看总数提示）
  out.计划计数提示 = (t.match(/计划\(\d+\)/g) || []).slice(0, 4);
  out.表格提示 = (t.match(/共\s*\d+\s*[条个]/g) || []).slice(0, 4);
  return JSON.stringify(out, null, 1);
})()
