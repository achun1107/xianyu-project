// probe-detail.js —— 打开陈都灵计划的「详情」，抓平台给的异常说明
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const out = { 时刻: new Date().toLocaleString('zh-CN'), url0: location.href };
  const findRow = n => [].slice.call(document.querySelectorAll('tbody tr')).find(r => (r.innerText || '').indexOf(n) >= 0);
  let row = findRow('北京陈都灵-咨询120');
  for (let p = 2; p <= 5 && !row; p++) {
    const pg = document.querySelector('.ant-pagination');
    const b = pg && [].slice.call(pg.querySelectorAll('.ant-pagination-item')).find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === String(p));
    if (!b) break;
    click1(b); await sleep(3200); row = findRow('北京陈都灵-咨询120');
  }
  if (!row) { out.err = '行没找到'; return JSON.stringify(out, null, 1); }

  const det = [].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '详情');
  out.有详情按钮 = !!det;
  if (!det) {
    // 可能「详情」是链接
    out.行内所有可点 = [].slice.call(row.querySelectorAll('a,span,button')).map(e => (e.innerText || '').trim()).filter(t => t).slice(0, 12);
    return JSON.stringify(out, null, 1);
  }
  click1(det);
  for (let i = 0; i < 20; i++) { await sleep(1000); if (/状态异常|异常|去处理|暂停原因/.test(document.body.innerText || '')) break; }
  out.urlAfter = location.href;
  out.title = document.title;
  const t = (document.body.innerText || '').replace(/\s+/g, ' ');
  out.含状态异常 = t.indexOf('状态异常') >= 0;
  out.异常附近 = t.match(/.{0,60}(状态异常|异常|去处理|暂停原因).{0,200}/g);
  out.正文前700 = t.slice(0, 700);
  out.抽屉数 = document.querySelectorAll('.ant-drawer-content').length;
  out.弹窗数 = document.querySelectorAll('.ant-modal-content').length;
  return JSON.stringify(out, null, 1);
})()
