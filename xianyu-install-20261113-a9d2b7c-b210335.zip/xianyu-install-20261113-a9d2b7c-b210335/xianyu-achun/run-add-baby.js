// run-add-baby.js —— 批量给计划加宝贝（保护预算不被冲掉）
// 用法: node run-add-baby.js [from] [to]
const http = require('http');
const fs = require('fs');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const MANAGE = 'https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage';

// 广州孙燕姿：每个广州计划各补 1 条广州宝贝（各补到 3 个绑定，不超平台上限）
const CFGS = [
  { planName: '孙燕姿广州-咨询120', addItemId: '1079022076546', searchKey: '孙燕姿', budget: 150 },
  { planName: '孙燕姿广州-订单120', addItemId: '1083662342559', searchKey: '孙燕姿', budget: 90 },
];
const LOG = 'D:\\DSH\\achun\\run-add-baby-log.ndjson';

function ev(code) {
  return new Promise((resolve) => {
    const payload = JSON.stringify({ store: STORE, code });
    const req = http.request({ host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      res => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: b.slice(0, 300) }); } }); });
    req.on('error', e => resolve({ ok: false, error: e.message })); req.write(payload); req.end();
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const from = Number(process.argv[2] || 0), to = Number(process.argv[3] || CFGS.length);
  const DRIVER = fs.readFileSync(__dirname + '\\ad-add-baby.js', 'utf8');
  for (let i = from; i < to; i++) {
    const c = CFGS[i];
    console.log(`\n───── [${i + 1}/${CFGS.length}] ${c.planName}  +宝贝 ${c.addItemId}  预算锁¥${c.budget} ─────`);
    let r = await ev(`(function(){location.href=${JSON.stringify(MANAGE)};return 'nav'})()`);
    if (!r.ok) { console.log('  跳转失败 ' + r.error); continue; }
    await sleep(16000);
    r = await ev(`window.__ABCFG=${JSON.stringify(c)}; 'set'`);
    if (!r.ok) { console.log('  cfg 失败 ' + r.error); continue; }
    r = await ev(DRIVER);
    if (!r.ok) { console.log('  driver 失败 ' + r.error); continue; }
    let j; try { j = typeof r.result === 'string' ? JSON.parse(r.result) : r.result; } catch (e) { console.log('  解析失败 ' + String(r.result).slice(0, 300)); continue; }
    console.log('  修改前(' + (j.修改前 || []).length + '): ' + JSON.stringify(j.修改前));
    console.log('  修改后(' + (j.修改后 || []).length + '): ' + JSON.stringify(j.修改后) + (j.badge ? '  徽标' + j.badge : ''));
    if (j.预算档位) console.log('  预算档位 ' + JSON.stringify(j.预算档位) + ' → 回读 ¥' + j.预算回读 + (j.预算走预设 ? '（预设）' : '（自定义）'));
    console.log('  已保存 ' + (j.已保存 ? '✅' : '—') + (j.提示 && j.提示.length ? '  提示' + JSON.stringify(j.提示) : ''));
    if (j.fatal) console.log('  FATAL: ' + j.fatal);
    fs.appendFileSync(LOG, JSON.stringify({ ts: new Date().toISOString(), i, ...j }) + '\n', 'utf8');
    await sleep(2000);
  }
  console.log('\n完成，日志: ' + LOG);
})().catch(e => { console.error('FAIL ' + e.message); process.exit(1); });
