/**
 * publish-3-quanzhou-xuliang.js — 上架 3 个泉州徐良链接，间隔 10 分钟
 *
 * 为什么写成一个自包含脚本而不是我手动跑三次：
 *   逐个手动跑要等 20+ 分钟，容易断；这个脚本挂着后台一次跑完，每步都有日志。
 *
 * 每次发布前都先预热店铺（POST /api/agent/open-all-stores）：
 *   agent 现在是懒启动 + 空闲 20 分钟回收，publish-one.js 依赖 agent.stores['好易美代拍']，
 *   不预热会报「店铺未启动 / 店铺未就绪」。
 *
 * 用法: node publish-3-quanzhou-xuliang.js [--gap=秒] [--n=个数]
 */
const { execFileSync } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { SVC, ROOT, NODE: ENV_NODE } = require('./lib/env');

const NODE = ENV_NODE.path;
const D = ROOT;
const PUB = path.join(D, 'publish-one.js');
const LEDGER = path.join(D, '上架台账.json');
const LOGF = path.join(D, 'publish-3-quanzhou.log');
const KEY = SVC.apiKey;
const CITY = '泉州', STAR = '徐良';

const argOf = (k, d) => {
  const a = process.argv.find(x => x.startsWith('--' + k + '='));
  return a ? Number(a.split('=')[1]) : d;
};
const N = argOf('n', 3);
const GAP_MS = argOf('gap', 600) * 1000;

function log(m) {
  const line = '[' + new Date().toLocaleString('zh-CN') + '] ' + m;
  console.log(line);
  try { fs.appendFileSync(LOGF, line + '\n'); } catch (e) { }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function post(p, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body || {});
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ raw: b.slice(0, 300) }); } }); });
    req.on('error', reject);
    req.setTimeout(timeoutMs || 300000, () => req.destroy(new Error('请求超时')));
    req.write(payload); req.end();
  });
}

function ledgerCount() {
  try { return JSON.parse(fs.readFileSync(LEDGER, 'utf8')).length; } catch (e) { return -1; }
}
function lastEntry() {
  try { const l = JSON.parse(fs.readFileSync(LEDGER, 'utf8')); return l[l.length - 1]; } catch (e) { return null; }
}

(async () => {
  log('=== 开始：上架 ' + N + ' 个 ' + CITY + STAR + '，间隔 ' + (GAP_MS / 1000) + ' 秒 ===');
  const results = [];

  for (let i = 1; i <= N; i++) {
    log('──── 第 ' + i + '/' + N + ' 个 ────');

    // 1) 预热店铺（保证 agent.stores['好易美代拍'] 存在）
    try {
      const w = await post('/api/agent/open-all-stores', {}, 300000);
      log('预热: ' + JSON.stringify(w).slice(0, 160));
    } catch (e) { log('⚠️ 预热失败: ' + e.message + '（继续尝试发布）'); }

    // 2) 发布（数组参数直调 node，中文不经 shell）
    const before = ledgerCount();
    let out = '';
    try {
      out = execFileSync(NODE, [PUB, CITY, STAR], { encoding: 'utf8', timeout: 900000, maxBuffer: 8 * 1024 * 1024 });
    } catch (e) {
      out = String(e.stdout || '') + '\n' + String(e.stderr || '') + '\n[exit] ' + e.message;
    }
    out.trim().split('\n').forEach(l => log('  ' + l));

    const e = lastEntry();
    const rec = (e && ledgerCount() > before) ? e : null;
    results.push({ n: i, ok: rec ? !!rec.ok : false, itemId: rec ? rec.itemId : null,
      标题: rec ? rec.标题 : null, 定位: rec ? rec.定位 : null, 定位_账号默认: rec ? rec.定位_账号默认 : null,
      模板: rec ? rec.主图模板 : null });
    log(rec ? ('✓ 第 ' + i + ' 个: ' + (rec.itemId ? 'https://www.goofish.com/item?id=' + rec.itemId : '无 itemId') +
               '  定位=' + rec.定位 + '（账号默认 ' + rec.定位_账号默认 + '）')
            : ('✗ 第 ' + i + ' 个: 台账没新增记录，可能失败'));

    if (i < N) { log('等待 ' + (GAP_MS / 1000) + ' 秒后上第 ' + (i + 1) + ' 个 ...'); await sleep(GAP_MS); }
  }

  log('=== 全部完成 ===');
  results.forEach(r => log('  #' + r.n + (r.ok ? ' ✅ ' : ' ❌ ') + (r.itemId || '-') + '  ' + (r.标题 || '') + '  定位=' + (r.定位 || '-')));
  fs.writeFileSync(path.join(D, 'publish-3-quanzhou-result.json'), JSON.stringify(results, null, 2), 'utf8');
  log('结果已写 publish-3-quanzhou-result.json');
})().catch(e => { log('❌ 未捕获: ' + (e && e.stack || e)); process.exit(1); });
