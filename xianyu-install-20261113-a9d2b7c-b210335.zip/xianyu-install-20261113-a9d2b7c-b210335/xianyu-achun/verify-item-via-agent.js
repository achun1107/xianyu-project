/**
 * verify-item-via-agent.js — 通过 agent 验证某个商品链接的实际上架情况
 *
 * 用法: node verify-item-via-agent.js [itemId]
 *
 * 做法（沿用 verify-spec.js / verify-new-item.js 的成熟路子）：
 *   1) 把店铺的 goofish 页导航到商品页
 *   2) 注入 _verify-item-page.js，读页面上的 标题/库存/规格/描述换行
 *
 * 前置：agent.stores['好易美代拍'] 必须已预热
 *       （POST /api/agent/start-one { name: '好易美代拍' }；或代码里用 lib/agent 的 ready()）
 */
const fs = require('fs');
const http = require('http');
const path = require('path');
const { SVC, STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const ID = process.argv[2] || '1086619474447';
const PAGE_CODE = fs.readFileSync(path.join(__dirname, '_verify-item-page.js'), 'utf8');

function post(p, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 400))); } }); });
    req.on('error', reject);
    req.setTimeout(timeoutMs || 180000, () => req.destroy(new Error('请求超时')));
    req.write(payload); req.end();
  });
}

(async () => {
  const url = 'https://www.goofish.com/item?id=' + ID;
  console.log('店铺: ' + STORE);
  console.log('商品: ' + url + '\n');

  console.log('① 导航到商品页 ...');
  const nav = await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href=' + JSON.stringify(url) + '; "navigating"' }, 90000);
  console.log('   ' + JSON.stringify(nav).slice(0, 200));
  await new Promise(z => setTimeout(z, 12000));

  console.log('\n② 注入验证脚本 ...');
  const res = await post('/api/agent/eval-on-store', { store: STORE, code: 'window.__VERIFY_ID=' + JSON.stringify(ID) + ';\n' + PAGE_CODE }, 180000);
  if (!res.ok) { console.log('❌ ' + JSON.stringify(res)); process.exit(1); }

  const r = res.result || {};
  console.log('\n════ 验证结果 ════');
  console.log('  页面标题 : ' + r.title);
  console.log('  实际 href: ' + r.href);
  console.log('  期望 ID  : ' + r.期望ID);
  console.log('  正文长度 : ' + r.正文长度);
  console.log('\n  ── 关键要素 ──');
  ['代拍费', '标准', '库存', '规格', '徐良', '泉州', '秒付', '代拍流程'].forEach(k => {
    const v = r['含_' + k];
    console.log('    ' + k.padEnd(6) + ' : ' + (v === false ? '❌ 未出现' : '✅ ' + v));
  });
  console.log('\n  ── 描述换行（contenteditable 会吃换行的坑） ──');
  console.log('    换行数=' + r.描述换行数 + '  行数=' + r.描述行数);
  if (r.描述前6行) r.描述前6行.forEach((l, i) => console.log('      ' + (i + 1) + '. ' + l));
  if (r.描述) console.log('    ' + r.描述);
  console.log('\n  ── 规格/库存节点 ──');
  console.log('    节点数=' + r.规格节点数);
  (r.规格节点 || []).forEach(x => console.log('      [' + x.cls + '] ' + x.text));
  console.log('\n  ── detail 接口 ──');
  console.log('    ret=' + JSON.stringify(r.detailRet) + '  err=' + (r.detailErr || '无'));
  if (r.quantity相关) console.log('    quantity相关=' + JSON.stringify(r.quantity相关).slice(0, 300));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
