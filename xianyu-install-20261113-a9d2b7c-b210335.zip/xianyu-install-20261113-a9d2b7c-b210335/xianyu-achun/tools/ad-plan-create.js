/**
 * tools/ad-plan-create.js — 按【店铺档案】建推广计划（超级擦亮）
 *
 * 为什么需要它：
 *   推广计划那 9 项（擦亮方式/擦亮宝贝/擦亮类型/出价方式/预期成本/日花费上限/计划名称/创意优化/定向时段）
 *   以前【只存在于桌面引擎的界面里】。老板要开 100 个店，每换一台机器、每加一个店，
 *   就得在界面上重填一遍这 9 项 —— 既慢又没法核对。
 *   现在这 9 项是 stores/<店铺名>.json 的一部分，这个脚本负责把它变成真实的计划。
 *
 * 唯一权威的取值来源是 lib/store-profile.js 的 resolveAdPlan()/campaignPayload()，
 * 不在这里重复解析配置（重复解析 = 两处会漂移，这是本项目反复踩过的坑）。
 *
 * 用法:
 *   node tools/ad-plan-create.js --store=好易美代拍 --items=1088881826804 --city=广州 --star=周杰伦
 *       预演（默认）。只打印将要下发的 requestJson 和这 9 项，不发任何请求。
 *   node tools/ad-plan-create.js --store=好易美代拍 --items=1088881826804 --city=广州 --star=周杰伦 --apply
 *       真建。
 *   node tools/ad-plan-create.js --store=XX --items=<id> --bid=2.88 --budget=120 --apply
 *       临时压过档案里的 预期成本 / 日上限（只这一次生效，不改档案）。
 *   node tools/ad-plan-create.js --store=XX --items=<id> --count=3 --apply
 *       同一条链接建 3 个计划（平台允许，用于分组比价）。
 *   node tools/ad-plan-create.js --store=XX --items=<id> --hours=9-22 --name=澳门梓渝-咨询150 --apply
 *       临时压过档案里的 投放时段 / 计划名（只这一次生效，不改档案）。
 *       --hours 收两种写法：区间 `9-22`（含两端）或列表 `9,10,...,22`。
 *       ⚠️ 时段是【格】不是【小时刻度】：格 h = h:00-(h+1):00，
 *          所以「9:00-23:00」= 9-22（14 格）。写成 9-23 就是 9:00-24:00，多一小时。
 *
 * 护栏:
 *   ① 默认【预演】。建计划是花钱的动作，必须显式 --apply。
 *   ② 广告.enabled=false 的店拒绝建（要建得加 --force），避免误给不投广告的店建计划。
 *   ③ 计划名不许以「擦亮宝贝」开头 —— 那是 tools/ad-cost-breaker.js 熔断护栏判「主/副集合」的前缀，
 *      单链计划用这个前缀会被护栏当成集合，从此永不自动暂停。这条踩过一次。
 *   ④ 时段合计 < 4 小时平台会拒（store-profile 已在解析时抛错，这里兜底再报一次）。
 *   ⑤ 建完【回读校验】：不拿 startV2 的返回值当成功，重新 search 一遍，
 *      按计划名找到它，逐项比对 出价/日预算/时段/目标/创意 是否真的落上去了。
 *
 * 前置: 8093 服务在跑 + 店铺已登录（node tools/store-ready.js "<店名>"）。广告接口只在 dayu.goofish.com 下可用。
 */
const fs = require('fs');
const path = require('path');
const args = require('../lib/args');
const agent = require('../lib/agent');
const profile = require('../lib/store-profile');
const { ROOT, STORE } = require('../lib/env');

const A = args.parse();
const STORE_NAME = A.store || STORE;
const ITEMS = String(A.items || '').split(',').map((s) => s.trim()).filter(Boolean);
const CITY = A.city || '';
const STAR = A.star || '';
const APPLY = A.on('apply');
const FORCE = A.on('force');
const COUNT = Math.max(1, parseInt(A.count || '1', 10) || 1);
const BID = A.bid || '';
const BUDGET = A.budget || '';
const HOURS = A.hours || '';

const LOGF = path.join(ROOT, 'ad-plan-create.log');
const log = (s) => {
  const l = '[' + new Date().toLocaleString('zh-CN') + '] ' + s;
  console.log(l);
  try { fs.appendFileSync(LOGF, l + '\n'); } catch (e) {}
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const yuan = (n) => '¥' + (Math.round(Number(n) * 100) / 100);

// ── 读档案 ────────────────────────────────────────────────────────────────
let P;
try { P = profile.load(STORE_NAME); }
catch (e) { console.log('❌ 读店铺档案失败：' + e.message); process.exit(2); }

let plan;
try { plan = profile.resolveAdPlan(P); }
catch (e) { console.log('❌ 档案里的推广 9 项有错：' + e.message); process.exit(2); }

// ── 护栏 ② ────────────────────────────────────────────────────────────────
if (!plan.enabled && !FORCE) {
  console.log('❌ 「' + STORE_NAME + '」的 广告.enabled = false（这个店不投广告）。');
  console.log('   确实要给它建计划，加 --force。');
  process.exit(2);
}

// ── 擦亮宝贝：从档案 + 命令行定 ───────────────────────────────────────────
let babies;
if (ITEMS.length) babies = ITEMS;
else if (Array.isArray(plan.宝贝)) babies = plan.宝贝.map(String);
else if (plan.宝贝 === 'none') { console.log('❌ 档案里 广告.计划.宝贝 = "none"，这个店不建计划。'); process.exit(2); }
else { console.log('❌ 档案里 广告.计划.宝贝 = "auto"，必须用 --items=<itemId>[,...] 告诉我要推哪条链接。'); process.exit(2); }
if (babies.length > profile.AD_PLAN.MAX_ITEMS_PER_PLAN) {
  console.log('⚠️ 平台一个计划最多 ' + profile.AD_PLAN.MAX_ITEMS_PER_PLAN + ' 条链接，多余的会被截掉：' + babies.length + ' → ' + profile.AD_PLAN.MAX_ITEMS_PER_PLAN);
}

// ── 临时覆盖出价 / 预算（只影响本次，不改档案）─────────────────────────────
// over 必须同时喂给「计划名」和「payload」，否则会出现名字写 ¥4、实际出价 ¥2.88 的错位。
const over = {};
if (BID) {
  const v = Number(BID);
  if (!(v > 0)) { console.log('❌ --bid 必须是 > 0 的数字（元）'); process.exit(2); }
  plan.预期成本 = v; plan.bidPrice = Math.round(v * 100);
  over.预期成本 = v; over.bidPrice = Math.round(v * 100);
  console.log('（本次覆盖：预期成本 → ' + yuan(v) + '）');
}
if (BUDGET) {
  const v = Number(BUDGET);
  if (!(v > 0)) { console.log('❌ --budget 必须是 > 0 的数字（元）'); process.exit(2); }
  plan.日上限 = v; plan.maxDayBudget = Math.round(v * 100);
  over.日上限 = v; over.maxDayBudget = Math.round(v * 100);
  console.log('（本次覆盖：日上限 → ' + yuan(v) + '）');
}

// ── 临时覆盖投放时段（只影响本次，不改档案）───────────────────────────────────
// 老板 2026-10-16：「周六日推广是早上9点到晚上23点」→ 需要按次改时段的能力。
// 口径同 AD_PLAN.DEFAULT_HOURS 的注释：格 h = h:00-(h+1):00，
//   所以「9:00-23:00」= 9-22（14 格）；写成 9-23 就成了 9:00-24:00。
if (HOURS) {
  const s = String(HOURS).trim();
  let v = null;
  const rng = /^(\d{1,2})\s*-\s*(\d{1,2})$/.exec(s);
  if (rng) {
    const a = Number(rng[1]), b = Number(rng[2]);
    if (a <= b) { v = []; for (let h = a; h <= b; h++) v.push(h); }
  } else if (/^\d{1,2}(\s*,\s*\d{1,2})*$/.test(s)) {
    v = s.split(',').map((x) => Number(x.trim()));
  }
  if (!v || !v.length || v.some((h) => !(Number.isInteger(h) && h >= 0 && h <= 23))) {
    console.log('❌ --hours 用法: 9-22（区间，含两端）或 9,10,...,22（列表），取值 0-23');
    process.exit(2);
  }
  plan.时段 = v;
  over.时段 = v;
  console.log('（本次覆盖：投放时段 → ' + v.join(',') + ' = ' + v[0] + ':00-' + (v[v.length - 1] + 1) + ':00，' + v.length + ' 格）');
}

// ── 护栏 ④ ────────────────────────────────────────────────────────────────
if (plan.时段.length < profile.AD_PLAN.MIN_HOURS) {
  console.log('❌ 投放时段只有 ' + plan.时段.length + ' 小时，平台要求至少 ' + profile.AD_PLAN.MIN_HOURS + ' 小时。');
  process.exit(2);
}

// ── 计划名 + 护栏 ③ ──────────────────────────────────────────────────────
// 【2026-10-11 加】--name 覆盖计划名。为什么需要：
//   同一场次要建多条计划时（如三亚周杰伦要重建 3 条），档案里的名字模板
//   「{出价}·{目标}·{城市}{明星}」会给三条产出【完全同名】的计划。后果有两个：
//     ① 本脚本自己的回读校验是按 title 【精确匹配】的（见下面 CODE_READ），
//        同名会让第 2、3 次运行把前面建的也一起搜出来，日志出现
//        「建成 1 个，但按名字只搜到 2/3 个」这种自相矛盾的告警；
//     ② 事后按名字找计划（暂停 / 改价 / 对账）分不清是哪一条。
//   老板手建的那批本来就是「三亚周杰伦-咨询120 / -2 / -3」这种带序号的命名，这里对齐它。
//   ⚠️ 覆盖必须同时进 payload.baseInfo.title，否则名字和落库内容不一致（这条在
//      lib/store-profile.js campaignTitle 的注释里也强调过）。
const NAME = A.name || '';
const title = NAME || profile.campaignTitle(P, { 城市: CITY, 明星: STAR }, over);
if (/^擦亮宝贝/.test(title)) {
  console.log('❌ 计划名「' + title + '」以「擦亮宝贝」开头。');
  console.log('   这个前缀是熔断护栏判「主/副集合」的判据（lib/mtop.js isCollection），');
  console.log('   单链计划用它会从此永不自动暂停。请改 stores/' + STORE_NAME + '.json 的 广告.计划.名称。');
  process.exit(2);
}

// ── 打印：这 9 项现在是什么 ───────────────────────────────────────────────
const payload = profile.campaignPayload(P, babies.map((id) => ({ itemId: id })), { 城市: CITY, 明星: STAR }, over);
if (NAME) payload.baseInfo.title = NAME;   // 名字覆盖必须同时进 payload（见上面 --name 的注释）
console.log('');
console.log('════ 店铺档案「' + STORE_NAME + '」的推广计划 9 项 ════');
console.log('  ① 擦亮方式      ' + plan.方式 + '  (productId=' + plan.productId + ')');
console.log('  ② 擦亮宝贝      ' + babies.length + ' 条：' + babies.join(', '));
console.log('  ③ 擦亮类型      ' + plan.类型 + '  (' + profile.AD_PLAN.PROMOTION_MODES[plan.类型] + ')');
console.log('  ④ 出价方式      ' + plan.出价方式 + '  (' + profile.AD_PLAN.BID_TYPES[plan.出价方式] + ')');
console.log('  ⑤ 预期成本出价  ' + yuan(plan.预期成本) + '  → bidPrice=' + plan.bidPrice + ' 分   目标=' +
  profile.AD_PLAN.BID_TARGETS[plan.目标] + ' (' + plan.目标 + ')');
console.log('  ⑥ 日花费上限    ' + yuan(plan.日上限) + '  → maxDayBudget=' + plan.maxDayBudget + ' 分');
console.log('  ⑦ 计划名称      「' + title + '」');
console.log('  ⑧ 创意优化      ' + (plan.创意优化 ? '开' : '关') + '  (creativeOptSwitch)');
console.log('  ⑨ 定向时段      ' + plan.时段.join(',') + '  (' + plan.时段.length + ' 小时)   地区=' +
  (plan.地区.length ? JSON.stringify(plan.地区) : '不限'));
console.log('');
console.log('将要下发的 requestJson:');
console.log(JSON.stringify(payload, null, 2));
console.log('');

if (!APPLY) {
  console.log('[预演] 没有发任何请求。确认上面 9 项无误后加 --apply 真建。');
  process.exit(0);
}

// ── 真建 ──────────────────────────────────────────────────────────────────
(async () => {
  await agent.enterAdConsole({ store: STORE_NAME, timeout: 90000 });

  // 【2026-10-18 修】原来这里把 mtop.request 的异常直接抛出去，Playwright 把它包成
  //   「page.evaluate: Object」—— 错误信息全丢，只剩"失败了"三个字，无法判断是限流、
  //   参数错还是风控弹窗。现在在页面内部 try/catch，把原始错误原样带回来。
  const CODE_ONE = `
    try {
      var r = await mtop.request({api:'mtop.taobao.idle.ad.campaign.startV2', v:'1.0', type:'POST',
        data:{ requestJson: ${JSON.stringify(JSON.stringify(payload))} }});
      return JSON.stringify({ ok:true, ret: (r&&r.ret)||null, data: (r&&r.data)||null });
    } catch (e) {
      var msg = '';
      try { msg = (typeof e === 'string') ? e : JSON.stringify(e); } catch (_) { msg = String(e); }
      return JSON.stringify({ ok:false, err: msg, name: (e&&e.name)||null, message: (e&&e.message)||null });
    }`;

  log('=== 开始建计划「' + title + '」× ' + COUNT + ' ===');
  let okCount = 0;
  for (let i = 0; i < COUNT; i++) {
    let r;
    try { r = await agent.mtop(CODE_ONE, { store: STORE_NAME, timeout: 180000 }); }
    catch (e) { log('  ❌ 第 ' + (i + 1) + ' 个：' + e.message); break; }
    if (r && r.ok === false) {
      log('  ❌ 第 ' + (i + 1) + ' 个 请求内报错：' + String(r.message || r.err).slice(0, 300));
      break;
    }
    const ok = String(((r && r.ret) || [])[0] || '').indexOf('SUCCESS') === 0;
    log('  ' + (ok ? '✅' : '❌') + ' 第 ' + (i + 1) + ' 个  ret=' + JSON.stringify((r && r.ret) || null).slice(0, 160));
    if (ok) okCount++; else break;                       // 第 1 个就失败 → 后面不用试了
    if (i < COUNT - 1) await sleep(2500);
  }
  if (!okCount) { log('❌ 一个都没建成，退出'); process.exit(1); }

  // ── 护栏 ⑤：回读校验 ────────────────────────────────────────────────────
  await sleep(6000);
  const CODE_READ = `
    var r = await mtop.request({api:'mtop.taobao.idle.ad.campaign.search', v:'1.0', type:'GET',
      data:{requestJson: JSON.stringify({pageNum:1, pageSize:100, campaignStatus:[], statusGroup:[]})}});
    if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0)) return JSON.stringify({err: r && r.ret});
    var list = ((r.data||{}).result) || [];
    return JSON.stringify(list.filter(function(c){ return String(c.title||'') === ${JSON.stringify(title)}; })
      .map(function(c){
        var it = c.infoTab || {};
        return { id: String(c.campaignId), title: String(c.title||''),
          bid: String(c.cpm), budget: String(c.maxDayBudget), target: c.bidTarget,
          bidType: c.bidType, mode: c.promotionMode, creative: c.creativeOptSwitch,
          pause: String(c.pauseStatus), hours: (it.budgetScheduleDurations||[]).map(Number),
          entities: (c.entityList||[]).map(function(e){ return String(e.entityId); }),
          catIds: (c.entityList||[]).map(function(e){ return String(e.catId); }) };
      }));`;

  let found = [];
  try { found = await agent.mtop(CODE_READ, { store: STORE_NAME, timeout: 240000 }); }
  catch (e) { log('⚠️ 回读失败（计划可能已建好，但没验上）：' + e.message); process.exit(1); }
  if (!Array.isArray(found)) { log('⚠️ 回读返回异常：' + JSON.stringify(found).slice(0, 200)); process.exit(1); }

  const hoursOk = (h) => h.slice().sort((a, b) => a - b).join(',') === plan.时段.join(',');
  const wantCat = String(P.分类.channelCatId || P.分类.catId);
  log('');
  log('=== 回读校验（按计划名精确匹配，找到 ' + found.length + ' 个）===');
  let bad = 0;
  found.forEach((f) => {
    const errs = [];
    if (Number(f.bid) !== plan.bidPrice) errs.push('出价 ' + f.bid + '≠' + plan.bidPrice);
    if (Number(f.budget) !== plan.maxDayBudget) errs.push('日预算 ' + f.budget + '≠' + plan.maxDayBudget);
    if (String(f.target) !== plan.目标) errs.push('目标 ' + f.target + '≠' + plan.目标);
    if (String(f.bidType) !== plan.出价方式) errs.push('出价方式 ' + f.bidType + '≠' + plan.出价方式);
    if (String(f.creative) !== String(plan.创意优化)) errs.push('创意 ' + f.creative + '≠' + plan.创意优化);
    if (!hoursOk(f.hours)) errs.push('时段 ' + f.hours.join(',') + '≠' + plan.时段.join(','));
    if (f.catIds.some((c) => c !== wantCat)) errs.push('类目 ' + f.catIds.join('/') + '≠' + wantCat);
    if (errs.length) bad++;
    log('  ' + (errs.length ? '❌' : '✅') + ' id=' + f.id + '  ' + (f.pause === '0' ? '投放中' : '已暂停(' + f.pause + ')') +
      '  ' + (errs.length ? errs.join('，') : '出价/预算/目标/出价方式/创意/时段/类目 全部一致'));
    log('       宝贝: ' + f.entities.join(','));
  });
  if (found.length !== okCount) log('  ⚠️ 建成 ' + okCount + ' 个，但按名字只搜到 ' + found.length + ' 个（重名或分页问题，去后台核一眼）');
  log('');
  log(bad ? ('❌ 有 ' + bad + ' 个计划落库后与档案不一致') : '✅ 全部按档案落库');
  fs.writeFileSync(path.join(ROOT, 'ad-plan-create-result.json'),
    JSON.stringify({ store: STORE_NAME, title, count: okCount, wanted: plan, found }, null, 2), 'utf8');
  log('（明细已写 ad-plan-create-result.json）');
})().catch((e) => { log('❌ ' + (e && e.stack || e)); process.exit(1); });
