/**
 * tools/ad-status.js — 所有擦亮计划一屏看完（取代 ad-verify-plans / dump-plan-states /
 * list-by-status / show-all-plans 等 4 个历史重复脚本）
 *
 * 用法:
 *   node tools/ad-status.js               # 近 7 日累计 + 今日，默认摘要
 *   node tools/ad-status.js --days=1      # 只看今日
 *   node tools/ad-status.js --full        # 不截断
 *
 * 退出码: 0 正常；1 有超成本计划；2 环境/服务问题
 *
 * 设计要点（省 token）：
 *   - 默认只打一张 13 行表 + 3 行结论，全量落 logs/
 *   - 以前每次要读 5–15 KB 的 JSON
 */
const out = require('../lib/out');
const fs = require('fs');
const path = require('path');
const mtop = require('../lib/mtop');
const agent = require('../lib/agent');
const args = require('../lib/args');
const { TH, RULES, ROOT } = require('../lib/env');

const a = args.parse();
const DAYS = Number(a.days || 7);

(async () => {
  if (!(await agent.isUp())) {
    out.bad('Playwright 服务没在跑（127.0.0.1:8093）');
    out.done(2);
  }

  await agent.ready();
  await agent.enterAdConsole();

  const plans = await mtop.adPlans({ days: DAYS });
  if (!plans.length) { out.warn('没拉到任何计划'); out.done(0); }

  out.head('擦亮计划 · 近 ' + DAYS + ' 日');

  const online = plans.filter((p) => p.verdict === 'online');
  const collections = plans.filter((p) => p.isCollection);
  const pausedBudget = plans.filter((p) => p.verdict === 'budget_paused');
  const pausedBalance = plans.filter((p) => p.verdict === 'balance_paused');
  const manual = plans.filter((p) => p.verdict === 'manual_paused');

  out.kv('计划总数', plans.length + '（集合 ' + collections.length + ' / 单链 ' + (plans.length - collections.length) + '）');
  out.kv('投放中', online.length + ' 条');
  const pausedBits = [];
  if (pausedBudget.length) pausedBits.push('超日预算 ' + pausedBudget.length);
  if (pausedBalance.length) pausedBits.push('余额不足 ' + pausedBalance.length);
  if (manual.length) pausedBits.push('手动暂停 ' + manual.length);
  if (pausedBits.length) out.kv('已停', pausedBits.join(' / '));

  // 按累计花费降序，花钱多的排前面
  const sorted = plans.slice().sort((x, y) => y.cumCost - x.cumCost);
  out.table(mtop.PLAN_HEADERS, sorted.map(mtop.planRow),
    { maxCol: [10, 24, 6, 13, 10, 10, 7, 6, 5] });

  // ── 对照永久规则：单次咨询成本 ≤ ¥4 ──
  const over = online.filter((p) => p.cumChat > 0 && p.costPerChat > TH.adTargetCost);
  const zeroChat = online.filter((p) => p.cumChat === 0 && p.cumCost >= TH.adCumCost);
  const totalCost = plans.reduce((s, p) => s + p.cumCost, 0);
  const totalChat = plans.reduce((s, p) => s + p.cumChat, 0);

  out.head('结论');
  out.kv('总花费/总咨询', '¥' + totalCost.toFixed(0) + ' / ' + totalChat +
    '  → 平均单次 ' + (totalChat ? '¥' + (totalCost / totalChat).toFixed(2) : '—'));

  if (over.length) {
    out.warn('超出 ¥' + TH.adTargetCost + ' 目标的计划 ' + over.length + ' 条：');
    over.sort((x, y) => y.costPerChat - x.costPerChat).forEach((p) =>
      out.plain('    ' + p.name.slice(0, 24) + '  ¥' + p.costPerChat.toFixed(2) + '/咨询' +
        (p.isCollection ? '  【集合·按规矩不动】' : '  【单链·可调】')));
  }
  if (zeroChat.length) {
    out.warn('花过 ¥' + TH.adCumCost + ' 但 0 咨询 ' + zeroChat.length + ' 条：' +
      zeroChat.map((p) => p.name.slice(0, 18)).join('、'));
  }
  if (pausedBalance.length) out.warn('有 ' + pausedBalance.length + ' 条因余额不足停投，需充值');

  // ── 「窗口内却没在投」——最容易漏的一类 ──
  //   它不超成本、不一定零咨询，只是压根没跑。2026-10-08 的广州KPL计划就是这样：
  //   run-cfgs 记 confirmed:true，平台侧 pauseStatus=1、今日 ¥0 ——
  //   而这条结论行当时照样打「全部在 ¥4 目标内，无异常」。
  //   关窗时段（23:00-08:00）全店暂停是【设计如此】，所以必须先看时间，否则每天夜里都假警报。
  const hour = new Date().getHours();
  const inWindow = hour >= 8 && hour < 23;
  const adsPaused = fs.existsSync(path.join(ROOT, 'PAUSE-ADS'));
  const stuck = (!adsPaused && inWindow)
    ? plans.filter((p) => p.verdict !== 'online' && p.verdict !== 'budget_paused' && p.verdict !== 'balance_paused')
    : [];
  if (stuck.length) {
    out.warn('现在是投放时段，但有 ' + stuck.length + ' 条计划【没在投】（不超成本也不缺余额，就是没跑）：');
    stuck.forEach((p) => out.plain('    ' + p.name.slice(0, 24) + '  ' + p.verdictCn +
      (p.desc ? '（' + p.desc.slice(0, 22) + '）' : '') + '  今日 ¥' + p.dayCost.toFixed(2)));
    out.plain('    → 先看平台给的状态描述；「部分商品因状态异常无法擦亮」多为新链接还没放行推广。');
  } else if (!inWindow && !adsPaused) {
    out.kv('窗口', '现在 ' + hour + ' 点，关窗时段（08:00-23:00 才投）—— 暂停属正常，不判定');
  } else if (adsPaused) {
    out.kv('窗口', '存在 PAUSE-ADS（全店停投）—— 暂停属正常，不判定');
  }

  // 三态收尾：✅ 验过没问题 / ❌ 验过有问题 / ⓘ 没验成。绝不把「没验成」渲染成 ✅
  const problems = over.length + zeroChat.length + pausedBalance.length + stuck.length;
  if (!plans.length) {
    out.warn('ⓘ 没验成：一条计划都没拉到 —— 这不是"没问题"，是"没检查"');
  } else if (problems) {
    out.bad('有 ' + problems + ' 处要看（见上）');
  } else if (!inWindow || adsPaused) {
    out.ok('已核对（当前是关窗/停投时段，只核对了成本与状态，未判定"在不在投"）');
  } else {
    out.ok('全部在 ¥' + TH.adTargetCost + ' 目标内，且都在投，无异常');
  }

  out.plain('');
  out.kv('永久规则', '单次咨询 ≤ ¥' + TH.adTargetCost + '；咨询量上限 ' + RULES.chatCap + '；订单量上限 ' + RULES.orderCap);
  out.kv('护栏', '「' + RULES.collectionPrefix + '*」主/副集合一律不自动暂停');

  out.full(plans, 'ad-status');
  // 退出码也分三态：有要看的（超成本 / 没在投 / 余额）→ 1；一条都没拉到 → 2（没验成，不能当通过）
  out.done(!plans.length ? 2 : (problems ? 1 : 0));
})().catch((e) => { out.bad(e.message); out.done(2); });
