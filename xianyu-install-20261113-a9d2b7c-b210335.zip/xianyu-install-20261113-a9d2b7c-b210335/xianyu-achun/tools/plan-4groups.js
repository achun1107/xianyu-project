/**
 * tools/plan-4groups.js — 4 组城市明星的标题预演（不发布）
 *
 * 回答老板的问题：「轮次是什么意思？你把轮次后的标题发我看看」
 * 做法：读真实的标题模板源（~/.xianyu-templates.json，4 条），
 *       对 4 个「城市+明星+轮次」组合，分别渲染：
 *         A) 现状模板（无 {场次类型}）—— 标题里看不出轮次
 *         B) 加轮次模板（插入 {场次类型}）—— 标题里带轮次
 *       并用与 publish-one.js 完全一致的 fitTitle 整形，报字数与卡片标题检查。
 *
 * 用法: node tools/plan-4groups.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

const TPLF = path.join(os.homedir(), '.xianyu-templates.json');
const T = JSON.parse(fs.readFileSync(TPLF, 'utf8')).templates;

// ── 与 publish-one.js 同源的 fitTitle（逐字复制，保证预演=实际）──
const TITLE_MAX = 40;
const TITLE_MIN = 30;
const TITLE_PAD = [' 全站全价位都可接', ' 全价位都能接', ' 高命中率', ' 全价位接', ' 可上号', ' 秒付前排', ' 稳中', ' 秒付', ' 包中'];
function fitTitle(t) {
  t = String(t == null ? '' : t);
  if (t.length > TITLE_MAX) return t.slice(0, TITLE_MAX);
  if (t.length < TITLE_MIN) {
    const gap = TITLE_MIN - t.length;
    let best = '';
    for (const f of TITLE_PAD) if (f.length <= gap && f.length > best.length) best = f;
    t += best;
    while (t.length < TITLE_MIN) t += '！';
  }
  return t;
}

const EVENT = '演唱会';
const GROUPS = [
  { no: 1, city: '广州', star: '徐良',   session: '首开' },
  { no: 2, city: '泉州', star: '徐良',   session: '二开' },
  { no: 3, city: '杭州', star: '孙燕姿', session: '三开' },
  { no: 4, city: '杭州', star: '孙燕姿', session: '回流捡漏' },
];

/** 给模板插入 {场次类型}：在 {活动类型} 之后插；模板4 把写死的「首开」换成 {场次类型} */
function withSession(p) {
  let s = String(p).replace(/首开代抢/, '{场次类型}代抢');        // 模板4 写死的首开
  s = s.replace(/(\{活动类型\})/, '$1{场次类型}');               // 其余在活动类型后插
  return s;
}

function render(pattern, g) {
  const raw = String(pattern)
    .replace(/\{明星\}/g, g.star)
    .replace(/\{城市\}/g, g.city)
    .replace(/\{活动类型\}/g, EVENT)
    .replace(/\{场次类型\}/g, g.session);
  const title = fitTitle(raw);
  const fullDescHead = (title + '\n\n').slice(0, 30);
  return { raw, title, cardOk: fullDescHead === title.slice(0, 30) };
}

console.log('模板源: ' + TPLF + '   （' + T.length + ' 条）\n');
console.log('='.repeat(78));
console.log('【现状】4 组 × 4 条模板 —— 标题里【看不出轮次】');
console.log('='.repeat(78));
for (const g of GROUPS) {
  console.log('\n━━ 第 ' + g.no + ' 组  ' + g.city + g.star + ' · ' + g.session + ' ━━');
  for (const t of T) {
    const r = render(t.titlePattern, g);
    console.log(' 模板' + t.id + ' (' + String(r.title.length).padStart(2) + '字' + (r.cardOk ? '' : ' ⚠正文渗入') + '): ' + r.title);
  }
}

console.log('\n\n' + '='.repeat(78));
console.log('【加轮次】同 4 组 —— 标题里【带轮次】');
console.log('='.repeat(78));
for (const g of GROUPS) {
  console.log('\n━━ 第 ' + g.no + ' 组  ' + g.city + g.star + ' · ' + g.session + ' ━━');
  for (const t of T) {
    const r = render(withSession(t.titlePattern), g);
    console.log(' 模板' + t.id + ' (' + String(r.title.length).padStart(2) + '字' + (r.cardOk ? '' : ' ⚠正文渗入') + '): ' + r.title);
  }
}

console.log('\n\n' + '='.repeat(78));
console.log('【关键对比】同一个「杭州孙燕姿」，第 3 组 vs 第 4 组 会不会撞');
console.log('='.repeat(78));
const g3 = GROUPS[2], g4 = GROUPS[3];
for (const t of T) {
  const a = render(withSession(t.titlePattern), g3).title;
  const b = render(withSession(t.titlePattern), g4).title;
  console.log('\n 模板' + t.id);
  console.log('   三开    : ' + a);
  console.log('   回流捡漏: ' + b);
  console.log('   是否相同: ' + (a === b ? '❌ 完全一样' : '✅ 不同'));
}
console.log('\n【若不改模板】同条件下：');
for (const t of T) {
  const a = render(t.titlePattern, g3).title;
  const b = render(t.titlePattern, g4).title;
  console.log(' 模板' + t.id + '  三开 vs 回流捡漏 → ' + (a === b ? '❌ 完全一样: ' + a : '✅ 不同'));
}
