/**
 * tools/ad-window.js — 每日投放窗口开关：08:00 全店开投 / 23:00 全店停投
 *
 * 为什么不用 pause-plans.js / resume-plans.js（2026-10-07 老板定的）：
 *   那两个按 campaignId 清单干活，清单过期就漏跑 —— 2026-10-07 凌晨写好 9:00 恢复脚本，
 *   但计划任务没登记，计划从 01:02 一直暂停到 13 点多。
 *   这个按【规则】干活：读全店计划 → 够了就恢复、到点就暂停 → 回读校验。
 *   以后新建的计划自动纳入，不用改计划任务、不用维护 ID 清单。
 *
 * 用法:
 *   node tools/ad-window.js --on              # 08:00 开投（PAUSE-ADS 在就跳过）
 *   node tools/ad-window.js --off             # 23:00 停投
 *   node tools/ad-window.js --on --dry        # 预演：只列会动哪些，不真改
 *   node tools/ad-window.js --on --force      # 无视 PAUSE-ADS 强制开投
 *   node tools/ad-window.js --verify          # 【守护】按当前时间判断"现在该开还是该停"，
 *                                             #   再看实际状态对不对；不一致就退出码 1 并记日志
 *
 * 为什么要有 --verify（2026-10-08 加）：
 *   这个窗口已经静默失败过两次，两次都是"任务没跑成，但没人知道"：
 *     · 2026-10-07 凌晨：9:00 的恢复脚本根本没登记成计划任务，计划从 01:02 停到 13 点多；
 *     · 2026-10-07 23:00：停投任务返回 0xFF（.cmd 混中文导致），日志一行没写，窗口整晚没关。
 *   光把任务修好不够 —— 要能在它【又没跑成】的时候发现。所以加一个独立的守护：
 *   由另一个时间点的计划任务来核对"现在到底开没开"，而不是自己证明自己。
 *
 * 约定:
 *   · PAUSE-ADS 存在 → --on 直接跳过（与 ad-watch-stuck.ps1 / ad-retry-order.ps1 同一套：
 *     「改文件、不改计划任务」，放假时落一个 PAUSE-ADS 就全停）。
 *   · --off 不受 PAUSE-ADS 影响 —— 停是安全的，也让「老板说停」立刻生效。
 *   · 主/副集合（擦亮宝贝*）按老板 2026-10-07 的要求【一并纳入】本窗口
 *     （与 pause-plans.js / set-ad-hours.js 的默认排除不同，这里是显式要管）。
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { ROOT, STORE, SVC, URLS } = require('../lib/env');

const KEY = SVC.apiKey;
const LOGF = path.join(ROOT, 'ad-window.log');
const OUTF = path.join(ROOT, 'ad-window-result.json');
const PAUSE_FLAG = path.join(ROOT, 'PAUSE-ADS');

const argv = process.argv.slice(2);
const VERIFY = argv.includes('--verify');
let DRY = argv.includes('--dry');
const FORCE = argv.includes('--force');

// 排除名单：AD-EXCLUDE.json 里的计划【不参与每日开投】。文件不存在 = 空名单（行为不变）。
// 老板 2026-10-08 说「广州周杰伦的推广全部暂停」—— 光调 pause 不够，因为平台把
// 「超日预算暂停」也记成 pauseStatus=1，第二天 08:00 的 --on 会把它一起开回来。
const EXCLUDE_FILE = path.join(ROOT, 'AD-EXCLUDE.json');
let EXCLUDED = [];
try { EXCLUDED = (JSON.parse(fs.readFileSync(EXCLUDE_FILE, 'utf8')).ids || []).map(String); }
catch (e) { EXCLUDED = []; }

/**
 * 现在"应该"是开还是停？
 *   PAUSE-ADS 在 → off（放假/老板说停）
 *   08:00–22:59 → on，其余 → off
 * 边界与计划任务一致：08:00 那个任务开投，23:00 那个停投。
 */
function expectedAction() {
  if (fs.existsSync(PAUSE_FLAG)) return 'off';
  const h = new Date().getHours();
  return (h >= 8 && h < 23) ? 'on' : 'off';
}

const ACTION = argv.includes('--on') ? 'on'
  : (argv.includes('--off') ? 'off' : (VERIFY ? expectedAction() : null));
if (!ACTION) { console.log('用法: node tools/ad-window.js --on|--off|--verify [--dry] [--force]'); process.exit(2); }
// --verify 绝不改任何东西：它就是来"看"的
if (VERIFY) DRY = true;

const log = (s) => {
  const l = '[' + new Date().toLocaleString('zh-CN') + '] ' + s;
  console.log(l);
  try { fs.appendFileSync(LOGF, l + '\n', 'utf8'); } catch (e) { /* 日志写不动不影响动作 */ }
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── 2026-11-09 加：失败告警（企微）──────────────────────────────
// 为什么：关窗失败过多次，退出码非 0 但没人看见。老板已批"失败要有人看得见"。
// 实现：复用已验证的 wecom-send.ps1（-DryRun 实测 exit 0）。告警失败绝不能拖垮主流程。
function alert(title, body) {
  // 【2026-11-13 加】预演时不发告警。
  //   为什么：--dry / --verify 都是"只看会做什么"，不该产生任何外部副作用。
  //   原来预演时如果中间某步失败，会真的去发飞书/企微 —— 演练把人半夜叫起来，
  //   而且告警里写的是"关窗失败"，实际什么都没改过。
  //   （同一天在 ad-cost-breaker.js 也修过同一个毛病：--dry 真的发了企微。）
  if (DRY) {
    log('ℹ️ 预演模式，不发告警（本来要发的：' + title + '）');
    return;
  }
  try {
    const f = path.join(ROOT, 'ad-window-alert.md');
    const line = title + '\n' + body + '\n时间：' + new Date().toLocaleString('zh-CN');
    fs.writeFileSync(f, '**' + title + '**\n\n' + body + '\n\n时间：' + new Date().toLocaleString('zh-CN'), 'utf8');

    // 【2026-11-10】首选飞书（企微 850003 已失效）；飞书失败再退企微，最后落桌面（feishu-alert 自己会写）。
    let feishuOk = false;
    try {
      require('child_process').execFileSync(process.execPath,
        [path.join(ROOT, 'tools', 'feishu-alert.js'), '--text', line],
        { timeout: 45000, encoding: 'utf8', stdio: 'pipe' });
      feishuOk = true;
    } catch (e) { /* 落到企微 */ }
    if (feishuOk) { log('📣 已发飞书告警'); return; }

    let code = 0, out = '';
    try {
      require('child_process').execFileSync('powershell.exe',
        ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(ROOT, 'wecom-send.ps1'), '-File', f],
        { timeout: 60000, encoding: 'utf8' });
    } catch (e) { code = e.status == null ? -1 : e.status; out = String((e.stdout || e.message || '')).slice(0, 200); }
    // 【2026-11-09 实测】企微机器人返回 850003「消息使用权限已过期」，wecom-send 会退 3 并写两个落盘兜底：
    //   本目录 `!企微发送失败.txt` + 桌面 `!XIANYU-ALERT-ACTION-NEEDED.txt`。
    //   所以 3 不是"没告警"，是"企微没发出去、但人能看到桌面文件"——照实记，不当成功也不当崩溃。
    if (code === 0) log('📣 飞书失败，已发企微告警');
    else if (code === 3) log('📣 飞书+企微都未送达，已落桌面兜底 !XIANYU-ALERT-ACTION-NEEDED.txt');
    else log('⚠ 告警异常（飞书失败、企微 exit ' + code + '）: ' + out);
  } catch (e) { log('⚠ 告警发送失败（不影响主流程）: ' + (e && e.message)); }
}

// ── 2026-11-09 加：就绪轮询（替代写死的 sleep 16s）──────────────
// 为什么：11-06 / 11-08 / 11-09 的失败都发生在"导航后固定等 16 秒"这一刻：
//   日志时间戳 `begin → +16s` 精确对上，而 11-07 成功那天 eval 多花了 8 秒才跑完。
//   根因是广告页掉登录 → mtop 拒绝（抛对象）→ eval 无 try/catch → 只剩 `page.evaluate: Object`。
//   所以两件事一起做：①等到页面真的可用再跑；②不可用时把原因原样打出来。
const READY_CODE = `(function(){
  try {
    var href = String(location.href || '');
    var onAd = href.indexOf('dayu.goofish.com') >= 0;
    var hasMtop = !!(window.lib && window.lib.mtop);
    var txt = document.body ? document.body.innerText : '';
    var needLogin = /立即登录|登\\s*录/.test(txt) && !/退出登录/.test(txt);
    return JSON.stringify({ href: href, onAd: onAd, hasMtop: hasMtop, needLogin: needLogin,
      ready: document.readyState, head: txt.replace(/\\s+/g,' ').slice(0, 160) });
  } catch (e) { return JSON.stringify({ error: String(e) }); }
})()`;

async function waitReady(maxMs) {
  const t0 = Date.now();
  let last = null;
  while (Date.now() - t0 < maxMs) {
    const r = await ev(READY_CODE, 30000);
    let info = null;
    try { info = typeof r.result === 'string' ? JSON.parse(r.result) : r.result; } catch (e) { info = null; }
    last = info || { raw: r };
    // 【2026-11-09 21:20 修】不再用「页面是否出现立即登录」当判据——那是**文案**，不是鉴权事实。
    // 实测：页面文案里有「立即登录」时，广告接口照样 SUCCESS（登录墙是渲染残留）。
    // 真正的鉴权判据在 inner eval：接口是否 SUCCESS。所以这里只等"页面就位"。
    if (info && info.onAd && info.hasMtop && info.ready === 'complete') return { ok: true, info };
    await sleep(2000);
  }
  return { ok: false, timeout: true, info: last };
}

function ev(code, timeoutMs) {
  return new Promise((resolve) => {
    const payload = JSON.stringify({ store: STORE, code });
    const req = http.request({ host: SVC.host, port: SVC.port, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: b.slice(0, 300) }); } }); });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.setTimeout(timeoutMs || 240000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}
const unpack = (r) => { let d = r && r.result; if (typeof d === 'string') { try { d = JSON.parse(d); } catch (e) {} } return d; };
const setUtf8 = (f, o) => fs.writeFileSync(f, JSON.stringify(o, null, 1), 'utf8');

const inner = `(async () => {
 try {
  const mtop = window.lib.mtop;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const ACTION = ${JSON.stringify(ACTION)};
  const DRY = ${DRY ? 'true' : 'false'};
  const WANT = ACTION === 'on' ? '0' : '1';
  // 【2026-10-08 加】排除名单：只对「开投」生效。
  //   为什么需要：老板说「XX 的推广全部暂停」，但平台把「超日预算暂停」和「手动暂停」
  //   的 pauseStatus 都记成 1，分不出来（lib/mtop.js 的注释警告过这个判据无效）。
  //   于是每天 08:00 的 --on 会把它一起开起来 —— 那样的「暂停」明天就自己回来了。
  //   停投(off)【不】看名单：停永远是安全的，也让「老板说停」立刻生效。
  const EXCLUDE = new Set(${JSON.stringify(EXCLUDED)}.map(String));
  const out = { 时刻: new Date().toLocaleString('zh-CN'), 动作: ACTION === 'on' ? '开投' : '停投' };

  const search = async () => {
    let all = [], p = 1;
    while (p <= 5) {
      const r = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
        data: { requestJson: JSON.stringify({ pageNum: p, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
      if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0)) throw new Error('search 失败: ' + JSON.stringify(r && r.ret));
      const list = (r.data || {}).result || [];
      all = all.concat(list);
      if (list.length < 100) break;
      p++;
    }
    return all;
  };

  const before = await search();
  const list = before.map(c => ({
    id: String(c.campaignId), name: String(c.title || ''),
    pause: String(c.pauseStatus), group: String(c.statusGroup || ''),
  }));
  out.全店计划数 = list.length;
  out.变更前 = { 投放中: list.filter(x => x.pause === '0').length, 已暂停: list.filter(x => x.pause === '1').length };

  // 只认 投放中(0) / 已暂停(1)；已结束等其他状态一律不碰
  // 排除名单只在开投时生效：名单里的计划即使 pauseStatus=1 也【不开】。
  const excluded = (WANT === '0') ? list.filter(x => EXCLUDE.has(x.id)) : [];
  out.排除 = excluded.map(x => ({ id: x.id, 计划名: x.name, 当前: x.pause === '0' ? '投放中' : '已暂停' }));
  const TODO = list.filter(x => (x.pause === '0' || x.pause === '1') && x.pause !== WANT)
    .filter(x => !(WANT === '0' && EXCLUDE.has(x.id)));
  out.将变更 = TODO.length;
  out.变更明细 = TODO.map(x => ({ id: x.id, 计划名: x.name, 从: x.pause === '0' ? '投放中' : '已暂停', 到: WANT === '0' ? '投放中' : '已暂停' }));
  out.不动 = list.filter(x => x.pause !== '0' && x.pause !== '1').map(x => x.id + ' 状态' + x.pause + ' ' + x.name);

  if (!TODO.length) { out.结果 = '本来就都是目标状态，无需变更'; return JSON.stringify(out, null, 1); }
  if (DRY) { out.结果 = '[预演] 没改任何东西'; return JSON.stringify(out, null, 1); }

  const ids = TODO.map(x => x.id);
  const pr = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.pause', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ campaignIds: ids, pauseStatus: Number(WANT) }) } });
  out.平台返回 = (pr.ret || [])[0];
  let ok = 0;
  Object.keys(pr.data || {}).forEach(k => { if (String((pr.data[k] || {}).pauseStatus) === WANT) ok++; });
  out.平台确认数 = ok;

  await sleep(7000);
  const after = await search();
  out.校验 = TODO.map(x => {
    const c = after.find(y => String(y.campaignId) === x.id);
    if (!c) return { id: x.id, 不存在: true };
    return { id: x.id, 计划名: String(c.title || ''), pauseStatus: String(c.pauseStatus),
      达标: String(c.pauseStatus) === WANT, 状态文案: String(c.statusDescTitle || '') };
  });
  const afterList = after.map(c => String(c.pauseStatus));
  out.变更后 = { 计划数: after.length, 投放中: afterList.filter(s => s === '0').length, 已暂停: afterList.filter(s => s === '1').length };
  const bad = out.校验.filter(x => !x.达标 && !x.不存在);
  out.结果 = bad.length
    ? ('⚠ ' + bad.length + ' 个没达标：' + bad.map(b => b.id + ' ' + b.计划名 + '（' + b.状态文案 + '）').join('；'))
    : '✅ 全部达标';
  return JSON.stringify(out, null, 1);
 } catch (e) {
  // 【2026-11-09 加】把"抛对象"变成可读错误：mtop 拒绝时给的是对象，不是 Error。
  let raw = ''; try { raw = JSON.stringify(e).slice(0, 800); } catch (x) { raw = String(e); }
  return JSON.stringify({ __error: String((e && (e.stack || e.message)) || e), __raw: raw });
 }
})()`;

(async () => {
  log('=== ad-window ' + (VERIFY ? ('verify（按时间应为 ' + ACTION + '）') : ACTION) + (DRY ? ' [预演]' : '') + ' ===');

  // PAUSE-ADS 门：只有开投会看它
  if (ACTION === 'on' && !FORCE && fs.existsSync(PAUSE_FLAG)) {
    log('PAUSE-ADS 存在：停投中，本轮不开投（要强开用 --force）');
    setUtf8(OUTF, { 时刻: new Date().toLocaleString('zh-CN'), 动作: '开投', 结果: '跳过：PAUSE-ADS 存在' });
    process.exit(0);
  }

  // 导航本身就是最好的探活：8093 在、但店铺页被回收时会明确回「店铺「x」未就绪」。
  // ⚠️ 别在导航前用 ev('1+1') 之类去探活 —— 页面没 ready 时它同样报错，会误判成「服务不可用」。
  const nav = await ev(`(function(){location.href=${JSON.stringify(URLS.adConsole)};return 'nav'})()`);
  if (!nav.ok) {
    log('❌ 导航失败：' + (nav.error || '未知') + '（先跑 node tools/ensure-agent.js 预热店铺页）');
    alert('擦亮窗口' + (ACTION === 'on' ? '开投' : '关窗') + '失败', '导航失败：' + (nav.error || '未知'));
    process.exit(2);
  }
  await sleep(1000);   // 导航后给页面一个起跑线，剩下的交给就绪轮询
  const wr = await waitReady(60000);
  if (!wr.ok) {
    const why = wr.login ? '广告页未登录（页面停在「立即登录」）'
      : (wr.timeout ? '等 60s 仍未就绪' : '未知');
    log('❌ 页面不可用：' + why + '  ' + JSON.stringify(wr.info || {}).slice(0, 300));
    alert('擦亮窗口' + (ACTION === 'on' ? '开投' : '关窗') + '失败',
      '页面不可用：' + why + '\n\n明细：' + JSON.stringify(wr.info || {}).slice(0, 600) +
      '\n\n处置：' + (wr.login ? '需要人工登录 dayu.goofish.com，然后手动跑 node tools/ad-window.js --off' : '检查 8093 服务与店铺页'));
    process.exit(3);
  }

  const r = await ev(inner);
  if (!r.ok) {
    log('❌ eval 失败: ' + r.error);
    alert('擦亮窗口' + (ACTION === 'on' ? '开投' : '关窗') + '失败', 'eval 失败：' + (r.error || '未知'));
    process.exit(1);
  }
  const d = unpack(r);
  if (d && d.__error) {
    log('❌ eval 内部报错: ' + d.__error + '  原文: ' + (d.__raw || '').slice(0, 400));
    alert('擦亮窗口' + (ACTION === 'on' ? '开投' : '关窗') + '失败', '内部报错：' + d.__error + '\n\n原文：' + (d.__raw || '').slice(0, 400));
    process.exit(1);
  }
  if (!d || typeof d !== 'object') { log('❌ 返回不可解析: ' + JSON.stringify(r).slice(0, 200)); process.exit(1); }

  log('全店 ' + d.全店计划数 + ' 条   变更前 投放中 ' + d.变更前.投放中 + ' / 已暂停 ' + d.变更前.已暂停);
  (d.变更明细 || []).forEach((x) => log('   · ' + x.id + '  ' + x.从 + ' → ' + x.到 + '  ' + x.计划名));
  // 必须把「排除了谁」也写进日志：否则将来没人看得出这些计划为什么没跟着开投
  (d.排除 || []).forEach((x) => log('   ⏸ 按 AD-EXCLUDE.json 排除，本轮不开投: ' + x.id + '  ' + x.计划名 + '（当前 ' + x.当前 + '）'));
  if ((d.不动 || []).length) (d.不动 || []).forEach((x) => log('   ~ 不动: ' + x));
  if (d.变更后) log('变更后 投放中 ' + d.变更后.投放中 + ' / 已暂停 ' + d.变更后.已暂停);
  log(d.结果 || '(无结果字段)');

  setUtf8(OUTF, d);
  if (VERIFY) {
    // 守护判定：期望状态 vs 实际状态。用「将变更」条数就够了 ——
    // 它就是"离目标状态还差几条"，0 条 = 达标。
    const diff = Number(d.将变更 || 0);
    const ok = diff === 0;
    log(ok
      ? ('✅ 守护校验通过：现在确实应该是「' + (ACTION === 'on' ? '投放中' : '已暂停') + '」，实际也达标（' + d.全店计划数 + ' 条）')
      : ('⚠️ 守护校验失败：现在应该是「' + (ACTION === 'on' ? '投放中' : '已暂停') + '」，但有 ' + diff + ' 条不达标' +
         '（投放中 ' + d.变更前.投放中 + ' / 已暂停 ' + d.变更前.已暂停 + '）' +
         ' —— 多半是 08:00 或 23:00 那个计划任务没跑成，看它的 LastTaskResult'));
    if (!ok) alert('擦亮窗口守护校验失败', '现在应该是「' + (ACTION === 'on' ? '投放中' : '已暂停') + '」，但有 ' + diff + ' 条不达标（投放中 ' + d.变更前.投放中 + ' / 已暂停 ' + d.变更前.已暂停 + '）');
    process.exit(ok ? 0 : 1);
  }
  const okFinal = /^✅|无需变更|预演/.test(String(d.结果 || ''));
  if (!okFinal) alert('擦亮窗口' + (ACTION === 'on' ? '开投' : '关窗') + '未达标', String(d.结果 || '(无结果字段)'));
  process.exit(okFinal ? 0 : 1);
})().catch((e) => { log('❌ ' + ((e && e.stack) || e)); process.exit(1); });
