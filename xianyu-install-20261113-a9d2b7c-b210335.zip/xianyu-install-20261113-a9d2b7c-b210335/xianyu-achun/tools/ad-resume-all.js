/**
 * tools/ad-resume-all.js — 一键恢复全店擦亮计划 + 摘掉停投开关
 *
 * 配套 tools/ad-pause-all.js。放假结束、老板说「可以开了」时跑这个。
 *
 * 只恢复【手动暂停】的计划 —— 那是我们自己停的。
 * 「余额不足」「超日预算」是平台按规则停的，不是我们的开关：
 *   余额不足 → 恢复也没用，得先充值；
 *   超日预算 → 次日预算重置会自己回来。
 * 这两类列出来但不碰，避免制造「已恢复」的假象。
 *
 * 用法:
 *   node tools/ad-resume-all.js --dry    # 只列出会被恢复的计划
 *   node tools/ad-resume-all.js          # 真恢复 + 摘开关，并回读平台确认
 *
 * 退出码: 0 = 全部在跑；1 = 有计划的恢复没被平台确认；2 = 环境问题
 */
const fs = require('fs');
const path = require('path');
const out = require('../lib/out');
const mtop = require('../lib/mtop');
const agent = require('../lib/agent');

const DRY = process.argv.includes('--dry');
const BATCH = 10;
const FLAG = path.join(__dirname, '..', 'PAUSE-ADS');

function clearFlag() {
  if (DRY) return;
  try { if (fs.existsSync(FLAG)) fs.unlinkSync(FLAG); }
  catch (e) { out.warn('摘停投开关失败：' + e.message); }
}

(async () => {
  if (!(await agent.isUp())) { out.bad('Playwright 服务没在跑（127.0.0.1:8093）'); out.done(2); return; }

  await agent.ready();
  await agent.enterAdConsole();

  const before = await mtop.adPlans({ days: 1 });
  const target = before.filter((p) => p.verdict === 'manual_paused');
  const online = before.filter((p) => p.verdict === 'online');
  const others = before.filter((p) => p.verdict !== 'manual_paused' && p.verdict !== 'online');

  out.head('全店复投');
  out.kv('计划总数', before.length + '（在跑 ' + online.length + '）');
  out.kv('待恢复（手动暂停）', target.length + ' 条');
  if (others.length) {
    out.kv('不动（平台按规则停的）', others.length + ' 条：' +
      others.map((p) => p.name.slice(0, 16) + '(' + p.verdictCn + ')').join('、'));
  }

  if (!target.length) {
    clearFlag();
    out.ok('没有需要恢复的手动暂停计划；停投开关' + (DRY ? '（--dry，未摘）' : '已摘掉'));
    out.done(0);
    return;
  }

  if (DRY) {
    out.table(mtop.PLAN_HEADERS, target.map(mtop.planRow), { maxCol: [10, 24, 6, 13, 10, 10, 7, 6, 5] });
    out.warn('--dry：以上计划【没有】下发恢复，开关也未摘');
    out.done(0);
    return;
  }

  const ids = target.map((p) => p.id);
  const failed = [];
  let ok = 0;
  for (let i = 0; i < ids.length; i += BATCH) {
    const batch = ids.slice(i, i + BATCH);
    const r = await mtop.adPause(batch, { pauseStatus: 0 });
    if (r.ok) ok += batch.length; else failed.push(batch.join(','));
    await agent.sleep(1500);
  }
  out.kv('平台接受', ok + ' / ' + ids.length);

  await agent.sleep(6000);
  const after = await mtop.adPlans({ days: 1 });
  const still = after.filter((p) => ids.indexOf(p.id) >= 0 && p.verdict !== 'online');

  out.kv('回读仍在停', still.length + ' 条');
  if (failed.length) out.warn('接口未确认的批次：' + failed.join(' | '));
  if (still.length) {
    out.table(mtop.PLAN_HEADERS, still.map(mtop.planRow), { maxCol: [10, 24, 6, 13, 10, 10, 7, 6, 5] });
    out.bad('还有 ' + still.length + ' 条没恢复');
  } else {
    out.ok('目标计划已全部恢复在跑');
  }
  clearFlag();
  out.kv('停投开关', 'PAUSE-ADS 已摘掉（自动建计划/自动恢复卡住 重新生效）');

  out.full({ before: before.length, 待恢复: ids, after: after.length, 未恢复: still.map((p) => p.id) }, 'ad-resume-all');
  out.done(still.length ? 1 : 0);
})().catch((e) => out.fail(e));
