/**
 * tools/ad-daily.js — 把擦亮计划的表现【按天落库】，供统计与归因用
 *
 * 为什么需要它（老板 2026-10-08：「你也能留下数据统计」）：
 *   原来只有 logs/ad-status-*.json 这种【快照文件】—— 每跑一次留一份，文件名带时间戳，
 *   份数越多越难用，而且要看"某条计划这周每天花了多少"得手工翻十几份文件。
 *   现在改成 data/ad-daily.json：按 (日期, 计划id) upsert，同一天只留【最晚】那次读数。
 *   一天跑两次（08:40 / 23:40），23:40 那次覆盖全天最终值。
 *
 * 字段带 今日曝光（dayShows）—— 判断"加价有没有换来量"的唯一依据。
 *
 * 用法:
 *   node tools/ad-daily.js            # 采集并写盘
 *   node tools/ad-daily.js --dry      # 只打印
 */
const fs = require('fs');
const path = require('path');
const mtop = require('../lib/mtop');
const { ROOT } = require('../lib/env');

const DRY = process.argv.includes('--dry');
const DATA = path.join(ROOT, 'data');
const FILE = path.join(DATA, 'ad-daily.json');

function hhmm() {
  const d = new Date();
  return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}
function ymdLocal() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

(async () => {
  let plans;
  try { plans = await mtop.adPlans(); }
  catch (e) { console.log('❌ 拉计划失败：' + (e && e.message || e)); process.exit(1); }

  const date = ymdLocal(), 时刻 = hhmm();
  const db = JSON.parse((() => { try { return fs.readFileSync(FILE, 'utf8'); } catch (e) { return '{}'; } })());
  if (!db[date]) db[date] = {};

  let wrote = 0, skipped = 0;
  for (const p of plans) {
    const prev = db[date][p.id];
    if (prev && String(prev.时刻) > 时刻) { skipped++; continue; }   // 已有更晚的读数，别倒退
    db[date][p.id] = {
      时刻,
      名称: p.name,
      目标: p.target,
      出价: p.bidYuan,
      预算: p.budgetYuan,
      状态: p.verdictCn,
      状态说明: p.desc || '',
      集合: !!p.isCollection,
      曝光: p.dayShows == null ? null : p.dayShows,
      花费: Number(p.dayCost.toFixed(2)),
      咨询: p.dayChat,
      单次咨询: p.dayChat > 0 ? Number((p.dayCost / p.dayChat).toFixed(2)) : null,
      累计花费: Number(p.cumCost.toFixed(2)),
      累计咨询: p.cumChat,
      宝贝数: p.itemCount,
      宝贝: String(p.items || '').split(',').map((s) => s.trim()).filter(Boolean),
    };
    wrote++;
  }

  const days = Object.keys(db).sort();
  console.log('日期 ' + date + ' · ' + 时刻 + '   计划 ' + plans.length + ' 条，更新 ' + wrote + '，跳过 ' + skipped);
  console.log('库里已有 ' + days.length + ' 天：' + days.slice(-7).join(', ') + (days.length > 7 ? ' …' : ''));

  if (DRY) { console.log('（--dry，未写盘）'); return; }
  if (!fs.existsSync(DATA)) fs.mkdirSync(DATA, { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(db, null, 1), 'utf8');
  console.log('已写 ' + path.relative(ROOT, FILE));
})().catch((e) => { console.log('❌ ' + (e && e.stack || e)); process.exit(1); });
