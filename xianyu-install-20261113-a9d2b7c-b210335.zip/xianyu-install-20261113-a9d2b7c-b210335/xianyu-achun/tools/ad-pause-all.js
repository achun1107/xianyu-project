/**
 * tools/ad-pause-all.js — 一键暂停全店擦亮计划 + 落下停投开关（放假 / 停投用）
 *
 * 为什么存在（2026-10-01 国庆）：
 *   老板：「今天国庆放假，推广都不开」「包含主集合副集合，全停」。
 *   以前只有 ad-resume-all.js（恢复全部），暂停全靠手输 id，放假这种临时停投没有入口。
 *   注意：本工具**不受**「主/副集合一律不自动暂停」那条护栏约束 ——
 *   那条护栏是给 ad-cost-breaker.js 的自动熔断用的（不许机器人自作主张停集合），
 *   而这里是老板明确下令的手动操作。两回事，别混。
 *
 * 除了下发暂停，还会创建 PAUSE-ADS 开关文件 —— 挡住两个会「自己把推广开起来」的任务：
 *   ad-retry-order.ps1（每天 09:00 自动建订单量计划）
 *   ad-watch-stuck.ps1（自动恢复卡住的计划）
 * 与 PAUSE-PUBLISH 同一套约定：删掉文件即恢复，不用去动 Windows 计划任务。
 *
 * 用法:
 *   node tools/ad-pause-all.js --dry     # 只列出会被暂停的计划，不下发、不落开关
 *   node tools/ad-pause-all.js           # 真暂停 + 落开关，并回读平台确认
 *
 * 退出码: 0 = 全部已停（或本来就没在跑）；1 = 有计划的暂停没被平台确认；2 = 环境问题
 */
const fs = require('fs');
const path = require('path');
const out = require('../lib/out');
const mtop = require('../lib/mtop');
const agent = require('../lib/agent');

const DRY = process.argv.includes('--dry');
const BATCH = 10;
const FLAG = path.join(__dirname, '..', 'PAUSE-ADS');

const FLAG_TEXT = [
  '停投开关（由 tools/ad-pause-all.js 落下）。',
  '',
  '存在时：',
  '  ad-retry-order.ps1   不自动建「订单量」计划',
  '  ad-watch-stuck.ps1   不自动恢复卡住的计划',
  '',
  '恢复：node tools/ad-resume-all.js   （删掉本文件并恢复计划）',
  '',
].join('\n');

function setFlag() {
  if (DRY) return;
  try {
    if (!fs.existsSync(FLAG)) fs.writeFileSync(FLAG, FLAG_TEXT, 'utf8');
  } catch (e) { out.warn('落停投开关失败：' + e.message); }
}

(async () => {
  if (!(await agent.isUp())) { out.bad('Playwright 服务没在跑（127.0.0.1:8093）'); out.done(2); return; }

  await agent.ready();
  await agent.enterAdConsole();

  const before = await mtop.adPlans({ days: 1 });
  const running = before.filter((p) => p.verdict === 'online');

  out.head('全店停投');
  out.kv('计划总数', before.length + '（已停 ' + (before.length - running.length) + '）');
  out.kv('待暂停', running.length + ' 条');

  if (!running.length) {
    setFlag();
    out.ok('本来就没有在跑的计划；停投开关' + (DRY ? '（--dry，未落）' : '已落下'));
    out.done(0);
    return;
  }

  if (DRY) {
    out.table(mtop.PLAN_HEADERS, running.map(mtop.planRow), { maxCol: [10, 24, 6, 13, 10, 10, 7, 6, 5] });
    out.warn('--dry：以上计划【没有】下发暂停，开关也未落');
    out.done(0);
    return;
  }

  const ids = running.map((p) => p.id);
  const failed = [];
  let ok = 0;
  for (let i = 0; i < ids.length; i += BATCH) {
    const batch = ids.slice(i, i + BATCH);
    const r = await mtop.adPause(batch, { pauseStatus: 1 });
    if (r.ok) ok += batch.length; else failed.push(batch.join(','));
    await agent.sleep(1500);
  }
  out.kv('平台接受', ok + ' / ' + ids.length);

  // 等平台状态刷新后回读确认 —— 不信下发时的返回值
  await agent.sleep(6000);
  const after = await mtop.adPlans({ days: 1 });
  const still = after.filter((p) => p.verdict === 'online');

  out.kv('回读仍在跑', still.length + ' 条');
  if (failed.length) out.warn('接口未确认的批次：' + failed.join(' | '));
  if (still.length) {
    out.table(mtop.PLAN_HEADERS, still.map(mtop.planRow), { maxCol: [10, 24, 6, 13, 10, 10, 7, 6, 5] });
    out.bad('还有 ' + still.length + ' 条在跑，没停干净（开关已落，先挡住自动开启）');
  } else {
    out.ok('全店 ' + after.length + ' 条计划已全部停投');
  }
  setFlag();
  out.kv('停投开关', 'PAUSE-ADS 已落下');

  out.full({ before: before.length, 待暂停: ids, after: after.length, 仍在跑: still.map((p) => p.id) }, 'ad-pause-all');
  out.done(still.length ? 1 : 0);
})().catch((e) => out.fail(e));
