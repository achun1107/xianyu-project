/**
 * tools/ad-report.js — 用 data/ad-daily.json + shows/ + 上架台账 出统计与归因
 *
 * 为什么要归因（老板 2026-10-08：要数据统计）：
 *   我们有 3 个主图版式（xuliang-v1 三黄块 / tpl_redtext 红字 / __shoukai 紫块）
 *   × 4 个文案模板 × 不同价位，但【从来没做过归因】—— 一直靠感觉在轮换。
 *   现在每个链接的版式/文案/价格都记在 shows/ 里，计划表现记在 data/ad-daily.json 里，
 *   把两者按【商品 ID】连起来就能回答「哪个版式/文案更划算」。
 *
 * 归因口径（重要，别误读）：
 *   · 只有【单链计划】（恰好绑 1 个宝贝）才能把计划表现直接当成该链接的表现。
 *   · 多宝贝计划（含集合）无法拆分到单品，单独列出、不参与归因，避免污染结论。
 *   · 「累计」列是计划生命周期累计值，样本比"今日"大得多，归因优先看它。
 *
 * 用法:
 *   node tools/ad-report.js                  # 全店今日 + 累计归因
 *   node tools/ad-report.js --days=7         # 最近 7 天
 *   node tools/ad-report.js --attr           # 只看归因
 */
const fs = require('fs');
const path = require('path');
const { ROOT } = require('../lib/env');

const DAYS = Number((process.argv.find((a) => a.startsWith('--days=')) || '--days=1').split('=')[1]) || 1;
const ONLY_ATTR = process.argv.includes('--attr');

const rd = (p, d) => { try { return JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '')); } catch (e) { return d; } };
const money = (n) => '¥' + Number(n || 0).toFixed(2);
const per = (cost, chat) => (chat > 0 ? money(cost / chat) : '—');

// itemId → {版式, 文案模板, 价格, 城市, 明星, 场次类型, 标题}
function linkIndex() {
  const idx = {};
  const dir = path.join(ROOT, 'shows');
  if (!fs.existsSync(dir)) return idx;
  for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.json'))) {
    const s = rd(path.join(dir, f), null);
    if (!s) continue;
    for (const l of (s.links || [])) {
      idx[String(l.itemId)] = {
        版式: l.主图版式 || '(未知)', 文案模板: l.文案模板, 价格: l.价格,
        城市: s.城市, 明星: s.明星, 场次类型: s.场次类型,
        开票时间: s.开票时间 || '', 标题: l.标题 || '', 区: l.区 || '',
      };
    }
  }
  return idx;
}

function loadDb() {
  const db = rd(path.join(ROOT, 'data', 'ad-daily.json'), {});
  const days = Object.keys(db).sort();
  return { db, days: days.slice(-DAYS), allDays: days };
}

(async () => {
  const { db, days, allDays } = loadDb();
  if (!days.length) { console.log('❌ data/ad-daily.json 还没有数据，先跑 tools/ad-daily.js'); process.exit(1); }
  const LI = linkIndex();

  // 每天每计划取【最晚】那次读数（同日跑了两次时以 23:40 为准）
  const latest = {};   // date -> planId -> rec
  for (const d of days) {
    latest[d] = {};
    for (const [id, v] of Object.entries(db[d] || {})) latest[d][id] = v;
  }

  // ── 汇总 ──
  let T = { 曝光: 0, 花费: 0, 咨询: 0 };
  for (const d of days) for (const v of Object.values(latest[d])) {
    T.曝光 += v.曝光 || 0; T.花费 += v.花费 || 0; T.咨询 += v.咨询 || 0;
  }
  console.log('\n══ 全店 ' + (DAYS === 1 ? days[days.length - 1] : days[0] + ' ~ ' + days[days.length - 1]) +
    '（' + days.length + ' 天，库内共 ' + allDays.length + ' 天）══');
  console.log('  曝光 ' + T.曝光 + '   花费 ' + money(T.花费) + '   咨询 ' + T.咨询 +
    '   平均单次 ' + per(T.花费, T.咨询) + '   （硬顶 ¥4）');

  if (!ONLY_ATTR) {
    // ── 按计划（累计优先，单链才有意义）──
    console.log('\n── 计划明细（累计 = 生命周期）──');
    const rows = [];
    for (const d of days) for (const [id, v] of Object.entries(latest[d])) {
      const key = id + '|' + v.名称;
      if (!rows.find((r) => r.key === key)) {
        rows.push({ key, id, ...v, 单链: v.宝贝数 === 1, 链: v.宝贝数 === 1 ? (LI[v.宝贝[0]] || null) : null });
      }
    }
    rows.sort((a, b) => (b.累计花费 || 0) - (a.累计花费 || 0));
    console.log('  id         名称                   宝贝  曝光(今) 花费(今)/咨   累计花费/咨   累计单次  版式');
    for (const r of rows) {
      console.log('  ' + String(r.id).padEnd(10) + String(r.名称).slice(0, 21).padEnd(23) +
        String(r.宝贝数).padStart(3) + '  ' + String(r.曝光 == null ? '?' : r.曝光).padStart(6) + '  ' +
        (money(r.花费) + '/' + r.咨询).padEnd(12) + '  ' +
        (money(r.累计花费) + '/' + r.累计咨询).padEnd(13) + '  ' +
        per(r.累计花费, r.累计咨询).padEnd(9) + '  ' +
        (r.单链 ? (r.链 ? r.链.版式 : '(不在 shows)') : '（多宝贝，不归因）'));
    }
  }

  // ── 归因：只用单链计划，累计口径 ──
  console.log('\n── 归因（只统计【单链计划】，口径 = 计划生命周期累计）──');
  const seenPlan = new Set();
  const attr = [];
  for (const d of days) for (const [id, v] of Object.entries(latest[d])) {
    if (seenPlan.has(id)) continue;
    seenPlan.add(id);
    if (v.宝贝数 !== 1) continue;
    const l = LI[v.宝贝[0]];
    if (!l) continue;
    attr.push({ id, 名称: v.名称, 累计花费: v.累计花费, 累计咨询: v.累计咨询, ...l });
  }
  if (!attr.length) { console.log('  （还没有可归因的单链计划）'); return; }
  console.log('  样本：' + attr.length + ' 条单链计划');

  const group = (label, keyFn) => {
    const g = {};
    for (const a of attr) {
      const k = keyFn(a) == null || keyFn(a) === '' ? '(未记录)' : String(keyFn(a));
      (g[k] = g[k] || { 花费: 0, 咨询: 0, n: 0 });
      g[k].花费 += a.累计花费 || 0; g[k].咨询 += a.累计咨询 || 0; g[k].n++;
    }
    const out = Object.entries(g).sort((x, y) => (y[1].咨询 - x[1].咨询) || (y[1].花费 - x[1].花费));
    console.log('\n  【' + label + '】');
    for (const [k, v] of out) {
      console.log('    ' + k.padEnd(16) + ' 计划 ' + String(v.n).padStart(2) +
        '   花费 ' + money(v.花费).padStart(9) + '   咨询 ' + String(v.咨询).padStart(3) +
        '   单次 ' + per(v.花费, v.咨询) +
        (v.花费 >= 50 && v.咨询 === 0 ? '   ⚠️ 花钱无咨询' : ''));
    }
  };
  group('主图版式', (a) => a.版式);
  group('文案模板', (a) => a.文案模板);
  group('价位', (a) => a.价格);

  console.log('\n  ⚠️ 读法提醒：样本还小（' + attr.length + ' 条），别拿单次成本差 ¥0.3 就下结论；');
  console.log('     要看"花过钱且拿到咨询"的组，花费 < ¥10 的组统计上没意义。');
})().catch((e) => { console.log('❌ ' + (e && e.stack || e)); process.exit(1); });
