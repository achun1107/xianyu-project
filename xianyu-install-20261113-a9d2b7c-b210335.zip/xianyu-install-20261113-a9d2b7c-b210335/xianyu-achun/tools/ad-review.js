/**
 * tools/ad-review.js —— 只读·免导航：逐条审查推广计划，按固定判据列出【该动什么】
 *
 * 老板 2026-10-11：「检查一下每个推广计划和商品想要的变动」。
 *
 * 为什么不直接用 store-audit.js：
 *   那个是【档案 vs 平台】的一致性对账，答的是「档案有没有落空」；
 *   这个问题问的是「哪些计划需要人工干预」，判据完全不同。
 *   而且它有一处会误导：它按「现在是投放时段」判定没在投的计划，但 23:00-08:00 是关窗时段，
 *   半夜跑就会把全店正常暂停的计划全报成异常。这里显式判断关窗。
 *
 * 判据（每条都能直接落到一个动作）：
 *   ① 单次咨询 > ¥4         → 超永久红线，该降出价或停投
 *   ② 单次咨询 3.2~4        → 逼近红线，观察
 *   ③ 累计花费 ≥ ¥20 且 0 咨询 → 买了量没转化，该换链接/降出价/停
 *   ④ 出价 = ¥4 上限        → 已顶格，不能再提
 *   ⑤ 日预算用掉 ≥90%       → 今天被预算卡住过
 *   ⑥ 状态不是投放中        → 分「关窗正常」和「真被停」两种
 *
 * 用法: node tools/ad-review.js
 */
const mtop = require('../lib/mtop');

const CAP = 4;                       // 咨询量出价/单次咨询红线（出价上限规则-永久.md）
const h = new Date().getHours();
const WINDOW_CLOSED = h < 8 || h >= 23;   // 全店 23:00-08:00 关窗，暂停属正常

const money = (v) => (v === Infinity ? '∞' : '¥' + Number(v || 0).toFixed(2));

(async () => {
  const ps = await mtop.adPlans();
  console.log('══ 推广计划复盘 · ' + new Date().toLocaleString('zh-CN') + ' ══');
  console.log(WINDOW_CLOSED
    ? '⚠️ 现在是【关窗时段】（全店 23:00-08:00 不投），下面显示「已暂停」的计划属正常，别当成故障。\n'
    : '现在是投放时段，显示已暂停的计划需要关注。\n');

  const rows = ps.map((p) => {
    const cpc = p.cumChat > 0 ? p.cumCost / p.cumChat : (p.cumCost > 0 ? Infinity : null);
    const flags = [];
    if (p.bidYuan >= CAP - 1e-9) flags.push('④出价顶格');
    // 【2026-10-11 修·假警报】原来 cumChat=0 且 cumCost>0 时 cpc=∞，于是「花了 ¥0.16 还没来咨询」
    //   这种完全正常的新计划会被标成「①单次咨询超¥4」。单次咨询成本这个指标只有在
    //   【至少来过 1 个咨询】时才有定义，所以先卡样本量。
    if (p.cumChat >= 1) {
      if (cpc > CAP) flags.push('①单次咨询超¥4');
      else if (cpc >= 3.2) flags.push('②逼近红线');
    } else if (p.cumCost >= 20) flags.push('③有量无转化');
    if (p.cumCost >= 20 && p.cumChat === 0) { /* 已在上面处理 */ }
    if (p.budgetYuan > 0 && p.dayCost / p.budgetYuan >= 0.9) flags.push('⑤预算打满');
    if (p.verdict === 'online') { /* ok */ }
    else if (p.isCollection) flags.push('⑥集合暂停(正常)');
    else if (WINDOW_CLOSED) flags.push('⑥关窗暂停(正常)');
    else flags.push('⑥★该在投却没投');
    return Object.assign({}, p, { cpc, flags });
  }).sort((a, b) => (b.cpc === Infinity ? 1e9 : (b.cpc || 0)) - (a.cpc === Infinity ? 1e9 : (a.cpc || 0)));

  const pad = (s, n) => { s = String(s); let w = 0; for (const ch of s) w += ch.charCodeAt(0) > 255 ? 2 : 1; return s + ' '.repeat(Math.max(1, n - w)); };
  console.log(pad('计划', 28) + pad('状态', 12) + pad('出价', 7) + pad('日预算', 8) + pad('累计¥/咨', 14)
    + pad('单次', 9) + pad('今日¥', 8) + pad('宝贝', 5) + '标记');
  console.log('-'.repeat(134));
  rows.forEach((p) => {
    console.log(
      pad(p.name.slice(0, 26), 28) + pad(p.verdictCn, 12) + pad('¥' + p.bidYuan, 7)
      + pad('¥' + p.budgetYuan, 8) + pad(money(p.cumCost) + '/' + p.cumChat, 14)
      + pad(money(p.cpc), 9) + pad(money(p.dayCost), 8) + pad(p.itemCount, 5) + p.flags.join(' ')
    );
  });

  const need = rows.filter((p) => p.flags.some((f) => /^[①②③④⑤]|★/.test(f)));
  console.log('\n── 需要你拍板的 ' + need.length + ' 条 ──');
  if (!need.length) console.log('  没有需要动的');
  need.forEach((p) => console.log('  ' + p.id + '  ' + p.name + '  → ' + p.flags.filter((f) => /^[①②③④⑤]|★/.test(f)).join('  ')
    + '   （出价¥' + p.bidYuan + ' 预算¥' + p.budgetYuan + ' 累计' + money(p.cumCost) + '/' + p.cumChat + '咨 单次' + money(p.cpc) + '）'));
})().catch((e) => { console.error('FAIL ' + ((e && e.stack) || e)); process.exit(1); });
