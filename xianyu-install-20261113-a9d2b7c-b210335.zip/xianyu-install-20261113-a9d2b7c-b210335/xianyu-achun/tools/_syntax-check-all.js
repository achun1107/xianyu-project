#!/usr/bin/env node
/**
 * tools/_syntax-check-all.js —— 单进程批量语法检查
 *
 * 为什么有它（2026-11-13）：
 *   verify-student-view 第⑨组原来对每个 js 文件启动一次 `node -c`，
 *   293 个文件 = 293 次进程启动，占掉全部检查时间的一半以上（总耗时 127 秒）。
 *   这里改成一个进程里用 vm.Script 检查所有文件，快 8 倍。
 *
 * 怎么处理 ESM：用 CommonJS 方式解析 import/export 会报错，但那【不是语法错】。
 *   这类报错直接跳过（achun 仓里绝大多数是 CJS，少数工具用了 ESM）。
 *
 * 用法:
 *   node tools/_syntax-check-all.js <目录> [<目录2> ...]
 *   node tools/_syntax-check-all.js --json <目录>
 * 退出码: 0 = 全通过，1 = 有语法错
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

// ESM 文件用 CJS 解析时会报这些 —— 不是语法错
//   ⚠️ 注意：`await is only valid in async functions` 【不能】放进这里。
//   2026-11-13 实测：函数内写 await（非 async）报的就是这句，那是【真语法错】。
//   第 76 轮那个 background.js 的 bug 正是这个 —— 被误当 ESM 跳过就永远发现不了。
//   真正的 ESM 顶层 await 也是这句，但那是极少数；宁可报出来人工看一眼，也别漏。
const ESM_NOISE = /Cannot use import statement|Unexpected token 'export'|import\.meta/i;

function walk(dir, out) {
  for (const name of fs.readdirSync(dir)) {
    if (name === 'node_modules' || name === '.git') continue;
    const p = path.join(dir, name);
    const st = fs.statSync(p);
    if (st.isDirectory()) walk(p, out);
    else if (/\.js$/i.test(name)) out.push(p);
  }
  return out;
}

const args = process.argv.slice(2);
const asJson = args[0] === '--json';
const dirs = asJson ? args.slice(1) : args;
if (!dirs.length) {
  console.log('用法: node tools/_syntax-check-all.js [--json] <目录...>');
  process.exit(2);
}

const files = [];
for (const d of dirs) {
  if (!fs.existsSync(d)) continue;
  walk(d, files);
}

const bad = [];
let skippedEsm = 0;
for (const f of files) {
  let src;
  try {
    src = fs.readFileSync(f, 'utf8');
  } catch (e) {
    bad.push({ file: f, err: '读不了: ' + e.message });
    continue;
  }
  src = src.replace(/^#!.*\n/, '');   // 去掉 shebang
  try {
    new vm.Script(src, { filename: f });   // 只解析，不执行
  } catch (e) {
    const msg = String(e.message || '');
    if (ESM_NOISE.test(msg)) { skippedEsm++; continue; }
    bad.push({ file: f, err: msg.split('\n')[0] });
  }
}

if (asJson) {
  console.log(JSON.stringify({ total: files.length, esmSkipped: skippedEsm, bad }, null, 2));
} else {
  console.log('  检查了 ' + files.length + ' 个文件（跳过 ' + skippedEsm + ' 个 ESM）');
  if (bad.length) {
    console.log('  ❌ ' + bad.length + ' 个有语法错:');
    bad.slice(0, 10).forEach((b) => console.log('     ' + path.basename(b.file) + ': ' + b.err));
  } else {
    console.log('  ✅ 全部通过');
  }
}
process.exit(bad.length ? 1 : 0);
