/**
 * tools/ad-hours-check.js —— 只读·免导航：把每个擦亮计划的【投放时段】摊开，并和期望【窗口】比对
 *
 * 为什么需要它：probe-plan-status.js 的「时段」列打印的是
 *   budgetScheduleDurationList 的【第一段~最后一段】，像 `8:00-12:00~20:00-24:00` ——
 *   首尾段看不出一共选了哪几格，而且该字段对老计划还是【过期缓存】，完全不能当依据。
 *   这个脚本摊的是 budgetScheduleDurations（整点格数组），答一个很具体的问题：
 *   **这条计划真的是 8 点到 23 点吗？**
 *
 * 【2026-10-09 修·口径】口径必须和 tools/set-ad-hours.js 一致（那边是实测得出的）：
 *   格 h 表示 h:00-(h+1):00，所以【窗口 8-23】= 格 [8..22] 共 15 格；
 *   格 [8..23] 共 16 格是窗口 8-24。权威依据是平台自己渲染的「投放时段」列
 *   （ad-hours-live.js 实测：15 格的计划平台显示「部分时段 8:00-23:00」）。
 *   ⚠ 这里原来把 --expect=8-23 当成 15 个格号 [8..23]（= 窗口 8-24），是错的。
 *
 * 用法:
 *   node tools/ad-hours-check.js                 # 只看和窗口 8-23 不一致的
 *   node tools/ad-hours-check.js --all           # 全部列出
 *   node tools/ad-hours-check.js --expect=9-17   # 指定期望窗口

 */
const agent = require('../lib/agent');

const argv = process.argv.slice(2);
const ALL = argv.includes('--all');
const EXP = (argv.find((a) => a.startsWith('--expect=')) || '').split('=')[1] || '8-23';
const [EH0, EH1] = EXP.split('-').map(Number);

const code = `
  var out = [];
  for (var p = 1; p <= 10; p++) {
    var r = await mtop.request({api:'mtop.taobao.idle.ad.campaign.search', v:'1.0', type:'GET',
      data:{requestJson: JSON.stringify({pageNum:p, pageSize:100, campaignStatus:[], statusGroup:[]})}});
    if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0)) return JSON.stringify({err:(r&&r.ret)||null});
    var list = ((r.data||{}).result) || [];
    for (var i = 0; i < list.length; i++) {
      var c = list[i], it = c.infoTab || {};
      out.push({ id: String(c.campaignId), name: String(c.title||''),
        hours: it.budgetScheduleDurations || null,
        ranges: it.budgetScheduleDurationList || null,
        pause: String(c.pauseStatus||'') });
    }
    if (list.length < 100) break;
  }
  return JSON.stringify(out);
`;

(async () => {
  const plans = await agent.mtop(code, { timeout: 180000 });
  if (!plans || plans.err) { console.log('❌ ' + JSON.stringify(plans).slice(0, 300)); process.exit(1); }

  // budgetScheduleDurations 的元素实测是纯小时字符串："8","9",...,"23"（见 tools/_probe-infoTab.js）。
  // 【2026-10-09 修·自己踩的坑】这里原来写的是 /^\\s*(\\d{1,2})/ ——
  //   这段是【普通 Node 代码】不是模板字符串，源码里的 \\s 就是字面双反斜杠，
  //   正则去匹配「反斜杠 + s」当然什么都匹配不到，于是每条计划都被判成
  //   「少了 8,9,...,23」，看着像全军覆没，其实全是工具自己的错。
  //   （同样写法的 \\s 放在模板字符串里反而会被解成 \s 而正确 —— 两种上下文别混。）
  const hourOf = (v) => {
    const n = parseInt(v, 10);          // "8" → 8；"8:00" → 8
    return isFinite(n) ? n : null;
  };
  // 窗口 X-Y 对应的整点格是 [X..Y-1]（格 h = h:00-(h+1):00），和 set-ad-hours.js 同一口径。
  const want = [];
  for (let h = EH0; h < EH1; h++) want.push(h);

  const winOf = (hs) => (hs.length ? hs[0] + ':00-' + (hs[hs.length - 1] + 1) + ':00' : '(空)');

  console.log('期望窗口: ' + EH0 + ':00–' + EH1 + ':00  →  整点格 [' + want.join(',') + ']  (' + want.length + ' 格)   共 ' + plans.length + ' 条计划\n');
  let bad = 0;
  plans.forEach((p) => {
    const hs = (p.hours || []).map(hourOf).filter((x) => x !== null).sort((a, b) => a - b);
    const missing = want.filter((h) => !hs.includes(h));
    const extra = hs.filter((h) => !want.includes(h));
    const ok = !missing.length && !extra.length;
    if (ok && !ALL) return;
    if (!ok) bad++;
    console.log((ok ? '✅' : '❌') + ' ' + p.id + '  ' + p.name);
    console.log('     格数=' + hs.length + '  实际窗口=' + winOf(hs) +
      '  范围字段(可能过期，仅供参考)=' + JSON.stringify(p.ranges));
    if (missing.length) console.log('     ⚠ 少了格: ' + missing.join(','));
    if (extra.length) console.log('     ⚠ 多了格: ' + extra.join(','));
  });
  console.log(bad ? '\n❌ 有 ' + bad + ' 条窗口不是 ' + EXP : '\n✅ 全部计划窗口都正好是 ' + EXP);
})().catch((e) => { console.error('FAIL ' + ((e && e.stack) || e)); process.exit(1); });
