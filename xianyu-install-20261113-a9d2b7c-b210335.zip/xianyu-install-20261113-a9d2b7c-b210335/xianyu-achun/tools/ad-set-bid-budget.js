/**
 * tools/ad-set-bid-budget.js —— 按 campaignId【只改出价和日预算】，不碰宝贝/时段/创意
 *
 * 为什么不用 ad-rebid.js：那个走的是网页「编辑计划」抽屉，而抽屉保存时会【提交所有字段】——
 *   仓库里记着真实事故（AB-图A-订单120 的预算被从 ¥60 冲成平台默认的 ¥96）。
 *   改【主/副集合】计划时更不能冒这个险。
 *
 * 为什么敢走 mtop：payload 结构不是猜的 —— set-ad-hours.js 里那份
 *   { itemCampaigns: [ {...search返回的整份计划对象, bid, entityIds, budget, targetInfo, budgetScheduleDurations} ] }
 *   是 2026-10-07 老板在界面上手工改一次时段、用 mtop 钩子抓下来的真实结构。
 *   读-改-写：把原对象原样回放，只换 bid / budget 两个值，其余一个字节都不动。
 *
 * 用法:
 *   node tools/ad-set-bid-budget.js 98448913 --bid=2.6 --budget=500          # 预演
 *   node tools/ad-set-bid-budget.js 98448913 --bid=2.6 --budget=500 --apply  # 真改
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { ROOT, STORE, SVC } = require('../lib/env');

const APPLY = process.argv.includes('--apply');
const ID = (process.argv.slice(2).find((a) => /^\d+$/.test(a))) || '';
const argOf = (k) => { const a = process.argv.find((x) => x.startsWith('--' + k + '=')); return a ? a.split('=')[1] : ''; };
const BID = argOf('bid') ? Number(argOf('bid')) : null;          // 元
const BUDGET = argOf('budget') ? Number(argOf('budget')) : null;  // 元
if (!ID || (BID === null && BUDGET === null)) {
  console.log('用法: node tools/ad-set-bid-budget.js <campaignId> [--bid=2.6] [--budget=500] [--apply]');
  process.exit(2);
}
const LOGF = path.join(ROOT, 'set-ad-bid-budget.log');
const log = (s) => { const l = '[' + new Date().toLocaleString('zh-CN') + '] ' + s; console.log(l); try { fs.appendFileSync(LOGF, l + '\n'); } catch (e) {} };

// 永久规则：咨询量 ≤ ¥4、订单量 ≤ ¥35（出价上限规则-永久.md）。超限 fail-closed。
const CAP = { chat: 4, order: 35 };

function ev(code, timeoutMs) {
  return new Promise((resolve) => {
    const payload = JSON.stringify({ store: STORE, code });
    const req = http.request({ host: '127.0.0.1', port: SVC.port, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': SVC.apiKey } },
      (res) => { let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: b.slice(0, 300) }); } }); });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.setTimeout(timeoutMs || 180000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}
const unpack = (r) => { let d = r && r.result; if (typeof d === 'string') { try { d = JSON.parse(d); } catch (e) {} return d; } return d; };

const READ = `(async function(){try{
var mtop=window.lib.mtop, all=[], p=1;
while(p<=5){
  var r=await mtop.request({api:'mtop.taobao.idle.ad.campaign.search',v:'1.0',type:'GET',
   data:{requestJson:JSON.stringify({pageNum:p,pageSize:100,campaignStatus:[],statusGroup:[]})}});
  if(!(r&&r.ret&&String(r.ret[0]).indexOf('SUCCESS')===0)) return JSON.stringify({err:r&&r.ret});
  var list=((r.data||{}).result)||[]; all=all.concat(list); if(list.length<100) break; p++;
}
return JSON.stringify(all.filter(function(c){ return String(c.campaignId)===${JSON.stringify(ID)}; }).map(function(c){
  var it=c.infoTab||{};
  return { id:String(c.campaignId), title:String(c.title||''), target:c.bidTarget, pause:String(c.pauseStatus),
    cpm:Number(c.cpm), budget:Number(c.maxDayBudget), creative:String(c.creativeOptSwitch),
    hours:(it.budgetScheduleDurations||[]), full:c,
    entities:(c.entityList||[]).map(function(e){ return { areaTarget:String(e.areaTarget), catId:e.catId, entityId:String(e.entityId), price:String(e.price), startTime:Number(e.publishTime)||Date.now() }; }) };
}));
}catch(e){return JSON.stringify({error:e.message});}})()`;

const TGT = { chat: '咨询量', order: '订单量' };

(async () => {
  const before = unpack(await ev(READ, 240000));
  if (!Array.isArray(before) || !before.length) { console.log('❌ 读不到计划 ' + ID + '：' + JSON.stringify(before).slice(0, 200)); process.exit(1); }
  const c = before[0];
  const targetKey = (c.target === 'order') ? 'order' : (c.target === 'chat' ? 'chat' : null);
  const cap = targetKey ? CAP[targetKey] : undefined;

  const newBidFen = BID !== null ? Math.round(BID * 100) : c.cpm;
  const newBudgetFen = BUDGET !== null ? Math.round(BUDGET * 100) : c.budget;

  console.log('计划: ' + c.id + '  ' + c.title);
  console.log('  目标=' + (TGT[c.target] || c.target) + '  状态=' + (c.pause === '0' ? '投放中' : '已暂停') +
    '  创意优化=' + c.creative + '  时段格数=' + c.hours.length + '（' + (c.hours.length ? c.hours[0] + ':00-' + (Number(c.hours[c.hours.length - 1]) + 1) + ':00' : '空') + '）');
  console.log('  出价  ¥' + (c.cpm / 100).toFixed(2) + ' → ¥' + (newBidFen / 100).toFixed(2));
  console.log('  日预算 ¥' + (c.budget / 100).toFixed(0) + ' → ¥' + (newBudgetFen / 100).toFixed(0));
  console.log('  宝贝 ' + c.entities.length + ' 个: ' + c.entities.map((e) => e.entityId).join(', '));

  if (cap !== undefined && newBidFen / 100 > cap + 1e-9) {
    console.log('❌ 出价 ¥' + (newBidFen / 100).toFixed(2) + ' 超过「' + (TGT[c.target] || c.target) + '」上限 ¥' + cap + '（永久规则），拒绝');
    process.exit(1);
  }
  if (!APPLY) { console.log('\n[预演] 没改任何东西。加 --apply 真改。'); return; }

  // ★ 原样回放整份计划对象，只换 bid / budget。
  //   budgetScheduleDurations 必须在【顶层】且是【字符串数组】（set-ad-hours.js 的抓包结论）；
  //   这里用计划当前的小时数转字符串，所以时段不会被改。
  const src = c.full || {};
  const edited = Object.assign({}, src, {
    bid: newBidFen,
    entityIds: (src.entityList || []).map((e) => Number(e.entityId)),
    budget: newBudgetFen,
    targetInfo: { divisionList: [], empty: true },
    budgetScheduleDurations: c.hours.map(String),
  });
  const payload = { itemCampaigns: [edited] };
  const r = unpack(await ev(`(async function(){try{
    var r=await window.lib.mtop.request({api:'mtop.taobao.idle.ad.campaign.edit',v:'1.0',type:'POST',
      data:{requestJson: ${JSON.stringify(JSON.stringify(payload))} }});
    return JSON.stringify({ret:r&&r.ret, data:r&&r.data});
  }catch(e){return JSON.stringify({err:e.message});}})()`, 150000));
  const ok = String(((r && r.ret) || [])[0] || '').indexOf('SUCCESS') === 0;
  log((ok ? '✅' : '❌') + ' 提交 ' + ID + (ok ? '' : '  ret=' + JSON.stringify((r && r.ret) || null).slice(0, 160) + ' err=' + String((r && r.err) || '—').slice(0, 160)));
  if (!ok) process.exit(1);

  await new Promise((s) => setTimeout(s, 7000));
  const after = unpack(await ev(READ, 240000));
  const a = Array.isArray(after) ? after[0] : null;
  if (!a) { log('⚠️ 回读失败'); process.exit(1); }
  const bidOk = a.cpm === newBidFen, budOk = a.budget === newBudgetFen, hOk = a.hours.join(',') === c.hours.join(',');
  log('回读: 出价 ¥' + (a.cpm / 100).toFixed(2) + (bidOk ? ' ✅' : ' ❌') +
    '   日预算 ¥' + (a.budget / 100).toFixed(0) + (budOk ? ' ✅' : ' ❌') +
    '   时段格数 ' + a.hours.length + (hOk ? ' ✅未变' : ' ❌变了: ' + JSON.stringify(a.hours)) +
    '   宝贝 ' + a.entities.length + (a.entities.length === c.entities.length ? ' ✅未变' : ' ❌变了'));
  log((bidOk && budOk && hOk) ? '✅ 全部到位' : '❌ 有项没到位');
})().catch((e) => { console.error('FAIL ' + ((e && e.stack) || e)); process.exit(1); });
