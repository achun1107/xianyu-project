/**
 * tools/ad-power.js —— 不导航地 暂停/恢复 擦亮计划（只调 mtop 接口）
 *
 * 为什么需要它：resume-plans.js / pause-plans.js 都会先 location.href 跳到广告后台。
 *   但浏览器里可能停着**没保存的发布草稿**（实测：停在 /publish?itemId=xxx），
 *   闲鱼的 beforeunload 会把跳转拦掉 —— 结果是 evaluate 上下文被销毁、脚本报
 *   "Execution context was destroyed"，而且反复重试都一样。
 *   而 mtop 是页面全局对象，任何 goofish 页都能调广告接口，根本不需要跳转。
 *
 * 护栏（与 resume-plans.js / pause-plans.js 一致）：
 *   目标里只要出现名字以「擦亮宝贝」开头的集合计划，整体中止 —— 集合永不由脚本自动开关。
 *
 * 用法:
 *   node tools/ad-power.js on  99746822           # 恢复
 *   node tools/ad-power.js off 12345678           # 暂停
 *   node tools/ad-power.js status 99746822        # 只看状态，不动
 */
const mtop = require('../lib/mtop');

const ACTION = process.argv[2];
const IDS = process.argv.slice(3).filter((a) => /^\d+$/.test(a));
if (!['on', 'off', 'status'].includes(ACTION) || !IDS.length) {
  console.log('用法: node tools/ad-power.js on|off|status <campaignId...>'); process.exit(2);
}

const brief = (p) => ({
  id: p.id, 名称: p.name, 目标: p.target, 状态: p.verdictCn,
  描述: p.desc || undefined, 出价: p.bidYuan, 日预算: p.budgetYuan,
  宝贝数: p.itemCount, 宝贝: p.items,
  今日花费: p.dayCost, 今日咨询: p.dayChat, 今日曝光: p.dayShows,
});

(async () => {
  const plans = await mtop.adPlans();
  const found = IDS.map((id) => plans.find((p) => p.id === id)).filter(Boolean);
  const missing = IDS.filter((id) => !plans.some((p) => p.id === id));

  console.log('目标明细（动作前）:');
  found.forEach((p) => console.log('  ' + JSON.stringify(brief(p))));
  if (missing.length) console.log('  ⚠ 没找到: ' + missing.join(', '));

  // 🚫 护栏：主/副集合一律不动
  const coll = found.filter((p) => p.isCollection);
  if (coll.length) {
    console.log('\n❌ 中止：目标里含主/副集合计划（' + coll.map((c) => c.id + ' ' + c.name).join(' | ') + '）');
    process.exit(1);
  }
  if (ACTION === 'status') { console.log('\n(只读，未做任何改动)'); return; }

  const want = ACTION === 'on' ? 0 : 1;
  // 【2026-10-13 修·一天踩两次】off 原来只挑 verdict === 'online' 的，于是
  //   「超日预算暂停」(budget_paused) / 「余额不足暂停」(balance_paused) 被当成"已停"跳过。
  //   但**这两种都会自己恢复**：预算型次日零点重置、余额型充值后即恢复。
  //   实测两次：100284773 深圳王者荣耀嘉年华、99951515 IEM北京 ——
  //   工具都回「✅ 目标已经都是「已停」，无需操作」，而计划其实明天就回来了。
  //   更坏的是下面的回读校验也写成"只要不是 online 就算成功"，于是它【报 ✅】——
  //   一个会撒谎的成功，比失败更难查。
  //   正确判据：off 要处理的是【所有不是手动暂停的】；回读也只认 manual_paused。
  // ⚠️【2026-11-12 修】found 为空时不能往下走。
  //   实测（第 18 轮）：查 107352452 时店铺上下文是好易美，一个都没找到，
  //   而 `need` 同样是空数组 → 走进下面那句「✅ 目标已经都是在跑，无需操作」。
  //   真相是"一条都没找到"，却报成"已经都是好的" —— 又一个会撒谎的成功。
  if (!found.length) {
    console.log('\n❌ 一个目标都没找到：' + (missing.join(', ') || '(未指定)'));
    console.log('   这【不等于】已经都在跑。常见原因：');
    console.log('     ① 店铺上下文不对 —— 加 XY_STORE="店名" 再试（agent 会切回默认店，很坑）');
    console.log('     ② 计划 id 打错，或计划在另一个广告账户下');
    console.log('     ③ 计划已被删除');
    process.exit(1);
  }

  const need = found.filter((p) => (ACTION === 'on' ? p.verdict !== 'online' : p.verdict !== 'manual_paused'));
  if (!need.length) { console.log('\n✅ ' + found.length + ' 个目标已经都是「' + (ACTION === 'on' ? '在跑' : '手动暂停') + '」，无需操作'); return; }

  console.log('\n将对 ' + need.length + ' 个计划执行 ' + (ACTION === 'on' ? '恢复' : '暂停') + '...');
  const r = await mtop.adPause(need.map((p) => p.id), { pauseStatus: want });
  console.log('平台返回: ' + (r.ret || []).join(' | '));

  await new Promise((s) => setTimeout(s, 8000));
  const after = await mtop.adPlans();
  console.log('\n动作后校验:');
  let bad = 0;
  IDS.forEach((id) => {
    const p = after.find((x) => x.id === id);
    if (!p) { console.log('  ' + id + ' (已不存在)'); return; }
    // off 的成功判据必须是「真的变成手动暂停」，不能是"反正它不是 online"
    const ok = ACTION === 'on' ? p.verdict === 'online' : p.verdict === 'manual_paused';
    if (!ok) bad++;
    let hint = p.desc ? ' (' + p.desc + ')' : '';
    if (!ok && (p.verdict === 'budget_paused' || p.verdict === 'balance_paused')) {
      hint += '  ⚠️ 仍是自动型暂停，**会自己恢复**（预算型次日重置 / 余额型充值后恢复）—— 没真正停住';
    }
    console.log('  ' + (ok ? '✅' : '❌') + ' ' + id + ' ' + p.name + ' → ' + p.verdictCn + hint);
  });
  console.log(bad ? '\n⚠ 有 ' + bad + ' 个没到位' : '\n✅ 全部到位');
})().catch((e) => { console.error('FAIL ' + ((e && e.stack) || e)); process.exit(1); });
