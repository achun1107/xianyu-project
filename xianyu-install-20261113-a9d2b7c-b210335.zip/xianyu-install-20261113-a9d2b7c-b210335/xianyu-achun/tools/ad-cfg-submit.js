/**
 * tools/ad-cfg-submit.js — 切换某个建计划配置文件的 submit 开关
 *
 * 为什么要单独做成工具：这个动作我已经用 node -e 内联做过十几次，
 *   而 PowerShell 内联 JS 在这个环境里经常被吃掉（引号/花括号），反复出问题。
 *   更重要的原因：**防重复建计划**。擦亮计划删除被服务端硬拦，建错了收不回来，
 *   所以"跑完立刻把 submit 复位成 false"必须是可靠的一步，不能靠手打。
 *
 * 用法:
 *   node tools/ad-cfg-submit.js <配置文件> true|false
 *   node tools/ad-cfg-submit.js <配置文件>                      # 只看当前值
 */
const fs = require('fs');
const path = require('path');

const F = process.argv[2];
const V = process.argv[3];
if (!F) { console.log('用法: node tools/ad-cfg-submit.js <配置文件> [true|false]'); process.exit(2); }
const p = path.isAbsolute(F) ? F : path.join(process.cwd(), F);
if (!fs.existsSync(p)) { console.log('❌ 文件不存在: ' + p); process.exit(1); }

const j = JSON.parse(fs.readFileSync(p, 'utf8'));
if (!Array.isArray(j)) { console.log('❌ 配置不是数组'); process.exit(1); }

if (V === undefined) {
  j.forEach((c) => console.log('  ' + (c.planName || '(无名)') + '  submit=' + !!c.submit));
  process.exit(0);
}
if (V !== 'true' && V !== 'false') { console.log('❌ 第三个参数只能是 true / false'); process.exit(2); }
const want = V === 'true';
j.forEach((c) => { c.submit = want; });
fs.writeFileSync(p, JSON.stringify(j, null, 2), 'utf8');
console.log('  ' + path.basename(p) + '  submit -> ' + want + '   （' + j.length + ' 个计划：' +
  j.map((c) => c.planName).join(', ') + '）');
