/**
 * tools/ad-bid-suggest.js —— 问闲鱼系统【建议出价】，并算出本店口径的实付出价。
 *
 * 老板 2026-10-14 12:5x：
 *   「新上架的链接不要直接到4，出价是系统推荐的百分之120就好，
 *     不然后面没有提价空间，而且计划容易跑飞。」
 *
 * 为什么单独做成一个工具（而不是塞进 ad-plan-create.js）：
 *   出价要按【这一组宝贝】问系统（同一条链接、不同宝贝组合的建议价不同），
 *   而 ad-plan-create.js 是"给定数字就建"的形态。把"问价"单独抽出来，
 *   跑手就能先问价、再把它当 --bid= 传给 ad-plan-create —— 两边都不用改职责。
 *
 * 口径来源（不是我自己发明的，仓库里早有）：
 *   tools/open-chat-campaigns.js 开头写着：
 *     「出价 = 闲鱼系统预估出价 × 140%」+「--rate=120 表示 120%（老板 2026-09-30 这批用 120%）」
 *   本工具复用同一套：同一个接口 mtop.taobao.idle.ad.customize.bid.estimates。
 *
 * ⚠️ 永久红线：咨询量出价硬上限 ¥4.00（= 400 分）。乘完超过就**夹到 ¥4** 并大声告警
 *    （open-chat-campaigns.js 的做法是"超了就整组不建"，那是批量场景；
 *      这里是老板点名要发的组，夹到顶格比不发更符合老板意图，但一定要留痕。）
 *
 * 用法:
 *   node tools/ad-bid-suggest.js --items=1090740938713,1090742070633            # 默认 120%
 *   node tools/ad-bid-suggest.js --items=a,b --rate=140                        # 改比例
 *   node tools/ad-bid-suggest.js --items=a,b --json                           # 只输出机器可读的一行
 *
 * 退出码: 0 成功（stdout 里 `BID=<元>` 一行可直接被调用方 grep）；1 取不到建议价。
 * ⚠️ 广告接口只在 dayu.goofish.com 域可用，所以必须先 enterAdConsole()。
 */
const out = require('../lib/out');
const agent = require('../lib/agent');
const { TH } = require('../lib/env');

const argv = process.argv.slice(2);
const itemsArg = (argv.find((a) => a.startsWith('--items=')) || '').slice(8);
const rateArg = Number(((argv.find((a) => a.startsWith('--rate=')) || '').split('=')[1]));
const RATE = rateArg > 0 ? rateArg / 100 : 1.2;          // 老板口径：120%
const RATE_PCT = Math.round(RATE * 100);
const JSON_ONLY = argv.includes('--json');

const ITEMS = itemsArg.split(',').map((s) => s.trim()).filter(Boolean);
if (!ITEMS.length) {
  console.log('用法: node tools/ad-bid-suggest.js --items=<id>[,<id>] [--rate=120] [--json]');
  process.exit(2);
}

const CAP_CENT = Math.round(TH.adTargetCost * 100);       // ¥4 → 400 分（永久红线）
const CAT_DEFAULT = 201456914;                            // 代购类目兜底

/** 在售池：拿到 catId / price / publishTime（问价接口要这几个字段） */
async function fetchPool() {
  const code = [
    "const r = await mtop.request({ api:'mtop.taobao.idle.ad.item.searchV2', v:'1.0', type:'POST',",
    "  data:{ requestJson: JSON.stringify({ pageNum:1, pageSize:200, tab:'all', needTabs:true }) } });",
    "if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0)) return JSON.stringify({ err:(r&&r.ret)||null });",
    'const d = (r.data || {}).result || r.data || {};',
    'return JSON.stringify({ ok:true, list:(d.itemList||[]).map(function(i){ return {',
    '  itemId:String(i.itemId), title:String(i.title||""), price:i.price, catId:i.catId, publishTime:i.publishTime }; }) });',
  ].join('\n');
  const r = await agent.mtop(code, { timeout: 180000 });
  const d = typeof r === 'string' ? JSON.parse(r) : r;
  if (!d || d.err) throw new Error('拉在售池失败：' + JSON.stringify(d && d.err));
  return d.list || [];
}

/** 问系统建议出价（分） */
async function suggestBid(entities) {
  const code = [
    "const r = await mtop.request({ api:'mtop.taobao.idle.ad.customize.bid.estimates', v:'1.0', type:'POST',",
    '  data:{ requestJson: JSON.stringify({ entityType:1, entityList:' + JSON.stringify(entities) + ',',
    "    bidTarget:'chat', bidPrice:100, noBid:false, pcFirstRequest:false }) } });",
    'if (!(r && r.ret && String(r.ret[0]).indexOf("SUCCESS") === 0)) return JSON.stringify({ err:(r&&r.ret)||null });',
    'const row = (((r.data||{}).customizeBidRecommendVOList)||[])[0] || {};',
    'return JSON.stringify({ bidPrice: row.bidPrice, minBid: row.minBid, maxBid: row.maxBid, improve: row.improve });',
  ].join('\n');
  const r = await agent.mtop(code, { timeout: 180000 });
  const d = typeof r === 'string' ? JSON.parse(r) : r;
  if (!d || d.err) throw new Error('问建议价失败：' + JSON.stringify(d && d.err));
  return d;
}

(async () => {
  await agent.ready();
  await agent.enterAdConsole();

  const pool = await fetchPool();
  const byId = {};
  pool.forEach((i) => { byId[String(i.itemId)] = i; });

  const missing = ITEMS.filter((id) => !byId[id]);
  const entities = ITEMS.filter((id) => byId[id]).map((id) => ({
    entityId: Number(id),
    catId: Number(byId[id].catId) || CAT_DEFAULT,
    price: Math.round(Number(byId[id].price) || 5000),
    areaTarget: false,
    startTime: Number(byId[id].publishTime) || Date.now(),
  }));

  if (!entities.length) {
    console.log('❌ 这些宝贝都不在在售池里：' + ITEMS.join(',') +
      (missing.length ? '（可能还没进广告库，等几分钟）' : ''));
    process.exit(1);
  }

  const sug = await suggestBid(entities);
  if (!sug || !sug.bidPrice) {
    console.log('❌ 系统没给建议价：' + JSON.stringify(sug));
    process.exit(1);
  }

  const suggested = Number(sug.bidPrice);
  const raw = Math.round(suggested * RATE);
  const clamped = raw > CAP_CENT;
  const bid = clamped ? CAP_CENT : raw;

  if (JSON_ONLY) {
    console.log(JSON.stringify({
      suggestedCent: suggested, bidCent: bid, ratePct: RATE_PCT,
      clamped, capCent: CAP_CENT, minBid: sug.minBid, maxBid: sug.maxBid,
      entities: entities.length, missing,
    }));
    process.exit(0);
  }

  out.head('系统建议出价 · 本店口径');
  out.kv('宝贝', entities.length + ' 条' + (missing.length ? '（不在池里 ' + missing.join(',') + '）' : ''));
  out.kv('系统建议出价', '¥' + (suggested / 100).toFixed(2) +
    (sug.minBid != null ? '   （区间 ¥' + (Number(sug.minBid) / 100).toFixed(2) + ' – ¥' + (Number(sug.maxBid) / 100).toFixed(2) + '）' : ''));
  out.kv('口径', '建议价 × ' + RATE_PCT + '%');
  out.kv('算出来的出价', '¥' + (bid / 100).toFixed(2) + (clamped ? '   ⚠️ 触发红线，已夹到 ¥4.00' : '   ✅'));
  out.kv('永久红线', '咨询量 ≤ ¥' + (CAP_CENT / 100).toFixed(2));
  console.log('');
  console.log('BID=' + (bid / 100).toFixed(2));   // ← 调用方 grep 这一行
  process.exit(0);
})().catch((e) => { console.log('❌ ' + (e && e.message)); process.exit(1); });
