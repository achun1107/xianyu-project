/**
 * tools/ad-plan-alert.js — 擦亮计划「状态描述异常」巡检
 *
 * 为什么写它（2026-10-08）：
 *   当天给新发的 5 条链接建了两条超级擦亮计划（周诗雨王奕成都-咨询120 /
 *   IEM北京-咨询120），建完平台给的 statusDescTitle 是
 *   「部分商品因状态异常无法擦亮」，而不是常规的「手动暂停」。
 *
 *   两个后果：
 *     ① planVerdict() 靠 statusDescTitle 判状态 → 这两条被判成 paused/「暂停」，
 *        看不出「手动暂停」。判定函数本身没错（它如实反映文案），错的是文案。
 *     ② 这条文案到底影不影响投放，平台没写清楚。当时逐条查商品页，5 条全部
 *        「在售」且都显示「刚刚擦亮」，但那也可能是发布时的免费擦亮，
 *        不能证明付费计划真的生效了 —— 只能靠 08:00 开投后实跑观察。
 *
 *   所以本脚本只做一件事：把「描述文案不常规」的计划点出来，交给日志留痕。
 *   它【不改任何计划、不改退出码语义】—— 由 ad-window-guard.cmd 在
 *   08:40 / 23:40 顺带调用，正好是 08:00 开投之后 40 分钟，能看到计划有没有真跑起来。
 *
 * 用法:
 *   node tools/ad-plan-alert.js            # 全量报告
 *   node tools/ad-plan-alert.js --quiet    # 只在有异常时多说话（守护用）
 *
 * 退出码: 永远是 0（它只报告，判定失败与否由 ad-window.js --verify 负责）。
 */
const fs = require('fs');
const path = require('path');
const mtop = require('../lib/mtop');
const { ROOT, RULES } = require('../lib/env');

const QUIET = process.argv.includes('--quiet');
const LOGF = path.join(ROOT, 'ad-plan-alert.log');

// 常规文案：平台在这些状态下给的都是这一类，不算异常。
// 注意 '暂停' / '投放中' 也是常规（planVerdict 的兜底），别误报。
const BENIGN_DESC = /^(手动暂停|暂停|投放中|日预算.*|.*日预算.*|.*余额不足.*)$/;
// 真·异常：出现这些词就值得看一眼
const SUSPECT_DESC = /异常|无法擦亮|违规|风险|失败|审核|下架|不存在/;

function log(line) {
  console.log(line);
  try { fs.appendFileSync(LOGF, '[' + new Date().toLocaleString('zh-CN') + '] ' + line + '\n', 'utf8'); } catch (e) { /* 日志写不动不影响报告 */ }
}

(async () => {
  let plans;
  try { plans = await mtop.adPlans({ days: 7 }); }
  catch (e) { log('❌ 拉取计划失败：' + (e && e.message || e)); process.exit(0); }

  const online = plans.filter((p) => p.verdict === 'online');
  const suspects = plans.filter((p) => SUSPECT_DESC.test(p.desc || ''));
  const oddDesc = plans.filter((p) => (p.desc || '') && !BENIGN_DESC.test(p.desc) && !SUSPECT_DESC.test(p.desc));
  const overCap = plans.filter((p) => p.target === '咨询量' && p.bidYuan > RULES.chatCap + 1e-9);

  log('── 计划巡检 ── 共 ' + plans.length + ' 条   投放中 ' + online.length +
      '   文案可疑 ' + suspects.length + '   出价超顶 ' + overCap.length);

  if (suspects.length) {
    suspects.forEach((p) => log('   ⚠️ ' + p.id + '  ' + p.name +
      '   文案「' + p.desc + '」  宝贝 ' + p.itemCount + ' 个' +
      '  今日 ¥' + p.dayCost.toFixed(2) + '/' + p.dayChat + ' 咨询' +
      '  近7日 ¥' + p.cumCost.toFixed(2) + '/' + p.cumChat + ' 咨询' +
      '  ' + p.verdictCn));
  }
  if (oddDesc.length) {
    oddDesc.forEach((p) => log('   · ' + p.id + '  ' + p.name + '   文案「' + p.desc + '」(' + p.verdictCn + ')'));
  }
  if (overCap.length) {
    overCap.forEach((p) => log('   ❌ 出价超永久规则：' + p.id + '  ' + p.name + '  ¥' + p.bidYuan.toFixed(2) + ' > ¥' + RULES.chatCap));
  }

  // 08:00 开投后最该回答的问题：关注中的计划到底跑起来没有。
  // 【2026-10-08 加】必须带上【曝光】：老板问「徐良加价到 140% 有没有用」，
  //   判据就是曝光。曝光涨了 = 出价问题；曝光还趴着 = 链接/需求问题，再加价是白花钱。
  //   只看花费和咨询会被误导 —— 花 ¥3 得 1 个咨询看着还行，其实是一天只给了 20 次曝光。
  const watch = [
    { id: '98851271', tag: '贵阳王俊凯（新建，待平台放量）' },
    { id: '99401580', tag: '三亚周杰伦' },
    { id: '98104495', tag: '泉州徐良·创意开（140%）' },
    { id: '99330190', tag: '广州徐良·创意关（140%）' },
    { id: '99346109', tag: '广州徐良·创意开（140%）' },
    { id: '99692886', tag: '周诗雨王奕成都' },
    { id: '99951515', tag: 'IEM北京' },
  ];
  watch.forEach((w) => {
    const p = plans.find((x) => x.id === w.id);
    if (!p) { log('   · ' + w.id + '  ' + w.tag + ' 不在了（被删？）'); return; }
    log('   👀 ' + w.id + '  ' + (p.name || w.tag).slice(0, 22) +
        '  [' + p.verdictCn + ']' +
        (p.desc ? '（' + p.desc + '）' : '') +
        '  曝光 ' + (p.dayShows == null ? '?' : p.dayShows) +
        '  今日 ¥' + p.dayCost.toFixed(2) + ' / 咨询 ' + p.dayChat +
        '  出价 ¥' + Number(p.bidYuan).toFixed(2));
  });

  if (!suspects.length && !oddDesc.length && !overCap.length) {
    if (!QUIET) log('   ✅ 全部文案常规、无超顶');
  }
  process.exit(0);
})().catch((e) => { log('❌ 未捕获：' + (e && e.stack || e)); process.exit(0); });
