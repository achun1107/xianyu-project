/**
 * tools/plan-items.js — 列出每个擦亮计划【绑定了哪些商品】，并把商品标题带出来。
 *
 * 为什么需要：计划名是【快照】，不是事实。名字叫「单明星-周杰伦」的计划可能绑着
 * 广州的、也可能绑着别的城市的周杰伦；名字叫「擦亮宝贝2026...」的集合更是看不出覆盖谁。
 * 老板说「暂停 XX 的推广」时，必须先按【绑定商品】定位，按名字猜会漏、会误伤。
 *
 * 标题来源：上架台账.json（离线、快）。台账里没有的 itemId 标「(台账无)」——
 * 那说明该商品不是本仓发的，或台账被改过，值得看一眼。
 *
 * 用法:
 *   node tools/plan-items.js                     # 全部计划
 *   node tools/plan-items.js 周杰伦               # 只看绑定商品标题含该关键词的计划
 *   node tools/plan-items.js 周杰伦 --json        # 机器可读
 */
const fs = require('fs');
const path = require('path');
const mtop = require('../lib/mtop');
const { ROOT } = require('../lib/env');

const KW = process.argv.slice(2).filter((a) => !a.startsWith('--'))[0] || '';
const AS_JSON = process.argv.includes('--json');

function titleMap() {
  const m = {};
  try {
    const led = JSON.parse(fs.readFileSync(path.join(ROOT, '上架台账.json'), 'utf8'));
    for (const r of led) if (r.itemId) m[String(r.itemId)] = r.标题 || '';
  } catch (e) { /* 台账读不到就全标未知 */ }
  return m;
}

(async () => {
  const plans = await mtop.adPlans({ days: 7 });
  const T = titleMap();

  const rows = plans.map((p) => {
    const ids = String(p.items || '').split(',').map((s) => s.trim()).filter(Boolean);
    return {
      id: p.id, name: p.name, verdict: p.verdictCn, desc: p.desc,
      target: p.target, bidYuan: p.bidYuan, budgetYuan: p.budgetYuan,
      dayCost: p.dayCost, dayChat: p.dayChat, cumCost: p.cumCost, cumChat: p.cumChat,
      isCollection: p.isCollection,
      items: ids.map((id) => ({ itemId: id, 标题: T[id] == null ? '(台账无)' : T[id] })),
    };
  });

  const hit = KW ? rows.filter((r) => r.items.some((it) => it.标题.includes(KW)) || r.name.includes(KW)) : rows;

  if (AS_JSON) { console.log(JSON.stringify(hit, null, 1)); return; }

  console.log('计划 ' + rows.length + ' 条' + (KW ? ('，其中 ' + hit.length + ' 条涉及「' + KW + '」') : ''));
  for (const r of hit) {
    console.log('');
    console.log('── ' + r.id + '  ' + r.name + '   [' + r.verdict + ']' + (r.desc ? ' 「' + r.desc + '」' : '') +
      (r.isCollection ? '  ★集合' : ''));
    console.log('   目标=' + r.target + '  出价¥' + Number(r.bidYuan).toFixed(2) + '  预算¥' + r.budgetYuan +
      '  今日¥' + Number(r.dayCost).toFixed(2) + '/' + r.dayChat + '咨  近7日¥' + Number(r.cumCost).toFixed(2) + '/' + r.cumChat + '咨');
    r.items.forEach((it) => console.log('     · ' + it.itemId + '  ' + it.标题.slice(0, 46)));
  }
  if (KW && !hit.length) console.log('  （没有计划涉及「' + KW + '」）');
})().catch((e) => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
