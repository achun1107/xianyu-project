/**
 * tpl-fit.js — 标题模板压力测试：在所有真实「明星×城市」组合上渲染，看最长是多少、会不会被 30 字砍在半句
 *
 * 用法: node tpl-fit.js
 */
const MAX = 30;

const STARS = ['那英', '许嵩', '张杰', '徐良', '刘宇', '断眉', '周深', '薛之谦', '周杰伦', '林俊杰',
  '五月天', '孙燕姿', '王力宏', '刘宪华', '汪苏泷', '华晨宇', '宋雨琦', '侯明昊', '陈都灵', '熊艺文',
  '李大奔', '毛不易', '邓紫棋', '李荣浩', '张韶涵', 'Capper', '凤凰传奇', '易烊千玺', '王源', '许巍'];
const CITIES = ['杭州', '北京', '上海', '广州', '深圳', '成都', '南京', '武汉', '西安', '重庆', '天津',
  '苏州', '长沙', '沈阳', '徐州', '常州', '厦门', '三亚', '宁波', '无锡', '郑州', '济南', '青岛',
  '合肥', '福州', '南昌', '昆明', '贵阳', '哈尔滨', '大连', '呼和浩特', '乌鲁木齐'];

const SESSION = '一开', EV = '演唱会';

function render(p, star, city) {
  return p.replace(/\{明星\}/g, star).replace(/\{城市\}/g, city)
    .replace(/\{场次类型\}/g, SESSION).replace(/\{活动类型\}/g, EV);
}

// 判断第30字收尾是否"断了"：末字是虚词/逗号，或末2-3字不是任何已出现词的完整结尾
function endsCleanly(cut, star, city) {
  const last = cut.slice(-1);
  if (/[，,、。的了和与及＋+·]/.test(last)) return false;
  // 末尾不能是明星名的第一个字（说明明星名被劈开且没有更早出现）
  if (star.length > 1 && last === star[0] && cut.indexOf(star) < 0) return false;
  // 末尾若是一个新词的起头（例如「杭州那」），标记为可疑
  const tail2 = cut.slice(-2);
  if (city.length >= 2 && tail2 === city.slice(0, 2) === tail2 && cut.lastIndexOf(city) === cut.length - city.length) return false;
  return true;
}

function evaluate(label, pattern) {
  let worst = null;
  for (const s of STARS) for (const c of CITIES) {
    const full = render(pattern, s, c);
    if (!worst || full.length > worst.full.length) worst = { star: s, city: c, full };
  }
  const over = worst.full.length - MAX;
  const cut = worst.full.slice(0, MAX);
  const clean = endsCleanly(cut, worst.star, worst.city);
  console.log('\n' + '─'.repeat(76));
  console.log('【' + label + '】');
  console.log('  模板: ' + pattern);
  console.log('  最长组合: ' + worst.star + ' / ' + worst.city);
  console.log('  渲染: ' + worst.full + '   (' + worst.full.length + ' 字)');
  console.log('  ' + (over <= 0 ? '✅ 全部组合都在 30 字内（最坏情况余 ' + (-over) + ' 字）' : '❌ 最坏超出 ' + over + ' 字'));
  if (over > 0) {
    console.log('  实际标题: ' + cut);
    console.log('  被砍掉: 「' + worst.full.slice(MAX) + '」');
    console.log('  第30字收尾: ' + (clean ? '勉强完整' : '❌ 断在半句/半词上'));
  }
  return { label, pattern, max: worst.full.length, over, ok: over <= 0 };
}

console.log('压力测试语料: ' + STARS.length + ' 个明星 × ' + CITIES.length + ' 个城市 = ' + (STARS.length * CITIES.length) + ' 组合');
console.log('固定 活动类型=' + EV + '  场次类型=' + SESSION);
console.log('最长明星: ' + STARS.slice().sort((a, b) => b.length - a.length)[0] + '  最长城市: ' + CITIES.slice().sort((a, b) => b.length - a.length)[0]);

const results = [];

console.log('\n\n══════════ 现状（线上在用的 2 个） ══════════');
results.push(evaluate('现状模板1', '【接代拍】{明星}{城市}站{活动类型}接代拍{场次类型}代抢{明星}{活动类型}代抢{城市}{明星}秒付前排'));
results.push(evaluate('现状模板2', '【{城市}{明星}代拍】{城市}{明星}{活动类型}接抢票{明星}{活动类型}代拍{场次类型}代抢{明星}{活动类型}代买'));

console.log('\n\n══════════ 模板1 候选（前缀 【接代拍】，尾巴 秒付前排） ══════════');
const C1 = [
  '【接代拍】{明星}{城市}站{活动类型}{场次类型}代抢 秒付前排',
  '【接代拍】{明星}{城市}站{活动类型}{场次类型}代抢{明星}秒付前排',
  '【接代拍】{明星}{城市}站{活动类型}接代拍{场次类型}代抢{明星}秒付前排',
  '【接代拍】{明星}{城市}站{活动类型}{场次类型}代抢{活动类型}代抢',
  '【接代拍】{明星}{城市}站{活动类型}代抢{场次类型}秒付前排',
  '【接代拍】{明星}{城市}站{活动类型}{场次类型}代抢{活动类型}秒付前排',
  '【接代拍】{明星}{城市}站{活动类型}{场次类型}代抢 秒付前排{明星}',
];
C1.forEach((p, i) => results.push(evaluate('模板1候选' + String.fromCharCode(97 + i), p)));

console.log('\n\n══════════ 模板2 候选（前缀 【{城市}{明星}代拍】） ══════════');
const C2 = [
  '【{城市}{明星}代拍】{活动类型}接抢票{场次类型}代抢',
  '【{城市}{明星}代拍】{活动类型}接抢票{场次类型}代买',
  '【{城市}{明星}代拍】{活动类型}接抢票代拍代抢',
  '【{城市}{明星}代拍】{活动类型}代拍代抢{场次类型}',
  '【{城市}{明星}代拍】{活动类型}接抢票{场次类型}代抢{活动类型}代拍',
  '【{城市}{明星}代拍】{活动类型}接抢票{场次类型}代抢 全价位接',
  '【{城市}{明星}代拍】{活动类型}{场次类型}代抢{活动类型}代拍代抢',
  '【{城市}{明星}代拍】{活动类型}接抢票{场次类型}代买{活动类型}',
  '【{城市}{明星}代拍】{活动类型}接抢票{场次类型}代抢代拍',
  '【{城市}{明星}代拍】{活动类型}接抢票{场次类型}代抢{城市}站',
];
C2.forEach((p, i) => results.push(evaluate('模板2候选' + String.fromCharCode(97 + i), p)));

console.log('\n\n══════════ 汇总 ══════════');
const byLabel = {};
results.forEach(r => { if (!byLabel[r.label]) byLabel[r.label] = r; });
[['模板1', 3], ['模板2', 4]].forEach(([grp, n]) => { });
console.log('通过（全组合 ≤30 字）的候选:');
results.filter(r => r.ok).forEach(r => console.log('  ✅ ' + r.label + '   最坏 ' + r.max + ' 字   ' + r.pattern));
console.log('不通过的:');
results.filter(r => !r.ok).forEach(r => console.log('  ❌ ' + r.label + '   最坏 ' + r.max + ' 字（超 ' + r.over + '）'));
