// debug-status-filter.js —— 只读：打开「擦亮状态」筛选器看选项
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const out = {};
  const tab = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn')).find(e => /^计划\(/.test((e.innerText || '').trim()));
  if (tab) { click1(tab); await sleep(3500); }

  const sels = [].slice.call(document.querySelectorAll('.ant-select.statusFil')).filter(e => e.getBoundingClientRect().width > 40);
  out.可见statusFil数 = sels.length;
  out.statusFil文字 = sels.map(e => (e.innerText || '').trim());
  if (sels.length) {
    const s = sels[0];
    const c = s.querySelector('.ant-select-selector') || s;
    c.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); c.click();
    await sleep(1500);
    const dd = [].slice.call(document.querySelectorAll('.ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option'));
    out.状态选项 = dd.map(e => (e.innerText || '').trim());
    // 选「全部」
    const all = dd.find(e => /^全部/.test((e.innerText || '').trim()));
    if (all) { click1(all); await sleep(4000); out.已选 = (all.innerText || '').trim(); }
    else { document.body.click(); await sleep(500); out.已选 = '(没有"全部"选项)'; }
  }
  await sleep(2000);
  // 再筛 97682524
  let box = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
  if (box) {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    d.set.call(box, '97682524'); box.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(600);
    box.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
    await sleep(4500);
  }
  const trs = [].slice.call(document.querySelectorAll('tbody tr'));
  out.筛后行 = trs.map(r => (r.innerText || '').replace(/\n+/g, ' | ').slice(0, 130)).slice(0, 6);
  return JSON.stringify(out, null, 1);
})()
