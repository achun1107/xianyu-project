/**
 * wecom-sheet.js — 企微智能表格读写（双向通道底层）
 *
 * 链路：Node 写 UTF-8 JSON -> ss-call.ps1（用 --json 调 wecom-cli，自动转义引号）
 *       -> 输出写 UTF-8 文件 -> Node 读回解析。
 * 原因：Node 直调 wecom-cli.cmd 在本环境静默失败；PowerShell 内联中文/引号会被吃掉。
 *
 * 通道结构（docid 见 CHANNEL）：
 *   子表「日报」  field: 日期/花费/咨询/单次咨询成本/下单/支付额/状态/明细
 *   子表「指令」  field: 时间/指令/状态/回复
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');
const { ROOT } = require('./lib/env');

const D = ROOT + '/';
const BRIDGE = path.join(D, 'ss-call.ps1');
const CHANNEL = {
  docid: 's3_AFkAkHiaACACNSDqvaudRQO00Ay4z_a',
  url: 'https://doc.weixin.qq.com/smartsheet/s3_AFkAkHiaACACNSDqvaudRQO00Ay4z_a?scode=ALYAMgeHAD4RNpeqj9AFkAkHiaACA',
  sheets: { 日报: 'Te2agX', 指令: 'Te2agX_cmd' },   // 指令的 sheet_id 首次用到时自动探测
};

let seq = 0;
/**
 * 调 CLI：cmd 形如 'smartsheet records add'，body 是请求体对象
 *
 * ⚠️ 关键约束（2026-09-27 实测）：传给 CLI 的 JSON 【不能含半角空格】。
 *    PowerShell 传原生命令时不会自动加引号，JSON 文本里的空格会把参数拆成多个，
 *    报错形如：error: unexpected argument '擦亮宝贝20260927113406' found。
 *    JSON.stringify 产生的空格【只可能出现在字符串值内部】，所以全局把 ' ' 换成 '·' 是安全的。
 */
function call(cmd, body) {
  const tag = process.pid + '_' + (++seq);
  const jf = path.join(os.tmpdir(), 'ssj_' + tag + '.json');
  const of = path.join(os.tmpdir(), 'sso_' + tag + '.txt');
  // 空格 → 不换行空格 NBSP(U+00A0)，规避参数拆分。
  // 为什么不用中点 ·：中点【会被人看见】（表格里显示成「降出价·刘宪华北京·2.5」），
  // 而 NBSP 不会被原生命令行当分隔符拆开，在企微表格里看起来就是普通空格。
  const json = JSON.stringify(body).replace(/ /g, '\u00A0');
  fs.writeFileSync(jf, json, 'utf8');
  try {
    execFileSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', BRIDGE,
      '-Cmd', cmd, '-JsonFile', jf, '-OutFile', of], { stdio: 'ignore' });
    const txt = fs.readFileSync(of, 'utf8').replace(/^\uFEFF/, '');
    let j = null; try { j = JSON.parse(txt); } catch (e) { }
    if (!j) throw new Error('CLI 非 JSON 输出: ' + txt.slice(0, 300));
    if (j.error) throw new Error('CLI 错误: ' + JSON.stringify(j.error).slice(0, 300));
    return j;
  } finally {
    try { fs.unlinkSync(jf); } catch (e) { }
    try { fs.unlinkSync(of); } catch (e) { }
  }
}

/** 列出子表（顺带把「指令」的 sheet_id 探出来） */
function listSheets() {
  const j = call('smartsheet sheets list', { docid: CHANNEL.docid });
  return j.sheets || [];
}
function sheetId(title) {
  if (CHANNEL.sheets[title] && !/_cmd$/.test(CHANNEL.sheets[title])) return CHANNEL.sheets[title];
  const s = listSheets().filter(x => x.title === title)[0];
  if (!s) throw new Error('找不到子表: ' + title + '（现有: ' + listSheets().map(x => x.title).join(',') + '）');
  CHANNEL.sheets[title] = s.sheet_id;
  return s.sheet_id;
}

/** 追加一行 */
function addRow(title, values) {
  return call('smartsheet records add', {
    docid: CHANNEL.docid, sheet_id: sheetId(title), type: 'add', key_type: 'field_title',
    records: [{ values }],
  });
}
/** 读记录 */
function listRows(title, filterSpec) {
  const body = { docid: CHANNEL.docid, sheet_id: sheetId(title), type: 'records' };
  if (filterSpec) body.filter_spec = filterSpec;
  return call('smartsheet records list', body).records || [];
}
/** 按 record_id 更新 */
function updateRow(title, recordId, values) {
  return call('smartsheet records update', {
    docid: CHANNEL.docid, sheet_id: sheetId(title), type: 'update', key_type: 'field_title',
    records: [{ record_id: recordId, values }],
  });
}

/** 批量删除（--records 数组只带 record_id） */
function deleteRows(title, recordIds) {
  return call('smartsheet records delete', {
    docid: CHANNEL.docid, sheet_id: sheetId(title), type: 'delete', key_type: 'field_title',
    records: recordIds.map(id => ({ record_id: id })),
  });
}

module.exports = { CHANNEL, call, listSheets, sheetId, addRow, listRows, updateRow, deleteRows };

if (require.main === module) {
  const cmd = process.argv[2];
  (async () => {
    if (cmd === 'sheets') { console.log(JSON.stringify(listSheets(), null, 1)); return; }
    if (cmd === 'addtest') {
      const r = addRow('日报', { 日期: '2026-09-27', 花费: '524.45', 咨询: '141', 单次咨询成本: '3.72', 下单: '8', 支付额: '3110.59', 状态: '正常', 明细: '连通性自检' });
      console.log('写入结果: ' + JSON.stringify(r).slice(0, 300));
      return;
    }
    if (cmd === 'readtest') {
      const r = listRows('日报');
      console.log('日报记录数: ' + r.length);
      console.log(JSON.stringify(r.slice(-3), null, 1));
      return;
    }
    console.log('用法: node wecom-sheet.js sheets|addtest|readtest');
  })().catch(e => { console.log('❌ ' + e.message); process.exit(1); });
}
