/**
 * rebuild-publish-baseline.js — 精确还原 publish.js 在 2026-09-26 我改动之前的内容
 *
 * 背景：这次 publish.js 的文件级基线我留晚了（备份时改动已写入），
 *      所以那份 baseline 无效。好在我的改动是【一个连续 hunk】，
 *      可以把新代码精确替换回旧代码，重建出真正的"改动前"状态。
 *
 * 只做一次字符串替换，替换后校验：旧代码出现 1 次、新代码出现 0 次。
 */
const fs = require('fs');
const path = require('path');
const { PATHS, ROOT } = require('./lib/env');

const SRC = path.join(PATHS.xianyuMonitor, 'publish.js');
const OUT = path.join(ROOT, 'baseline-preEdit-publish.js');

const NEW = [
  '                    var tKey = getTplKey();',
  '                    var tpls = r.data[tKey];',
  '                    // Native Host 落盘的形状是 {key, templates}，不是 {店铺键: [...]}。',
  '                    // 只有 key 与当前店铺一致才采用；不再"取第一个数组"兜底 ——',
  '                    // 那会把上一家店的模板灌进当前店铺（2026-09-26 发现）。',
  '                    if (!tpls && r.data.key === tKey && Array.isArray(r.data.templates)) tpls = r.data.templates;',
].join('\n');

const OLD = [
  '                    var tKey = getTplKey();',
  '                    var tpls = r.data[tKey];',
  '                    if (!tpls) {',
  '                        var keys = Object.keys(r.data);',
  '                        for (var ki = 0; ki < keys.length; ki++) {',
  '                            if (r.data[keys[ki]] && Array.isArray(r.data[keys[ki]])) { tpls = r.data[keys[ki]]; break; }',
  '                        }',
  '                    }',
].join('\n');

const cur = fs.readFileSync(SRC, 'utf8');
// 按文件真实行尾重建多行串（publish.js 是 CRLF，直接 join('\n') 匹配不上）
const EOL = cur.indexOf('\r\n') >= 0 ? '\r\n' : '\n';
console.log('文件行尾: ' + (EOL === '\r\n' ? 'CRLF' : 'LF'));
const NEW_S = NEW.split('\n').join(EOL);
const OLD_S = OLD.split('\n').join(EOL);

const nNew = cur.split(NEW_S).length - 1;
console.log('当前文件里"新代码"出现次数: ' + nNew);
if (nNew !== 1) { console.log('❌ 不是恰好 1 次，中止'); process.exit(1); }

const restored = cur.replace(NEW_S, OLD_S);
console.log('还原后"旧代码"出现次数: ' + (restored.split(OLD_S).length - 1));
console.log('还原后"新代码"出现次数: ' + (restored.split(NEW_S).length - 1));
if ((restored.split(OLD_S).length - 1) !== 1 || (restored.split(NEW_S).length - 1) !== 0) {
  console.log('❌ 校验失败，中止'); process.exit(1);
}

fs.writeFileSync(OUT, restored);
console.log('✅ 已重建真正的改动前基线: ' + OUT);
console.log('   行数 ' + cur.split(EOL).length + ' → ' + restored.split(EOL).length + '（差 ' + (restored.split(EOL).length - cur.split(EOL).length) + ' 行）');
