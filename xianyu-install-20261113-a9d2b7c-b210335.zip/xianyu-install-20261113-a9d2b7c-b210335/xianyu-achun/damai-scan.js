// damai-scan.js —— 按店铺在售商品涉及的明星，扫大麦搜索，找出「还没开票/即将开抢」的项目
// 用法: node damai-scan.js
const path = require('path');
const fs = require('fs');
const { PATHS } = require('./lib/env');
const PW = require(path.join(PATHS.playwrightService, 'node_modules', 'playwright'));

const STARS = ['华晨宇', '刘宪华', '孙燕姿', '侯明昊', '周杰伦', 'Capper', '汪苏泷', '徐良',
  '宋雨琦', '张杰', '查理普斯', 'Yidol', '许嵩', '王力宏', '蔡依林', 'BIGBANG',
  'GAI', '初音未来', '那英', '凤凰传奇', '刘宇', '薛之谦', '周深', '林俊杰'];

const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const b = await PW.chromium.launch({ headless: true });
  const ctx = await b.newContext({
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
    viewport: { width: 390, height: 844 }, isMobile: true,
  });
  const p = await ctx.newPage();

  let bucket = [];
  p.on('response', async r => {
    const u = r.url();
    if (!/mtop\.damai\.(cn|wireless)/.test(u)) return;
    if (!/search\.search/.test(u)) return;
    try {
      const t = await r.text();
      if (t.length < 60) return;
      const j = JSON.parse(t);
      const pi = j && j.data && j.data.projectInfo;
      if (Array.isArray(pi)) bucket = bucket.concat(pi);
    } catch (e) { }
  });

  const all = [];
  for (const star of STARS) {
    bucket = [];
    const kw = star + ' 演唱会';
    for (let attempt = 0; attempt < 2 && bucket.length === 0; attempt++) {
      try {
        // 必须 networkidle：mtop 的 XHR 是 SPA 启动后才发的，domcontentloaded 太早，会一条都抓不到
        await p.goto('https://m.damai.cn/damai/search/index.html?keyword=' + encodeURIComponent(kw),
          { waitUntil: 'networkidle', timeout: 40000 }).catch(() => { });
        await sleep(3500);
      } catch (e) { }
    }
    bucket.forEach(x => all.push(Object.assign({ _star: star }, x)));
    console.log(`[${star}] 抓到 ${bucket.length} 条`);
    await sleep(1200);
  }
  await b.close();

  // 去重
  const byId = {};
  all.forEach(x => { if (!byId[x.id]) byId[x.id] = x; });
  const items = Object.values(byId);

  const statusCount = {};
  items.forEach(x => {
    const d = (x.showStatus && x.showStatus.desc) || '?';
    statusCount[d] = (statusCount[d] || 0) + 1;
  });
  console.log('\n=== showStatus.desc 分布 ===');
  Object.entries(statusCount).sort((a, b) => b[1] - a[1]).forEach(([k, v]) => console.log(`  ${k}: ${v}`));

  const now = Date.now();
  const soon = items.filter(x => {
    const d = (x.showStatus && x.showStatus.desc) || '';
    return d !== '去购票' && d !== '已结束' && d !== '';
  }).sort((a, b) => (a.nearestPerformTime || 0) - (b.nearestPerformTime || 0));

  console.log('\n=== 非「去购票」的项目（重点）===');
  soon.forEach(x => {
    const dt = x.nearestPerformTime ? new Date(x.nearestPerformTime).toISOString().slice(0, 10) : '-';
    console.log(`${(x.showStatus.desc || '').padEnd(10)} | ${String(x.cityName || '').padEnd(5)} | ${dt} | ${(x.name || '').slice(0, 40)} | ¥${x.priceStr || ''}`);
  });

  fs.writeFileSync('D:\\DSH\\achun\\damai-scan.json', JSON.stringify({
    运行时刻: new Date().toLocaleString('zh-CN'),
    抓到条数: items.length,
    状态分布: statusCount,
    未开票: soon.map(x => ({
      状态: x.showStatus && x.showStatus.desc, 明星: x.actores, 城市: x.cityName,
      项目: x.name, 演出时间: x.showTime, 票价: x.priceStr, 场馆: x.venueName,
      热度: x.ipvuv, id: x.id, 命中词: x._star,
    })),
  }, null, 2), 'utf8');
  console.log('\n已写 damai-scan.json');
})().catch(e => { console.error('FAIL:', e.message, e.stack); process.exit(1); });
