/**
 * clean-command-sheet.js — 清理「指令」子表的测试行
 *
 * 为什么必须有这个脚本：
 *   sheet-command-runner.js 的 --dry 模式【不写回状态】，
 *   所以 dry 跑过的测试行仍然是「待办」，会被真实轮询捡起来真的执行。
 *   2026-09-27 踩过：测试用的「降出价 刘宪华北京 2.5」差 2 分钟就被定时任务真的执行了。
 *
 * 用法：
 *   node clean-command-sheet.js --wipe        # 删掉「指令」表【所有】行（上线前清测试数据）
 *   node clean-command-sheet.js --void        # 只把 待办/待人工/失败 标成「已作废」
 *   node clean-command-sheet.js --list        # 只看，不动
 *   加 --dry 只打印计划。
 *   --keep ID1,ID2  保留这些 record_id。
 */
const sheet = require('./wecom-sheet.js');

const ARGV = process.argv.slice(2);
const has = f => ARGV.includes(f);
const DRY_RUN = has('--dry');
const MODE = has('--wipe') ? 'wipe' : has('--void') ? 'void' : has('--list') ? 'list' : 'void';

// 单元格是 [{text,type}] 数组，不是字符串 —— 直接 String(v) 会得到 [object Object]（踩过）
const txt = v => Array.isArray(v) ? String((v[0] && v[0].text) || '').trim()
  : (v === null || v === undefined ? '' : String(v).trim());
// 传输时空格被换成 NBSP(U+00A0)（历史数据里是 ·），读回来要还原
const dec = s => String(s || '').replace(/[\u00B7\u00A0]/g, ' ');

const TERMINAL = ['已完成', '已作废'];

(async () => {
  const rows = sheet.listRows('指令');
  console.log('指令表共 ' + rows.length + ' 行   模式=' + MODE + (DRY_RUN ? '  (dry)' : ''));

  const keepArg = ARGV[ARGV.indexOf('--keep') + 1];
  const KEEP = (has('--keep') && keepArg) ? keepArg.split(',').map(s => s.trim()).filter(Boolean) : [];

  const targets = MODE === 'wipe'
    ? rows.filter(r => KEEP.indexOf(r.record_id) < 0)
    : rows.filter(r => {
        const s = txt((r.values || {})['状态']);
        return TERMINAL.indexOf(s) < 0 && KEEP.indexOf(r.record_id) < 0;
      });

  if (!targets.length) { console.log('没有需要处理的行 ✓'); return; }

  console.log('命中 ' + targets.length + ' 行:');
  for (const r of targets) {
    const v = r.values || {};
    console.log('  ' + r.record_id + '  [' + (txt(v['状态']) || '空') + ']  ' + dec(txt(v['指令'])));
  }

  if (MODE === 'list') { console.log('\n--list 模式，未改动'); return; }
  if (DRY_RUN) { console.log('\n[dry] 未写入'); return; }

  if (MODE === 'wipe') {
    try {
      sheet.deleteRows('指令', targets.map(r => r.record_id));
      console.log('✅ 已删除 ' + targets.length + ' 行');
    } catch (e) {
      console.log('❌ 删除失败：' + (e && e.message || e));
      process.exitCode = 1;
    }
    return;
  }

  let ok = 0, fail = 0;
  for (const r of targets) {
    const v = r.values || {};
    try {
      // 注意：回复文本里【不要出现 ASCII 空格】，否则写进表格会变成 NBSP/中点
      sheet.updateRow('指令', r.record_id, {
        时间: txt(v['时间']) || new Date().toLocaleString('zh-CN'),
        状态: '已作废',
        回复: '测试行，上线前作废，不执行',
      });
      ok++; console.log('  ✅ ' + r.record_id);
    } catch (e) {
      fail++; console.log('  ❌ ' + r.record_id + '  ' + (e && e.message || e));
    }
  }
  console.log('\n作废完成：成功 ' + ok + '，失败 ' + fail);
})().catch(e => { console.log('❌ ' + (e && e.stack || e)); process.exit(1); });
