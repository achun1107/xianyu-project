// gen-copy.js —— 代拍文案生成器（规律全部来自 168 条同行 top 的实测）
//
// 用法：
//   node gen-copy.js --star 许嵩 --cities 成都,天津,苏州
//   node gen-copy.js --star 刘宪华 --cities 深圳 --len brief
//   node gen-copy.js --star 宋雨琦 --cities 成都 --type 见面会 --len std
//
// ══ 铁律一：前 30 字是唯一能被看到的 ══
//   168/168 条同行标题恰好 30 字，且 标题 === 全文.slice(0,30) 全部成立。
//   所以"标题"不是一个独立字段，而是商品描述的最前 30 个字符。
//   → 前 30 字必须自成一句完整的话；第 31 字起卡片上完全看不到。
//   → 既然只用 30 字，就【填满】它：能塞下的要素一个都不留空（v2 新增）
//
// ══ 铁律二：城市列表 > 通吃话术 > 其他 ══
//   前 30 字要素覆盖率：明星 99% · 城市 98% · 代拍/代抢 90% · 活动类型 83%
//   前缀括号 79% · 承诺词 65% · 通吃话术(全站/全价位) 18% · 场次词 18%
//   → 挤不下时，先丢场次词和承诺词，绝不能丢城市。
//
// ══ 铁律三：全文长度有锚 ══
//   168 条全文 37~233 字、中位 130。上一版润色稿 379 字超出所有同行
//   —— 那不是"更完整"，是没人这么写。默认 mid ≈ p60。
//
// ══ 铁律四：手续费条款是必留项（v2 新增）══
//   线上在用的 2 个模板（~/.xianyu-templates.json）正文里都有这条：
//     「开抢前大于四个小时收 20% 手续费，四个小时内收 40%」
//   旧版生成器把它放在优先级 8，结果被长度目标挡在外面、从来没出现过。
//   这是有商业价值的条款（客服少扯皮），改成【必留】，长度目标让位。

const fs = require('fs');
const ARG = {};
process.argv.slice(2).forEach((a, i, arr) => {
  if (a.startsWith('--')) ARG[a.slice(2)] = (arr[i + 1] && !arr[i + 1].startsWith('--')) ? arr[i + 1] : true;
});

const star = ARG.star;
const cities = String(ARG.cities || ARG.city || '').split(/[,，/、]/).filter(Boolean);
const typeW = ARG.type || '演唱会';
const MAX = Number(ARG.max || 30);
const LEN = ARG.len || 'mid';
if (!star || !cities.length) {
  console.log('用法: node gen-copy.js --star 许嵩 --cities 成都,天津,苏州 [--type 演唱会] [--len brief|mid|std]');
  process.exit(1);
}

// ── 同行长度分布（直接从已抓的数据算，不硬编码）──────────────
const D = __dirname + '\\';
let DIST = [];
try {
  for (const f of ['xy-scan-result-0-7.json', 'xy-scan-result-7-14.json']) {
    JSON.parse(fs.readFileSync(D + f, 'utf8')).forEach(s => (s.top || [])
      .forEach(t => { if (t.判定 === '代拍' && t.全文字数) DIST.push(t.全文字数); }));
  }
  DIST.sort((a, b) => a - b);
} catch (e) { /* 数据不在就跳过分位 */ }
const pctOf = n => {
  if (!DIST.length) return '（无数据）';
  const below = DIST.filter(x => x <= n).length;
  return (below / DIST.length * 100).toFixed(0) + '% 分位（同行中位 ' + DIST[Math.floor(DIST.length / 2)] + '，最长 ' + DIST[DIST.length - 1] + '）';
};

const PREFIX = ARG.prefix || '【必中代拍】';

// ══ 第一行（= 标题）构造：把 30 字填满，而不是"塞得下就停" ══
// 分段枚举 + 打分选优。城市完整度一票否决（98% 覆盖率，不可让），
// 其余段（活动类型 / 代拍词 / 通吃话术 / 承诺词 / 服务词）按价值加权，
// 同分时取更长的那条 —— 这就是"填满 30 字"的实现方式。
function buildFirstLine() {
  const cityOptions = [cities.join('/'), cities.slice(0, 2).join('/'), cities[0], '全站']
    .filter((v, i, a) => v && a.indexOf(v) === i);
  const TYPE = typeW === '演唱会' ? ['演唱会', '演唱会门票'] : [typeW];
  const PAY = ['代抢', '代拍代抢'];
  const EXTRA = ['', '全价位接', '全价位都能接', '全站全价位都可接'];
  const PROMISE = ['', '稳中', '高命中率'];
  const SERVICE = ['', '可上号', '秒付前排'];

  const cityRank = cv => cv === cities.join('/') ? 3
    : (cities.length > 1 && cv === cities.slice(0, 2).join('/')) ? 2
      : (cv === cities[0] ? 1 : 0);
  const score = (cv, tf, pf, ex, pr, sv) =>
    cityRank(cv) * 100000
    + (tf !== typeW ? 3000 : 0)                 // 带「门票」加分
    + (pf === '代拍代抢' ? 2000 : 0)
    + EXTRA.indexOf(ex) * 200
    + PROMISE.indexOf(pr) * 60
    + SERVICE.indexOf(sv) * 20;

  let best = null, shortest = null;
  for (const cv of cityOptions) for (const tf of TYPE) for (const pf of PAY)
    for (const ex of EXTRA) for (const pr of PROMISE) for (const sv of SERVICE) {
      const head = PREFIX + star + cv + tf + pf;
      const extras = [ex, pr, sv].filter(Boolean);
      const t = head + (extras.length ? ' ' + extras.join(' ') : '');
      if (!shortest || t.length < shortest.length) shortest = t;
      if (t.length > MAX) continue;
      const sc = score(cv, tf, pf, ex, pr, sv);
      if (!best || sc > best.score || (sc === best.score && t.length > best.t.length)) best = { t, score: sc };
    }
  // 极端长名（明星+城市就撑爆 30 字）时退到最短组合，保证不吐超长标题
  return best ? best.t : shortest;
}

// 正文行池 —— 与线上模板的统一正文【逐字一致】（2026-09-26 对齐）
// 顺序 = 输出顺序；must=true 的行必留（长度目标让位）。
// 这 7 行就是 ~/.xianyu-templates.json 里两个模板现在共用的那份 descPattern。
const POOL = [
  { p: 0, must: true, text: '场次全接：首开 + 捡漏回流 + 二开 + 三开' },
  { p: 1, must: false, text: '七级店铺 + 上千好评 + 战绩可查 ｜ 专业设备 全程无风险' },
  { p: 2, must: false, text: '全价位都能接：看台/内场、单张/连坐，抢不到全额退款' },
  { p: 3, must: false, text: '问价方式：日期 + 票面 + 几张' },
  { p: 4, must: false, text: '代拍流程：需提供你的账号或身份证；抢到后第一时间通知付款；因买家原因退票代拍费不退，只退扣费后票钱' },
  // ↓ 手续费条款：线上模板里就有，且是有商业价值的条款（客服少扯皮），必留
  { p: 5, must: true, text: '取消规则：开抢前 4 小时以上收 20%，4 小时以内收 40%' },
  { p: 6, must: false, text: '也可自己一起抢，你抢到我退全款' },
];
const quantile = q => {
  if (!DIST.length) return { brief: 116, mid: 138, std: 149, full: 200 }[LEN] || 138;
  return DIST[Math.min(DIST.length - 1, Math.floor(DIST.length * q))];
};
// 目标不硬编码：直接取同行真实分布的分位点
//   brief ≈ p40（偏短，适合短语料/新链接）
//   mid   ≈ p60（默认，略高于中位）
//   std   ≈ p85（长版，但不越界）
//   full  ≈ p100（7 行全上，与线上模板的统一正文同长；这就是"完整版"）
const TARGET = quantile({ brief: 0.40, mid: 0.60, std: 0.85, full: 1.0 }[LEN] || 0.60);

const first = buildFirstLine();
const ordered = POOL.slice().sort((a, b) => a.p - b.p);

// 必留行先占位，其余行再按优先级往里塞到目标长度
const keep = new Set(ordered.filter(l => l.must).map(l => l.p));
let used = first.length + 1 + ordered.filter(l => keep.has(l.p)).reduce((n, l) => n + l.text.length + 1, 0) - 1;
for (const l of ordered) {
  if (keep.has(l.p)) continue;
  if (used + 1 + l.text.length <= TARGET) { keep.add(l.p); used += 1 + l.text.length; }
}
const chosen = ordered.filter(l => keep.has(l.p));
const body = chosen.map(l => l.text).join('\n');
const full = first + '\n' + body;

const chk = {
  明星名: new RegExp(star).test(first),
  城市完整: cities.every(c => first.indexOf(c) >= 0) || /全站/.test(first),
  活动类型: new RegExp(typeW).test(first),
  代拍: /代拍/.test(first),
  前缀: /^[【\[]/.test(first),
  长度合规: first.length <= MAX,
  填满30: first.length >= MAX - 2,
  场次四连在正文: /首开/.test(body) && /二开/.test(body) && /三开/.test(body) && /(回流|捡漏)/.test(body),
  手续费条款在正文: /(20%|20％)/.test(body) && /(40%|40％)/.test(body),
};

console.log('══════ 前 ' + first.length + ' 字（卡片上唯一可见的部分，上限 ' + MAX + '）══════');
console.log(first);
console.log('\n要素自检: ' + Object.keys(chk).map(k => (chk[k] ? '✅' : '❌') + k).join('  '));
console.log('全文 ' + full.length + ' 字' + (full.length > TARGET ? '（必留条款撑过目标 ' + TARGET + '）' : '') + ' → ' + pctOf(full.length));
console.log('\n══════ 提交用完整文案 ══════');
console.log(full);
console.log('\n' + '─'.repeat(52));
console.log('前 30 字里同行【不放】的（放了就是浪费稀缺位）：');
console.log('  价格/报价 1% · CTA「私聊」3% · 店铺背书 6% · 场次词(首开/二开) 18%');
console.log('这些一律放到第 31 字之后的正文。');
console.log('长度档目标 ' + TARGET + ' 字（同行 --len ' + LEN + ' 分位）；手续费条款为必留项，会让位');
console.log('可选长度档: --len brief(p40) / mid(p60，默认) / std(p85)');
