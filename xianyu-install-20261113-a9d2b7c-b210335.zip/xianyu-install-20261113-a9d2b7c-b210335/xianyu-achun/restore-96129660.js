// restore-96129660.js —— 把 96129660 的出价/预算改回原值（27.1 / 90），带读回校验
// cfg = window.__RB = { planId, planName, bid, budget }
(async () => {
  const C = window.__RB;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const setNative = (el, v) => { const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value'); d.set.call(el, String(v)); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  const blur = el => { el.dispatchEvent(new FocusEvent('focusout', { bubbles: true })); el.dispatchEvent(new Event('blur', { bubbles: true })); };
  const drawers = () => [].slice.call(document.querySelectorAll('.ant-drawer-content')).filter(d => d.getBoundingClientRect().width > 200);
  const outer = () => drawers().find(d => /编辑计划/.test(d.innerText || ''));
  const R = { plan: C.planName, planId: C.planId };

  try {
    const tab = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn')).find(e => /^计划\(/.test((e.innerText || '').trim()));
    if (tab) { click1(tab); await sleep(4000); }
    const box = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
    if (box) {
      setNative(box, String(C.planId)); await sleep(700);
      box.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
      await sleep(5000);
    }
    const tr = [].slice.call(document.querySelectorAll('tbody tr')).find(r => (r.innerText || '').indexOf(C.planName) >= 0);
    if (!tr) throw new Error('找不到计划行');
    click1([].slice.call(tr.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑'));
    let od = null;
    for (let i = 0; i < 20; i++) { await sleep(1000); od = outer(); if (od && od.querySelector('[class*=goodsTitle]')) break; }
    if (!od) throw new Error('抽屉没打开');

    const grpOf = () => od.querySelector('[class*=radioGroup--eEugUXoZ]')
      || [].slice.call(od.querySelectorAll('div')).filter(d => /自定义/.test(d.innerText || '') && d.querySelectorAll('[class*=radio--]').length >= 2).sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length)[0];

    // ── 等出价输入框 + 预算槽都渲染出来 ──
    let bidInput = null, slots = [], lastTxt = '';
    for (let i = 0; i < 40; i++) {
      od = outer() || od;
      bidInput = od.querySelector('input[placeholder*="自定义出价"]');
      const grp = grpOf();
      slots = grp ? [].slice.call(grp.querySelectorAll('[class*=radio--]')) : [];
      lastTxt = slots.length ? (slots[slots.length - 1].innerText || '').trim() : '';
      if (bidInput && /^¥\s*\d/.test(lastTxt)) break;
      await sleep(1000);
    }
    R.出价框当前值 = bidInput ? String(bidInput.value || '') : '(找不到出价输入框)';
    R.预算槽 = slots.map(e => (e.innerText || '').trim());
    if (!bidInput) throw new Error('等不到出价输入框');

    // ── 设出价 ──
    setNative(bidInput, C.bid); await sleep(900); blur(bidInput); await sleep(2000);
    od = outer() || od;
    bidInput = od.querySelector('input[placeholder*="自定义出价"]');
    R.出价读回 = bidInput ? String(bidInput.value || '').trim() : '(空)';

    // ── 设预算（走自定义槽）──
    let grp = grpOf();
    let bs = [].slice.call(grp.querySelectorAll('[class*=radio--]'));
    const custom = bs[bs.length - 1];
    R.预算槽点击前 = (custom.innerText || '').trim();
    click1(custom); await sleep(2000);
    grp = grpOf(); bs = [].slice.call(grp.querySelectorAll('[class*=radio--]'));
    const custom2 = bs[bs.length - 1];
    let bi = custom2.querySelector('input') || grp.querySelector('input');
    if (!bi) throw new Error('自定义预算槽没有输入框');
    setNative(bi, C.budget); await sleep(900); blur(bi); await sleep(2200);
    grp = grpOf(); bs = [].slice.call(grp.querySelectorAll('[class*=radio--]'));
    const custom3 = bs[bs.length - 1];
    bi = custom3.querySelector('input') || grp.querySelector('input');
    R.预算读回 = bi ? String(bi.value || '').trim() : (custom3.innerText || '').trim();
    R.预算槽结束 = bs.map(e => (e.innerText || '').trim());

    if (Number(String(R.出价读回).replace(/[^\d.]/g, '')) !== Number(C.bid)) throw new Error('出价读回=' + R.出价读回 + ' 期望 ' + C.bid);
    if (Number(String(R.预算读回).replace(/[^\d.]/g, '')) !== Number(C.budget)) throw new Error('预算读回=' + R.预算读回 + ' 期望 ' + C.budget);

    const wrap = od.closest('.ant-drawer');
    const foot = wrap && wrap.querySelector('.ant-drawer-footer');
    const ok = foot && [].slice.call(foot.querySelectorAll('div,span,button')).find(e => e.children.length === 0 && /^确\s*定$/.test((e.innerText || '').trim()));
    if (!ok) throw new Error('找不到确定');
    click1(ok);
    R.已保存 = true;
    await sleep(7000);
    R.提示 = ((document.body.innerText || '').match(/[^\n]*(成功|失败|错误|不能|至少)[^\n]*/g) || []).slice(0, 3);
    R.抽屉已关 = !outer();
  } catch (e) { R.fatal = e.message; }
  return JSON.stringify(R, null, 1);
})()
