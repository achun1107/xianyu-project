// xy-store-data.js —— 拉闲鱼店铺侧数据（数据罗盘商品级 + 店铺级）
// 需先导航到 seller.goofish.com（卖家工作台）
(async () => {
  const num = v => { const n = Number(v); return isFinite(n) ? n : 0; };
  const out = { 运行时刻: new Date().toLocaleString('zh-CN'), url: location.href };

  const ui = (window.__PC_SELLER_WORKBENCH__ || {}).userInfo || {};
  out.工作台用户信息 = { 有workbench: !!window.__PC_SELLER_WORKBENCH__, idle_site_biz_code: ui.idle_site_biz_code || null, member: ui.idle_user_group_member_id || null };
  const h = {};
  if (ui.idle_site_biz_code) h.idle_site_biz_code = ui.idle_site_biz_code;
  if (ui.idle_user_group_member_id) h.idle_user_group_member_id = ui.idle_user_group_member_id;

  const call = async (dateType, pageNo, pageSize) => {
    const r = await window.lib.mtop.request({
      api: 'mtop.alibaba.idle.seller.pc.datacompass.item.list', v: '1.0', type: 'POST',
      data: { dateType, pageNo, pageSize },
      appKey: '34839810', accountSite: 'xianyu', dataType: 'json', timeout: 20000,
      needLogin: false, sessionOption: 'AutoLoginOnly', ecode: 0, ext_headers: h, headers: h,
    });
    return r;
  };

  // ---- 商品级（近7天）----
  try {
    const all = [];
    let range = null, total = null;
    for (let p = 1; p <= 4; p++) {
      const r = await call('recent7d', p, 50);
      if (!range) range = ((r.data || {}).extendInfo || {}).realDateRange;
      const d = (r.data || {}).data || {};
      if (total === null) total = d.total;
      const list = d.list || [];
      list.forEach(it => all.push({
        itemId: String(it.itmId),
        标题: (it.itmName || '').slice(0, 34),
        曝光: num(it.showPv), 浏览人数: num(it.ipvUv), 浏览: num(it.ipv),
        成交: num(it.payOrdCnt), 支付额: num(it.payAmt),
        转化率: it.ipvPayUcvr, 上架天数: num(it.daysOnShelf),
      }));
      if (list.length < 50) break;
    }
    out.近7天区间 = range;
    out.商品总数 = total;
    out.商品 = all;
    out.近7天汇总 = {
      商品数: all.length,
      曝光: all.reduce((s, x) => s + x.曝光, 0),
      浏览人数: all.reduce((s, x) => s + x.浏览人数, 0),
      成交: all.reduce((s, x) => s + x.成交, 0),
      支付额: all.reduce((s, x) => s + x.支付额, 0),
    };
  } catch (e) { out.近7天错误 = String((e && e.message) || e); }

  // ---- 店铺级（会员/店铺数据）----
  try {
    const r2 = await window.lib.mtop.request({
      api: 'mtop.taobao.idle.ad.member.data.query', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({}) },
    });
    const scal = o => { const z = {}; for (const k in (o || {})) { const v = o[k]; if (v !== null && ['string', 'number', 'boolean'].indexOf(typeof v) >= 0) z[k] = v; } return z; };
    out.店铺级 = { ret: (r2.ret || [])[0], data: scal(r2.data) };
  } catch (e) { out.店铺级错误 = String((e && e.message) || e); }

  return JSON.stringify(out);
})()
