// xy-snapshot-run.js —— 跑快照并落盘到 xy-daily/
// 用法: node xy-snapshot-run.js [标签]
const http = require('http'), fs = require('fs'), path = require('path');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const DIR = 'D:\\DSH\\achun\\xy-daily';

function ev(code) {
  return new Promise(r => {
    const p = JSON.stringify({ store: STORE, code });
    const q = http.request({ host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(p), 'x-api-key': KEY } },
      res => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { r(JSON.parse(b)); } catch (e) { r({ ok: false, error: b.slice(0, 300) }); } }); });
    q.on('error', e => r({ ok: false, error: e.message })); q.write(p); q.end();
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
const M = v => '¥' + Math.round(Number(v) || 0).toLocaleString();

(async () => {
  const tag = process.argv[2] || '';
  if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });

  // 数据罗盘要在 seller.goofish.com；商品列表两处都能用 → 先停在卖家后台
  let r = await ev(`(function(){location.href='https://seller.goofish.com/?site=COMMONPRO#/seller-ad/home';return 'nav'})()`);
  if (!r.ok) { console.log('跳转失败 ' + r.error); process.exit(1); }
  await sleep(18000);

  r = await ev(fs.readFileSync(path.join(__dirname, 'xy-snapshot.js'), 'utf8'));
  if (!r.ok) { console.log('快照失败 ' + r.error); process.exit(1); }
  const d = typeof r.result === 'string' ? JSON.parse(r.result) : r.result;

  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  const stamp = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate()) + '_' + pad(now.getHours()) + pad(now.getMinutes());
  const file = path.join(DIR, stamp + (tag ? '_' + tag : '') + '.json');
  d.文件名 = path.basename(file);
  fs.writeFileSync(file, JSON.stringify(d, null, 1), 'utf8');

  // 追加汇总 CSV（一天一行一样本，便于后续算增量）
  const csv = path.join(DIR, 'xy-daily.csv');
  if (!fs.existsSync(csv)) {
    fs.writeFileSync(csv, '\ufeff时间,itemId,标题,价格,状态,想要,曝光,浏览人数,成交,支付额,上架天数\n', 'utf8');
  }
  const esc = s => '"' + String(s == null ? '' : s).replace(/"/g, '""') + '"';
  const lines = d.商品.map(x => [stamp, x.itemId, esc(x.标题), x.价格, x.状态, x.想要, x.曝光, x.浏览人数, x.成交, x.支付额, x.上架天数].join(','));
  fs.appendFileSync(csv, lines.join('\n') + '\n', 'utf8');

  console.log('采集时刻 ' + d.采集时刻 + '   罗盘区间 ' + JSON.stringify(d.罗盘区间));
  console.log('商品列表 ' + d.商品数 + ' 个   罗盘 ' + d.罗盘条数 + ' 条   左连接后 ' + d.商品.length + ' 行');
  if (d.错误 && d.错误.length) console.log('错误: ' + JSON.stringify(d.错误));
  console.log('落盘: ' + file);
  console.log('汇总: ' + csv);

  const withWant = d.商品.filter(x => x.想要 != null);
  console.log('\n有想要数的商品 ' + withWant.length + ' / ' + d.商品.length);
  console.log('有罗盘数据的 ' + d.商品.filter(x => x.有罗盘数据).length + ' 个');
  console.log('\n══ 想要 Top 15 ══');
  withWant.slice().sort((a, b) => b.想要 - a.想要).slice(0, 15).forEach(x =>
    console.log('  ' + String(x.想要).padStart(6) + ' 想要  ' + String(x.曝光 == null ? '-' : x.曝光).padStart(7) + ' 曝光 ' + String(x.浏览人数 == null ? '-' : x.浏览人数).padStart(5) + ' 浏览 ' + String(x.成交 == null ? '-' : x.成交).padStart(3) + ' 单  上架' + String(x.上架天数 == null ? '-' : x.上架天数).padStart(4) + '天  ' + x.标题.slice(0, 36)));
  console.log('\n══ 仅罗盘有、商品列表没抓到的（' + (d.仅罗盘有 || []).length + ' 个）══');
  (d.仅罗盘有 || []).slice(0, 10).forEach(x => console.log('  ' + x.itemId + '  曝光' + x.曝光 + ' 成交' + x.成交 + ' 上架' + x.上架天数 + '天'));
})().catch(e => { console.error('FAIL ' + e.message); process.exit(1); });
