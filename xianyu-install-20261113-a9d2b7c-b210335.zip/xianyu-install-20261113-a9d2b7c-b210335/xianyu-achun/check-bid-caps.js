// check-bid-caps.js —— 审计全店计划是否符合「出价上限」永久规则
// 规则：咨询量 ≤ ¥4，订单量 ≤ ¥35（见 出价上限规则-永久.md）
(async () => {
  const BID_CAPS = Object.assign({ chat: 4, order: 35 }, (typeof window !== 'undefined' && window.__BID_CAPS) || {});
  const TGT = { exposure: '曝光量', click: '浏览量', follow_collect: '关注收藏量', chat: '咨询量', order: '订单量' };
  const mtop = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };

  let all = [];
  for (let p = 1; p <= 5; p++) {
    const r = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: p, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
    if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0)) return JSON.stringify({ err: r && r.ret }, null, 1);
    const list = ((r.data || {}).result) || [];
    all = all.concat(list);
    if (list.length < 100) break;
  }

  const rows = [];
  for (let i = 0; i < all.length; i++) {
    const c = all[i];
    const key = c.bidTarget;
    const cap = BID_CAPS[key];
    const bid = n(c.cpm) / 100;
    rows.push({
      id: c.campaignId, name: c.title,
      target: TGT[key] || key, key: key,
      bid: bid, cap: cap === undefined ? null : cap,
      合规: cap === undefined ? '未设上限' : (bid <= cap + 1e-9 ? '✅' : '❌ 超限'),
      超出: cap === undefined ? null : (bid > cap + 1e-9 ? +(bid - cap).toFixed(2) : 0),
      budget: n(c.maxDayBudget) / 100,
      code: c.statusDescCode, pause: c.pauseStatus,
      goods: (c.entityList || []).length,
    });
  }
  const bad = rows.filter(x => x.合规.indexOf('❌') === 0);
  const byTarget = {};
  rows.forEach(x => { byTarget[x.target] = byTarget[x.target] || { 条数: 0, 超限: 0, 出价区间: [] }; byTarget[x.target].条数++; if (x.合规.indexOf('❌') === 0) byTarget[x.target].超限++; byTarget[x.target].出价区间.push(x.bid); });
  Object.keys(byTarget).forEach(k => {
    const a = byTarget[k].出价区间.sort((p, q) => p - q);
    byTarget[k].出价区间 = '¥' + a[0] + ' ~ ¥' + a[a.length - 1];
  });

  return JSON.stringify({
    时刻: new Date().toLocaleString('zh-CN'),
    规则: { 咨询量: '≤ ¥' + BID_CAPS.chat, 订单量: '≤ ¥' + BID_CAPS.order },
    计划数: rows.length,
    超限数: bad.length,
    按目标汇总: byTarget,
    超限明细: bad,
    全部: rows.map(x => (x.合规 === '✅' ? '✅' : x.合规 === '未设上限' ? '—' : '❌') + ' ' + String(x.target).padEnd(6) + ' ¥' + String(x.bid).padEnd(7) + ' cap=' + String(x.cap).padEnd(5) + ' ' + x.name),
  }, null, 1);
})()
