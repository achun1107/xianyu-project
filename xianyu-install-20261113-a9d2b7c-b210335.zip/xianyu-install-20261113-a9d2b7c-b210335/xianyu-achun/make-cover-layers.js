/**
 * make-cover-layers.js — 渲染「文字层模板（_LAYER_TPL_LIB）」，与 /api/poster/make 的成品版式区分
 *
 * 关键：前端对纯文字层版式会传 blocks:[] / tags:[] 来压掉服务端默认的三黄块+一紫块。
 *      本脚本复刻该行为，否则会多叠四色块（这是 2026-09-26 出 07/08 时踩过的坑）。
 *
 * 用法: node make-cover-layers.js <城市> <明星> <libKey关键词...>
 *   例: node make-cover-layers.js 杭州 那英 ⑨
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const { SVC: SVC_ENV, PATHS, ROOT } = require('./lib/env');

const SVC = PATHS.playwrightService;
const KEY = SVC_ENV.apiKey;
const CITY = process.argv[2] || '杭州';
const STAR = process.argv[3] || '那英';
const WANTS = process.argv.slice(4);
const OUTDIR = path.join(ROOT, '图层模板-' + STAR + CITY);

function api(p, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 200))); } }); });
    req.on('error', reject); req.write(payload); req.end();
  });
}
function extractObj(src, header) {
  const i = src.indexOf(header);
  if (i < 0) throw new Error('找不到: ' + header);
  let j = src.indexOf('{', i), d = 0, k = j;
  for (; k < src.length; k++) { const c = src[k]; if (c === '{') d++; else if (c === '}') { d--; if (d === 0) break; } }
  return src.slice(j, k + 1);
}
function extractFn(src, header) {
  const i = src.indexOf(header);
  if (i < 0) throw new Error('找不到: ' + header);
  let j = src.indexOf('{', i), d = 0, k = j;
  for (; k < src.length; k++) { const c = src[k]; if (c === '{') d++; else if (c === '}') { d--; if (d === 0) break; } }
  return src.slice(i, k + 1);
}

const dash = fs.readFileSync(path.join(PATHS.xianyuMonitor, 'publish_dashboard.js'), 'utf8');
const LIB = eval('(' + extractObj(dash, 'var _LAYER_TPL_LIB = {') + ')');
const SRC_NORM = extractFn(dash, 'function _normLayer(l)');
const SRC_APPLY = extractFn(dash, 'function _iwApplyText(callback, overrides, srcUrl, layersOverride)');

const keys = Object.keys(LIB).filter(k => !WANTS.length || WANTS.some(w => k.indexOf(w) >= 0));
if (!keys.length) { console.log('没有匹配的层模板。可用:'); Object.keys(LIB).forEach(k => console.log('  ' + k)); process.exit(2); }

(async () => {
  fs.mkdirSync(OUTDIR, { recursive: true });
  const { chromium } = require(SVC + '/node_modules/playwright');
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.setContent('<!doctype html><html><head><meta charset="utf-8"></head><body></body></html>');
  await page.addScriptTag({ content:
    'window._iw = { layers: [], stickerImgs: [], sourceUrl: "" };\nfunction addLog(){};\n' + SRC_NORM + '\n' + SRC_APPLY + '\n' +
    'window.__render = function(b64, layers, ov) { return new Promise(function(res){ _iwApplyText(function(d){ res(d); }, ov, "data:image/jpeg;base64," + b64, layers); }); };' });

  // 干净底图：传 blocks:[] / tags:[] 压掉服务端默认四色块（复刻前端 L1953 行为）
  console.log('取干净底图（' + CITY + ' ' + STAR + ', source=damai_official, blocks=[]）...');
  const r = await api('/api/poster/make', { city: CITY, star: STAR, source: 'damai_official', ratio: '3:4', blocks: [], tags: [] });
  if (!r.ok) { console.log('底图失败: ' + r.error); await browser.close(); process.exit(1); }
  console.log('  baseOrigin=' + (r.baseOrigin || 'search'));
  const baseDir = path.join(ROOT, '主图筛选-' + STAR + CITY);
  fs.mkdirSync(baseDir, { recursive: true });
  fs.writeFileSync(path.join(baseDir, '_干净底图.jpg'), Buffer.from(r.imageB64, 'base64'));
  console.log('  干净底图已存: ' + path.join(baseDir, '_干净底图.jpg'));

  let n = 0;
  for (const k of keys) {
    n++;
    const layers = LIB[k];
    const dataUrl = await page.evaluate(({ b64, layers, city, star }) => window.__render(b64, layers, { city, star }),
      { b64: r.imageB64, layers, city: CITY, star: STAR });
    if (!dataUrl) { console.log('  ' + k + ' 渲染失败'); continue; }
    const file = path.join(OUTDIR, String(n).padStart(2, '0') + '-' + k.replace(/[\\/:*?"<>|]/g, '').slice(0, 30) + '.png');
    fs.writeFileSync(file, Buffer.from(dataUrl.replace(/^data:image\/[a-z]+;base64,/, ''), 'base64'));
    console.log('  OK  ' + k + '  (' + layers.length + ' 层)  → ' + path.basename(file));
  }
  await browser.close();
  console.log('\n输出目录: ' + OUTDIR);
})();
