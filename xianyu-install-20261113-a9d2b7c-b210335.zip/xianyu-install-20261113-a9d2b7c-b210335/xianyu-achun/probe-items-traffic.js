/**
 * probe-items-traffic.js — 批量访问商品页读流量数据
 * 用法: node probe-items-traffic.js <itemId> [itemId...]
 */
const fs = require('fs');
const http = require('http');
const path = require('path');
const { SVC, STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const IDS = process.argv.slice(2).filter(x => /^\d+$/.test(x));
if (!IDS.length) { console.log('用法: node probe-items-traffic.js <itemId>...'); process.exit(1); }
const CODE = fs.readFileSync(path.join(__dirname, '_probe-item-traffic.js'), 'utf8');

function post(p, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 300))); } }); });
    req.on('error', reject);
    req.setTimeout(timeoutMs || 180000, () => req.destroy(new Error('请求超时')));
    req.write(payload); req.end();
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const all = [];
  for (const id of IDS) {
    const url = 'https://www.goofish.com/item?id=' + id;
    process.stdout.write(id + ' ... ');
    await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href=' + JSON.stringify(url) + '; "nav"' }, 90000);
    await sleep(9000);
    const res = await post('/api/agent/eval-on-store', { store: STORE, code: 'window.__ID=' + JSON.stringify(id) + ';\n' + CODE }, 120000);
    const r = res.ok ? (res.result || {}) : { err: JSON.stringify(res).slice(0, 200) };
    all.push(r);
    console.log('浏览=' + (r.浏览 || '-') + '  想要=' + (r.想要 || '-') + '  已售=' + (r.已售 || '-') + '  价=' + (r.价格 || '-') + '  ' + (r.err || ''));
    if (r.计数片段 && r.计数片段.length) console.log('        计数片段: ' + r.计数片段.join(' | '));
  }
  fs.writeFileSync(path.join(__dirname, 'items-traffic.json'), JSON.stringify(all, null, 2), 'utf8');
  console.log('\n已存 items-traffic.json');
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
