/**
 * publish-stagger.js —— 按【1 小时间隔】发完 4 条链接（澳门梓渝 2 条 + 南京华晨宇 2 条）
 *
 * 老板 2026-10-10：「上架澳门梓渝两个商品链接…上架南京华晨宇两个商品链接…上架间隔为一小时。」
 *
 * 为什么拆成两个"组"而不是一个脚本跑 3 小时：
 *   publish-group.js 的 city/star/event/baseImg 是【方案级】的，两个城市必须两份方案。
 *   而连着跑两份方案，组1最后一条和组2第一条之间会【间隔 0】——不符合"间隔一小时"。
 *   所以：组1 现在跑（内部 itemGapSec=3600），组2 由一次性计划任务在 t0+2h 起，四条两两相隔 1 小时。
 *
 * 用法:
 *   node publish-stagger.js 1     # 只发第 1 组（澳门梓渝，2 条，中间隔 1 小时）
 *   node publish-stagger.js 2     # 只发第 2 组（南京华晨宇，2 条，中间隔 1 小时）
 */
const path = require('path');
const { spawnSync } = require('child_process');

// 不依赖调用方的 cwd：计划任务/别的脚本从任意目录起它都要能跑对
// （publish-group.js 会把 publish-group-result-*.json 写到 cwd，所以 cwd 必须对）
process.chdir(__dirname);

const GROUP = String(process.argv[2] || '');
const GROUPS = {
  1: 'publish-groups\\澳门梓渝-首开.json',
  2: 'publish-groups\\南京华晨宇-首开.json',
};
if (!GROUPS[GROUP]) { console.log('用法: node publish-stagger.js 1|2'); process.exit(2); }

const FILE = path.join(__dirname, GROUPS[GROUP]);
const RUNNER = path.join(__dirname, 'tools', 'publish-group.js');

console.log('[' + new Date().toLocaleString('zh-CN') + '] 起第 ' + GROUP + ' 组: ' + GROUPS[GROUP]);
// stdio:'inherit' —— 不要把子进程的输出经管道抓过来（被沙箱挡过），直接继承到本进程 stdout
const r = spawnSync(process.execPath, [RUNNER, FILE], { stdio: 'inherit', cwd: __dirname });
console.log('[' + new Date().toLocaleString('zh-CN') + '] 第 ' + GROUP + ' 组结束，退出码 ' + r.status);
process.exit(r.status === 0 ? 0 : 1);
