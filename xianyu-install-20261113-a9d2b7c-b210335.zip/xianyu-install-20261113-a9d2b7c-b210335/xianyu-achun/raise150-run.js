// raise150-run.js —— 把指定计划反解到「预计提升 >= 150%」，一位小数
// 用法: node raise150-run.js <from> <to>
// 顺序与范围：用户 2026-09-21 确认的 20 个（单明星 17 + 热销其他 3）
// 其中 6 个订单120 预算 ¥60 不足（150% 后需 >=¥67），一并提到 ¥70
const http = require('http');
const fs = require('fs');
const { SVC, STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const URL = 'https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage';
const TARGET = Number(process.env.REBID_TARGET || 150);
const CAMP_URL = 'https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage';

const DEFAULT_PLANS = [
  { name: '单明星-侯明昊-订单120', id: '95962377', budget: 70 },
  { name: '单明星-侯明昊-订单130', id: '94688535' },
  { name: '单明星-侯明昊-咨询120', id: '95283163' },
  { name: '单明星-刘宇-订单120', id: '95299021', budget: 70 },
  { name: '单明星-刘宇-订单130', id: '95373021' },
  { name: '单明星-刘宇-咨询120', id: '95761455' },
  { name: '单明星-孙燕姿-订单120', id: '95235397', budget: 70 },
  { name: '单明星-孙燕姿-订单130', id: '95809297' },
  { name: '单明星-孙燕姿-咨询120', id: '94712218' },
  { name: '单明星-王力宏-订单120', id: '95285374', budget: 70 },
  { name: '单明星-王力宏-咨询120', id: '96559366' },
  { name: '单明星-许嵩-订单120', id: '95309358', budget: 70 },
  { name: '单明星-许嵩-订单130', id: '95317370' },
  { name: '单明星-许嵩-咨询120', id: '95761439' },
  { name: '单明星-周杰伦-订单120', id: '96559506', budget: 70 },
  { name: '单明星-周杰伦-订单130', id: '96116473' },
  { name: '单明星-周杰伦-咨询120', id: '95259165' },
  { name: '热销-汪苏泷广州-咨询130', id: '94744199' },
  { name: '热销-Capper北京-咨询130', id: '95309260' },
  { name: '热销-断眉广州-咨询130', id: '95291265' },
];
// 也可以用 PLANS_JSON 指定另一批计划（2026-09-21 加，给"漏掉的计划"复用同一套逻辑）
const PLANS = process.env.PLANS_JSON
  ? JSON.parse(fs.readFileSync(process.env.PLANS_JSON, 'utf8'))
  : DEFAULT_PLANS;
const LOG = process.env.PLANS_LOG || 'D:\\DSH\\achun\\raise150-log.ndjson';

function ev(code) {
  return new Promise((resolve) => {
    const payload = JSON.stringify({ store: STORE, code });
    const req = http.request({ host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      res => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: b.slice(0, 200) }); } }); });
    req.on('error', e => resolve({ ok: false, error: e.message })); req.write(payload); req.end();
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
function log(o) { fs.appendFileSync(LOG, JSON.stringify({ ts: new Date().toISOString(), ...o }) + '\n', 'utf8'); }

(async () => {
  const from = Number(process.argv[2] || 0), to = Number(process.argv[3] || PLANS.length);
  const REBID = fs.readFileSync(__dirname + '\\ad-rebid.js', 'utf8');
  for (let i = from; i < to; i++) {
    const p = PLANS[i];
    console.log(`\n───── [${i + 1}/${PLANS.length}] ${p.name}${p.budget ? '  预算→¥' + p.budget : ''} ─────`);
    let r = await ev(`(function(){location.href=${JSON.stringify(URL)};return 'nav'})()`);
    if (!r.ok) { console.log('  跳转失败 ' + r.error); log({ i, name: p.name, step: 'nav', err: r.error }); continue; }
    await sleep(16000);
    const cfg = JSON.stringify({ planName: p.name, planId: p.id, targetImprove: TARGET, budget: p.budget, submit: true });
    r = await ev(`window.__RCFG=${cfg}; 'set'`);
    if (!r.ok) { console.log('  cfg 失败 ' + r.error); log({ i, name: p.name, step: 'cfg', err: r.error }); continue; }
    r = await ev(REBID);
    if (!r.ok) { console.log('  rebid 失败 ' + r.error); log({ i, name: p.name, step: 'rebid', err: r.error }); continue; }
    let j; try { j = typeof r.result === 'string' ? JSON.parse(r.result) : r.result; } catch (e) { console.log('  解析失败: ' + String(r.result).slice(0, 200)); log({ i, name: p.name, step: 'parse', raw: String(r.result).slice(0, 300) }); continue; }
    const line = `${(j.beforeBid + '→' + j.finalBid).padEnd(18)} ${String(j.beforeImprove).padStart(4)}%→${String(j.finalImprove).padStart(4)}%  存${j.inputAtSave}  自检${j.selfCheckPassed} 保存${j.saved}${j.budgetInputVal ? '  预算¥' + j.budgetInputVal : ''}`;
    console.log('  ' + line);
    if (j.fatal) console.log('  FATAL: ' + j.fatal);
    if (j.aborted) console.log('  ABORTED: ' + j.aborted);
    if (j.afterSave && j.afterSave.toast && j.afterSave.toast.length) console.log('  提示: ' + JSON.stringify(j.afterSave.toast));
    if (j.budgetOptions) console.log('  预算档位: ' + JSON.stringify(j.budgetOptions) + (j.budgetByPreset !== undefined ? '  走预设=' + j.budgetByPreset : ''));
    log({ i, name: p.name, before: j.beforeBid, after: j.finalBid, atSave: j.inputAtSave || null, impBefore: j.beforeImprove, impAfter: j.finalImprove, saved: !!j.saved, check: !!j.selfCheckPassed, budget: j.budgetInputVal || null, fatal: j.fatal || null, aborted: j.aborted || null });
    await sleep(1500);
  }
  console.log('\n本批完成，日志: ' + LOG);
})().catch(e => { console.error('FAIL ' + e.message); process.exit(1); });
