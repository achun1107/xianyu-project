/**
 * gen-3-covers.js — 为指定城市/明星生成【全部主图模板】的成品图
 *
 * 与 make-covers.js 的区别：make-covers 只遍历本地版式库（poster-templates.json，2 个），
 * 而脚本实际会用的主图模板有 3 个 —— 第三个 __shoukai 来自发布台的
 * _LAYER_TPL_LIB（文字层模板库 ⑨），不在版式库里。这里把它一起生成。
 *
 * 城市/明星在此写死（PowerShell 传中文会被 OEM 936 吃掉）。
 * 输出: D:\DSH\achun\主图筛选-<明星><城市>-3模板\
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const { SVC: SVC_ENV, PATHS, ROOT } = require('./lib/env');

const CITY = '成都';
const STAR = '宋雨琦';
const SVC = PATHS.playwrightService;
const KEY = SVC_ENV.apiKey;
const OUTDIR = path.join(ROOT, '主图筛选-' + STAR + CITY + '-3模板');

function api(p, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 200))); } }); });
    req.on('error', reject); req.write(payload); req.end();
  });
}
function apiGet(p) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port: 8093, path: p, headers: { 'x-api-key': KEY } }, (res) => {
      let b = ''; res.on('data', c => b += c);
      res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error('非 JSON')); } });
    }).on('error', reject);
  });
}
function extractFn(src, header) {
  const i = src.indexOf(header);
  if (i < 0) throw new Error('找不到函数: ' + header);
  let j = src.indexOf('{', i), depth = 0, k = j;
  for (; k < src.length; k++) { const c = src[k]; if (c === '{') depth++; else if (c === '}') { depth--; if (depth === 0) break; } }
  return src.slice(i, k + 1);
}

const dash = fs.readFileSync(path.join(PATHS.xianyuMonitor, 'publish_dashboard.js'), 'utf8');
const SRC_NORM = extractFn(dash, 'function _normLayer(l)');
const SRC_APPLY = extractFn(dash, 'function _iwApplyText(callback, overrides, srcUrl, layersOverride)');
const LIB = eval('(' + (() => { const i = dash.indexOf('var _LAYER_TPL_LIB = {'); let j = dash.indexOf('{', i), d = 0, k = j; for (; k < dash.length; k++) { const c = dash[k]; if (c === '{') d++; else if (c === '}') { d--; if (d === 0) break; } } return dash.slice(j, k + 1); })() + ')');
const SHOUKAI = LIB['⑨ 刘宪华首开样式（紫块白字+红字三行·居中）'];

(async () => {
  fs.mkdirSync(OUTDIR, { recursive: true });

  // 组装脚本实际会用的 3 个主图模板
  const local = (await apiGet('/api/poster/templates')).items || [];
  const LIST = [
    { key: 'xuliang-v1', label: '三黄块+一紫块', kind: 'json', layers: (local.find(x => x.id === 'xuliang-v1') || {}).layers || [] },
    { key: '__shoukai', label: '首开紫块样式（干净版）', kind: 'layer', layers: SHOUKAI || [] },
    { key: 'tpl_redtext', label: '白底红字版', kind: 'json', layers: (local.find(x => x.id === 'tpl_redtext') || {}).layers || [] },
  ];

  const { chromium } = require(SVC + '/node_modules/playwright');
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.setContent('<!doctype html><html><head><meta charset="utf-8"></head><body></body></html>');
  await page.addScriptTag({ content:
    'window._iw = { layers: [], stickerImgs: [], sourceUrl: "" };\nfunction addLog(){};\n' +
    SRC_NORM + '\n' + SRC_APPLY + '\n' +
    'window.__render = function(b64, layers, ov) { return new Promise(function(res){ _iwApplyText(function(d){ res(d); }, ov, "data:image/jpeg;base64," + b64, layers); }); };'
  });

  const report = [];
  let n = 0;
  for (const tpl of LIST) {
    n++;
    const tag = String(n).padStart(2, '0') + '-' + tpl.key;
    process.stdout.write('[' + n + '/' + LIST.length + '] ' + tpl.key + ' (' + tpl.label + ') ... ');
    const body = { city: CITY, star: STAR, source: 'damai_official', ratio: '3:4' };
    if (tpl.kind === 'json') body.templateId = tpl.key; else { body.blocks = []; body.tags = []; }
    let r;
    try { r = await api('/api/poster/make', body); } catch (e) { console.log('调用失败 ' + e.message); continue; }
    if (!r.ok || !r.imageB64) { console.log('出图失败 ' + (r.error || '')); continue; }

    let finalB64 = r.imageB64, mode = 'raw', ext = 'jpg';
    if (tpl.layers.length) {
      const du = await page.evaluate(({ b64, layers, city, star }) => window.__render(b64, layers, { city, star }), { b64: r.imageB64, layers: tpl.layers, city: CITY, star: STAR });
      if (du) { finalB64 = du.replace(/^data:image\/[a-z]+;base64,/, ''); mode = 'layers×' + tpl.layers.length; ext = 'png'; }
    }
    const f = path.join(OUTDIR, tag + '.' + ext);
    fs.writeFileSync(f, Buffer.from(finalB64, 'base64'));
    console.log('OK ' + Math.round(fs.statSync(f).size / 1024) + 'KB  base=' + (r.baseOrigin || '') + '  ' + mode);
    report.push({ file: f, key: tpl.key, label: tpl.label, baseOrigin: r.baseOrigin || '', layers: tpl.layers.length, mode });
  }
  await browser.close();
  fs.writeFileSync(path.join(OUTDIR, '_report.json'), JSON.stringify(report, null, 2), 'utf8');
  console.log('\n输出目录: ' + OUTDIR);
  report.forEach(x => console.log('  ' + path.basename(x.file) + '  ←  ' + x.label));
})().catch(e => { console.log('❌ ' + (e && e.stack || e)); process.exit(1); });
