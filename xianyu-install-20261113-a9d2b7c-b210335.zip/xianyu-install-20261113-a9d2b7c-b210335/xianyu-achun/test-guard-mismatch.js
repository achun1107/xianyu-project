/**
 * test-guard-mismatch.js — 负向测试：页面商品与目标 id 不一致时必须拒绝点击
 * 不产生任何实际下架（护栏会在点击前返回 err）。
 */
const fs = require('fs'); const http = require('http'); const path = require('path');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const CODE = fs.readFileSync(path.join(__dirname, '_click-offshelf.js'), 'utf8');
const REAL_ID = '1087704049928';     // 真打开这个页面
const FAKE_ID = '9999999999999';     // 但假装目标是这个

function post(p, body, t) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 300))); } }); });
    req.on('error', reject); req.setTimeout(t || 120000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}
(async () => {
  const key = SVC.apiKey;
  console.log('打开商品页 ' + REAL_ID + ' ...');
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/item?id=' + REAL_ID + '"; "nav"' }, 90000);
  await new Promise(z => setTimeout(z, 12000));
  console.log('注入时传【不匹配】的 __EXPECT_ID=' + FAKE_ID + '（期望被拒绝）...\n');
  const res = await post('/api/agent/eval-on-store', { store: STORE, code: 'window.__EXPECT_ID=' + JSON.stringify(FAKE_ID) + ';\n' + CODE }, 120000);
  const r = (res && res.result) || {};
  console.log(JSON.stringify(r, null, 1));
  console.log('\n════ 判定 ════');
  if (r.err && /itemId/.test(r.err)) console.log('  ✅ 护栏生效：页面 id 与目标不一致 → 拒绝点击，没有误伤');
  else console.log('  ❌ 护栏没拦住！err=' + (r.err || '无'));
  console.log('  页面itemId=' + r.页面itemId + '  期望=' + r.期望itemId + '  已点下架=' + (r.已点下架 || false));
  // 恢复：把页面导航回首页，别留在商品页
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/"; "back"' }, 60000);
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
