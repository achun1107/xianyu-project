/**
 * check-item-images.js — 轻量确认：商品页上的主图有没有真的加载出来
 * 走 /api/agent/eval-on-store（操作闲鱼标签页，已多次验证可用），只读 DOM，不做重活。
 * 用法: node check-item-images.js <itemId> [...]
 */
const fs = require('fs'); const http = require('http'); const path = require('path');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const IDS = process.argv.slice(2).filter(x => /^\d+$/.test(x));
if (!IDS.length) { console.log('用法: node check-item-images.js <itemId>...'); process.exit(2); }
const OUT = path.join(__dirname, '渲染确认');
fs.mkdirSync(OUT, { recursive: true });

const CODE = `(() => {
  const out = { href: location.href, docTitle: document.title };
  const imgs = [...document.querySelectorAll('img')].map(e => {
    const r = e.getBoundingClientRect();
    return { src: String(e.currentSrc || e.src || '').slice(0, 120), natW: e.naturalWidth, natH: e.naturalHeight,
             dispW: Math.round(r.width), dispH: Math.round(r.height), complete: !!e.complete };
  }).filter(x => x.natW > 0 || x.dispW > 0);
  imgs.sort((a, b) => (b.dispW * b.dispH) - (a.dispW * a.dispH));
  out.图片数 = imgs.length;
  out.主图 = imgs[0] || null;
  out.主图已加载 = !!(imgs[0] && imgs[0].natW > 0 && imgs[0].complete);
  out.正文长度 = (document.body.innerText || '').length;
  out.含宋雨琦 = (document.body.innerText || '').indexOf('宋雨琦') >= 0;
  out.含广州 = (document.body.innerText || '').indexOf('广州') >= 0;
  return out;
})()`;

const { post: httpPost } = require('./lib/http');
function post(p, body, t) { return httpPost(p, body, { timeout: t || 100000 }); }
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const all = [];
  for (const id of IDS) {
    console.log('\n════ ' + id + ' ════');
    const nav = await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/item?id=' + id + '"; "nav"' }, 90000);
    console.log('  导航: ' + JSON.stringify(nav).slice(0, 100));
    await sleep(11000);
    const res = await post('/api/agent/eval-on-store', { store: STORE, code: CODE }, 100000);
    if (!res.ok) { console.log('  ❌ ' + JSON.stringify(res).slice(0, 200)); continue; }
    const r = res.result || {};
    console.log('  页面标题 : ' + r.docTitle);
    console.log('  图片数   : ' + r.图片数 + '     正文 ' + r.正文长度 + ' 字    含宋雨琦=' + r.含宋雨琦 + ' 含广州=' + r.含广州);
    console.log('  主图     : ' + (r.主图已加载 ? '✅ 已加载' : '❌ 未加载'));
    if (r.主图) console.log('             ' + r.主图.natW + 'x' + r.主图.natH + '  显示 ' + r.主图.dispW + 'x' + r.主图.dispH + '\n             ' + r.主图.src);
    all.push({ id, ...r });
  }
  fs.writeFileSync(path.join(OUT, '_images.json'), JSON.stringify(all, null, 2), 'utf8');
  console.log('\n════ 汇总 ════');
  all.forEach(x => console.log('  ' + x.id + '  主图' + (x.主图已加载 ? '✅' : '❌') + '  ' + (x.主图 ? x.主图.natW + 'x' + x.主图.natH : '-')));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
