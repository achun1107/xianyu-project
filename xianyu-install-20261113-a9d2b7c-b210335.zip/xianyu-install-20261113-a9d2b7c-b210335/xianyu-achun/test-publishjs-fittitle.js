/**
 * test-publishjs-fittitle.js — 验证 publish.js 里的 fitTitle 与 publish-one.js 结果一致
 * 做法：从 publish.js 抽出 fitTitle 源码 eval 出来，用同一批模板跑，逐条比对。
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { PATHS } = require('./lib/env');

// ① 从 publish.js 抽 fitTitle（含 TITLE_MAX / TITLE_MIN / TITLE_PAD）
const src = fs.readFileSync(path.join(PATHS.xianyuMonitor, 'publish.js'), 'utf8');
const i = src.indexOf('var TITLE_MAX');
if (i < 0) { console.log('❌ publish.js 里找不到 var TITLE_MAX'); process.exit(1); }
let j = src.indexOf('function fitTitle', i);
let k = src.indexOf('{', j), d = 0, e = k;
for (; e < src.length; e++) { const c = src[e]; if (c === '{') d++; else if (c === '}') { d--; if (d === 0) break; } }
const consts = src.slice(i, j);
const fn = src.slice(j, e + 1);
// 用 new Function 隔离作用域，避免抽出代码里的 var 与本文件的同名常量冲突
const fitTitlePublished = new Function(consts + '\n' + fn + '\nreturn fitTitle;')();

// ② publish-one.js 的版本 —— 【2026-10-11 改】不再手抄一份逻辑。
//    原来这里硬写 TITLE_MAX = 40 + 手抄的 fitTitle，于是「两边到底同不同步」全靠人肉维护，
//    而且 40 这个错值它也跟着一起错。现在 publish-one.js 走 lib/title.js（唯一实现），
//    这里直接 require 它、pad 从 publish-one.js 里抠（与 tools/publish-group.js 同一个手法）。
const titleLib = require('./lib/title');
const P1 = fs.readFileSync(path.join(__dirname, 'publish-one.js'), 'utf8');
const PAD_FROM_P1 = eval(P1.match(/const TITLE_PAD = (\[[^\]]*\]);/)[1]);
const fitTitleOne = titleLib.makeFitTitle({ pad: PAD_FROM_P1, max: titleLib.PLATFORM_TITLE_MAX, min: 30 });

const T = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.xianyu-templates.json'), 'utf8'));
const SAMPLES = [['泉州', '徐良'], ['广州', '宋雨琦'], ['北京', '凤凰传奇'], ['南京', '华晨宇']];
const EVENT = '演唱会', SESSION = '首开';

console.log('publish.js 里的常量: ' + consts.trim().replace(/\s+/g, ' ').slice(0, 120));
console.log('');
let bad = 0, n = 0;
for (const t of T.templates) {
  console.log('════ 模板' + t.id + ' ════');
  for (const [city, star] of SAMPLES) {
    const raw = String(t.titlePattern).split('{明星}').join(star).split('{城市}').join(city)
      .split('{活动类型}').join(EVENT).split('{场次类型}').join(SESSION);
    const a = fitTitlePublished(raw), b = fitTitleOne(raw);
    n++;
    const same = a === b;
    if (!same) bad++;
    console.log('  [' + city + star + '] ' + (same ? '✅' : '❌ 不一致') + '  ' + a.length + '字');
    console.log('      ' + a + (same ? '' : '\n      publish-one: ' + b));
  }
}
console.log('\n════ 结论 ════');
console.log(bad === 0 ? '  ✅ ' + n + ' 组全部一致，两份 fitTitle 已同步' : '  ❌ ' + bad + '/' + n + ' 组不一致');
process.exit(bad === 0 ? 0 : 1);
