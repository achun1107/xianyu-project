// stuck-plan.js —— 浏览器侧：找出「部分商品因状态异常」(statusDescCode=16) 的暂停计划，并尝试恢复
(async () => {
  const m = window.lib.mtop;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const search = async () => {
    const r = await m.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
    return (r.data || {}).result || [];
  };
  const before = await search();
  // 【2026-10-08 修·真实事故】必须尊重排除名单，否则它会【撤销老板要停的计划】。
  //   老板说停某计划 → 我手动 pauseStatus=1；但只要那条计划带 statusDescCode=16
  //   （部分商品因状态异常无法擦亮），本脚本就会把它当成"卡住"再恢复一次 ——
  //   手动暂停被无声撤销。实测：泉州徐良 98104495 停了之后被它开回来，
  //   与 ad-window.js 的排除名单形成两个反向机制。
  //   名单由 ad-watch-stuck.ps1 从 AD-EXCLUDE.json 读出后注入 window.__AD_EXCLUDE，
  //   与 ad-window.js 共用同一个文件（单一事实来源）。
  const EXCLUDE = new Set((window.__AD_EXCLUDE || []).map(String));
  const allStuck = before.filter(c => String(c.statusDescCode) === '16' && String(c.pauseStatus) === '1');
  const skippedByExclude = allStuck.filter(c => EXCLUDE.has(String(c.campaignId)));
  const stuck = allStuck.filter(c => !EXCLUDE.has(String(c.campaignId)));
  const out = {
    ts: new Date().toLocaleString('zh-CN'),
    stuckCount: stuck.length,
    stuck: stuck.map(c => c.campaignId + ' ' + c.title).join(' | '),
    excludedCount: skippedByExclude.length,
    excluded: skippedByExclude.map(c => c.campaignId + ' ' + c.title).join(' | '),
    total: before.length,
    online: before.filter(c => c.statusGroup === 'online').length,
    paused: before.filter(c => String(c.pauseStatus) === '1').length,
  };
  if (stuck.length) {
    const ids = stuck.map(c => String(c.campaignId));
    await m.request({ api: 'mtop.taobao.idle.ad.campaign.pause', v: '1.0', type: 'POST',
      data: { requestJson: JSON.stringify({ campaignIds: ids, pauseStatus: 0 }) } });
    await sleep(9000);
    const after = await search();
    out.stillStuck = after.filter(c => ids.indexOf(String(c.campaignId)) >= 0 && String(c.pauseStatus) === '1').length;
    out.recoveredNow = after.filter(c => ids.indexOf(String(c.campaignId)) >= 0 && String(c.pauseStatus) !== '1').map(c => c.campaignId + ' ' + c.title).join(' | ');
  }
  return JSON.stringify(out);
})()
