// bal-probe.js —— 想办法把余额读出来
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const out = { 时刻: new Date().toLocaleString('zh-CN') };
  // 停在首页多等一会儿，再找任何 ¥ 数字
  location.href = 'https://seller.goofish.com/?site=COMMONPRO#/seller-ad/home';
  await sleep(22000);
  out.url = location.href;
  const t = (document.body.innerText || '').replace(/\s+/g, ' ');
  out.正文长度 = t.length;
  out.含可用余额 = t.indexOf('可用余额') >= 0;
  out.含余额 = t.indexOf('余额') >= 0;
  const m = t.match(/.{0,30}余额.{0,60}/g);
  out.余额附近 = m ? m.slice(0, 4) : null;
  const money = t.match(/¥\s*[\d,]+(\.\d+)?/g);
  out.页面里的金额 = money ? money.slice(0, 12) : null;
  out.正文前400 = t.slice(0, 400);
  // 也找一下有没有"充值"入口
  out.含充值 = t.indexOf('充值') >= 0;
  const r = t.match(/.{0,20}充值.{0,40}/g);
  out.充值附近 = r ? r.slice(0, 3) : null;
  return JSON.stringify(out, null, 1);
})()
