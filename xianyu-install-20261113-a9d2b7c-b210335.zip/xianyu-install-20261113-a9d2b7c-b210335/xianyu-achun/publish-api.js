/**
 * publish-api.js — 走 mtop API 发布（window.kunPublish.publishOne），而不是网页 UI
 *
 * 为什么：网页 UI ① 给不了库存（恒为 1）② contenteditable 会把描述换行吃掉。
 *        API 路径 quantity 直传、desc 原始 \n 直存，且与店铺现有 76 条同路径。
 *
 * 用法: node publish-api.js <城市> <明星> [--dry]
 */
const http = require('http');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const CITY = process.argv[2] || '杭州';
const STAR = process.argv[3] || '那英';
const DRY = process.argv.indexOf('--dry') >= 0;
const EVENT = '演唱会';
const SESSION = '首开';
const PRICE = '50';
const STOCK = '9999';
const IMG = process.argv[4] && !process.argv[4].startsWith('--') ? process.argv[4] : '';

function evalStore(store, code) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify({ store, code });
    const req = http.request({ host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 300))); } }); });
    req.on('error', reject);
    req.setTimeout(600000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}

const inner = `(async function(){
  var sleep = function(ms){ return new Promise(function(r){ setTimeout(r, ms); }); };
  var out = { href: location.href };
  if (!window.kunPublish) return Object.assign(out, { err: 'kunPublish 未注入（当前页不在 www.goofish.com？）' });
  if (typeof ADDRESS_DB === 'undefined') out.addrDb = '未定义';
  else out.addrDb = ADDRESS_DB.length + ' 条';
  window.kunPublish.setStore(${JSON.stringify(STORE)});
  await sleep(600);
  var t1 = window.kunPublish.renderConcertTitle(1, ${JSON.stringify(STAR)}, ${JSON.stringify(CITY)}, ${JSON.stringify(SESSION)}, ${JSON.stringify(EVENT)});
  var t2 = window.kunPublish.renderConcertTitle(2, ${JSON.stringify(STAR)}, ${JSON.stringify(CITY)}, ${JSON.stringify(SESSION)}, ${JSON.stringify(EVENT)});
  var desc = window.kunPublish.renderConcertDesc(1);
  out.模板1标题 = t1; out.模板1标题字数 = t1.length;
  out.模板2标题 = t2; out.模板2标题字数 = t2.length;
  out.正文 = desc; out.正文字数 = desc.length; out.正文行数 = desc.split('\\n').length;
  var full = t1 + '\\n\\n' + desc;
  out.fullDesc = full; out.fullDesc字数 = full.length;
  out.卡片标题 = full.slice(0, 30);
  out.卡片标题等于模板1标题 = (full.slice(0, 30) === t1);
  out.换行数 = (full.match(/\\n/g) || []).length;
  var cfg = {}; try { cfg = window.kunPublish.loadStoreConfig() || {}; } catch(e){}
  out.commitment = cfg.commitment || null;
  out.specs = cfg.specs ? '有' : '无';
  if (${DRY ? 'true' : 'false'}) return out;

  // 1) 上传主图到 CDN
  var imgPath = ${JSON.stringify(IMG)};
  if (!imgPath) return Object.assign(out, { err: '需要图片路径（第 4 个参数）' });
  var url = await window.kunPublish.uploadLocalImage(imgPath);
  out.上传结果 = url ? String(url).slice(0, 90) : '(空)';
  if (!url || String(url).startsWith('data:')) return Object.assign(out, { err: '图片上传失败' });

  // 2) 发布
  var r = await window.kunPublish.publishOne(
    t1, full, ${JSON.stringify(PRICE)}, [url], ${JSON.stringify(CITY)}, '',
    '代购', ${JSON.stringify(STOCK)}, 'nomail', cfg.commitment, ${JSON.stringify(PRICE)}
  );
  out.发布返回 = r;
  return out;
})()`;

(async () => {
  console.log('导航到 www.goofish.com（publish.js 只在这个域注入）...');
  await evalStore(STORE, 'location.href="https://www.goofish.com/"; "ok"');
  await new Promise(r => setTimeout(r, 9000));
  console.log('执行（dry=' + DRY + '）...\n');
  const res = await evalStore(STORE, inner);
  console.log(JSON.stringify(res, null, 2));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
