/**
 * probe-item-location.js — 导航到商品页并注入 _probe-item-location.js
 * 用法: node probe-item-location.js <itemId>
 */
const fs = require('fs');
const http = require('http');
const path = require('path');
const { SVC, STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const ID = process.argv[2] || '1086619474447';
const CODE = fs.readFileSync(path.join(__dirname, '_probe-item-location.js'), 'utf8');

function post(p, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 400))); } }); });
    req.on('error', reject);
    req.setTimeout(timeoutMs || 180000, () => req.destroy(new Error('请求超时')));
    req.write(payload); req.end();
  });
}

(async () => {
  const url = 'https://www.goofish.com/item?id=' + ID;
  console.log('商品: ' + url + '\n');
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href=' + JSON.stringify(url) + '; "navigating"' }, 90000);
  await new Promise(z => setTimeout(z, 12000));
  const res = await post('/api/agent/eval-on-store', { store: STORE, code: 'window.__VERIFY_ID=' + JSON.stringify(ID) + ';\n' + CODE }, 180000);
  if (!res.ok) { console.log('❌ ' + JSON.stringify(res).slice(0, 500)); process.exit(1); }
  console.log(JSON.stringify(res.result, null, 1));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
