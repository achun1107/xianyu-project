// check-login.js —— 查两个后台的登录态
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const out = { 时刻: new Date().toLocaleString('zh-CN') };
  const probe = async (label, url, waitMs) => {
    const r = { label, 目标: url };
    try {
      location.href = url;
      await sleep(waitMs);
      r.实际URL = location.href;
      r.标题 = document.title;
      r.在登录页 = /login|passport|havana/.test(location.href);
      r.有mtop = !!(window.lib && window.lib.mtop);
      r.正文前120 = (document.body.innerText || '').replace(/\s+/g, ' ').slice(0, 120);
      if (r.有mtop) {
        try {
          const rr = await window.lib.mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
            data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 5, campaignStatus: [], statusGroup: [] }) } });
          r.接口ret = (rr.ret || [])[0];
          r.计划数 = (((rr.data || {}).result) || []).length;
        } catch (e) { r.接口错误 = String((e && e.message) || e); }
      }
    } catch (e) { r.错误 = String((e && e.message) || e); }
    return r;
  };
  out.seller = await probe('seller.goofish.com', 'https://seller.goofish.com/?site=COMMONPRO#/seller-ad/home', 16000);
  out.dayu = await probe('dayu.goofish.com', 'https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage', 16000);
  return JSON.stringify(out, null, 1);
})()
