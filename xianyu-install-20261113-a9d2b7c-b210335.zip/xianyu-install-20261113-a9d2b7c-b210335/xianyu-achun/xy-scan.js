// xy-scan.js —— 逐个明星抓闲鱼搜索结果（综合排序第一页），输出想要数排名
// 用法: node xy-scan.js <起始下标> <结束下标>
// 为什么用 Node 而不是 PowerShell 拼命令：PowerShell 会把命令行里的中文关键字吃掉，
// 导致搜的是空关键词、返回一堆无关推荐（实测踩过）。
const http = require('http');
const fs = require('fs');
const { SVC, STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const STARS = ['华晨宇', '刘宪华', '王力宏', '周杰伦', '孙燕姿', '侯明昊', '许嵩', '刘宇',
  '徐良', '汪苏泷', 'Capper', '断眉', '张杰', '宋雨琦'];

function ev(code) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify({ store: STORE, code });
    const req = http.request({
      host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY },
    }, res => {
      let b = ''; res.on('data', c => b += c);
      res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: 'nonjson:' + b.slice(0, 200) }); } });
    });
    req.on('error', reject); req.write(payload); req.end();
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

const PARSE = fs.readFileSync(__dirname + '\\xy-scan-page.js', 'utf8');

(async () => {
  const from = Number(process.argv[2] || 0), to = Number(process.argv[3] || STARS.length);
  const all = [];
  for (let i = from; i < to; i++) {
    const star = STARS[i];
    const kw = star + '代拍';
    const nav = "(function(){location.href='https://www.goofish.com/search?q='+encodeURIComponent(" + JSON.stringify(kw) + ");return 'nav'})()";
    let r = await ev(nav);
    if (!r.ok) { console.log(`${star}: 跳转失败 ${r.error}`); continue; }
    await sleep(15000);
    r = await ev(PARSE);
    if (!r.ok) { console.log(`${star}: 解析失败 ${r.error}`); continue; }
    let j; try { j = typeof r.result === 'string' ? JSON.parse(r.result) : r.result; } catch (e) { console.log(`${star}: JSON 解析失败`); continue; }
    const items = (j.代拍条目 || []).filter(x => x.想要 !== null);
    const 分布 = j.判定分布 || {};
    all.push({ 明星: star, 关键词: j.关键词, 本页总数: j.本页总数, 判定分布: 分布, 代拍条数: j.代拍条数, top: (j.代拍条目 || []).slice(0, 12) });
    const drop = (j.本页总数 || 0) - (j.代拍条数 || 0);
    console.log(`\n===== ${star}（${kw}）本页 ${j.本页总数} 条 → 代拍 ${j.代拍条数} 条，丢弃 ${drop} 条 ${JSON.stringify(分布)} =====`);
    items.slice(0, 6).forEach(x => console.log(`  ${String(x.想要).padStart(6)}人想要  ¥${String(x.价格).padEnd(6)} ${x.标题.slice(0, 40)}`));
  }
  const out = `D:\\DSH\\achun\\xy-scan-result-${from}-${to}.json`;
  fs.writeFileSync(out, JSON.stringify(all, null, 2), 'utf8');
  console.log('\n已写 ' + out);
})().catch(e => { console.error('FAIL: ' + e.message); process.exit(1); });
