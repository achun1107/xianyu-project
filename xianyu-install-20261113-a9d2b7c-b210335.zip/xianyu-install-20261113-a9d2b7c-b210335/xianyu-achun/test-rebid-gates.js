/**
 * test-rebid-gates.js — 验证 ad-rebid.js 的两道提价闸真的会拦
 * 安全设计：submit:false（无论如何都不保存）+ 刻意收紧阈值，只验拦截路径。
 */
const http = require('http');
const fs = require('fs');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const URL = 'https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage';

// 用一条当前出价低、提升高的计划做靶子（改前先不保存，绝对安全）
const TARGET = { name: '单明星-周杰伦-咨询120', id: '95259165' };

function ev(code) {
  return new Promise((resolve) => {
    const payload = JSON.stringify({ store: STORE, code });
    const req = http.request({ host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      res => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: b.slice(0, 200) }); } }); });
    req.on('error', e => resolve({ ok: false, error: e.message })); req.write(payload); req.end();
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

const CASES = [
  { label: '闸2 幅度上限（maxRaisePct=0 → 任何提价都该拦）', cfg: { targetImprove: 151, maxRaisePct: 0 } },
  { label: '闸1 历史成本（maxCostPerChat=0.1 → 现有成本必超）', cfg: { targetImprove: 151, maxRaisePct: 999, maxCostPerChat: 0.1, minHistoryCost: 0 } },
  { label: '两闸都放宽 → 应能走到"未保存(dry)"而不是被拦', cfg: { targetImprove: 151, maxRaisePct: 999, maxCostPerChat: 999 } },
];

(async () => {
  const REBID = fs.readFileSync(__dirname + '/ad-rebid.js', 'utf8');
  for (const c of CASES) {
    console.log('\n════ ' + c.label + ' ════');
    let r = await ev(`(function(){location.href=${JSON.stringify(URL)};return 'nav'})()`);
    if (!r.ok) { console.log('  跳转失败 ' + r.error); continue; }
    await sleep(16000);
    const cfg = JSON.stringify(Object.assign({ planName: TARGET.name, planId: TARGET.id, submit: false }, c.cfg));
    r = await ev(`window.__RCFG=${cfg}; 'set'`);
    if (!r.ok) { console.log('  cfg 失败 ' + r.error); continue; }
    r = await ev(REBID);
    if (!r.ok) { console.log('  rebid 失败 ' + r.error); continue; }
    let j; try { j = typeof r.result === 'string' ? JSON.parse(r.result) : r.result; } catch (e) { console.log('  解析失败 ' + String(r.result).slice(0, 300)); continue; }
    console.log('  改前出价¥' + j.beforeBid + '  提升' + j.beforeImprove + '%');
    console.log('  反解出价¥' + j.finalBid + '  提升' + j.finalImprove + '%');
    console.log('  提价幅度: ' + j.提价幅度 + '  (上限 ' + j.幅度上限 + ')');
    console.log('  历史成本: ' + JSON.stringify(j.历史成本));
    if (j.历史成本警告) console.log('  警告: ' + j.历史成本警告);
    console.log('  ⇒ ' + (j.fatal ? '🛑 被拦: ' + j.fatal : (j.aborted ? '⏹ ' + j.aborted : '（未被拦，saved=' + j.saved + '）')));
  }
})().catch(e => { console.error('FAIL ' + e.message); process.exit(1); });
