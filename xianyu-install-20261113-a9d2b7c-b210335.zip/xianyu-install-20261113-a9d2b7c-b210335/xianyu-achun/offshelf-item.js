/**
 * offshelf-item.js — 只走【下架 off.shelf】（可逆），不碰永久删除
 * 用法: node offshelf-item.js <itemId> [...]
 *
 * 为什么要单独写：delete-item.js 是先试 delete（永久、不可恢复）再试 off.shelf。
 * 用户说的是「下架」，所以我优先走可逆路径；off.shelf 走不通再谈别的，不擅自删。
 */
const http = require('http');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const IDS = process.argv.slice(2).filter(a => /^\d+$/.test(a));
if (!IDS.length) { console.log('用法: node offshelf-item.js <itemId> [...]'); process.exit(2); }

function post(p, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 300))); } }); });
    req.on('error', reject); req.setTimeout(timeoutMs || 180000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}

const inner = `(async function(){
  var out = { results: [] };
  if (!window.lib || !window.lib.mtop) return { err: 'no lib.mtop' };
  var ids = ${JSON.stringify(IDS)};
  // 只试下架 + 几个可能的变体接口，全部只读不改语义
  var apis = [
    'mtop.idle.pc.idleitem.off.shelf',
    'mtop.idle.pc.idleitem.offshelf',
    'mtop.idle.pc.idleitem.shelf.off',
    'mtop.taobao.idle.item.off.shelf'
  ];
  for (var i = 0; i < ids.length; i++) {
    var rec = { itemId: ids[i], tries: [] };
    for (var j = 0; j < apis.length; j++) {
      for (var t = 0; t < 2; t++) {
        var tp = t === 0 ? 'POST' : 'GET';
        try {
          var r = await window.lib.mtop.request({ api: apis[j], v: '1.0', data: { itemId: String(ids[i]) }, type: tp });
          var ret = r && r.ret ? r.ret[0] : JSON.stringify(r && r.data).slice(0, 80);
          rec.tries.push({ api: apis[j], type: tp, ret: ret });
          if (ret && String(ret).indexOf('SUCCESS') === 0) { rec.done = apis[j] + '/' + tp; break; }
        } catch (e) {
          rec.tries.push({ api: apis[j], type: tp, err: (e && (e.ret ? e.ret[0] : e.message)) || String(e) });
        }
      }
      if (rec.done) break;
    }
    out.results.push(rec);
  }
  return out;
})()`;

(async () => {
  console.log('目标: ' + IDS.join(', ') + '（只走可逆下架）');
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/"; "ok"' }, 60000);
  await new Promise(z => setTimeout(z, 8000));
  const res = await post('/api/agent/eval-on-store', { store: STORE, code: inner }, 300000);
  console.log(JSON.stringify(res, null, 2));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
