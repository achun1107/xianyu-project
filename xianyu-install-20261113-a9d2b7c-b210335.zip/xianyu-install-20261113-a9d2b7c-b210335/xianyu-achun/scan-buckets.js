// scan-buckets.js —— 只读：清掉粘住的 ID 筛选，然后 5 档状态各扫一遍找 97682524
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { if (!e) return false; const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 10 && r.height > 10 && s.display !== 'none' && s.visibility !== 'hidden'; };
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => { const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent; el.dispatchEvent(new E(t, o)); });
    return true;
  }
  const setNative = (el, v) => { const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value'); d.set.call(el, String(v)); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  const out = {};
  const tab = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn')).find(e => /^计划\(/.test((e.innerText || '').trim()));
  if (tab) { click1(tab); await sleep(4000); }

  // ① 清掉粘住的 ID 筛选
  let box = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
  out.ID框原值 = box ? box.value : null;
  if (box) {
    setNative(box, ''); await sleep(800);
    box.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
    await sleep(4500);
  }
  const planIds = () => [].slice.call(document.querySelectorAll('tbody tr')).map(r => {
    const m = (r.innerText || '').match(/\t(\d{8})\t\s*([^\t\n]+)/);
    return m ? m[1] + ' ' + m[2].trim() : null;
  }).filter(Boolean);
  out.清空后计划 = planIds();

  for (const label of ['擦亮中', '已暂停', '商品异常暂停', '余额不足暂停', '擦亮完成']) {
    const s = [].slice.call(document.querySelectorAll('.ant-select')).filter(e => vis(e) && /擦亮状态|已暂停|商品异常暂停|擦亮中|擦亮完成|余额不足暂停|全部/.test((e.innerText || '').trim()))[0];
    if (!s) { out[label] = 'no-filter'; continue; }
    const c = s.querySelector('.ant-select-selector') || s;
    c.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); await sleep(300); click1(c); await sleep(1600);
    const dd = [].slice.call(document.querySelectorAll('.ant-select-dropdown')).filter(vis).pop();
    const o = dd && [].slice.call(dd.querySelectorAll('.ant-select-item-option')).find(e => (e.innerText || '').trim() === label);
    if (!o) { document.body.click(); await sleep(500); out[label] = 'no-option'; continue; }
    click1(o); await sleep(5000);
    out[label] = planIds();
  }
  out.含97682524的档 = Object.keys(out).filter(k => Array.isArray(out[k]) && out[k].some(s => s.indexOf('97682524') >= 0));
  return JSON.stringify(out, null, 1);
})()
