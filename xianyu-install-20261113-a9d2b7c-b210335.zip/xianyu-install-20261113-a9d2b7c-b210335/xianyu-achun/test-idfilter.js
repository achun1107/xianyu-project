// test-idfilter.js —— 测「请输入计划ID」框能不能筛表
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function setNative(el, val) {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    d.set.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const out = {};
  const inp = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
  out.找到输入框 = !!inp;
  if (!inp) return JSON.stringify(out, null, 1);

  const rowsNow = () => [].slice.call(document.querySelectorAll('tbody tr')).map(r => (r.innerText || '').replace(/\s+/g, ' ').slice(0, 50));
  out.筛选前 = rowsNow().length;

  setNative(inp, '96129660');
  await sleep(600);
  inp.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
  inp.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
  await sleep(4000);
  const r1 = rowsNow();
  out.回车后 = r1.length;
  out.回车后内容 = r1.slice(0, 4);

  // 再试「不按回车，直接失焦」
  if (r1.filter(t => /孙燕姿广州-订单120/.test(t)).length === 0) {
    inp.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
    inp.dispatchEvent(new Event('blur', { bubbles: true }));
    await sleep(3000);
    const r2 = rowsNow();
    out.失焦后 = r2.length;
    out.失焦后内容 = r2.slice(0, 4);
  }
  out.正文含目标 = (document.body.innerText || '').indexOf('孙燕姿广州-订单120') >= 0;
  return JSON.stringify(out, null, 1);
})()
