/**
 * push-redtext.js — 把「白底红字版」推送到中台版式库
 *
 * 用户需求：底图走【底图来源】逻辑，用户只填城市+明星就出图 → 做成中台版式。
 *
 * 三个关键决定（都有依据，不是拍脑袋）：
 *  1. 封面用【带字成品图】。依据：中台已有的「三黄块+一紫块版式」封面就是
 *     徐良官方海报 + 黄紫块烧字，即"成品图当封面"是这家租户的既定约定。
 *  2. 封面底图走 /api/poster/make（大麦官方海报 → 其他城市 → 猫眼/微博 → AI兜底），
 *     也就是用户说的"底图有底图来源"。本次 baseOrigin=damai。
 *  3. prompt 里必须含 {城市}/{明星}（中台硬校验），并把"来源"写成自然语言
 *     —— 因为中台版式只有 8 个字段，放不下可执行的抓取逻辑。
 *
 * ⚠️ 中台 `poster-templates` 只有 add，没有 delete。推之前必须查同名。
 *
 * 用法：node push-redtext.js          # 真推
 *       node push-redtext.js --check  # 只检查，不推
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { ROOT, MIDDLE, NODE: ENV_NODE } = require('./lib/env');

const NODE = ENV_NODE.path;
const CLI  = ENV_NODE.museavCli;
const KEY  = MIDDLE.key;

const SRC_COVER = path.join(ROOT, '主图筛选-那英杭州/01-tpl_redtext-白底红字版.png');
const DIR       = path.join(ROOT, '中台版式');
const COVER     = path.join(DIR, 'tpl_redtext-封面.png');

const NAME = '白底红字版';
// 照抄「三黄块+一紫块版式」的 prompt 结构：先写来源，再逐项写前景层
const PROMPT =
  '竖版{城市}{明星}演唱会代拍宣传海报，背景为{明星}{城市}演唱会官方海报（大麦官方主视觉，或用户提供的底图），' +
  '保持垫图人物形象与构图不变；前景由系统居中叠加五行文字，全部为红色粗体、白色描边：' +
  '顶部大字写{城市}{明星}，其下写超高命中率100，中部写万人团队 战绩可查，' +
  '中下部写7级店铺➕⬆千好评（左端带一枚蓝色数字7徽章），底部写评价可查。' +
  '现代电商营销海报风格，3:4竖版，高清平面印刷质感，文字清晰锐利';

const CHECK_ONLY = process.argv.includes('--check');

const api = async () => {
  const r = await fetch('https://manager.museav.top/api/poster-templates', { headers: { 'X-API-Key': KEY } });
  const j = await r.json();
  return Array.isArray(j) ? j : (j.items || j.data || []);
};

(async () => {
  // ── 0. 封面就位 ──
  if (!fs.existsSync(SRC_COVER)) { console.log('❌ 找不到封面: ' + SRC_COVER); process.exit(1); }
  fs.mkdirSync(DIR, { recursive: true });
  fs.copyFileSync(SRC_COVER, COVER);

  console.log('封面: ' + COVER + '   ' + Math.round(fs.statSync(COVER).size / 1024) + ' KB');
  console.log('名称: ' + NAME);
  console.log('描述: ' + PROMPT);
  console.log('');

  // ── 1. 同名检查（推了删不掉，这一步是命门）──
  const before = await api();
  console.log('中台现有 ' + before.length + ' 个版式: ' + before.map(t => t.name).join('、'));
  const dup = before.filter(t => String(t.name || '').trim() === NAME);
  if (dup.length) {
    console.log('\n❌ 中台已存在同名版式「' + NAME + '」id=' + dup.map(d => d.id).join(',') + '，中止（会变成重复项）');
    process.exit(1);
  }
  if (PROMPT.indexOf('{城市}') < 0 && PROMPT.indexOf('{明星}') < 0) {
    console.log('\n❌ 描述里没有 {城市}/{明星} 占位符，中台会拒'); process.exit(1);
  }
  console.log('✅ 同名检查通过，占位符检查通过');

  if (CHECK_ONLY) { console.log('\n[--check] 未推送'); return; }

  // ── 2. 推送：数组参数直调 node，不经过 shell ──
  console.log('\n推送中...');
  let out = '';
  try {
    out = execFileSync(NODE, [CLI, 'poster-templates', 'add', COVER, '--name', NAME, '--prompt', PROMPT],
      { encoding: 'utf8', timeout: 180000, maxBuffer: 4 * 1024 * 1024 });
  } catch (e) {
    console.log('❌ 推送失败:');
    console.log(String(e.stdout || '') + '\n' + String(e.stderr || '') + '\n' + e.message);
    process.exit(1);
  }
  console.log(out.trim());
  const m = out.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
  if (m) console.log('\n新版式 id = ' + m[0]);

  // ── 3. 复核 ──
  await new Promise(r => setTimeout(r, 2000));
  const after = await api();
  console.log('\n复核：中台现有 ' + after.length + ' 个版式');
  after.forEach(t => console.log('  · ' + String(t.name).padEnd(20) + ' ' + t.id));
  const hit = after.filter(t => String(t.name).trim() === NAME);
  console.log(hit.length ? '\n🎉 推送成功，「' + NAME + '」已在中台（id=' + hit[0].id + '）' : '\n❌ 没查到新条目，推送可能没生效');
})().catch(e => { console.log('❌ ' + (e && e.stack || e)); process.exit(1); });
