/**
 * make-covers.js — 批量出主图（复用发布台 publish_dashboard.js 的 _iwApplyText 渲染逻辑）
 *
 * 用法: node make-covers.js <城市> <明星> [source] [templateId1,templateId2,...]
 *   例: node make-covers.js 杭州 那英
 *       node make-covers.js 杭州 那英 damai_official xuliang-v1,tpl_redtext
 *
 * 输出: D:\DSH\achun\主图筛选-<明星><城市>\NN-<id>-<name>.png
 *       + _report.json（baseOrigin / 尺寸 / 是否叠了文字层）
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const { SVC: SVC_ENV, PATHS, ROOT } = require('./lib/env');

const SVC = PATHS.playwrightService;
const KEY = SVC_ENV.apiKey;
const CITY = process.argv[2] || '杭州';
const STAR = process.argv[3] || '那英';
const SOURCE = process.argv[4] || 'damai_official';
const ONLY = process.argv[5] ? process.argv[5].split(',').map(s => s.trim()).filter(Boolean) : null;
const OUTDIR = path.join(ROOT, '主图筛选-' + STAR + CITY);

function api(p, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({
      host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY },
    }, (res) => {
      let buf = '';
      res.on('data', c => buf += c);
      res.on('end', () => { try { resolve(JSON.parse(buf)); } catch (e) { reject(new Error('HTTP ' + res.statusCode + ' 非 JSON: ' + buf.slice(0, 200))); } });
    });
    req.on('error', reject);
    req.write(payload); req.end();
  });
}
function apiGet(p) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port: 8093, path: p, headers: { 'x-api-key': KEY } }, (res) => {
      let buf = ''; res.on('data', c => buf += c);
      res.on('end', () => { try { resolve(JSON.parse(buf)); } catch (e) { reject(new Error('非 JSON')); } });
    }).on('error', reject);
  });
}

// ── 从 publish_dashboard.js 抽出 _normLayer / _iwApplyText 源码（保证与线上渲染一致）──
function extractFn(src, header) {
  const i = src.indexOf(header);
  if (i < 0) throw new Error('找不到函数: ' + header);
  let j = src.indexOf('{', i), depth = 0, k = j;
  for (; k < src.length; k++) {
    const ch = src[k];
    if (ch === '{') depth++;
    else if (ch === '}') { depth--; if (depth === 0) break; }
  }
  return src.slice(i, k + 1);
}
const dash = fs.readFileSync(path.join(PATHS.xianyuMonitor, 'publish_dashboard.js'), 'utf8');
const SRC_NORM = extractFn(dash, 'function _normLayer(l)');
const SRC_APPLY = extractFn(dash, 'function _iwApplyText(callback, overrides, srcUrl, layersOverride)');

(async () => {
  fs.mkdirSync(OUTDIR, { recursive: true });

  const t = await apiGet('/api/poster/templates');
  let tpls = t.items || [];
  if (ONLY) tpls = ONLY.map(id => tpls.find(x => x.id === id)).filter(Boolean);

  // 排序：能换 {城市}{明星} 的排前面
  const plh = x => (x.layers || []).some(l => /\{城市\}|\{明星\}/.test(String(l.text || ''))) || x.id === 'xuliang-v1' || x.id === 'shoukai-v1';
  tpls.sort((a, b) => (plh(b) ? 1 : 0) - (plh(a) ? 1 : 0));

  const { chromium } = require(SVC + '/node_modules/playwright');
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.setContent('<!doctype html><html><head><meta charset="utf-8"></head><body></body></html>');
  await page.addScriptTag({ content:
    'window._iw = { layers: [], stickerImgs: [], sourceUrl: "" };\n' +
    'function addLog(){};\n' +
    SRC_NORM + '\n' + SRC_APPLY + '\n' +
    'window.__render = function(b64, layers, ov) {\n' +
    '  return new Promise(function(res){ _iwApplyText(function(d){ res(d); }, ov, "data:image/jpeg;base64," + b64, layers); });\n' +
    '};'
  });

  const report = [];
  let n = 0;
  for (const tpl of tpls) {
    n++;
    const layers = tpl.layers || [];
    const tag = String(n).padStart(2, '0') + '-' + tpl.id + '-' + String(tpl.name).replace(/[\\/:*?"<>|（）()·+]/g, '').slice(0, 22);
    process.stdout.write('[' + n + '/' + tpls.length + '] ' + tpl.id + ' ... ');
    let r;
    try {
      r = await api('/api/poster/make', { city: CITY, star: STAR, source: SOURCE, ratio: '3:4', templateId: tpl.id });
    } catch (e) { console.log('调用失败 ' + e.message); report.push({ id: tpl.id, ok: false, err: e.message }); continue; }
    if (!r.ok || !r.imageB64) { console.log('出图失败 ' + (r.error || '')); report.push({ id: tpl.id, ok: false, err: r.error }); continue; }

    let finalB64 = r.imageB64, mode = 'raw', ext = 'jpg';
    if (layers.length) {
      const dataUrl = await page.evaluate(({ b64, layers, city, star }) =>
        window.__render(b64, layers, { city: city, star: star }), { b64: r.imageB64, layers, city: CITY, star: STAR });
      if (dataUrl) { finalB64 = dataUrl.replace(/^data:image\/[a-z]+;base64,/, ''); mode = 'layers×' + layers.length; ext = 'png'; }
    }
    const file = path.join(OUTDIR, tag + '.' + ext);
    fs.writeFileSync(file, Buffer.from(finalB64, 'base64'));
    const kb = Math.round(fs.statSync(file).size / 1024);
    console.log('OK  ' + kb + 'KB  base=' + (r.baseOrigin || 'search') + '  ' + mode);
    report.push({ file: path.basename(file), id: tpl.id, name: tpl.name, ok: true,
      baseOrigin: r.baseOrigin || '', layers: layers.length, appliedLayers: layers.length ? mode : '', kb });
  }

  fs.writeFileSync(path.join(OUTDIR, '_report.json'), JSON.stringify(report, null, 2), 'utf8');
  await browser.close();
  console.log('\n输出目录: ' + OUTDIR);
})();
