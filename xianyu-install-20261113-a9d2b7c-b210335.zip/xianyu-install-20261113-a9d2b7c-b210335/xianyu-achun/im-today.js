// im-today.js —— 只读：把闲鱼 web IM 里【今天】的会话逐个点开，读聊天内容，按关键词归类
//
// 为什么这么做（2026-10-10 实测结论）：
//   闲鱼 web IM **不挂商品卡** —— 整页查不到任何商品图（-0-fleamarket / -0-xy_item / bao/uploaded）、
//   没有 13 位 itemId、没有【】式商品标题。所以从 IM 认不出「这条会话是关于哪条链接的」。
//   买家问什么只写在消息文本里（如「单依纯无锡可以吗」「福州+谢霆锋+11.28+1380/1680」）。
//   → IM 只能做到【按活动/明星】，做不到【按链接】。要按链接只能用广告后台的宝贝信息子行。
//
// 设计：只点开【时间标签是今天】的会话（刚刚 / N分钟前 / N小时前），避免为历史会话白跑。
//   关键词从 CFG 传进来（KEYWORDS 数组），命中就算一条；一条会话可命中多个。
//
// 由 run-driver.js 驱动：
//   DRIVER=im-today.js URL="https://www.goofish.com/im" CFG_JSON=im-keywords.json node run-driver.js
(async () => {
  const cfg = window.__RUNDRV_CFG || {};
  const KEYS = cfg.KEYWORDS || [];
  const MAX_OPEN = Number(cfg.MAX_OPEN || 40);
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();
  const click1 = (el) => {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  };

  for (let i = 0; i < 20; i++) {
    if (document.querySelectorAll('[class*=conversation-item]').length) break;
    await sleep(800);
  }

  const rowsOf = () => [].slice.call(document.querySelectorAll('[class*=conversation-item]'));
  // 列表可能一开始只渲染一部分：滚左栏把更多会话滚出来
  const listBox = (() => {
    let box = null;
    [].slice.call(document.querySelectorAll('div')).forEach(e => {
      const r = e.getBoundingClientRect();
      if (r.left < window.innerWidth * 0.4 && r.height > 300 && e.scrollHeight > e.clientHeight + 20) {
        if (!box || e.scrollHeight > box.scrollHeight) box = e;
      }
    });
    return box;
  })();
  for (let k = 0; k < 12 && listBox; k++) {
    const before = listBox.scrollTop;
    listBox.scrollTop = before + Math.max(200, Math.floor(listBox.clientHeight * 0.9));
    await sleep(500);
    if (listBox.scrollTop === before) break;
  }
  if (listBox) listBox.scrollTop = 0;
  await sleep(600);

  const TIME_RE = /(刚刚|\d+\s*分钟前|\d+\s*小时前|昨天|\d+\s*天前|\d{1,2}:\d{2})/;
  const isToday = (t) => /刚刚|分钟前|小时前/.test(t);
  const rows = rowsOf().map(el => {
    const t = norm(el.innerText).replace(/\n/g, ' ');
    const m = t.match(TIME_RE);
    return { el, 文本: t, 时间: m ? m[1] : '', 昵称: t.split(' ')[0] };
  });
  const today = rows.filter(r => isToday(r.时间));

  const 右栏文本 = () => {
    const cands = [].slice.call(document.querySelectorAll('div')).filter(e => {
      const r = e.getBoundingClientRect();
      return r.left > window.innerWidth * 0.35 && r.width > 200 && r.height > 200;
    });
    if (!cands.length) return '';
    cands.sort((a, b) => (b.getBoundingClientRect().width * b.getBoundingClientRect().height)
      - (a.getBoundingClientRect().width * a.getBoundingClientRect().height));
    return norm(cands[0].innerText);
  };

  const tally = {};
  const 会话 = [];
  for (const r of today.slice(0, MAX_OPEN)) {
    click1(r.el);
    await sleep(1500);
    const text = 右栏文本();
    const hit = KEYS.filter(k => text.indexOf(k.kw) >= 0).map(k => k.kw);
    hit.forEach(k => { tally[k] = (tally[k] || 0) + 1; });
    会话.push({ 昵称: r.昵称.slice(0, 18), 时间: r.时间, 命中: hit, 文本: text.slice(0, 200) });
  }

  return JSON.stringify({
    时刻: new Date().toLocaleString('zh-CN'),
    列表行数: rows.length,
    今天会话数: today.length,
    实际点开: 会话.length,
    关键词命中统计: tally,
    认不出商品关键词的会话: 会话.filter(s => !s.命中.length).length,
    会话,
  }, null, 1);
})()
