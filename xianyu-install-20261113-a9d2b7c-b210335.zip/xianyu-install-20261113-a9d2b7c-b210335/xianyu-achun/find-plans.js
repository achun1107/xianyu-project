/**
 * find-plans.js — 列出匹配关键词的计划（默认只列，不动）
 * 用法: node find-plans.js <关键词1> [关键词2] ...
 */
const http = require('http'), fs = require('fs');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const KW = process.argv.slice(2);
if (!KW.length) { console.log('用法: node find-plans.js <关键词...>'); process.exit(2); }

function ev(code) {
  return new Promise(r => {
    const p = JSON.stringify({ store: STORE, code });
    const q = http.request({ host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(p), 'x-api-key': KEY } },
      res => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { r(JSON.parse(b)); } catch (e) { r({ ok: false, error: b.slice(0, 300) }); } }); });
    q.on('error', e => r({ ok: false, error: e.message })); q.write(p); q.end();
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await ev(`(function(){location.href='https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage';return 'n'})()`);
  await sleep(16000);
  const r = await ev(fs.readFileSync(__dirname + '\\ad-today-perplan.js', 'utf8'));
  if (!r.ok) { console.log('ERR ' + r.error); process.exit(1); }
  const d = typeof r.result === 'string' ? JSON.parse(r.result) : r.result;
  if (d.err) { console.log('API ERR ' + JSON.stringify(d.err)); process.exit(1); }
  fs.writeFileSync('D:\\DSH\\achun\\plans-all-now.json', JSON.stringify(d, null, 1), 'utf8');
  console.log('快照 ' + d.时刻 + '，共 ' + d.计划数 + ' 个计划\n');

  const re = new RegExp(KW.join('|'));
  const hit = d.计划.filter(p => re.test(p.name));
  const cat = {};
  d.计划.forEach(p => { cat[p.类别] = (cat[p.类别] || 0) + 1; });
  console.log('全店计划分类: ' + JSON.stringify(cat));
  console.log('\n══════ 匹配「' + KW.join(' / ') + '」的 ' + hit.length + ' 个 ══════');
  hit.forEach(p => console.log(
    (p.paused ? '⏸' : '▶') + ' ' + String(p.id).padEnd(9) + '【' + p.类别 + '】' + p.name.padEnd(30) +
    ' 出价¥' + String(p.cpm).padEnd(6) + ' 预算¥' + String(p.budget).padEnd(5) + ' ' + String(p.target).padEnd(6) +
    ' ' + p.商品数 + '件  商品:' + p.商品 + '  今日¥' + p.成本 + ' 曝光' + p.曝光));
  console.log('\n══════ 所有【主/副集合】类计划（这些一律不动）══════');
  d.计划.filter(p => p.类别 === '主/副集合').forEach(p => console.log('  ' + String(p.id).padEnd(9) + p.name.padEnd(30) + ' ' + p.商品数 + '件 今日¥' + p.成本));
})();
