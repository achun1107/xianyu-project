// 离线验证守卫正则：用真实的 WorkBuddy 删除代码样本
var DELETE_GUARD = /idle\.ad\.campaign\.(delete|cancel)/i;
var cases = [
  ["WorkBuddy 脚本A", "var dr = await req('mtop.taobao.idle.ad.campaign.delete', { campaignId: dead[d].id }, 'POST');"],
  ["WorkBuddy 脚本B", "await req('mtop.taobao.idle.ad.campaign.delete', { campaignId: dead[d].id }, 'POST');"],
  ["monitor.js 直调", "await mtopR('mtop.taobao.idle.ad.campaign.delete', { campaignId: cid }, 'POST');"],
  ["空格变体", "request({ api: 'mtop.taobao.idle.ad.campaign.delete' })"],
  ["pause（应放行）", "await req('mtop.taobao.idle.ad.campaign.pause', { campaignIds: [1], pauseStatus: 1 }, 'POST');"],
  ["search（应放行）", "await req('mtop.taobao.idle.ad.campaign.search', { pageNum: 1 }, 'GET');"],
  ["edit（应放行）", "await req('mtop.taobao.idle.ad.campaign.edit', {}, 'POST');"],
  ["普通读操作", "return document.title;"],
  ["上传图片", "window.kunPublish.uploadLocalImage('x.jpg');"]
];
var blocked = 0, passed = 0;
cases.forEach(function(c){
  var hit = DELETE_GUARD.test(c[1]);
  if(hit) blocked++; else passed++;
  console.log((hit ? "🚫 拦截 " : "✅ 放行 ") + c[0] + (hit ? "   <<< 命中删除守卫" : ""));
});
console.log("\n拦截 " + blocked + " 个，放行 " + passed + " 个");
