/**
 * probe-artist-items.js — 拉 侯明昊 / 孙燕姿 的商品清单 + 全部可用字段
 * 接口：mtop.taobao.idle.ad.item.searchV2（按关键词搜擦亮商品）
 */
(async () => {
  const mtop = window.lib.mtop;
  const out = { 时刻: new Date().toLocaleString('zh-CN'), 结果: {} };
  const ARTS = ['侯明昊', '孙燕姿'];

  for (const a of ARTS) {
    try {
      const r = await mtop.request({
        api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
        data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 50, tab: 'platReco', needTabs: false, searchKey: a }) },
      });
      const list = ((r.data || {}).result || {}).itemList || [];
      out.结果[a] = {
        条数: list.length,
        首条全字段名: list[0] ? Object.keys(list[0]) : [],
        首条原始: list[0] ? JSON.stringify(list[0]).slice(0, 900) : null,
        明细: list.map(x => ({
          itemId: String(x.itemId),
          标题: String(x.title || '').split('\n')[0].slice(0, 56),
          成交: x.saleCnt,
          标签: (x.tags || []).join('/'),
          发布时间: x.publishTime ? new Date(Number(x.publishTime)).toLocaleDateString('zh-CN') : null,
          其余字段: Object.keys(x).filter(k => ['itemId', 'title', 'saleCnt', 'tags', 'publishTime', 'catId'].indexOf(k) < 0)
            .reduce((o, k) => { o[k] = x[k]; return o; }, {}),
        })),
      };
    } catch (e) { out.结果[a] = { err: (e && (e.ret || e.message)) || String(e) }; }
  }
  return JSON.stringify(out, null, 1);
})()
