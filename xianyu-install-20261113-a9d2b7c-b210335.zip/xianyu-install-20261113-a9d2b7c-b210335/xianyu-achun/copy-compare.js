/**
 * copy-compare.js — 把「现在线上在用的文案模板」与「我定稿的生成器」对同一标的渲染出来对比
 *
 * 数据源:
 *   A. ~/.xianyu-templates.json  ← publish.js 真实读取的模板（Native Host 落盘），线上实际在用的
 *   B. publish.js 里的 CONCERT_TEMPLATES 默认值（仅当 A 不存在时生效）
 *   C. gen-copy.js（我按 168 条同行数据定的）
 *
 * 用法: node copy-compare.js [城市] [明星] [活动类型] [场次类型]
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const os = require('os');

const CITY = process.argv[2] || '杭州';
const STAR = process.argv[3] || '那英';
const EV = process.argv[4] || '演唱会';
const SESSION = process.argv[5] || '一开';

// ── A. 线上真实模板（磁盘副本；格式 {key, templates}，按店铺独立） ──
const TPL_FILE = path.join(os.homedir(), '.xianyu-templates.json');
let live = [], liveKey = '';
if (fs.existsSync(TPL_FILE)) {
  const j = JSON.parse(fs.readFileSync(TPL_FILE, 'utf8'));
  live = Array.isArray(j) ? j : (j.templates || []);
  liveKey = Array.isArray(j) ? '(无 key，全局)' : (j.key || '');
}
console.log('模板文件: ' + TPL_FILE);
console.log('  店铺 key: ' + liveKey + '    改动时间: ' + (fs.existsSync(TPL_FILE) ? fs.statSync(TPL_FILE).mtime.toLocaleString() : '-'));
console.log('');

// ── C. 我的生成器 ──
const NODE = process.execPath;
function genCopy(len) {
  try {
    return execFileSync(NODE, [path.join(__dirname, 'gen-copy.js'), '--star', STAR, '--cities', CITY, '--type', EV, '--len', len],
      { encoding: 'utf8', maxBuffer: 1 << 20 });
  } catch (e) { return '(生成失败: ' + e.message + ')'; }
}

function render(tpl) {
  return String(tpl)
    .replace(/\{明星\}/g, STAR).replace(/\{城市\}/g, CITY)
    .replace(/\{场次类型\}/g, SESSION).replace(/\{活动类型\}/g, EV);
}

const rows = [];
live.forEach(t => rows.push({ src: '线上(' + TPL_FILE.replace(os.homedir(), '~') + ')', name: t.name, full: render(t.titlePattern), desc: t.descPattern, titleMode: t.titleMode || 'placeholder' }));

const line = n => '─'.repeat(n);
console.log('标的: ' + CITY + ' / ' + STAR + ' / ' + EV + ' / ' + SESSION);
console.log('='.repeat(78));

rows.forEach((r, i) => {
  const full = r.full;
  const cut = full.slice(0, 30);
  const over = full.length - 30;
  console.log('\n【' + (i + 1) + '】' + r.name + '  来源: ' + r.src + '   titleMode=' + r.titleMode);
  console.log('   模板: ' + (live[i] ? live[i].titlePattern : ''));
  console.log('   全文: ' + full);
  console.log('   长度: ' + full.length + ' 字' + (over > 0 ? '   ⚠ 超出 30 字硬窗 ' + over + ' 字' : '   ✅ 在 30 字内'));
  console.log('   标题(=前30字): ' + cut);
  if (over > 0) {
    console.log('   被截掉的: 「' + full.slice(30) + '」');
    const last = cut.slice(-1);
    const dangling = /[，,、的了和与及]/.test(last);
    console.log('   第30字收尾: 「' + cut.slice(-6) + '」' + (dangling ? '   ❌ 断在虚词/逗号上' : '   （收在实词上，但仍是半句）'));
  }
});

// ── C 三档 ──
['brief', 'mid', 'std'].forEach(len => {
  const out = genCopy(len);
  const firstLine = (out.split(/\r?\n/).find(l => l.indexOf('【') === 0) || '').trim();
  const title = firstLine.slice(0, 30);
  console.log('\n【我的生成器 --len ' + len + '】');
  console.log('   标题(=前30字): ' + title + '   (' + firstLine.length + ' 字)');
  const m = out.match(/前 ?30 ?字[^\n]*/);
  if (m) console.log('   ' + m[0].trim());
});
console.log('\n' + '='.repeat(78));
console.log('说明: 闲鱼「标题」不是独立字段，就是商品描述的最前 30 个字符（168/168 实测）。');
