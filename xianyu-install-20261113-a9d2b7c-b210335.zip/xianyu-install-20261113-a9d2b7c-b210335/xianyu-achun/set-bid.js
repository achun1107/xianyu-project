// set-bid.js —— 把指定计划的「自定义出价」改成【指定数值】（可降可升）
//
// 为什么不用 ad-rebid.js：那个脚本是"反解出价以达成目标预计提升%"，逻辑只往上走
// （while (imp < target) 才加价；当前提升已高于目标时它不动），**降不了价**。
//
// 今天（2026-09-27）踩过的两个坑，本脚本都做了防护：
//   坑1 抽屉默认选中的是「建议出价」行，不是「自定义」行 → 不先切，读到的是建议价。
//   坑2 抽屉保存会提交【全部字段】→ 目标类型/预算可能被写成默认值。
//      所以：改动前把 目标类型/出价/预算 三项都读出来；保存前再核对一次；
//            预算若漂移就写回原值；目标类型若漂移就【中止不保存】。
//
// cfg = window.__SB = [{ planName, planId, newBid, statusLabel? }]
//   statusLabel: 可选，先切「擦亮状态」筛选（如 '已暂停'），默认不改筛选
(async () => {
  const PLANS = window.__SB || [];
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const out = [];

  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const setNative = (el, v) => { const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value'); d.set.call(el, String(v)); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  const blur = el => { el.dispatchEvent(new FocusEvent('focusout', { bubbles: true })); el.dispatchEvent(new Event('blur', { bubbles: true })); };
  const drawers = () => [].slice.call(document.querySelectorAll('.ant-drawer-content')).filter(d => d.getBoundingClientRect().width > 200);
  const outer = () => drawers().find(d => /编辑计划/.test(d.innerText || ''));
  const bidInput = () => { const od = outer(); return od ? (od.querySelector('input[placeholder*="自定义出价"]') || od.querySelector('input[placeholder*="出价"]')) : null; };
  const readImp = () => { const od = outer(); if (!od) return null; const m = od.innerText.match(/预计提升\s*(\d+)%/); return m ? parseInt(m[1], 10) : null; };
  const TGT_NAMES = { '曝光量': 'exposure', '浏览量': 'click', '关注收藏量': 'follow_collect', '咨询量': 'chat', '订单量': 'order' };
  function readTarget() {
    const od = outer(); if (!od) return null;
    const labels = [].slice.call(od.querySelectorAll('label'));
    for (const l of labels) { const t = (l.innerText || '').trim(); if (!TGT_NAMES[t]) continue; const r = l.querySelector('input[type=radio]'); if (r && r.checked) return t; }
    const radios = [].slice.call(od.querySelectorAll('input[type=radio]'));
    for (const r of radios) { if (!r.checked) continue; const w = r.closest('label') || r.parentElement; const t = w ? (w.innerText || '').trim() : ''; if (TGT_NAMES[t]) return t; }
    const act = [].slice.call(od.querySelectorAll('[class*=radioActive],[class*=active],[class*=checked]'));
    for (const a of act) { const t = (a.innerText || '').trim(); if (TGT_NAMES[t]) return t; }
    return null;
  }
  const grpOf = () => {
    const od = outer(); if (!od) return null;
    return od.querySelector('[class*=radioGroup--eEugUXoZ]')
      || [].slice.call(od.querySelectorAll('div')).filter(d => /自定义|¥\s*\d/.test(d.innerText || '') && d.querySelectorAll('[class*=radio--]').length >= 2).sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length)[0];
  };
  const budgetText = () => { const g = grpOf(); if (!g) return null; const s = [].slice.call(g.querySelectorAll('[class*=radio--]')); return s.length ? (s[s.length - 1].innerText || '').trim() : null; };

  for (const cfg of PLANS) {
    const R = { plan: cfg.planName, planId: cfg.planId, 目标出价: cfg.newBid };
    try {
      // 清掉粘住的「计划ID」筛选
      const idf = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
      if (idf && String(idf.value || '').trim() !== '') {
        setNative(idf, ''); await sleep(600);
        idf.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
        await sleep(3500);
      }
      // 计划 tab
      const planTab = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn')).find(e => /^计划\(\d+\)$/.test((e.innerText || '').trim()));
      if (planTab) { click1(planTab); await sleep(3500); }

      // 可选：切状态筛选
      if (cfg.statusLabel) {
        const sel = [].slice.call(document.querySelectorAll('.ant-select')).filter(e => { const r = e.getBoundingClientRect(); return r.width > 10 && /^(擦亮状态|已暂停|擦亮中|擦亮完成|商品异常暂停|余额不足暂停)$/.test((e.innerText || '').trim()); })[0];
        if (sel) {
          const c = sel.querySelector('.ant-select-selector') || sel;
          c.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); await sleep(300); click1(c); await sleep(1600);
          const dd = [].slice.call(document.querySelectorAll('.ant-select-dropdown')).filter(d => d.getBoundingClientRect().width > 10).pop();
          const opt = dd && [].slice.call(dd.querySelectorAll('.ant-select-item-option')).find(e => (e.innerText || '').trim() === cfg.statusLabel);
          if (opt) { click1(opt); await sleep(4500); R.状态筛选 = cfg.statusLabel; }
          else { document.body.click(); await sleep(500); R.状态筛选 = '未找到选项'; }
        } else R.状态筛选 = '未找到筛选器';
      }

      // 按 ID 筛选
      const box = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
      if (box) {
        setNative(box, String(cfg.planId)); await sleep(700);
        box.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
        await sleep(5000);
      }
      const findRow = () => [].slice.call(document.querySelectorAll('tbody tr')).find(r => (r.innerText || '').indexOf(cfg.planName) >= 0 || (r.innerText || '').indexOf(String(cfg.planId)) >= 0);
      let row = null;
      for (let i = 0; i < 12 && !row; i++) { await sleep(1000); row = findRow(); }
      if (!row) throw new Error('找不到计划行');
      click1([].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑'));

      // 等抽屉就绪：出价框 + 预算槽 + 提升%
      let od = null;
      for (let i = 0; i < 20; i++) {
        await sleep(1000);
        od = outer();
        if (od && bidInput() && readImp() !== null && /^¥\s*\d/.test(String(budgetText() || ''))) break;
      }
      if (!od) throw new Error('抽屉没打开或无出价框');

      // 坑1：先切到「自定义」出价行
      const imps = [].slice.call(od.querySelectorAll('[class*=improveNum]'));
      R.improveRows = imps.length;
      if (imps.length >= 2) {
        let r2 = imps[1];
        for (let i = 0; i < 10 && r2 && !r2.querySelector('input[type=radio]'); i++) r2 = r2.parentElement;
        const lab = r2 && r2.querySelector('label');
        if (lab) { click1(lab); await sleep(1800); R.已切自定义行 = true; }
      }
      for (let i = 0; i < 12; i++) {
        const v = parseFloat((bidInput() || {}).value || '0');
        if (v > 0 && readImp() !== null) break;
        await sleep(800);
      }

      const before = { bid: parseFloat((bidInput() || {}).value || '0'), imp: readImp(), target: readTarget(), budget: budgetText() };
      R.改前 = before;
      if (!before.bid) throw new Error('读不到当前出价');

      // 设新出价
      const el = bidInput();
      if (!el) throw new Error('出价框消失');
      setNative(el, cfg.newBid); await sleep(700); blur(el); await sleep(2500);
      R.改后出价 = String((bidInput() || {}).value || '').trim();
      R.改后提升 = readImp();
      R.改后目标 = readTarget();
      R.改后预算 = budgetText();

      if (Math.abs(parseFloat(R.改后出价) - Number(cfg.newBid)) > 1e-6) throw new Error('出价写回失败：' + R.改后出价 + ' 期望 ' + cfg.newBid);

      // 坑2-a：目标类型漂移 → 中止
      if (before.target && R.改后目标 && before.target !== R.改后目标) {
        throw new Error('目标类型漂移 ' + before.target + ' → ' + R.改后目标 + '，中止不保存（手动关抽屉）');
      }
      // 坑2-b：预算漂移 → 写回原值
      if (before.budget && R.改后预算 && before.budget !== R.改后预算) {
        R.预算漂移 = before.budget + ' → ' + R.改后预算;
        const g = grpOf();
        const bs = [].slice.call(g.querySelectorAll('[class*=radio--]'));
        const custom = bs[bs.length - 1];
        click1(custom); await sleep(1800);
        let bi = custom.querySelector('input') || g.querySelector('input');
        if (bi) {
          setNative(bi, String(String(before.budget).replace(/[^\d.]/g, ''))); await sleep(700); blur(bi); await sleep(2200);
          R.预算已写回 = budgetText();
        } else R.预算写回失败 = '无输入框';
      }

      // 保存
      const wrap = od.closest('.ant-drawer');
      const foot = wrap && wrap.querySelector('.ant-drawer-footer');
      const ok = foot && [].slice.call(foot.querySelectorAll('div,span,button')).find(e => e.children.length === 0 && /^确\s*定$/.test((e.innerText || '').trim()));
      if (!ok) throw new Error('找不到确定');
      click1(ok);
      R.已保存 = true;
      await sleep(6500);
      R.提示 = ((document.body.innerText || '').match(/[^\n]*(修改成功|成功|失败|错误|不能)[^\n]*/g) || []).slice(0, 3);
      R.抽屉已关 = !outer();
    } catch (e) { R.fatal = e.message; }
    out.push(R);
    await sleep(2000);
  }
  return JSON.stringify(out, null, 1);
})()
