/**
 * probe-relist.js — 找「重新上架」入口（先只看不点）
 * 用法: node probe-relist.js <itemId>
 */
const fs = require('fs');
const http = require('http');
const path = require('path');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const ID = process.argv[2];
if (!ID) { console.log('用法: node probe-relist.js <itemId>'); process.exit(2); }

const CODE = `(async () => {
  const out = { href: location.href, title: document.title };
  for (let i = 0; i < 22; i++) { if ((document.body.innerText || '').length > 300) break; await new Promise(r => setTimeout(r, 800)); }
  const body = document.body.innerText || '';
  out.正文长度 = body.length;
  const leaf = t => [...document.querySelectorAll('div,span,button,a,li')].filter(e => (e.innerText || '').trim() === t && e.children.length === 0);
  out.按钮 = {};
  ['上架','重新上架','下架','删除','编辑','擦亮'].forEach(t => {
    const els = leaf(t);
    out.按钮[t] = els.map(e => { const r = e.getBoundingClientRect(); return { cls: String(e.className).slice(0,56), 可见: r.width>0&&r.height>0, top: Math.round(r.top), 父文本: (e.parentElement?(e.parentElement.innerText||''):'').replace(/\\n+/g,' | ').slice(0,70) }; });
  });
  ['已下架','下架成功','上架','重新上架','在售','审核'].forEach(k => {
    const i = body.indexOf(k);
    out['含_' + k] = i >= 0 ? body.slice(Math.max(0, i - 50), i + 70).replace(/\\n/g, ' / ') : false;
  });
  out.前18行 = body.split('\\n').map(s => s.trim()).filter(Boolean).slice(0, 18);
  return out;
})()`;

function post(p, body, t) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 300))); } }); });
    req.on('error', reject); req.setTimeout(t || 120000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}
(async () => {
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/item?id=' + ID + '"; "nav"' }, 90000);
  await new Promise(z => setTimeout(z, 12000));
  const res = await post('/api/agent/eval-on-store', { store: STORE, code: CODE }, 120000);
  console.log(JSON.stringify(res, null, 1));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
