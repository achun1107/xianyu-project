(function () {
  if (location.href.indexOf('/search') < 0) return JSON.stringify({ 不在搜索页: location.href });

  // 代拍服务必须命中的核心词
  const RE_DAIPAI = /代拍|代抢|帮抢|上号|代拍流程|用你的账号|用你自己的账号|用你的大麦|提供大麦账号|提供账号/;
  // 明确卖票/转让的信号（命中即排除）
  const RE_MAIPIAO = /出票|现货票|纸质票|实体票|面交|快递发|顺丰|多抢了|多买了一张|急出|转让票|原价出|低价出|现票|有票出|包邮出|连坐出|单连出/;
  // 纯噪音（二手实物、无关商品）
  const RE_NOISE = /iPhone|手机|衣服|裙|鞋|币|花洒|宠物|酒店管家|壁纸|耳机|相机|手表|包邮出|自用|闲置|回血/i;

  const cards = [].slice.call(document.querySelectorAll('a[class*=feeds-item-wrap]'));
  const q = new URLSearchParams(location.search).get('q') || '';

  const parse = a => {
    const href = a.getAttribute('href') || '';
    const itemId = (href.match(/id=(\d+)/) || [])[1] || '';
    const cat = (href.match(/categoryId=(\d+)/) || [])[1] || '';
    const titleEl = a.querySelector('[class*=main-title]') || a.querySelector('[class*=row1-wrap-title]');
    const title = titleEl ? (titleEl.getAttribute('title') || titleEl.innerText || '').replace(/\s+/g, ' ').trim() : '';
    const numEl = a.querySelector('[class*=number--]');
    const price = numEl ? (numEl.innerText || '').trim() : ((a.innerText || '').match(/¥\s*([0-9.]+)/) || [])[1] || '';
    const txt = (a.innerText || '').replace(/\s+/g, ' ');
    const want = (txt.match(/(\d+)\s*人想要/) || [])[1];
    const sellerEl = a.querySelector('[class*=seller-text-wrap]');
    const seller = sellerEl ? (sellerEl.getAttribute('title') || '') : '';
    const body = title + ' ' + txt;
    // ⚠️ 卡片的 title 属性里装的是「标题 + 描述正文」全文（与详情页一致），
    // 上一版我截断到 70 字，把文案信息丢了。这里保留全文。
    const full = title.replace(/\s+/g, ' ').trim();
    // 标题 ≈ 前 30 字（闲鱼标题长度上限），其余算正文
    const shortTitle = full.slice(0, 30);
    const desc = full.slice(30);
    const isDaipai = RE_DAIPAI.test(body);
    const isMaipiao = RE_MAIPIAO.test(body);
    const isNoise = RE_NOISE.test(body);
    return {
      itemId, categoryId: cat, 标题: shortTitle, 全文: full.slice(0, 600), 正文: desc.slice(0, 520),
      价格: price, 想要: want ? Number(want) : null, 卖家地域: seller, 全文字数: full.length,
      // 优先级：只要命中代拍核心词就算代拍服务 —— 卖票词不能一票否决，
      // 否则会把「代拍流程…」这类真代拍误杀（实测踩过，误杀 2/30）
      判定: isDaipai ? '代拍' : isMaipiao ? '卖票' : isNoise ? '噪音' : '存疑',
    };
  };

  const all = cards.map(parse).filter(x => x.itemId);
  const daipai = all.filter(x => x.判定 === '代拍').sort((a, b) => (b.想要 || 0) - (a.想要 || 0));
  const 丢弃 = all.filter(x => x.判定 !== '代拍');
  const 判定分布 = {};
  all.forEach(x => { 判定分布[x.判定] = (判定分布[x.判定] || 0) + 1; });

  return JSON.stringify({
    关键词: q,
    本页总数: all.length,
    判定分布,
    代拍条数: daipai.length,
    代拍里有想要数: daipai.filter(x => x.想要 !== null).length,
    代拍条目: daipai,
    丢弃样例: 丢弃.slice(0, 10).map(x => ({ 判定: x.判定, 价格: x.价格, 标题: x.标题.slice(0, 42) })),
  }, null, 1);
})()
