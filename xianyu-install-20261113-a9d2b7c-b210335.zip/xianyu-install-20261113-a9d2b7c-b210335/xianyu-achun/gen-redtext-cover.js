/**
 * gen-redtext-cover.js — 生成「白底红字版」成品封面（供推送到中台当版式封面）
 *
 * 为什么要这么绕：PowerShell 传中文参数会被吃掉，所以参数在这里写死，
 * 再 require make-covers.js（它读 process.argv）。
 *
 * 链路：/api/poster/make（走底图来源级联：大麦官方海报 → 其他城市 → 猫眼/微博 → AI兜底）
 *       → 拿到垫图 → 用发布台的 _iwApplyText 烧上 tpl_redtext 的文字层 → 成品 PNG
 */
process.argv[2] = '杭州';            // 城市
process.argv[3] = '那英';            // 明星
process.argv[4] = 'damai_official';  // 底图来源
process.argv[5] = 'tpl_redtext';     // 只出这一个版式
require('./make-covers.js');
