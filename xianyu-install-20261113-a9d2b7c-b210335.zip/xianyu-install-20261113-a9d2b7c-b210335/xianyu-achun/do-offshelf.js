/**
 * do-offshelf.js — 对指定 itemId 执行「下架」（导航到商品页 → 点下架 → 确认）
 * 用法: node do-offshelf.js <itemId> [<itemId>...]
 *
 * 为什么走 UI：mtop.idle.pc.idleitem.off.shelf / delete 全系接口都是 ABORT::接口异常退出
 *（2026-09-28 实测 8 次全挂），唯一可行路径是页面上的「下架」按钮。
 * 只点「下架」（可逆），绝不点「删除」（永久）。
 */
const fs = require('fs');
const http = require('http');
const path = require('path');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const IDS = process.argv.slice(2).filter(a => /^\d+$/.test(a));
if (!IDS.length) { console.log('用法: node do-offshelf.js <itemId> [...]'); process.exit(2); }
const CODE = fs.readFileSync(path.join(__dirname, '_click-offshelf.js'), 'utf8');

const { post: httpPost } = require('./lib/http');
function post(p, body, t) { return httpPost(p, body, { timeout: t || 150000 }); }
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  for (const id of IDS) {
    console.log('\n════ 下架 ' + id + ' ════');
    await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/item?id=' + id + '"; "nav"' }, 90000);
    await sleep(12000);
    // 传入目标 itemId，脚本内部会核对页面上的 itemId，不一致就拒点
    const res = await post('/api/agent/eval-on-store', { store: STORE, code: 'window.__EXPECT_ID=' + JSON.stringify(id) + ';\n' + CODE }, 150000);
    console.log(JSON.stringify(res, null, 1));
    await sleep(2500);
  }
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/"; "back"' }, 60000);
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
