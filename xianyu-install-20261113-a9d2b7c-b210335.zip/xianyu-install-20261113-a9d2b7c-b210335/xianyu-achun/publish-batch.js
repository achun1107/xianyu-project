/**
 * publish-batch.js — 通用批量上架：读 publish-batch-config.json，逐个发布，间隔可配
 *
 * 配置（publish-batch-config.json）：
 *   { "city": "广州", "star": "宋雨琦", "store": "好易美代拍", "n": 4, "gapSec": 600 }
 *
 * 为什么用 JSON 文件而不是命令行参数：中文参数过 PowerShell 会被 OEM 936 编码吃掉。
 *
 * 预热（只做一次，在循环外）：POST /api/agent/start-one { name: store }
 *   agent 是懒启动 + 空闲 20 分钟回收，publish-one.js 依赖 agent.stores[store]。
 *   2026-09-28 改：原来在循环里调 open-all-stores，每发一条就把三个店铺全开一遍。
 *   现在只启动本批要用的那个店铺（当前只运营「好易美代拍」，见 lib/config.json 的 store.active）。
 *
 * 用法: node publish-batch.js [配置文件路径]
 */
const { execFileSync } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { SVC, ROOT, STORE: DEFAULT_STORE, NODE: ENV_NODE } = require('./lib/env');

const NODE = ENV_NODE.path;
const D = ROOT;
const PUB = path.join(D, 'publish-one.js');
const LEDGER = path.join(D, '上架台账.json');
// 第一个参数若不是 -- 开头才当作配置文件路径（否则 --plan 会被误当成路径）
const CFGF = (process.argv[2] && process.argv[2].indexOf('--') !== 0)
  ? process.argv[2] : path.join(D, 'publish-batch-config.json');
const KEY = SVC.apiKey;

const cfg = JSON.parse(fs.readFileSync(CFGF, 'utf8'));
const CITY = cfg.city, STAR = cfg.star, STORE = cfg.store || DEFAULT_STORE;
const N = cfg.n || 1, GAP_MS = (cfg.gapSec == null ? 600 : cfg.gapSec) * 1000;
const LOGF = path.join(D, 'publish-batch-' + CITY + STAR + '.log');

// ── 批次内【不重复】分配标题模板 / 主图模板（2026-09-28 加）──
// 起因：publish-one.js 原来是「每次独立随机抽」，4 个模板发 4 条时
//       标题全不重复的概率只有 4!/4^4 = 9.4% —— 也就是 90% 会撞车（宋雨琦那批就撞了 3 条）。
// 做法：本批开始时把模板列表打乱，然后按序号依次分配，传给子进程。
//       模板数 ≥ 条数时 = 零重复；模板数不够才会循环回来重复。
const os = require('os');
let TPL_IDS = [];
try {
  TPL_IDS = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.xianyu-templates.json'), 'utf8')).templates.map(x => x.id);
} catch (e) { }
const MAIN_KEYS = ['xuliang-v1', '__shoukai', 'tpl_redtext'];
const shuffle = a => a.map(v => [Math.random(), v]).sort((x, y) => x[0] - y[0]).map(p => p[1]);
const TITLE_ASSIGN = shuffle(TPL_IDS.slice());
const MAIN_ASSIGN = shuffle(MAIN_KEYS.slice());

// --plan：只预览本批怎么分配、会生成什么标题，不发布
if (process.argv.includes('--plan')) {
  const T = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.xianyu-templates.json'), 'utf8'));
  const EVENT = '演唱会', SESSION = '首开';
  console.log('批次分配预览：' + CITY + STAR + ' × ' + N + '（不发布）');
  console.log('可用标题模板: ' + TPL_IDS.join(', ') + '    主图模板: ' + MAIN_KEYS.join(', ') + '\n');
  const used = [];
  for (let i = 1; i <= N; i++) {
    const tplId = TITLE_ASSIGN.length ? TITLE_ASSIGN[(i - 1) % TITLE_ASSIGN.length] : null;
    const mainKey = MAIN_ASSIGN[(i - 1) % MAIN_ASSIGN.length];
    const t = T.templates.find(x => Number(x.id) === Number(tplId)) || T.templates[0];
    const raw = String(t.titlePattern).split('{明星}').join(STAR).split('{城市}').join(CITY)
      .split('{活动类型}').join(EVENT).split('{场次类型}').join(SESSION);
    used.push(tplId);
    console.log('  #' + i + '  模板id=' + tplId + '  主图=' + mainKey);
    console.log('       标题(' + raw.length + '字): ' + raw);
  }
  console.log('');
  console.log(used.length === new Set(used).size
    ? '  ✅ 本批标题模板互不重复（' + used.length + ' 条 / ' + TPL_IDS.length + ' 个模板）'
    : '  ⚠️ 有重复：模板数 ' + TPL_IDS.length + ' < 条数 ' + N + '，这一批必然撞标题');
  process.exit(0);
}

function log(m) {
  const line = '[' + new Date().toLocaleString('zh-CN') + '] ' + m;
  console.log(line);
  try { fs.appendFileSync(LOGF, line + '\n'); } catch (e) { }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function post(p, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body || {});
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ raw: b.slice(0, 300) }); } }); });
    req.on('error', reject);
    req.setTimeout(timeoutMs || 300000, () => req.destroy(new Error('请求超时')));
    req.write(payload); req.end();
  });
}
const ledger = () => { try { return JSON.parse(fs.readFileSync(LEDGER, 'utf8')); } catch (e) { return []; } };

(async () => {
  log('=== 批量上架：' + CITY + STAR + ' × ' + N + '，间隔 ' + (GAP_MS / 1000) + 's，店铺 ' + STORE + ' ===');

  // 预热只做一次。
  // 2026-09-28 改：原来这段在循环里，每发一条就把【三个店铺】全开一遍
  // （open-all-stores 无差别启动 好易美代拍/好易美娱乐/超能水手代拍）。
  // 现在只启动本批真正要用的那个店铺。
  try { log('预热: ' + JSON.stringify(await post('/api/agent/start-one', { name: STORE }, 300000)).slice(0, 120)); }
  catch (e) { log('⚠️ 预热失败: ' + e.message + '（仍尝试发布）'); }

  const results = [];
  const titles = {};

  for (let i = 1; i <= N; i++) {
    log('──── 第 ' + i + '/' + N + ' 个 ────');

    const before = ledger().length;
    // 本批分配（不重复）
    const tplId = TITLE_ASSIGN.length ? TITLE_ASSIGN[(i - 1) % TITLE_ASSIGN.length] : null;
    const mainKey = MAIN_ASSIGN[(i - 1) % MAIN_ASSIGN.length];
    const childEnv = Object.assign({}, process.env);
    if (tplId != null) childEnv.KUN_TITLE_TPL_ID = String(tplId);
    childEnv.KUN_MAIN_TPL = mainKey;
    log('分配: 标题模板 id=' + (tplId == null ? '(随机)' : tplId) + '   主图模板=' + mainKey);

    let out = '';
    try { out = execFileSync(NODE, [PUB, CITY, STAR], { encoding: 'utf8', timeout: 900000, maxBuffer: 8 * 1024 * 1024, env: childEnv }); }
    catch (e) { out = String(e.stdout || '') + '\n' + String(e.stderr || '') + '\n[exit] ' + e.message; }

    // 只摘关键行，别把整段 JSON 灌进日志
    out.split('\n').forEach(l => { if (/主图模板|出图:|文字层|标题\(|正文 |卡片标题|所在地|图床:|itemId|✅|❌|已记账/.test(l)) log('  ' + l.trim()); });

    const led = ledger();
    const rec = led.length > before ? led[led.length - 1] : null;
    if (rec) titles[rec.标题] = (titles[rec.标题] || 0) + 1;
    results.push({ n: i, ok: rec ? !!rec.ok : false, itemId: rec ? rec.itemId : null, 标题: rec ? rec.标题 : null,
      定位: rec ? rec.定位 : null, 模板: rec ? rec.主图模板 : null });
    log(rec ? ('✓ 第 ' + i + ': ' + (rec.itemId ? 'https://www.goofish.com/item?id=' + rec.itemId : '无 itemId') + '  定位=' + rec.定位)
            : ('✗ 第 ' + i + ': 台账没新增，可能失败'));

    if (i < N) { log('等待 ' + (GAP_MS / 1000) + ' 秒 ...'); await sleep(GAP_MS); }
  }

  log('=== 完成 ===');
  results.forEach(r => log('  #' + r.n + (r.ok ? ' ✅ ' : ' ❌ ') + (r.itemId || '-') + '  ' + (r.标题 || '') + '  ' + (r.模板 || '')));
  const dup = Object.keys(titles).filter(t => titles[t] > 1);
  if (dup.length) log('⚠️ 标题重复: ' + dup.map(t => '「' + t + '」×' + titles[t]).join('；'));
  const resF = path.join(D, 'publish-batch-result.json');
  fs.writeFileSync(resF, JSON.stringify({ cfg, results, 标题重复: dup }, null, 2), 'utf8');
  log('结果已写 ' + resF);
})().catch(e => { log('❌ 未捕获: ' + (e && e.stack || e)); process.exit(1); });
