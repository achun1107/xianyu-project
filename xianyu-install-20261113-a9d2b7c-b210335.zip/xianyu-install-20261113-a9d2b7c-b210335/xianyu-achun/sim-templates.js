/**
 * sim-templates.js — 用新模板文件模拟生成标题（不安装、不发布）
 * 复刻 publish-one.js 的 fitTitle 逻辑，逐条验证占位符/字数/正文行数
 */
const fs = require('fs');
const path = require('path');

const FILE = process.argv[2] || path.join(__dirname, '_xianyu-templates-new.json');
const T = JSON.parse(fs.readFileSync(FILE, 'utf8'));

const TITLE_MAX = 40;
const TITLE_MIN = 30;
const TITLE_PAD = [' 全站全价位都可接', ' 全价位都能接', ' 高命中率', ' 全价位接', ' 可上号', ' 秒付前排', ' 稳中', ' 秒付', ' 包中'];
function fitTitle(t) {
  t = String(t == null ? '' : t);
  if (t.length > TITLE_MAX) return t.slice(0, TITLE_MAX);
  if (t.length < TITLE_MIN) {
    const gap = TITLE_MIN - t.length;
    let best = '';
    for (const f of TITLE_PAD) if (f.length <= gap && f.length > best.length) best = f;
    t += best;
    while (t.length < TITLE_MIN) t += '！';
  }
  return t;
}

const SAMPLES = [['泉州', '徐良'], ['广州', '宋雨琦']];
const EVENT = '演唱会', SESSION = '首开';

console.log('文件: ' + FILE);
console.log('模板数: ' + T.templates.length + '\n');

let problems = [];
for (const t of T.templates) {
  console.log('════ 模板' + t.id + '  ' + (t.name || '') + ' ════');
  console.log('  titlePattern: ' + t.titlePattern);
  const miss = ['{明星}', '{城市}'].filter(p => t.titlePattern.indexOf(p) < 0);
  if (miss.length) { console.log('  ❌ 标题缺占位符: ' + miss.join(',')); problems.push('模板' + t.id + ' 标题缺 ' + miss.join(',')); }
  const dmiss = ['{明星}', '{城市}'].filter(p => t.descPattern.indexOf(p) < 0);
  console.log('  正文含占位符: ' + (dmiss.length ? '❌ 无（描述里看不到明星/城市）' : '✅ 有'));
  console.log('  正文 ' + t.descPattern.split('\n').length + ' 行 / ' + t.descPattern.length + ' 字');
  if (t.descPattern[0] === '\n') { console.log('  ⚠️ 正文以空行开头'); problems.push('模板' + t.id + ' 正文以空行开头'); }

  for (const [city, star] of SAMPLES) {
    const raw = String(t.titlePattern).split('{明星}').join(star).split('{城市}').join(city)
      .split('{场次类型}').join(SESSION).split('{活动类型}').join(EVENT);
    const fin = fitTitle(raw);
    const cut = raw.length > TITLE_MAX;
    console.log('   [' + city + star + '] 原始' + raw.length + '字 → 最终' + fin.length + '字' + (cut ? '  ⚠️超30被截断' : '  (补足)'));
    console.log('      ' + fin);
    if (cut) problems.push('模板' + t.id + ' 标题原始 ' + raw.length + ' 字 > 30，会被截断（尾部丢失）');
  }
  console.log('');
}

console.log('════ 问题汇总 ════');
if (!problems.length) console.log('  ✅ 无');
else problems.forEach(p => console.log('  ⚠️ ' + p));

// 标题唯一性（占位符归一后）
const norm = t => String(t.titlePattern).split('{明星}').join('#').split('{城市}').join('#');
const seen = {};
T.templates.forEach(t => { const k = norm(t); seen[k] = (seen[k] || 0) + 1; });
const dup = Object.keys(seen).filter(k => seen[k] > 1);
console.log('\n════ 占位符归一后仍相同（= 会产出一样标题） ════');
console.log(dup.length ? dup.map(k => '  ×' + seen[k] + '  ' + k).join('\n') : '  无 —— 4 个模板互不相同 ✅');
