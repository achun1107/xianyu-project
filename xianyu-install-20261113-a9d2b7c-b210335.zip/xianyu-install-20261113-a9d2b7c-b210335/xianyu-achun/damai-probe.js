// damai-probe.js —— 摸清大麦搜索 mtop 返回的原始字段，找「即将开抢」的判据
// 用法: node damai-probe.js "华晨宇 南京"
const path = require('path');
const { PATHS } = require('./lib/env');
const PW = require(path.join(PATHS.playwrightService, 'node_modules', 'playwright'));

const kw = process.argv[2] || '华晨宇 南京';

(async () => {
  const b = await PW.chromium.launch({ headless: true });
  const ctx = await b.newContext({
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
    viewport: { width: 390, height: 844 }, isMobile: true,
  });
  const p = await ctx.newPage();
  const hits = [];
  p.on('response', async r => {
    const u = r.url();
    if (!/mtop\.damai\.(wireless|cn)/.test(u)) return;
    if (/search\.search|project\.detail|project\.performance/.test(u) === false) return;
    try {
      const t = await r.text();
      if (t.length < 50) return;
      const j = JSON.parse(t);
      hits.push({ api: (u.match(/mtop\.damai\.[a-z.]+/) || [''])[0], body: j });
    } catch (e) { }
  });

  try {
    await p.goto('https://m.damai.cn/damai/search/index.html?keyword=' + encodeURIComponent(kw),
      { waitUntil: 'networkidle', timeout: 40000 }).catch(() => { });
    await p.waitForTimeout(3000);
  } catch (e) { }

  console.log('命中接口数:', hits.length);
  for (const h of hits.slice(0, 3)) {
    console.log('\n############ API:', h.api);
    const pi = h.body && h.body.data && h.body.data.projectInfo;
    if (Array.isArray(pi) && pi.length) {
      console.log('projectInfo 条数:', pi.length);
      console.log('--- 第 1 条的全部字段 ---');
      console.log(JSON.stringify(pi[0], null, 2).slice(0, 6000));
      console.log('\n--- 所有条目的关键候选字段 ---');
      pi.forEach((x, i) => console.log(i, '|', JSON.stringify({
        id: x.id, name: (x.name || '').slice(0, 30), city: x.cityName,
        showStatus: x.showStatus, buyBtnText: x.buyBtnText, priceStr: x.priceStr,
        showTime: x.showTime, sellStartTime: x.sellStartTime, buyStartTime: x.buyStartTime,
        nearestPerformTime: x.nearestPerformTime, itemType: x.itemType,
      })));
    } else {
      console.log('--- 无 projectInfo，顶层 keys:', Object.keys(h.body.data || h.body).join(','));
      console.log(JSON.stringify(h.body).slice(0, 3000));
    }
  }
  await b.close();
})().catch(e => { console.error('FAIL:', e.message); process.exit(1); });
