@echo off
rem ===== One-click health check (ASCII only on purpose) =====
rem Why a .cmd wrapper: the AI-illiterate user just double-clicks this file.
rem Double-clicking a .ps1 does NOT run it (Windows opens it in Notepad).
rem
rem Why the contents are ASCII: this file has no "chcp 65001", so cmd.exe
rem decodes it in the OEM codepage (936). A UTF-8 Chinese byte sequence
rem re-decoded as GBK can land on an ASCII metacharacter, the line gets split,
rem and cmd tries to RUN the fragments. That cost us a whole night once
rem (ad-window-11pm.cmd returned 0xFF and the ad window stayed open all night).
rem The node script prints the Chinese output itself - that is safe.
rem
rem Usage:
rem   this file              full check
rem   this file --quiet      only show problems and the conclusion
rem   this file --json       machine readable
setlocal
set "HERE=%~dp0"
set "RUN=%HERE%run-node.cmd"
if not exist "%RUN%" set "RUN=node"

"%RUN%" "%HERE%tools\healthcheck.js" %*
set "CODE=%ERRORLEVEL%"
echo.
echo [healthcheck] exit code = %CODE%
echo   0 = ready to use
echo   1 = there are blocking problems (see the FAIL lines above)
echo   2 = could not even read the environment
echo.
pause
exit /b %CODE%
