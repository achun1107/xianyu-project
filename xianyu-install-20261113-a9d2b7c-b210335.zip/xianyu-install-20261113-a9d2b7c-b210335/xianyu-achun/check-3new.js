// check-3new.js —— 轮询三个新计划是否自动恢复（浏览器侧代码）
(async () => {
  const m = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const cr = await m.request({
    api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) },
  });
  const list = (cr.data || {}).result || [];
  const want = ['北京陈都灵-咨询120', '成都熊艺文-咨询120', '南京wuuhaha-咨询120'];
  return JSON.stringify({
    时刻: new Date().toLocaleString('zh-CN'),
    计划: list.filter(c => want.indexOf(c.title) >= 0).map(c => ({
      name: c.title, pause: c.pauseStatus, group: c.statusGroup,
      说明: c.statusDescTitle || '-',
      花费: n((c.infoTab || {}).todayCost) / 100,
      曝光: n((c.todayAdDataDetail || {}).showPv),
    })),
    全店: {
      计划数: list.length,
      在跑: list.filter(c => c.statusGroup === 'online').length,
      暂停: list.filter(c => String(c.pauseStatus) === '1').length,
    },
  }, null, 1);
})()
