/**
 * unify-live-desc.js — 把两个模板的 descPattern 统一成同一份正文
 *
 * 统一原则：
 *   - 结构取自 gen-copy.js 的 POOL 顺序：场次四连 → 信任 → 覆盖 → 问价 → 流程 → 条款
 *   - 保留线上两个正文的全部要素（含只在一方出现的「专业设备」与「全价位覆盖」两行）
 *   - 长度收进同行区间内（同行全文 n=168，最长 233）
 * 只改 descPattern，其它字段一律不动。
 */
const fs = require('fs');
const path = require('path');
const os = require('os');

const FILE = path.join(os.homedir(), '.xianyu-templates.json');

const UNIFIED = [
  '场次全接：首开 + 捡漏回流 + 二开 + 三开',
  '七级店铺 + 上千好评 + 战绩可查 ｜ 专业设备 全程无风险',
  '全价位都能接：看台/内场、单张/连坐，抢不到全额退款',
  '问价方式：日期 + 票面 + 几张',
  '代拍流程：需提供你的账号或身份证；抢到后第一时间通知付款；因买家原因退票代拍费不退，只退扣费后票钱',
  '取消规则：开抢前 4 小时以上收 20%，4 小时以内收 40%',
  '也可自己一起抢，你抢到我退全款',
].join('\n');

// ── 同行分布（用于长度校验）──
const D = __dirname + '\\';
let DIST = [];
try {
  for (const f of ['xy-scan-result-0-7.json', 'xy-scan-result-7-14.json']) {
    JSON.parse(fs.readFileSync(D + f, 'utf8')).forEach(s => (s.top || [])
      .forEach(t => { if (t.判定 === '代拍' && t.全文字数) DIST.push(t.全文字数); }));
  }
  DIST.sort((a, b) => a - b);
} catch (e) { }

const FULL = 30 + 2 + UNIFIED.length;   // 全文 = 标题30 + "\n\n" + 正文
const ELEMS = ['首开', '二开', '三开', '回流', '七级店铺', '好评', '专业设备', '全额退款', '问价', '代拍流程', '20%', '40%', '自己'];
const missing = ELEMS.filter(k => UNIFIED.indexOf(k) < 0);

console.log('统一正文: ' + UNIFIED.length + ' 字 / ' + UNIFIED.split('\n').length + ' 行');
console.log('全文长度: ' + FULL + ' 字' + (DIST.length ? '（同行最长 ' + DIST[DIST.length - 1] + '，' + (FULL <= DIST[DIST.length - 1] ? '✅ 在范围内' : '❌ 超出') + '）' : ''));
console.log('要素覆盖: ' + ELEMS.map(k => (UNIFIED.indexOf(k) >= 0 ? '✅' : '❌') + k).join(' '));

if (missing.length) { console.log('\n❌ 缺要素: ' + missing.join(',') + ' → 中止'); process.exit(1); }
if (DIST.length && FULL > DIST[DIST.length - 1]) { console.log('\n❌ 超出同行最长 → 中止'); process.exit(1); }

const raw = fs.readFileSync(FILE, 'utf8');
const obj = JSON.parse(raw);
const before = JSON.parse(JSON.stringify(obj));

if (!obj.templates || obj.templates.length !== 2) { console.log('❌ 模板数不是 2 → 中止'); process.exit(1); }
obj.templates.forEach(t => {
  console.log('\n── id=' + t.id + ' ' + t.name + '  正文 ' + String(t.descPattern).length + ' 字 → ' + UNIFIED.length + ' 字');
  t.descPattern = UNIFIED;
});

// 非 descPattern 字段必须一字不动
const other = ['titlePattern', 'price', 'stock', 'categoryName', 'name', 'id', 'titleMode'];
const dirty = [];
before.templates.forEach((b, i) => other.forEach(k => {
  if (JSON.stringify(b[k]) !== JSON.stringify(obj.templates[i][k])) dirty.push('templates[' + i + '].' + k);
}));
if (JSON.stringify(before.key) !== JSON.stringify(obj.key)) dirty.push('key');
if (dirty.length) { console.log('\n❌ 非 descPattern 字段被改动: ' + dirty.join(', ') + ' → 中止'); process.exit(1); }
console.log('\n✅ 除 descPattern 外无字段变化');

fs.writeFileSync(FILE, JSON.stringify(obj, null, 2));
console.log('已写出 ' + FILE);

const back = JSON.parse(fs.readFileSync(FILE, 'utf8'));
console.log('\n回读: key=' + back.key + '  模板数=' + back.templates.length);
console.log('两个 descPattern 是否完全一致: ' + (back.templates[0].descPattern === back.templates[1].descPattern));
console.log(back.templates[0].descPattern.split('\n').map((l, i) => '  ' + (i + 1) + ' | ' + l).join('\n'));
