// im-conv-dump.js —— 只读：逐个点开 IM 会话，摸清右侧会话里【商品卡片】长什么样
//
// 背景：会话列表行只有买家昵称 + 末条消息 + 时间，没有商品。要按商品统计咨询，
//   必须从会话内容里认出「这条会话是关于哪个商品」。闲鱼 IM 通常在会话顶部放一张商品卡。
//   这个脚本点开每个会话，把右栏的候选特征原样打出来，用来定「怎么认出商品」的规则。
//
// 由 run-driver.js 驱动：DRIVER=im-conv-dump.js URL="https://www.goofish.com/im" node run-driver.js
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();
  const click1 = (el) => {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  };

  for (let i = 0; i < 20; i++) {
    if (document.querySelectorAll('[class*=conversation-item]').length) break;
    await sleep(800);
  }
  const items = [].slice.call(document.querySelectorAll('[class*=conversation-item]'));
  const LIMIT = 5;

  const 右栏 = () => {
    // 右栏 = 视口右半边里最大的那个可见容器
    const cands = [].slice.call(document.querySelectorAll('div')).filter(e => {
      const r = e.getBoundingClientRect();
      return r.left > window.innerWidth * 0.35 && r.width > 200 && r.height > 200;
    });
    if (!cands.length) return null;
    cands.sort((a, b) => (b.getBoundingClientRect().width * b.getBoundingClientRect().height)
      - (a.getBoundingClientRect().width * a.getBoundingClientRect().height));
    return cands[0];
  };

  const out = { 时刻: new Date().toLocaleString('zh-CN'), 会话数: items.length, 逐个: [] };
  for (let i = 0; i < Math.min(LIMIT, items.length); i++) {
    const it = items[i];
    const 昵称 = norm(it.innerText).split('\n')[0].slice(0, 24);
    click1(it);
    await sleep(1800);
    const pane = 右栏();
    const html = pane ? (pane.innerHTML || '') : '';
    const imgs = (html.match(/(?:O1CN[A-Za-z0-9]+)/g) || []);
    const ids13 = (html.match(/\b\d{13}\b/g) || []);
    // 【2026-10-10 加】右栏那个 div 里没有商品卡，所以把范围放大到【整页】再确认一次：
    //   闲鱼 web IM 有时把「在聊的宝贝」放在右栏之外的头部条里。
    const docHtml = document.documentElement.innerHTML || '';
    const 商品图候选 = (docHtml.match(/https?:\/\/[^"'\\ ]*(?:-0-fleamarket|-0-xy_item|bao\/uploaded)[^"'\\ ]*/g) || []);
    const 整页13位 = [].slice.call(new Set(docHtml.match(/\b\d{13}\b/g) || []));
    const 像商品标题 = [].slice.call(document.querySelectorAll('*'))
      .filter(e => e.children.length === 0 && /^【[^】]{2,12}】/.test(norm(e.innerText)))
      .map(e => norm(e.innerText).slice(0, 40)).slice(0, 4);
    out.逐个.push({
      i, 昵称,
      右栏文本: pane ? norm(pane.innerText).slice(0, 260) : '(右栏没找到)',
      图O1CN: [].slice.call(new Set(imgs)).slice(0, 4),
      数字13位: [].slice.call(new Set(ids13)).slice(0, 4),
      价格样式文本: pane ? [].slice.call(pane.querySelectorAll('*'))
        .map(e => norm(e.innerText)).filter(t => /^¥\s?\d/.test(t)).slice(0, 4) : [],
      // 画布上带 href 的链接（商品卡常常是可点链接）
      链接: pane ? [].slice.call(pane.querySelectorAll('a[href]')).map(a => a.getAttribute('href')).slice(0, 5) : [],
      整页商品图候选: [].slice.call(new Set(商品图候选)).slice(0, 3),
      整页13位数字: 整页13位.slice(0, 5),
      像商品标题的元素: 像商品标题,
    });
  }
  return JSON.stringify(out, null, 1);
})()
