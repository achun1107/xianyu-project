const { userIdOf } = require('./lib/user-id');
const USER_ID = userIdOf();   // 在 Node 侧求值，模板里用 ${JSON.stringify(USER_ID)} 传下去
// diag-4items.js —— 查这 4 个宝贝的状态与投放资格
(async () => {
  const m = window.lib.mtop;
  const num = v => { const n = Number(v); return isFinite(n) ? n : 0; };
  const ids = {
    '1087837028215': '陈都灵 A【稳中代拍】',
    '1087837516154': '陈都灵 B【代拍必中】',
    '1087839816259': '熊艺文 A【必中代拍】',
    '1087840072336': '熊艺文 B【高命中代拍】',
  };

  // A. 商品列表里的状态
  const API = 'mtop.idle.web.xyh.item.list';
  const BASE = { needGroupInfo: false, userId: USER_ID, pageSize: 20, groupName: '综合', groupId: 52785096, defaultGroup: true };
  const list = {};
  for (let p = 1; p <= 12; p++) {
    let r;
    try { r = await m.request({ api: API, v: '1.0', type: 'POST', data: Object.assign({}, BASE, { pageNumber: p }) }); } catch (e) { break; }
    if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0)) break;
    const cards = (r.data && r.data.cardList) || [];
    if (!cards.length) break;
    let added = 0;
    cards.forEach(c => {
      const cd = c.cardData || {};
      const id = String(cd.id || '');
      if (!id || list[id]) return;
      added++;
      list[id] = { 状态: cd.itemStatus, 标题: String(cd.title || '').slice(0, 30) };
    });
    if (!added) break;
  }

  // B. 可投放池
  const ir = await m.request({ api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, tab: 'all', needTabs: true }) } });
  const adv = ((ir.data || {}).result || {}).itemList || [];
  const by = {}; adv.forEach(it => by[String(it.itemId)] = it);

  const out = { 时刻: new Date().toLocaleString('zh-CN'), 可投放总数: adv.length, 逐条: {} };
  for (const id in ids) {
    const a = by[id], l = list[id];
    out.逐条[id] = {
      说明: ids[id],
      商品列表状态: l ? l.状态 : '不在商品列表',
      在可投放池: !!a,
      supportAd: a ? a.supportAd : null,
      tags: a ? a.tags : null,
      不支持原因: a ? a.notSupportAdInfo : null,
    };
  }
  // C. 也看看这两个计划
  const cr = await m.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
  out.计划 = (((cr.data || {}).result) || []).filter(c => /陈都灵|熊艺文/.test(c.title))
    .map(c => ({ id: c.campaignId, name: c.title, pause: c.pauseStatus, group: c.statusGroup, 说明: c.statusDescTitle, 宝贝数: (c.entityList || []).length }));
  return JSON.stringify(out, null, 1);
})()
