/**
 * delete-item.js — 删除/下架商品
 * 用法: node delete-item.js <itemId> [<itemId>...]
 *
 * 先试 delete，失败再试 off.shelf（下架，可逆）。
 * 注意：server.js 的 DELETE_GUARD 只拦 idle.ad.campaign.(delete|cancel)（擦亮计划），
 *       商品删除不受影响。
 */
const http = require('http');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const IDS = process.argv.slice(2).filter(a => /^\d+$/.test(a));
if (!IDS.length) { console.log('用法: node delete-item.js <itemId> [...]'); process.exit(2); }

function post(p, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 300))); } }); });
    req.on('error', reject); req.setTimeout(timeoutMs || 180000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}

const inner = `(async function(){
  var out = { results: [] };
  if (!window.lib || !window.lib.mtop) return { err: 'no lib.mtop' };
  var ids = ${JSON.stringify(IDS)};
  var apis = [
    { api: 'mtop.idle.pc.idleitem.delete',   label: '删除' },
    { api: 'mtop.idle.pc.idleitem.off.shelf', label: '下架' }
  ];
  for (var i = 0; i < ids.length; i++) {
    var rec = { itemId: ids[i], tries: [] };
    for (var j = 0; j < apis.length; j++) {
      try {
        var r = await window.lib.mtop.request({ api: apis[j].api, v: '1.0', data: { itemId: String(ids[i]) }, type: 'POST' });
        var ret = r && r.ret ? r.ret[0] : '无响应';
        rec.tries.push({ api: apis[j].api, label: apis[j].label, ret: ret });
        if (ret && ret.indexOf('SUCCESS') === 0) { rec.done = apis[j].label; break; }
      } catch (e) {
        rec.tries.push({ api: apis[j].api, label: apis[j].label, err: (e && (e.ret ? e.ret[0] : e.message)) || String(e) });
      }
    }
    out.results.push(rec);
  }
  return out;
})()`;

(async () => {
  console.log('目标: ' + IDS.join(', '));
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/"; "ok"' }, 60000);
  await new Promise(z => setTimeout(z, 8000));
  const res = await post('/api/agent/eval-on-store', { store: STORE, code: inner }, 300000);
  console.log(JSON.stringify(res, null, 2));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
