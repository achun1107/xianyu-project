// list-by-status.js —— 只读：切「擦亮状态」筛选，列出该档下所有计划的目标/出价
// cfg = window.__LS = { statusLabel: '已暂停', minBidAlert: 4 }
(async () => {
  const C = window.__LS || {};
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { if (!e) return false; const r = e.getBoundingClientRect(); return r.width > 10 && r.height > 10 && getComputedStyle(e).visibility !== 'hidden'; };
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => { const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent; el.dispatchEvent(new E(t, o)); });
    return true;
  }
  const setNative = (el, v) => { const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value'); d.set.call(el, String(v)); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  const out = { 状态: C.statusLabel };

  // 清粘住的 ID 筛选
  const idf = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
  if (idf && String(idf.value || '').trim() !== '') {
    setNative(idf, ''); await sleep(600);
    idf.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
    await sleep(3500);
  }
  // 计划 tab
  const tab = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn')).find(e => /^计划\(\d+\)$/.test((e.innerText || '').trim()));
  if (tab) { click1(tab); await sleep(3500); }

  // 状态筛选
  const sel = [].slice.call(document.querySelectorAll('.ant-select')).filter(e => vis(e) && /^(擦亮状态|已暂停|擦亮中|擦亮完成|商品异常暂停|余额不足暂停)$/.test((e.innerText || '').trim()))[0];
  if (!sel) return JSON.stringify(Object.assign(out, { err: '找不到状态筛选器' }), null, 1);
  const c = sel.querySelector('.ant-select-selector') || sel;
  c.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); await sleep(300); click1(c); await sleep(1600);
  const dd = [].slice.call(document.querySelectorAll('.ant-select-dropdown')).filter(vis).pop();
  const opt = dd && [].slice.call(dd.querySelectorAll('.ant-select-item-option')).find(e => (e.innerText || '').trim() === C.statusLabel);
  if (!opt) { document.body.click(); await sleep(500); return JSON.stringify(Object.assign(out, { err: '没找到选项 ' + C.statusLabel }), null, 1); }
  click1(opt); await sleep(5500);
  out.已切换 = C.statusLabel;

  // 读表格：跨页收集
  async function readPage() {
    return [].slice.call(document.querySelectorAll('tbody tr')).map(r => {
      const t = (r.innerText || '').replace(/\n+/g, ' ').replace(/\t/g, ' ');
      const idm = t.match(/(\d{8})/);
      const nm = t.match(/(\d{8})\s+([^\d]{2,40}?)\s+\d/);
      // 出价：列顺序里"预期成本出价"在预算后面，取形如 27.1 / 34 / 2.8 的数
      const nums = (t.match(/\b\d+(?:\.\d+)?\b/g) || []);
      return { id: idm ? idm[1] : null, name: nm ? nm[2].trim() : null, raw: t.slice(0, 200) };
    }).filter(x => x.id);
  }
  out.行 = await readPage();
  return JSON.stringify(out, null, 1);
})()
