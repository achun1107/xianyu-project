/**
 * run-eval-store.js — 把某个 js 文件的内容注入店铺页面执行，打印结果
 * 用法: node run-eval-store.js <js文件路径> [store名，默认 好易美代拍]
 */
const fs = require('fs');
const http = require('http');
const { SVC, STORE: DEFAULT_STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const FILE = process.argv[2];
const STORE = process.argv[3] || DEFAULT_STORE;
if (!FILE) { console.log('用法: node run-eval-store.js <js文件> [store]'); process.exit(1); }
const CODE = fs.readFileSync(FILE, 'utf8');

function post(p, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 400))); } }); });
    req.on('error', reject);
    req.setTimeout(timeoutMs || 180000, () => req.destroy(new Error('请求超时')));
    req.write(payload); req.end();
  });
}

(async () => {
  console.log('店铺: ' + STORE + '   注入: ' + FILE + '\n');
  const res = await post('/api/agent/eval-on-store', { store: STORE, code: CODE }, 240000);
  if (!res.ok) { console.log('❌ ' + JSON.stringify(res).slice(0, 600)); process.exit(1); }
  console.log(JSON.stringify(res.result, null, 1));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
