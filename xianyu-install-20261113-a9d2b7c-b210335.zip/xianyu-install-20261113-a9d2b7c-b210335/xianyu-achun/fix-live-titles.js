/**
 * fix-live-titles.js — 把 ~/.xianyu-templates.json 里两个模板的 titlePattern 换成 ≤30 字的安全版
 *
 * 只改 titlePattern；descPattern / price / stock / categoryName / id / name 一律不动。
 * 写出仍保持 {key, templates} 形状（Native Host 的既有形状）。
 */
const fs = require('fs');
const path = require('path');
const os = require('os');

const FILE = path.join(os.homedir(), '.xianyu-templates.json');
const NEW = {
  1: '【接代拍】{明星}{城市}站{活动类型}{场次类型}代抢 秒付前排',
  2: '【{城市}{明星}代拍】{活动类型}{场次类型}代抢{活动类型}代拍代抢',
};

const raw = fs.readFileSync(FILE, 'utf8');
const obj = JSON.parse(raw);
const before = JSON.parse(JSON.stringify(obj));

console.log('店铺 key: ' + obj.key);
console.log('模板数: ' + (obj.templates || []).length);
console.log('');

let changed = 0;
(obj.templates || []).forEach(t => {
  const nw = NEW[t.id];
  if (!nw) { console.log('id=' + t.id + ' 不在替换清单里，跳过'); return; }
  console.log('── id=' + t.id + '  ' + t.name);
  console.log('   旧: ' + t.titlePattern);
  console.log('   新: ' + nw);
  t.titlePattern = nw;
  changed++;
});

if (changed !== 2) {
  console.log('\n❌ 只该改 2 条，实际 ' + changed + ' 条 → 中止，未写文件');
  process.exit(1);
}

// 其它字段必须一字不动
const other = ['descPattern', 'price', 'stock', 'categoryName', 'name', 'id', 'titleMode'];
let dirty = [];
before.templates.forEach((b, i) => {
  const a = obj.templates[i];
  other.forEach(k => { if (JSON.stringify(b[k]) !== JSON.stringify(a[k])) dirty.push('templates[' + i + '].' + k); });
});
if (dirty.length) { console.log('\n❌ 非 titlePattern 字段被改动: ' + dirty.join(', ') + ' → 中止'); process.exit(1); }
console.log('\n✅ 除 titlePattern 外无字段变化');

fs.writeFileSync(FILE, JSON.stringify(obj, null, 2));
console.log('已写出 ' + FILE);

const back = JSON.parse(fs.readFileSync(FILE, 'utf8'));
console.log('回读校验: ' + back.templates.length + ' 个模板');
back.templates.forEach(t => console.log('  id=' + t.id + '  ' + t.titlePattern));
