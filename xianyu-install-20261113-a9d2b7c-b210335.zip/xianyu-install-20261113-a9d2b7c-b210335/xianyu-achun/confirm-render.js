/**
 * confirm-render.js — 逐条打开商品页：① 检查主图是否真的加载 ② 截图存盘
 * 用法: node confirm-render.js <itemId> [...]
 */
const fs = require('fs'); const http = require('http'); const path = require('path');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const IDS = process.argv.slice(2).filter(x => /^\d+$/.test(x));
if (!IDS.length) { console.log('用法: node confirm-render.js <itemId>...'); process.exit(2); }
const OUT = path.join(__dirname, '渲染确认');
fs.mkdirSync(OUT, { recursive: true });

const CODE = `(async () => {
  const out = { href: location.href, docTitle: document.title };
  for (let i = 0; i < 25; i++) { if ((document.body.innerText || '').length > 500) break; await new Promise(r => setTimeout(r, 800)); }
  await new Promise(r => setTimeout(r, 2500));   // 等图片解码
  const imgs = [...document.querySelectorAll('img')].map(e => {
    const r = e.getBoundingClientRect();
    return { src: String(e.currentSrc || e.src || '').slice(0, 130), natW: e.naturalWidth, natH: e.naturalHeight,
             dispW: Math.round(r.width), dispH: Math.round(r.height), complete: e.complete, alt: String(e.alt || '').slice(0, 40) };
  }).filter(x => x.natW > 0 || x.dispW > 0);
  // 主图 = 显示面积最大的那张
  imgs.sort((a, b) => (b.dispW * b.dispH) - (a.dispW * a.dispH));
  out.图片数 = imgs.length;
  out.主图 = imgs[0] || null;
  out.主图加载成功 = !!(imgs[0] && imgs[0].natW > 0 && imgs[0].complete);
  out.前5张 = imgs.slice(0, 5);
  out.页面含标题 = (document.body.innerText || '').indexOf('宋雨琦') >= 0;
  return out;
})()`;

const { post: httpPost } = require('./lib/http');
function post(p, body, t) { return httpPost(p, body, { timeout: t || 150000 }); }
function shot(file) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port: 8093, path: '/api/agent/screenshot', headers: { 'x-api-key': KEY } }, (res) => {
      if (res.statusCode !== 200) return reject(new Error('HTTP ' + res.statusCode));
      const chunks = []; res.on('data', c => chunks.push(c));
      res.on('end', () => { fs.writeFileSync(file, Buffer.concat(chunks)); resolve(fs.statSync(file).size); });
    }).on('error', reject);
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const all = [];
  for (const id of IDS) {
    console.log('\n════ ' + id + ' ════');
    await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/item?id=' + id + '"; "nav"' }, 90000);
    await sleep(13000);
    const res = await post('/api/agent/eval-on-store', { store: STORE, code: CODE }, 150000);
    if (!res.ok) { console.log('  ❌ ' + JSON.stringify(res).slice(0, 200)); continue; }
    const r = res.result || {};
    console.log('  页面标题: ' + r.docTitle);
    console.log('  图片数=' + r.图片数 + '   主图加载成功=' + (r.主图加载成功 ? '✅' : '❌'));
    if (r.主图) console.log('  主图: ' + r.主图.natW + 'x' + r.主图.natH + '  显示 ' + r.主图.dispW + 'x' + r.主图.dispH + '\n        ' + r.主图.src);
    const f = path.join(OUT, id + '.png');
    try { const kb = await shot(f); console.log('  截图: ' + path.basename(f) + '  ' + Math.round(kb / 1024) + ' KB'); }
    catch (e) { console.log('  截图失败: ' + e.message); }
    all.push({ id, 主图加载成功: r.主图加载成功, 主图: r.主图, 截图: f });
  }
  fs.writeFileSync(path.join(OUT, '_report.json'), JSON.stringify(all, null, 2), 'utf8');
  console.log('\n════ 汇总 ════');
  all.forEach(x => console.log('  ' + x.id + '  主图' + (x.主图加载成功 ? '✅' : '❌') + '  ' + (x.主图 ? x.主图.natW + 'x' + x.主图.natH : '-')));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
