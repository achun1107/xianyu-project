// read-msgs.js —— 读擦亮后台的消息中心
(async () => {
  const m = window.lib.mtop;
  const scal = o => { const z = {}; for (const k in (o || {})) { const v = o[k]; if (v !== null && ['string', 'number', 'boolean'].indexOf(typeof v) >= 0) z[k] = v; } return z; };
  const out = { 时刻: new Date().toLocaleString('zh-CN') };
  try {
    const r = await m.request({ api: 'mtop.taobao.idle.ad.message.list', v: '1.0', type: 'POST',
      data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 30 }) } });
    out.ret = (r.ret || [])[0];
    const d = (r.data || {}).result || r.data || {};
    const list = d.list || d.messageList || d.records || [];
    out.条数 = list.length;
    out.消息 = list.map(x => ({ 时间: x.gmtCreate || x.createTime || x.time, 标题: x.title || x.subject, 内容: String(x.content || x.message || '').slice(0, 200), 已读: x.readStatus || x.isRead, 类型: x.type || x.messageType }));
  } catch (e) { out.错误 = String((e && e.message) || e); }
  return JSON.stringify(out, null, 1);
})()
