/**
 * gen-with-poster-prompt.js — 端到端：用中台版式的 prompt + 任意底图出图
 *
 * 结论依据（已实测）：
 *   - `museav gen --template <版式id>` ❌ 报「模板不存在或已停用」
 *     → gen --template 只认 museav templates（图片模板），不认 poster-templates（版式）
 *   - `museav gen --ref <图>` ✅ 垫图上传成功
 *   → 所以中台版式的用法必然是：把版式的 prompt 占位符替换掉，配一张垫图，直接 gen --prompt
 *     —— 这也正是网页端在做的事。
 *
 * 这个脚本同时验证用户要的「三类底图来源」：只换 --ref 就能换底图
 *      (a) 大麦搜的官方海报  (b) 中台出的图  (c) 用户上传的图
 *
 * 用法：node gen-with-poster-prompt.js <底图路径> [--tpl=<版式id或名字片段>] [--city=杭州] [--star=那英]
 *   不传 --tpl 用下面的 TPL_ID 兜底。
 *   ⚠️ 版式清单会变（老板 2026-10-11 一次就加了 10 个），所以版式必须能按名字挑，不能只写死 id。
 *      列版式：museav poster-templates
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { ROOT, MIDDLE, NODE: ENV_NODE } = require('./lib/env');

const NODE = ENV_NODE.path;
const CLI  = ENV_NODE.museavCli;
const KEY  = MIDDLE.key;
const TPL_ID = '396f670d-d969-422a-afdb-f72844126aac';
const argOf = (n) => { const a = process.argv.find((x) => x.startsWith('--' + n + '=')); return a ? a.slice(n.length + 3) : null; };
const CITY = argOf('city') || '杭州', STAR = argOf('star') || '那英';
const WANT_TPL = argOf('tpl') || TPL_ID;
const OUT = path.join(ROOT, '中台版式');

const REF = process.argv.slice(2).find((a) => a.indexOf('--') !== 0) || path.join(ROOT, '主图筛选-那英杭州/_干净底图.jpg');

(async () => {
  if (!fs.existsSync(REF)) { console.log('❌ 底图不存在: ' + REF); process.exit(1); }

  // ── 1. 取版式的 prompt ──
  const r = await fetch('https://manager.museav.top/api/poster-templates', { headers: { 'X-API-Key': KEY } });
  const j = await r.json();
  const arr = Array.isArray(j) ? j : (j.items || j.data || []);
  // 先按 id 精确匹配，再按名字片段匹配 —— 名字匹配到多个就报错让你写清楚，不猜
  let tpl = arr.find(t => String(t.id) === String(WANT_TPL));
  if (!tpl) {
    const hit = arr.filter(t => String(t.name || '').indexOf(WANT_TPL) >= 0);
    if (hit.length > 1) { console.log('❌ 版式名「' + WANT_TPL + '」匹配到 ' + hit.length + ' 个: ' + hit.map(t => t.name).join(' / ') + ' —— 写全一点'); process.exit(1); }
    tpl = hit[0];
  }
  if (!tpl) { console.log('❌ 中台找不到版式 ' + WANT_TPL); process.exit(1); }

  // ── 2. 占位符替换（网页端也是这么干的）──
  const prompt = String(tpl.prompt).split('{城市}').join(CITY).split('{明星}').join(STAR);

  console.log('版式: ' + tpl.name + '  (' + tpl.id + ')');   // ⚠️ 原来这里打的是常量 TPL_ID，不是匹配到的那条 —— 日志说 A 做 B
  console.log('底图: ' + REF + '  ' + Math.round(fs.statSync(REF).size / 1024) + ' KB');
  console.log('\n替换后的 prompt:\n  ' + prompt + '\n');

  // ── 3. 出图 ──
  const args = ['gen', '--prompt', prompt, '--ref', REF, '--ratio', '3:4'];
  console.log('执行: museav gen --prompt <上> --ref <上> --ratio 3:4\n');
  let out;
  try {
    out = execFileSync(NODE, [CLI].concat(args), { encoding: 'utf8', timeout: 600000, maxBuffer: 8 * 1024 * 1024 });
  } catch (e) {
    out = String(e.stdout || '') + '\n' + String(e.stderr || '');
    console.log(out.trim());
    console.log('\n❌ 出图失败'); process.exit(1);
  }
  console.log(out.trim());

  // ── 4. 提取【出图结果】URL —— 必须排掉垫图上传返回的那个 URL ──
  const lines = out.split(/\r?\n/);
  const refUrls = new Set();
  lines.forEach(l => { if (/垫图|图片1\s*就绪/.test(l)) (l.match(/https?:\/\/\S+/g) || []).forEach(u => refUrls.add(u)); });
  const all = (out.match(/https?:\/\/[^\s"']+\.(?:png|jpe?g|webp)/gi) || []);
  const resultUrls = all.filter(u => !refUrls.has(u));
  const url = resultUrls.length ? resultUrls[resultUrls.length - 1] : null;

  console.log('\n垫图 URL（不算结果）: ' + (Array.from(refUrls).join(', ') || '无'));
  if (!url) { console.log('❌ 没解析到出图结果 URL'); process.exit(1); }
  console.log('✅ 出图结果: ' + url);

  fs.mkdirSync(OUT, { recursive: true });
  const dest = path.join(OUT, '端到端-' + String(tpl.name || '版式').replace(/[\\/:*?"<>|]/g, '_') + '-' + CITY + STAR + '.png');
  fs.writeFileSync(dest, Buffer.from(await (await fetch(url)).arrayBuffer()));
  console.log('   已存: ' + dest + '  ' + Math.round(fs.statSync(dest).size / 1024) + ' KB');
})().catch(e => { console.log('❌ ' + (e && e.stack || e)); process.exit(1); });
