/**
 * shot-items.js — 逐条把 agent.page 导航到商品页并截图（用于肉眼确认渲染）
 *
 * 为什么不用 /api/agent/eval-on-store 配截图：
 *   eval-on-store 操作的是 stores[store].pages.goofish（闲鱼标签页），
 *   而 /api/agent/screenshot 截的是 agent.page（大柚广告页）—— 两个不同的标签页，会截错。
 *   /api/agent/navigate 才是操作 agent.page 的，所以用它。
 *
 * 跑完会把 agent.page 导航回大柚广告页，不影响广告脚本。
 */
const fs = require('fs'); const http = require('http'); const path = require('path');
const { SVC } = require('./lib/env');   // 【密钥外置】由 tools/dedupe-api-key.js 插入
const KEY = SVC.apiKey;
const IDS = process.argv.slice(2).filter(x => /^\d+$/.test(x));
const OUT = path.join(__dirname, '渲染确认');
fs.mkdirSync(OUT, { recursive: true });
const AD = 'https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage';

function post(p, body, t) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => resolve(b.slice(0, 200))); });
    req.on('error', reject); req.setTimeout(t || 90000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}
function get(p) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port: 8093, path: p, headers: { 'x-api-key': KEY } }, (res) => {
      const ch = []; res.on('data', c => ch.push(c));
      res.on('end', () => resolve({ status: res.statusCode, buf: Buffer.concat(ch) }));
    }).on('error', reject);
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  for (const id of IDS) {
    const url = 'https://www.goofish.com/item?id=' + id;
    console.log('\n════ ' + id + ' ════');
    console.log('  导航: ' + (await post('/api/agent/navigate', { url: url }, 90000)).slice(0, 120));
    await sleep(9000);
    const f = path.join(OUT, id + '.png');
    const r = await get('/api/agent/screenshot');
    if (r.status !== 200) { console.log('  截图失败 HTTP ' + r.status + '  ' + r.buf.toString('utf8').slice(0, 150)); continue; }
    fs.writeFileSync(f, r.buf);
    console.log('  截图: ' + path.basename(f) + '  ' + Math.round(r.buf.length / 1024) + ' KB');
  }
  // 收尾：把 agent.page 导航回广告页
  console.log('\n收尾：导航回广告页');
  console.log('  ' + (await post('/api/agent/navigate', { url: AD }, 90000)).slice(0, 120));
  console.log('\n截图目录: ' + OUT);
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
