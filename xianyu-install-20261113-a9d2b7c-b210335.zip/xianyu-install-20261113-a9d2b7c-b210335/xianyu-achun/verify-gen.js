/**
 * verify-gen.js — 批量验证 gen-copy.js：在所有真实「明星×城市」上跑，检查标题长度与要素覆盖
 */
const { execFileSync } = require('child_process');
const path = require('path');
const NODE = process.execPath;
const GEN = path.join(__dirname, 'gen-copy.js');

const STARS = ['那英', '许嵩', '张杰', '徐良', '刘宇', '断眉', '周深', '周杰伦', '孙燕姿', '王力宏',
  '刘宪华', '汪苏泷', '华晨宇', '宋雨琦', '侯明昊', '陈都灵', '熊艺文', 'Capper', '凤凰传奇', '易烊千玺'];
const CITIES = ['杭州', '北京', '呼和浩特', '乌鲁木齐', '三亚', '成都', '常州', '石家庄'];

const rows = [];
for (const s of STARS) for (const c of CITIES) {
  let out;
  try {
    out = execFileSync(NODE, [GEN, '--star', s, '--cities', c, '--type', '演唱会', '--len', 'mid'],
      { encoding: 'utf8', maxBuffer: 1 << 20 });
  } catch (e) { rows.push({ s, c, err: e.message }); continue; }
  const title = (out.split(/\r?\n/).find(l => /^【/.test(l)) || '').trim();
  const fullLen = (out.match(/全文 (\d+) 字/) || [])[1];
  const failed = [];
  if (title.length > 30) failed.push('超30(' + title.length + ')');
  if (title.indexOf(s) < 0) failed.push('无明星');
  if (title.indexOf(c) < 0) failed.push('无城市');
  if (title.indexOf('演唱会') < 0) failed.push('无活动类型');
  if (!/代拍|代抢/.test(title)) failed.push('无代拍');
  if (title.length < 28) failed.push('欠填(' + title.length + ')');
  if (!/(20%|20％)/.test(out) || !/(40%|40％)/.test(out)) failed.push('无手续费条款');
  rows.push({ s, c, len: title.length, fullLen, title, failed });
}

const bad = rows.filter(r => r.err || r.failed.length);
console.log('测试组合: ' + rows.length + '   通过: ' + (rows.length - bad.length) + '   失败: ' + bad.length);
const lens = rows.filter(r => r.len).map(r => r.len);
console.log('标题长度: 最短 ' + Math.min(...lens) + '  最长 ' + Math.max(...lens) + '  平均 ' + (lens.reduce((a, b) => a + b, 0) / lens.length).toFixed(1));
const fulls = rows.filter(r => r.fullLen).map(r => +r.fullLen);
console.log('全文长度: 最短 ' + Math.min(...fulls) + '  最长 ' + Math.max(...fulls) + '  平均 ' + (fulls.reduce((a, b) => a + b, 0) / fulls.length).toFixed(0));

if (bad.length) {
  console.log('\n❌ 未通过的组合:');
  bad.forEach(r => console.log('  ' + r.s + ' / ' + r.c + '  → ' + (r.err || r.failed.join(',')) + '   「' + (r.title || '') + '」'));
} else {
  console.log('\n✅ 全部组合：标题 ≤30 字、≥28 字（填满）、要素齐全、手续费条款在正文');
}
console.log('\n抽样:');
[['那英', '杭州'], ['许嵩', '成都'], ['Capper', '呼和浩特'], ['凤凰传奇', '北京'], ['刘宪华', '常州']].forEach(([s, c]) => {
  const r = rows.find(x => x.s === s && x.c === c);
  if (r) console.log('  ' + s + '/' + c + '  ' + r.len + '字  ' + r.title);
});
