(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const out = { url: location.href, title: document.title };
  out.trs = document.querySelectorAll('tbody tr').length;
  out.tabs = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn')).map(e => (e.innerText || '').replace(/\s+/g, ' ').trim()).slice(0, 6);
  out.body = (document.body.innerText || '').replace(/[ \t]+/g, ' ').slice(0, 700);
  out.hasTable = !!document.querySelector('.ant-table');
  out.pagination = document.querySelectorAll('.ant-pagination-item').length;
  return JSON.stringify(out, null, 1);
})()
