const { userIdOf } = require('./lib/user-id');
const USER_ID = userIdOf();   // 在 Node 侧求值，模板里用 ${JSON.stringify(USER_ID)} 传下去
// find-new-group.js —— 找标题含 南京/wuuhaa 的商品，并查它们的投放资格
(async () => {
  const mtop = window.lib.mtop;
  const num = v => { const n = Number(v); return isFinite(n) ? n : 0; };

  // A. 商品列表（全部）
  const API = 'mtop.idle.web.xyh.item.list';
  const BASE = { needGroupInfo: false, userId: USER_ID, pageSize: 20, groupName: '综合', groupId: 52785096, defaultGroup: true };
  const items = {};
  for (let p = 1; p <= 12; p++) {
    let r;
    try { r = await mtop.request({ api: API, v: '1.0', type: 'POST', data: Object.assign({}, BASE, { pageNumber: p }) }); } catch (e) { break; }
    if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0)) break;
    const cards = (r.data && r.data.cardList) || [];
    if (!cards.length) break;
    let added = 0;
    cards.forEach(c => {
      const cd = c.cardData || {};
      const id = String(cd.id || '');
      if (!id || items[id]) return;
      added++;
      const hits = [];
      const walk = o => { if (!o || typeof o !== 'object') return; if (Array.isArray(o)) return o.forEach(walk); if (typeof o.content === 'string') hits.push(o.content); Object.keys(o).forEach(k => walk(o[k])); };
      walk(cd.itemLabelDataVO);
      let want = null, pubAgo = null;
      hits.forEach(t => { let m; if ((m = t.match(/^(\d+)人想要$/))) want = Math.max(want || 0, parseInt(m[1], 10)); else if (/小时内发布|一周内发布|天内发布/.test(t)) pubAgo = t; });
      items[id] = { itemId: id, 标题: String(cd.title || '').slice(0, 60), 价格: cd.priceInfo ? num(cd.priceInfo.price) : null, 状态: cd.itemStatus, 想要: want, 发布时效: pubAgo };
    });
    if (!added) break;
  }

  // B. 可投放池
  const ir = await mtop.request({ api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, tab: 'all', needTabs: true }) } });
  const adv = ((ir.data || {}).result || {}).itemList || [];
  const advIds = {}; adv.forEach(it => advIds[String(it.itemId)] = it);

  const key = /南京|wuuhaa|wuhaa|呜哈|伍哈/i;
  const hit = Object.values(items).filter(x => key.test(x.标题));
  return JSON.stringify({
    时刻: new Date().toLocaleString('zh-CN'),
    商品总数: Object.keys(items).length,
    可投放总数: adv.length,
    '命中南京/wuuhaa': hit.map(x => ({
      ...x,
      可投放: !!advIds[x.itemId],
      supportAd: advIds[x.itemId] ? advIds[x.itemId].supportAd : null,
      tags: advIds[x.itemId] ? advIds[x.itemId].tags : null,
      notSupport: advIds[x.itemId] ? advIds[x.itemId].notSupportAdInfo : null,
    })),
    // 兜底：列出所有「小时内发布」的（可能是刚上架的）
    最近上架: Object.values(items).filter(x => x.发布时效 && /小时/.test(x.发布时效)).map(x => x.itemId + ' | ' + x.发布时效 + ' | ' + x.标题.slice(0, 34)),
  }, null, 1);
})()
