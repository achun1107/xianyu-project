// 判定脚本：用 @deepseek-ai/dsh-client-modules 自己的解析规则，检查两个插件的
// dsh.client 声明在此安装中能否解析成功。纯只读，不加载插件、不改任何状态。
//
// 复刻自 dsh-client-modules/lib/index.js 的 parseDshClient + clientExportOf 行为。

import { createRequire } from 'node:module'
import { readFileSync, existsSync } from 'node:fs'
import { join, dirname, isAbsolute } from 'node:path'

const profileDir = process.argv[2]
if (!profileDir) {
  console.error('用法: node check-client-decl.mjs <profile目录>')
  process.exit(2)
}

const require = createRequire(join(profileDir, 'noop.js'))

const rows = ['dsh-llm-hub', '@kubor/dsh-bloom-theme']

function clientExportOf(pkgName, exportsField) {
  if (exportsField === undefined || exportsField === null) return undefined
  const entry = exportsField['./client']
  if (entry === undefined) return undefined
  if (typeof entry === 'string') return entry
  if (entry && typeof entry === 'object' && typeof entry.default === 'string') return entry.default
  return undefined
}

const report = []

for (const row of rows) {
  const item = { row }

  // 1) 行名能否解析到 package.json —— 与 loader 的解析同源
  let pkgPath
  try {
    pkgPath = require.resolve(`${row}/package.json`)
    item.pkgResolved = pkgPath
  } catch (error) {
    item.pkgResolved = null
    item.error = `无法解析 ${row}/package.json: ${error.message}`
    report.push(item)
    continue
  }

  // 2) 读 dsh.client 声明
  let pkg
  try {
    pkg = JSON.parse(readFileSync(pkgPath, 'utf8'))
  } catch (error) {
    item.error = `package.json 解析失败: ${error.message}`
    report.push(item)
    continue
  }

  const decl = pkg.dsh && typeof pkg.dsh === 'object' ? pkg.dsh.client : undefined
  item.declaration = decl ?? null

  if (decl === undefined || decl === null) {
    item.error = '未声明 dsh.client —— 客户端半不会被扫描到'
    report.push(item)
    continue
  }
  if (decl.platform !== 'web') {
    item.error = `platform=${decl.platform}，不是 web —— 会被跳过`
    report.push(item)
    continue
  }

  // 3) 解析 exports["./client"] 指向的实体文件
  const clientRel = clientExportOf(row, pkg.exports)
  if (clientRel === undefined) {
    item.error = '声明了 dsh.client 但 exports 没有 "./client" —— 会抛错'
    report.push(item)
    continue
  }
  const clientAbs = join(dirname(pkgPath), clientRel)
  item.clientPath = clientAbs
  item.clientExists = existsSync(clientAbs)
  if (item.clientExists) {
    item.clientBytes = readFileSync(clientAbs).length
  }

  // 4) 声明了 inject 的包，检查被注入方是否也存在
  if (Array.isArray(decl.inject) && decl.inject.length > 0) {
    item.injectResolutions = decl.inject.map((name) => {
      try {
        return { name, resolved: require.resolve(`${name}/package.json`) }
      } catch (error) {
        return { name, resolved: null, error: error.message }
      }
    })
  }

  item.verdict = item.clientExists ? '可解析：声明与产物都正常' : '产物缺失：扫描时会抛错'
  report.push(item)
}

console.log(JSON.stringify(report, null, 2))
