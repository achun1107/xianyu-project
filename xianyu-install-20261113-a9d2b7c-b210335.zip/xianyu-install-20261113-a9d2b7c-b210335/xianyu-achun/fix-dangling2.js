// fix-dangling2.js —— 从计划里摘掉悬空宝贝并保存；预算【只校验不写】
// 与 ad-fix-dangling.js 的区别：不在摘除后重渲染的间隙去写预算（那时槽位显示占位文案「自定义」），
// 而是等它渲染出真实数值后只做核对，不符就中止（fail-closed），避免静默改预算。
// cfg = window.__RBCFG = [{ planName, planId, removeTitles:[], budget }]
(async () => {
  const PLANS = window.__RBCFG || [];
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const setNative = (el, v) => { const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value'); d.set.call(el, String(v)); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  const drawers = () => [].slice.call(document.querySelectorAll('.ant-drawer-content')).filter(d => d.getBoundingClientRect().width > 200);
  const outer = () => drawers().find(d => /编辑计划/.test(d.innerText || ''));
  const titles = od => [].slice.call(od.querySelectorAll('[class*=goodsTitle]')).map(e => (e.innerText || '').trim());
  const out = [];

  for (const cfg of PLANS) {
    const R = { plan: cfg.planName };
    try {
      const idFilter = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
      if (idFilter && String(idFilter.value || '').trim() !== '') {
        setNative(idFilter, ''); await sleep(600);
        idFilter.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
        await sleep(3500);
      }
      const planTab = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn')).find(e => /^计划\(\d+\)$/.test((e.innerText || '').trim()));
      if (planTab) { click1(planTab); await sleep(4000); }
      const box = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
      if (box) {
        setNative(box, String(cfg.planId)); await sleep(700);
        box.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
        await sleep(5000);
        R.已按ID筛选 = String(cfg.planId);
      }
      const findRow = () => [].slice.call(document.querySelectorAll('tbody tr')).find(r => (r.innerText || '').indexOf(cfg.planName) >= 0);
      let row = null;
      for (let i = 0; i < 12 && !row; i++) { await sleep(1000); row = findRow(); }
      if (!row) throw new Error('找不到计划行');
      click1([].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑'));
      let od = null;
      for (let i = 0; i < 20; i++) { await sleep(1000); od = outer(); if (od && od.querySelector('[class*=goodsTitle]')) break; }
      if (!od) throw new Error('编辑抽屉没打开');
      R.修改前 = titles(od);

      let removed = 0;
      for (let pass = 0; pass < 6; pass++) {
        const items = [].slice.call(od.querySelectorAll('[class*=goodsItem]'));
        let hit = null;
        for (const it of items) {
          const t = ((it.querySelector('[class*=goodsTitle]') || {}).innerText || '').trim();
          if (cfg.removeTitles.indexOf(t) >= 0) { hit = it.querySelector('[class*=clearItemBtn]'); break; }
        }
        if (!hit) break;
        click1(hit); removed++; await sleep(2800);
        od = outer() || od;
      }
      R.已摘掉 = removed;
      od = outer() || od;
      R.修改后 = titles(od);
      R.badge = ((od.innerText || '').match(/已选宝贝\(([^)]*)\)/) || [])[1];
      if (removed === 0) throw new Error('没摘到任何宝贝');

      // ── 预算：等它渲染出真实数值，只核对，不写 ──
      const getGrp = () => od.querySelector('[class*=radioGroup--eEugUXoZ]')
        || [].slice.call(od.querySelectorAll('div')).filter(d => /自定义|¥\s*\d/.test(d.innerText || '') && d.querySelectorAll('[class*=radio--]').length >= 2).sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length)[0];
      let slots = [], lastTxt = '', waited = 0;
      for (let i = 0; i < 40; i++) {
        od = outer() || od;
        const grp = getGrp();
        slots = grp ? [].slice.call(grp.querySelectorAll('[class*=radio--]')) : [];
        lastTxt = slots.length ? (slots[slots.length - 1].innerText || '').trim() : '';
        if (/^¥\s*\d/.test(lastTxt)) break;
        await sleep(1000); waited++;
      }
      R.等待预算渲染秒 = waited;
      R.预算档位 = slots.map(e => (e.innerText || '').trim());
      R.预算末槽 = lastTxt;
      const want = '¥' + cfg.budget;
      if (cfg.budget && lastTxt !== want) {
        throw new Error('预算末槽="' + lastTxt + '" 期望 "' + want + '"（可能还没渲染出来），未保存');
      }
      R.预算核对 = '✅ ' + lastTxt + '（未改动）';

      const wrap = od.closest('.ant-drawer');
      const foot = wrap && wrap.querySelector('.ant-drawer-footer');
      const ok = foot && [].slice.call(foot.querySelectorAll('div,span,button')).find(e => e.children.length === 0 && /^确\s*定$/.test((e.innerText || '').trim()));
      if (!ok) throw new Error('找不到外层确定');
      click1(ok);
      R.已保存 = true;
      await sleep(7000);
      R.提示 = ((document.body.innerText || '').match(/[^\n]*(成功|失败|错误|不能|至少)[^\n]*/g) || []).slice(0, 3);
      R.抽屉已关 = !outer();
    } catch (e) { R.fatal = e.message; }
    out.push(R);
    await sleep(2000);
  }
  return JSON.stringify(out, null, 1);
})()
