/**
 * probe-offshelf-btn.js — 导航到商品页并探测「下架」按钮（不点击）
 * 用法: node probe-offshelf-btn.js <itemId>
 */
const fs = require('fs');
const http = require('http');
const path = require('path');
const { SVC, STORE } = require('./lib/env');
const KEY = SVC.apiKey;
const ID = process.argv[2];
if (!ID) { console.log('用法: node probe-offshelf-btn.js <itemId>'); process.exit(2); }
const CODE = fs.readFileSync(path.join(__dirname, '_probe-offshelf-btn.js'), 'utf8');

function post(p, body, t) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 300))); } }); });
    req.on('error', reject); req.setTimeout(t || 120000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}
(async () => {
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/item?id=' + ID + '"; "nav"' }, 90000);
  await new Promise(z => setTimeout(z, 11000));
  const res = await post('/api/agent/eval-on-store', { store: STORE, code: CODE }, 120000);
  console.log(JSON.stringify(res, null, 1));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
