// reveal-and-dump.js —— 只读：① 看「商品异常暂停」有哪些计划 ② 打开 96129660 看宝贝标题
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { if (!e) return false; const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 10 && r.height > 10 && s.display !== 'none' && s.visibility !== 'hidden'; };
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const setNative = (el, v) => { const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value'); d.set.call(el, String(v)); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  async function pickStatus(label) {
    const s = [].slice.call(document.querySelectorAll('.ant-select')).filter(e => vis(e) && /擦亮状态|已暂停|商品异常暂停|擦亮中|擦亮完成/.test((e.innerText || '').trim()))[0];
    if (!s) return '找不到筛选器';
    const c = s.querySelector('.ant-select-selector') || s;
    c.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); await sleep(300); click1(c); await sleep(1500);
    const dd = [].slice.call(document.querySelectorAll('.ant-select-dropdown')).filter(vis).pop();
    const o = dd && [].slice.call(dd.querySelectorAll('.ant-select-item-option')).find(e => (e.innerText || '').trim() === label);
    if (!o) { document.body.click(); await sleep(500); return '没找到选项 ' + label; }
    click1(o); await sleep(4500); return '已选 ' + label;
  }
  async function filterId(id) {
    const box = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
    if (!box) return '无ID框';
    setNative(box, id); await sleep(700);
    box.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
    await sleep(5000); return '已筛 ' + id;
  }
  function rows() { return [].slice.call(document.querySelectorAll('tbody tr')).map(r => (r.innerText || '').replace(/\n+/g, ' | ').slice(0, 150)); }
  function planRows() {
    return [].slice.call(document.querySelectorAll('tbody tr')).map(r => {
      const m = (r.innerText || '').match(/\t(\d{8})\t\s*([^\t\n]+)/);
      return m ? { id: m[1], name: m[2].trim(), 可编辑: !!([].slice.call(r.querySelectorAll('span,a,button')).find(x => (x.innerText || '').trim() === '编辑')) } : null;
    }).filter(Boolean);
  }

  const out = {};
  const tab = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn')).find(e => /^计划\(/.test((e.innerText || '').trim()));
  if (tab) { click1(tab); await sleep(4000); }

  // ① 商品异常暂停
  out.切商品异常暂停 = await pickStatus('商品异常暂停');
  await sleep(2000);
  out.商品异常暂停的计划 = planRows();
  out.该档行样本 = rows().slice(0, 4);

  // ② 切回擦亮中，筛 96129660，开编辑抽屉
  out.切擦亮中 = await pickStatus('擦亮中');
  await sleep(2000);
  out.筛96129660 = await filterId('96129660');
  const pr = planRows();
  out.找到96129660 = pr.find(x => x.id === '96129660') || null;
  const tr = [].slice.call(document.querySelectorAll('tbody tr')).find(r => (r.innerText || '').indexOf('96129660') >= 0);
  if (!tr) { out.err = '表格里没有 96129660 的行'; return JSON.stringify(out, null, 1); }
  click1([].slice.call(tr.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑'));
  let od = null;
  for (let i = 0; i < 18; i++) {
    await sleep(1000);
    od = [].slice.call(document.querySelectorAll('.ant-drawer-content')).filter(d => d.getBoundingClientRect().width > 200).find(d => /编辑计划/.test(d.innerText || ''));
    if (od && od.querySelector('[class*=goodsTitle]')) break;
  }
  if (!od) { out.err = '编辑抽屉没打开'; out.行文字 = (tr.innerText || '').slice(0, 200); return JSON.stringify(out, null, 1); }
  out.已选宝贝badge = ((od.innerText || '').match(/已选宝贝\(([^)]*)\)/) || [])[1];
  const items = [].slice.call(od.querySelectorAll('[class*=goodsItem]'));
  out.宝贝数 = items.length;
  out.宝贝 = items.map(it => ({
    标题: ((it.querySelector('[class*=goodsTitle]') || {}).innerText || '').trim(),
    有移除按钮: !!it.querySelector('[class*=clearItemBtn]'),
  }));
  out.抽屉片段 = (od.innerText || '').replace(/\n+/g, ' | ').slice(0, 500);
  const wrap = od.closest('.ant-drawer');
  const close = wrap && wrap.querySelector('.ant-drawer-close');
  if (close) { click1(close); await sleep(2500); }
  out.已关抽屉 = true;
  return JSON.stringify(out, null, 1);
})()
