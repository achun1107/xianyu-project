/**
 * final-check.js — 收尾总验证：生成器 full 档正文 与 线上模板 descPattern 是否逐字一致
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

const NODE = process.execPath;
const GEN = path.join(__dirname, 'gen-copy.js');

const out = execFileSync(NODE, [GEN, '--star', '那英', '--cities', '杭州', '--len', 'full'],
  { encoding: 'utf8', maxBuffer: 1 << 20 });
// 取"提交用完整文案"之后的正文（去掉第一行标题）
const seg = out.split('══════ 提交用完整文案 ══════')[1].split('─'.repeat(20))[0].trim();
const genLines = seg.split(/\r?\n/).slice(1).map(s => s.trim()).filter(Boolean);

const TPL = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.xianyu-templates.json'), 'utf8'));
const tplLines = TPL.templates[0].descPattern.split(/\r?\n/).map(s => s.trim());

console.log('生成器 full 档正文行数: ' + genLines.length);
console.log('线上模板 descPattern 行数: ' + tplLines.length);
console.log('两个模板 descPattern 是否一致: ' + (TPL.templates[0].descPattern === TPL.templates[1].descPattern));
console.log('');

const n = Math.max(genLines.length, tplLines.length);
let diff = 0;
for (let i = 0; i < n; i++) {
  const a = genLines[i] || '(缺)', b = tplLines[i] || '(缺)';
  const same = a === b;
  if (!same) diff++;
  console.log((same ? '  ✅ ' : '  ❌ ') + (i + 1) + ' | ' + a + (same ? '' : '\n       线上: ' + b));
}
console.log('');
console.log(diff === 0
  ? '✅ 生成器 full 档 与 线上模板正文 逐行逐字完全一致（已统一）'
  : '❌ 有 ' + diff + " 行不一致");

// 长度对照
const DIST = [];
for (const f of ['xy-scan-result-0-7.json', 'xy-scan-result-7-14.json']) {
  try { JSON.parse(fs.readFileSync(path.join(__dirname, f), 'utf8')).forEach(s => (s.top || [])
    .forEach(t => { if (t.判定 === '代拍' && t.全文字数) DIST.push(t.全文字数); })); } catch (e) { }
}
DIST.sort((a, b) => a - b);
const pct = n => DIST.length ? (DIST.filter(x => x <= n).length / DIST.length * 100).toFixed(0) + '%' : '-';
console.log('\n长度对照（同行 n=' + DIST.length + '，最长 ' + DIST[DIST.length - 1] + '）:');
console.log('  旧模板1 正文 244 → 全文 276  ' + pct(276) + ' 分位  ❌ 超出同行最长');
console.log('  旧模板2 正文 249 → 全文 281  ' + pct(281) + ' 分位  ❌ 超出同行最长');
console.log('  统一后  正文 ' + TPL.templates[0].descPattern.length + ' → 全文 ' + (30 + 2 + TPL.templates[0].descPattern.length) + '  ' + pct(30 + 2 + TPL.templates[0].descPattern.length) + ' 分位  ✅ 在范围内');
