// diag-entity.js —— 倒出计划里 entityList 的每个字段，找异常标记
(async () => {
  const m = window.lib.mtop;
  const cr = await m.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
  const list = ((cr.data || {}).result) || [];
  const want = ['北京陈都灵-咨询120', '成都熊艺文-咨询120', '南京wuuhaha-咨询120'];
  const scal = o => { const z = {}; for (const k in (o || {})) { const v = o[k]; if (v !== null && ['string', 'number', 'boolean'].indexOf(typeof v) >= 0) z[k] = v; } return z; };
  return JSON.stringify({
    时刻: new Date().toLocaleString('zh-CN'),
    计划: list.filter(c => want.indexOf(c.title) >= 0).map(c => ({
      id: c.campaignId, name: c.title, pause: c.pauseStatus, group: c.statusGroup, 说明: c.statusDescTitle,
      statusDescCode: c.statusDescCode,
      entityList: (c.entityList || []).map(e => scal(e)),
      infoTab: scal(c.infoTab || {}),
      extraFunctions: scal(c.extraFunctions || {}),
    })),
  }, null, 1);
})()
