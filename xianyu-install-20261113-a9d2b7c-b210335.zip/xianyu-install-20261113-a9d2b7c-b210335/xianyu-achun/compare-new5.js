// compare-new5.js —— 对比 5 条新场次计划的状态
(async () => {
  const m = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const cr = await m.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
  const list = ((cr.data || {}).result) || [];
  const want = ['凤凰传奇北京-咨询120', '李大奔广州-咨询120', '南京wuuhaha-咨询120', '北京陈都灵-咨询120', '成都熊艺文-咨询120'];
  const rows = list.filter(c => want.indexOf(c.title) >= 0).map(c => ({
    名称: c.title, id: c.campaignId, 状态码: c.statusDescCode, 说明: c.statusDescTitle || '-',
    group: c.statusGroup, 花费: n((c.infoTab || {}).todayCost) / 100,
    曝光: n((c.todayAdDataDetail || {}).showPv),
    建于: c.startTime,
    宝贝: (c.entityList || []).length,
  }));
  return JSON.stringify({ 时刻: new Date().toLocaleString('zh-CN'), 计划: rows, 全店: { 计划数: list.length, 在跑: list.filter(c => c.statusGroup === 'online').length, 暂停: list.filter(c => String(c.pauseStatus) === '1').length } }, null, 1);
})()
