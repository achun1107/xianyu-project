// probe-status-dom.js —— 挖后台状态列的细节，找平台自己给的异常说明
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const out = { 时刻: new Date().toLocaleString('zh-CN') };
  const findRow = n => [].slice.call(document.querySelectorAll('tbody tr')).find(r => (r.innerText || '').indexOf(n) >= 0);
  let row = findRow('北京陈都灵-咨询120');
  if (!row) {
    for (let p = 2; p <= 5 && !row; p++) {
      const pg = document.querySelector('.ant-pagination');
      const b = pg && [].slice.call(pg.querySelectorAll('.ant-pagination-item')).find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === String(p));
      if (!b) break;
      click1(b); await sleep(3200); row = findRow('北京陈都灵-咨询120');
    }
  }
  out.找到行 = !!row;
  if (!row) return JSON.stringify(out, null, 1);
  out.整行 = (row.innerText || '').replace(/\s+/g, ' ').slice(0, 300);

  // 状态单元格：找含「状态异常」字样的叶子，往上找单元格
  const leaf = [].slice.call(row.querySelectorAll('*')).find(e => e.children.length === 0 && /状态异常/.test(e.innerText || ''));
  out.状态叶子 = !!leaf;
  if (leaf) {
    let cell = leaf;
    for (let i = 0; i < 5 && cell.parentElement; i++) { cell = cell.parentElement; if (cell.tagName === 'TD') break; }
    out.状态单元格HTML = (cell.outerHTML || '').replace(/\s+/g, ' ').slice(0, 900);
    out.状态单元格内可点元素 = [].slice.call(cell.querySelectorAll('*'))
      .filter(e => e.children.length === 0)
      .map(e => ({ tag: e.tagName, txt: (e.innerText || '').trim().slice(0, 20), cls: String(e.className).slice(0, 50) })).slice(0, 12);
    // 试着点它，看会不会出气泡/弹窗
    click1(leaf); await sleep(2500);
    const tips = [].slice.call(document.querySelectorAll('.ant-tooltip, .ant-popover, .ant-modal-content, .ant-drawer-content'))
      .filter(e => e.getBoundingClientRect().width > 30)
      .map(e => (e.innerText || '').replace(/\s+/g, ' ').slice(0, 400));
    out.点击后弹出的内容 = tips.slice(0, 5);
    out.body新增 = (document.body.innerText || '').replace(/\s+/g, ' ').match(/.{0,60}状态异常.{0,160}/g);
  }
  return JSON.stringify(out, null, 1);
})()
