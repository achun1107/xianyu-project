/**
 * verify-publish-3.js — 用「发闲置」编辑页核对 3 个新链接的真实值
 * 编辑页是本项目唯一能看到「宝贝所在地 / 库存 / 价格」的地方（买家页不显示这些）。
 */
const fs = require('fs');
const http = require('http');
const path = require('path');
const { SVC, STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const IDS = process.argv.slice(2).filter(x => /^\d+$/.test(x));
if (!IDS.length) { console.log('用法: node verify-publish-3.js <itemId> [itemId...]'); process.exit(1); }

const PAGE_CODE = `(async () => {
  const out = { href: location.href, title: document.title };
  for (let i = 0; i < 25; i++) { if ((document.body.innerText || '').length > 400) break; await new Promise(r => setTimeout(r, 1000)); }
  const body = document.body.innerText || '';
  const pick = (label) => { const i = body.indexOf(label); return i >= 0 ? body.slice(i, i + 40).replace(/\\n/g, ' ') : null; };
  out.宝贝所在地 = pick('宝贝所在地');
  out.有没有杭州 = body.indexOf('杭州') >= 0;
  out.有没有泉州 = body.indexOf('泉州') >= 0;
  const inputs = [...document.querySelectorAll('input')];
  out.价格 = (inputs.find(e => e.placeholder === '0.00') || {}).value || null;
  out.库存 = (inputs.find(e => e.placeholder === '0') || {}).value || null;
  out.规格 = (inputs.find(e => e.placeholder === '请输入具体的代拍费') || {}).value || null;
  out.标题 = (body.match(/【[^】]+】[^\\n]{5,40}/) || [])[0] || null;
  return out;
})()`;

function post(p, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 300))); } }); });
    req.on('error', reject);
    req.setTimeout(timeoutMs || 180000, () => req.destroy(new Error('请求超时')));
    req.write(payload); req.end();
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const results = [];
  for (const id of IDS) {
    const url = 'https://www.goofish.com/publish?itemId=' + id;
    console.log('\n════ ' + id + ' ════');
    await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href=' + JSON.stringify(url) + '; "nav"' }, 90000);
    await sleep(14000);
    const res = await post('/api/agent/eval-on-store', { store: STORE, code: PAGE_CODE }, 180000);
    if (!res.ok) { console.log('  ❌ ' + JSON.stringify(res).slice(0, 260)); results.push({ id, ok: false }); continue; }
    const r = res.result || {};
    console.log('  宝贝所在地: ' + (r.宝贝所在地 || '(没读到)'));
    console.log('  标题      : ' + (r.标题 || '(没读到)'));
    console.log('  价格      : ' + r.价格 + '   库存: ' + r.库存 + '   规格: ' + r.规格);
    console.log('  页面含杭州: ' + r.有没有杭州 + '   含泉州: ' + r.有没有泉州);
    results.push({ id, ok: true, ...r });
  }
  // 页面导航回首页，别把编辑页留着
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://www.goofish.com/"; "back"' }, 60000);
  fs.writeFileSync(path.join(__dirname, 'verify-publish-3-result.json'), JSON.stringify(results, null, 2), 'utf8');
  console.log('\n════ 汇总 ════');
  results.forEach(r => console.log('  ' + r.id + (r.ok ? '  ' + (r.宝贝所在地 || '?') + '  库存=' + r.库存 + '  价=' + r.价格 : '  失败')));
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
