/**
 * probe-image-to-template.js — 安全探针：让中台读「白底红字版」成品图，看它会逆向出什么模板草稿
 *
 * 用 --no-create：只出草稿，不建模板、不占模板库、不消耗 credits（中台文档明说）
 *
 * 目的：用户想把「白底红字版」做成【贴图模板】(templates 表，visibility=shared，能给其他用户用)，
 *       而不是【版式模板】(poster-templates 表，租户级，给不了外人)。
 *       先看中台自动逆向的结果，再决定是走这条路还是手工建。
 */
const { execFileSync } = require('child_process');
const path = require('path');
const { ROOT, NODE: ENV_NODE } = require('./lib/env');

const NODE = ENV_NODE.path;
const CLI  = ENV_NODE.museavCli;

// 用发布台烧好字的成品图当输入（最能代表这个版式长什么样）
const IMG = path.join(ROOT, '主图筛选-那英杭州/01-tpl_redtext-白底红字版.png');

const args = ['image-to-template', IMG, '--no-create',
  '--name', '白底红字版',
  '--category', '演唱会',
  '--labels', JSON.stringify({ 'city': '城市', 'star': '明星' })];

console.log('$ museav ' + args.map(a => /[\s"]/.test(a) ? JSON.stringify(a) : a).join(' '));
console.log('输入图: ' + IMG + '\n');

try {
  const out = execFileSync(NODE, [CLI].concat(args), { encoding: 'utf8', timeout: 600000, maxBuffer: 16 * 1024 * 1024 });
  console.log(out);
} catch (e) {
  console.log(String(e.stdout || ''));
  console.log(String(e.stderr || ''));
  if (!e.stdout && !e.stderr) console.log('❌ ' + e.message);
}
