// run-cfgs.js —— 批量新建擦亮计划（吃 __CFGS 数组，逐个驱动 ad-driver.js）
// 用法: node run-cfgs.js <from> <to>
// 规格沿用 常州/刘宪华北京：每场 1 咨询 + 1 订单，三个商品一组，提升 120%，
//                        时段 8:00-23:00，创意优化保持默认开启
// 【2026-10-04 改】预算统一 ¥50：咨询 ¥150→¥50、订单 ¥90→¥50。
//   理由：咨询量出价有 ¥4.00 硬顶（规则 chatCap=4），¥150 的日预算永远花不完，
//   写大了只是虚高数字；订单量部分商品平台侧开不了，就那几个商品不建订单计划，
//   不要为了凑预算反复重试。两处口径必须与 open-chat-campaigns.js 的 ¥50 一致。
const http = require('http');
const fs = require('fs');
const { SVC, STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const CREATE = 'https://dayu.goofish.com/?site=FISHAD#/ad/polish/create-plan?source=home&fromBiz=COMMONPRO';

// ⚠️ 两条新链接在这里：
//   孙燕姿广州 ¥100 = 1084002927441（新）  + 1079022076546 / 1083662342559（原有 ¥50）
//   侯明昊郑州 ¥200 = 1084002847732（新）  + 1085933901026（¥100）/ 1072513395163（原有 ¥50）
const DEFAULT_CFGS = [
  {
    searchKey: '孙燕姿',
    items: ['1084002927441', '1079022076546', '1083662342559'],
    target: 'chat', improvePct: 120, expectedBid: '2.5',
    budget: 50, planName: '孙燕姿广州-咨询120',
    startHour: 8, endHour: 22, submit: true,
  },
  {
    searchKey: '孙燕姿',
    items: ['1084002927441', '1079022076546', '1083662342559'],
    target: 'order', improvePct: 120, expectedBid: '26.7',
    budget: 50, planName: '孙燕姿广州-订单120',
    startHour: 8, endHour: 22, submit: true,
  },
  {
    searchKey: '侯明昊',
    items: ['1084002847732', '1085933901026', '1072513395163'],
    target: 'chat', improvePct: 120, expectedBid: '2.5',
    budget: 50, planName: '侯明昊郑州-咨询120',
    startHour: 8, endHour: 22, submit: true,
  },
  {
    searchKey: '侯明昊',
    items: ['1084002847732', '1085933901026', '1072513395163'],
    target: 'order', improvePct: 120, expectedBid: '26.7',
    budget: 50, planName: '侯明昊郑州-订单120',
    startHour: 8, endHour: 22, submit: true,
  },
];
// 可用 CFGS_JSON 指定另一批（2026-09-23 加，给新场次复用同一套逻辑）
const CFGS = process.env.CFGS_JSON ? JSON.parse(fs.readFileSync(process.env.CFGS_JSON, 'utf8')) : DEFAULT_CFGS;
const LOG = process.env.CFGS_LOG || 'D:\\DSH\\achun\\run-cfgs-log.ndjson';

function ev(code) {
  return new Promise((resolve) => {
    const payload = JSON.stringify({ store: STORE, code });
    const req = http.request({ host: '127.0.0.1', port: 8093, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      res => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: b.slice(0, 300) }); } }); });
    req.on('error', e => resolve({ ok: false, error: e.message })); req.write(payload); req.end();
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
function log(o) { fs.appendFileSync(LOG, JSON.stringify({ ts: new Date().toISOString(), ...o }) + '\n', 'utf8'); }

(async () => {
  const from = Number(process.argv[2] || 0), to = Number(process.argv[3] || CFGS.length);
  const DRIVER = fs.readFileSync(__dirname + '\\ad-driver.js', 'utf8');
  for (let i = from; i < to; i++) {
    const c = CFGS[i];
    console.log(`\n───── [${i + 1}/${CFGS.length}] ${c.planName}  ${c.target} · 提升${c.improvePct}% · 预算¥${c.budget} · ${c.items.length}个宝贝 ─────`);
    let r = await ev(`(function(){location.href=${JSON.stringify(CREATE)};return 'nav'})()`);
    if (!r.ok) { console.log('  跳转失败 ' + r.error); log({ i, name: c.planName, step: 'nav', err: r.error }); continue; }
    await sleep(17000);
    r = await ev(`window.__ADCFG=${JSON.stringify(c)}; 'set'`);
    if (!r.ok) { console.log('  cfg 失败 ' + r.error); log({ i, name: c.planName, step: 'cfg', err: r.error }); continue; }
    r = await ev(DRIVER);
    if (!r.ok) { console.log('  driver 失败 ' + r.error); log({ i, name: c.planName, step: 'driver', err: r.error }); continue; }
    let j; try { j = typeof r.result === 'string' ? JSON.parse(r.result) : r.result; } catch (e) {
      console.log('  解析失败: ' + String(r.result).slice(0, 300)); log({ i, name: c.planName, step: 'parse', raw: String(r.result).slice(0, 400) }); continue;
    }
    console.log('  自检 ' + (j.selfCheckPassed ? '✅' : '❌') + '   提交 ' + (j.submitted ? '✅' : '—') + '   提交确认 ' + (j.submitConfirmed ? '✅' : '❌'));
    if (j.checks) console.log('  ' + Object.keys(j.checks).map(k => (j.checks[k] ? '✅' : '❌') + k).join('  '));
    if (j.readback) console.log('  回读: 宝贝' + j.readback.选择宝贝 + ' 提升' + j.readback.预计提升 + '% 出价¥' + j.readback.自定义出价 + ' 预计花费¥' + j.readback.预计花费 + ' 余额¥' + j.readback.余额);
    if (j.afterSubmit && j.afterSubmit.toast && j.afterSubmit.toast.length) console.log('  提示: ' + JSON.stringify(j.afterSubmit.toast));
    if (j.fatal) console.log('  FATAL: ' + j.fatal);
    if (j.aborted) console.log('  ABORTED: ' + j.aborted);
    log({ i, name: c.planName, target: c.target, submitted: !!j.submitted, confirmed: !!j.submitConfirmed,
          imp: j.finalImprove || null, bid: j.readback && j.readback.自定义出价 || null,
          skipped: j.skippedItems || null, warnings: j.warnings || null,
          checks: j.checks || null, fatal: j.fatal || null, aborted: j.aborted || null });
    await sleep(2500);
  }
  console.log('\n本批完成，日志: ' + LOG);
})().catch(e => { console.error('FAIL ' + e.message); process.exit(1); });
