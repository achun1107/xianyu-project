/**
 * gen-via-central.js — 端到端验证：大麦官方海报当垫图 → 用中台「白底红字版」出图
 *
 * 链路：发布台 /api/poster/make 搜到的大麦官方海报（_干净底图.jpg）
 *       → --ref 送进中台
 *       → 中台版式「白底红字版」的 prompt 排版
 *       → 出图
 *
 * 要验的三件事：
 *   1. --ref 垫图能不能传（三类底图来源的公共入口）
 *   2. poster-templates 的 id 能不能用在 gen --template（可能只认 templates 的 id）
 *   3. 出来的图长什么样，跟发布台直接跑 tpl_redtext 的结果比
 *
 * 用法：node gen-via-central.js          # 真出图（消耗 credits）
 *       node gen-via-central.js --probe  # 只检查参数，不出图
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { ROOT, NODE: ENV_NODE } = require('./lib/env');

const NODE = ENV_NODE.path;
const CLI  = ENV_NODE.museavCli;

const POSTER_TPL = '396f670d-d969-422a-afdb-f72844126aac';   // 「白底红字版」版式模板
const REF  = path.join(ROOT, '主图筛选-那英杭州/_干净底图.jpg');   // 大麦官方海报（发布台搜来的）
const OUT  = path.join(ROOT, '中台版式');
const FIELDS = { '城市': '杭州', '明星': '那英' };

const PROBE = process.argv.includes('--probe');

function run(args, label) {
  console.log('\n──── ' + label + ' ────');
  console.log('  $ museav ' + args.map(a => /[\s"]/.test(a) ? JSON.stringify(a) : a).join(' '));
  try {
    const out = execFileSync(NODE, [CLI].concat(args), { encoding: 'utf8', timeout: 300000, maxBuffer: 8 * 1024 * 1024 });
    console.log(out.trim());
    return { ok: true, out };
  } catch (e) {
    const o = String(e.stdout || '') + '\n' + String(e.stderr || '');
    console.log('  ❌ ' + (o.trim() || e.message));
    return { ok: false, out: o, err: e.message };
  }
}

(async () => {
  if (!fs.existsSync(REF)) { console.log('❌ 垫图不存在: ' + REF); process.exit(1); }
  console.log('垫图: ' + REF + '  ' + Math.round(fs.statSync(REF).size / 1024) + ' KB');
  console.log('版式: ' + POSTER_TPL + '  (中台 poster-templates 里的「白底红字版」)');
  console.log('字段: ' + JSON.stringify(FIELDS));
  fs.mkdirSync(OUT, { recursive: true });

  if (PROBE) { console.log('\n[--probe] 未出图'); return; }

  // ── 主路径：版式 id + 垫图 ──
  const r = run(['gen', '--template', POSTER_TPL, '--fields', JSON.stringify(FIELDS),
                 '--ref', REF, '--ratio', '3:4'], '用版式 id 出图');

  const url = (r.out || '').match(/https?:\/\/[^\s"']+\.(?:png|jpe?g|webp)/i);
  if (url) {
    console.log('\n✅ 出图 URL: ' + url[0]);
    const dest = path.join(OUT, '端到端-白底红字版-大麦垫图.png');
    const resp = await fetch(url[0]);
    fs.writeFileSync(dest, Buffer.from(await resp.arrayBuffer()));
    console.log('   已存: ' + dest + '  ' + Math.round(fs.statSync(dest).size / 1024) + ' KB');
  } else {
    console.log('\n⚠️ 没拿到图片 URL。若上面报的是「模板不存在」，说明 gen --template 只认 museav templates 的 id，');
    console.log('   版式模板（poster-templates）必须走别的渲染入口 —— 这点需要确认。');
  }
})().catch(e => { console.log('❌ ' + (e && e.stack || e)); process.exit(1); });
