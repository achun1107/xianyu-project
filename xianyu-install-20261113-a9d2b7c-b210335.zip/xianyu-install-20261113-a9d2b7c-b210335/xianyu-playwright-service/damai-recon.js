/* damai-recon.js — 侦察大麦页面：抓所有 API 请求 + 搜索接口的响应结构
 * 目的：找出「即将开抢」可用的字段（预售状态 / 开售时间）
 * 只读，不改任何数据。
 */
const path = require('path');
const { chromium } = require(path.join(__dirname, 'node_modules', 'playwright'));

(async () => {
  const kw = process.argv[2] || '演唱会';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
    viewport: { width: 390, height: 844 }, isMobile: true,
  });
  const page = await ctx.newPage();

  const apis = {};
  const samples = [];

  page.on('response', async (resp) => {
    const u = resp.url();
    if (!/mtop\.damai|damai\.cn\/api/i.test(u)) return;
    // 记录接口名
    const m = u.match(/mtop\.damai[\w.]*/);
    const key = m ? m[0] : u.split('?')[0].slice(-60);
    apis[key] = (apis[key] || 0) + 1;
    // 对搜索接口，抓样本看字段
    if (/search/i.test(key) && samples.length < 3) {
      try {
        const j = JSON.parse(await resp.text());
        const list = (j.data && (j.data.projectInfo || j.data.projectList || j.data.list)) || [];
        if (Array.isArray(list) && list.length) {
          samples.push({
            api: key,
            count: list.length,
            字段: Object.keys(list[0]),
            样本: list.slice(0, 3).map(it => {
              const o = {};
              Object.keys(it).forEach(k => {
                const v = it[k];
                if (v === null || v === undefined) return;
                if (typeof v === 'object') return;
                o[k] = String(v).slice(0, 40);
              });
              return o;
            })
          });
        }
      } catch (e) {}
    }
  });

  // 1) 首页
  await page.goto('https://m.damai.cn/damai/home/index.html', { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(6000);

  // 2) 搜索页
  await page.goto('https://m.damai.cn/damai/search/index.html?keyword=' + encodeURIComponent(kw), { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(7000);

  console.log('=== 捕获到的接口 ===');
  Object.keys(apis).sort((a, b) => apis[b] - apis[a]).forEach(k => console.log('  ' + apis[k] + 'x  ' + k));

  console.log('\n=== 搜索接口响应结构 ===');
  console.log(JSON.stringify(samples, null, 1).slice(0, 4000));

  await browser.close();
})();
