/* damai-plan-list.js — 用独立浏览器打开擦亮计划列表，读取每个计划的 7 天数据
 * 复用 8093 的浏览器 profile（已登录），但独立启动，不影响正在运行的服务。
 */
const path = require('path');
const { chromium } = require(path.join(__dirname, 'node_modules', 'playwright'));

(async () => {
  const profileDir = path.join(__dirname, 'browser-profiles', 'store-好易美代拍');
  let browser;
  try {
    browser = await chromium.launchPersistentContext(profileDir, {
      headless: true,
      viewport: { width: 1600, height: 900 },
      args: ['--no-sandbox']
    });
  } catch (e) {
    console.log('启动失败（可能 profile 被占用）: ' + e.message);
    process.exit(1);
  }

  const page = browser.pages()[0] || await browser.newPage();

  // 1) 先去卖家工作台，再进擦亮计划列表
  const urls = [
    'https://seller.goofish.com/?site=COMMONPRO#/seller-ad/campaign/list',
    'https://seller.goofish.com/?site=COMMONPRO#/seller-ad/campaign',
    'https://seller.goofish.com/?site=COMMONPRO#/seller-ad/plan'
  ];

  for (const u of urls) {
    try {
      await page.goto(u, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await page.waitForTimeout(9000);
      const info = await page.evaluate(() => {
        const b = document.body ? document.body.innerText.replace(/\s+/g, ' ') : '';
        return { url: location.href, title: document.title, len: b.length, head: b.slice(0, 700) };
      });
      console.log('\n===== ' + u + ' =====');
      console.log('实际URL: ' + info.url);
      console.log('标题: ' + info.title + '  正文长度: ' + info.len);
      console.log('正文: ' + info.head);
      if (/计划|擦亮|曝光|花费|出价/.test(info.head) && info.len > 400 && !/无权限|禁止访问/.test(info.head)) {
        console.log('\n*** 这个地址有内容，可能可用 ***');
      }
    } catch (e) {
      console.log('\n===== ' + u + ' ===== 出错: ' + e.message);
    }
  }

  await browser.close();
})();
