// 闲鱼单浏览器多账号 Playwright 服务
// 共享一个浏览器窗口，切换账号通过 Cookie 加载实现

// 全局错误捕获，防止未处理异常导致进程退出
process.on('uncaughtException', (err) => { console.error('[agent] 未捕获异常:', err.message); });
process.on('unhandledRejection', (reason) => { console.error('[agent] 未处理 Promise 拒绝:', reason); });

const express = require('express');
const https = require('https');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');
const execAsync = require('util').promisify(exec);
const { XianyuAgent } = require('./agent');

// ══════════════════════════════════════════════════════════════════
// 本机密钥与账号配置（service.local.json / 环境变量）
//
// 为什么必须外置：这个仓库在 gitlab.com/hym-company 上，学员要 clone。
//   2026-10-08 之前，下面这些【明文写在代码里】，而且已经进了 git 历史：
//     · 8093 访问密钥（L87 一份 + L421 注入脚本里又一份）
//     · 好易美后台账号密码
//     · Supabase service_role key（等于整库读写权限）
//     · 中台 tenant key（sk-studio-...）
//   ⛔ 已泄漏，必须去各自后台【轮换】。外置只保证今后不再重复泄漏。
//
// 取值顺序：环境变量 > service.local.json > 空
//   8093 密钥没配时【自动生成随机值并落盘】—— 学员机器上没人愿意手编密钥，
//   而且每台机器一把随机密钥，比所有机器共用一把安全得多。
// ══════════════════════════════════════════════════════════════════
const CFG_FILE = path.join(__dirname, 'service.local.json');
let LOCAL_CFG = {};
try {
  if (fs.existsSync(CFG_FILE)) LOCAL_CFG = JSON.parse(fs.readFileSync(CFG_FILE, 'utf8')) || {};
} catch (e) { console.error('[cfg] service.local.json 读不了，按空处理：' + e.message); }

function cfgVal(key, envName) {
  const env = process.env[envName || key];
  if (env) return String(env);
  const v = LOCAL_CFG[key];
  return (v === undefined || v === null) ? '' : String(v);
}

let API_KEY = cfgVal('apiKey', 'API_KEY');
if (!API_KEY) {
  API_KEY = 'xy_' + require('crypto').randomBytes(16).toString('hex');
  LOCAL_CFG.apiKey = API_KEY;
  try {
    fs.writeFileSync(CFG_FILE, JSON.stringify(LOCAL_CFG, null, 2) + '\n', 'utf8');
    console.log('[cfg] 首次启动：已生成 8093 访问密钥并写入 ' + CFG_FILE);
    console.log('[cfg]   密钥 = ' + API_KEY);
    console.log('[cfg]   客户端（achun）的 config.local.json 里 service.apiKey 要填这个值。');
  } catch (e) { console.error('[cfg] 写 service.local.json 失败，本次用临时密钥：' + e.message); }
}

/** 取一个必须存在的配置；没有就给一句能照做的报错，而不是让 fetch 拿着空 key 去撞 401 */
function needCfg(key, envName, what) {
  const v = cfgVal(key, envName);
  if (!v) throw new Error(what + ' 未配置：请在 ' + CFG_FILE + ' 里填 "' + key + '"（或设环境变量 ' + (envName || key) + '）');
  return v;
}

const app = express();
app.use(express.json({ limit: '30mb' }));

// CORS - 允许闲鱼页面跨域请求本地服务
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, X-API-Key');
  // Chrome 私有网络访问(PNA)预检：公共页面(goofish.com)访问 localhost 需显式放行
  res.header('Access-Control-Allow-Private-Network', 'true');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// 提供操作台静态文件（dashboard.html + dashboard.js）
const MONITOR_DIR = (function () {
  // 优先用【和服务并排】的 xianyu-monitor（学员安装后的布局），回落本机历史位置。
  // 2026-11-12：原来写死 C:/Users/43462/Desktop/... —— 学员机器上不存在，
  // 后果是「服务能起来、health 正常、界面能开，但发布和广告全不工作且不报错」。
  var beside = path.join(__dirname, '..', 'xianyu-monitor');
  try { if (fs.existsSync(beside)) return beside; } catch (e) {}
  return 'C:/Users/43462/Desktop/xianyu-monitor';
})();
// 前端 JS/HTML 不缓存：避免改代码后浏览器仍用缓存旧版
app.use(function(req, res, next) { if (/\.(js|html)$/.test(req.path)) { res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate'); } next(); });
app.use(express.static(MONITOR_DIR));
// 根路径 → 发布台（避免直接打开 http://localhost:8094 出现 Cannot GET /）
app.get('/', function(req, res) { res.redirect('/publish_dashboard.html'); });

// ===== 副图库：发布台上传自定义副图（最多8张）→ 存到 闲鱼上架图片/自定义副图/  → 发布时优先用 =====
const SUBIMG_DIR = (function () {
  // 同上：并排优先。学员机没有 Desktop\闲鱼上架图片，但 publish-assets 一定在 achun 下。
  var a = path.join(__dirname, '..', 'xianyu-achun', 'publish-assets', '自定义副图');
  var b = path.join(__dirname, '..', 'publish-assets', '自定义副图');
  try { if (fs.existsSync(path.join(__dirname, '..', 'xianyu-achun'))) return a; } catch (e) {}
  try { if (fs.existsSync(b)) return b; } catch (e) {}
  return 'C:/Users/43462/Desktop/闲鱼上架图片/自定义副图';
})();
try { if (!fs.existsSync(SUBIMG_DIR)) fs.mkdirSync(SUBIMG_DIR, { recursive: true }); } catch(e) {}
app.use('/subimg', express.static(SUBIMG_DIR));
app.post('/api/poster/sub-image', auth, async (req, res) => {
  try {
    const idx = parseInt(req.body.index) || 1; if (idx < 1 || idx > 8) return res.json({ ok: false, error: '副图索引需1-8' });
    const dataUrl = String(req.body.b64 || '');
    const b64 = dataUrl.replace(/^data:image\/[^;]+;base64,/, '');
    const m = dataUrl.match(/^data:image\/([a-z]+)/i); let ext = (m && m[1]) || 'jpg'; if (ext !== 'jpg' && ext !== 'jpeg' && ext !== 'png') ext = 'jpg';
    const grp = String(req.body.group || '').replace(/[\\/]+/g, '/').replace(/^\/|\/$/g, '');
    const dir = grp ? (SUBIMG_DIR + '/' + grp) : SUBIMG_DIR;
    try { if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true }); } catch(e){}
    if (!b64) {
      // 空 b64 = 清空该副图槽（删除）
      ['jpg','jpeg','png'].forEach(function(e){ try { fs.unlinkSync(dir + '/' + idx + '.' + e); } catch(_e){} });
      return res.json({ ok: true, index: idx, deleted: true });
    }
    fs.writeFileSync(dir + '/' + idx + '.' + ext, Buffer.from(b64, 'base64'));
    ['jpg','jpeg','png'].forEach(function(e){ if (e !== ext) { try { fs.unlinkSync(dir + '/' + idx + '.' + e); } catch(_e){} } });
    res.json({ ok: true, index: idx, url: '/subimg/' + (grp ? grp + '/' : '') + idx + '.' + ext });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});
app.get('/api/poster/sub-images', auth, (req, res) => {
  try {
    const items = [];
    function scanDir(base, group) {
      for (let i = 1; i <= 8; i++) {
        ['jpg','jpeg','png'].forEach(function(e){ if (fs.existsSync(base + '/' + i + '.' + e)) items.push({ index: i, url: '/subimg/' + (group ? group + '/' : '') + i + '.' + e, ext: e, group: group }); });
      }
    }
    scanDir(SUBIMG_DIR, ''); // 通用组
    // 递归扫到 3 层，覆盖 明星 / 明星+城市 / 明星+城市+场次 / 明星+场次 等分组
    function scanDeep(base, group, depth) {
      scanDir(base, group);
      if (depth <= 0) return;
      try {
        fs.readdirSync(base, { withFileTypes: true }).forEach(function(d) {
          if (!d.isDirectory() || d.name === 'node_modules') return;
          scanDeep(base + '/' + d.name, group ? group + '/' + d.name : d.name, depth - 1);
        });
      } catch(e){}
    }
    scanDeep(SUBIMG_DIR, '', 2); // 根(通用组) + 最多两层分组
    res.json({ ok: true, items: items });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

const PORT = process.env.PORT || 8093;
// API_KEY 已在文件顶部从 service.local.json / 环境变量解析（没配会自动生成随机值并落盘）。
const ADMIN_HOST = cfgVal('adminHost') || 'manager.hympro.cn';

// 精简：不加载的账号(瘦身) —— 从账号列表隐藏/不启动
const EXCLUDE_ACCOUNTS = ['湖畔暴富的蓝环章鱼', '追梦的镇宇', 'casa家居'];

// 认证：本地请求或带正确密钥
function auth(req, res, next) {
  const isLocal = req.ip === '::1' || req.ip === '127.0.0.1' || req.ip === '::ffff:127.0.0.1';
  if (isLocal || req.headers['x-api-key'] === API_KEY) return next();
  return res.status(401).json({ error: 'Unauthorized' });
}

// 单浏览器实例 + 账号列表
let agent = null;
let accountsCache = [];

// ===== 账号来源 =====
// 优先级：service.local.json 的 localAccounts > 远程 manager 的 /api/xianyu-accounts > 内置兜底。
//
// 为什么 localAccounts 要排最前：远程那个列表是【老板的全量账号】，
// 而学员只该看到自己的店。中台的 /api/xianyu-install-config 会按学员下发他名下的账号，
// 安装器把它写进这里的 localAccounts，学员机器就不会看到别人的店了。
const LOCAL_ACCOUNTS = (Array.isArray(LOCAL_CFG.localAccounts) && LOCAL_CFG.localAccounts.length)
  ? LOCAL_CFG.localAccounts
  : [
    { id: '594c5e52-4ebf-4aa0-8f95-f49643a26645', name: 'casa家居' },
    { id: 'f14c27bc-c353-448a-89a-430e53ad9ac0', name: '好易美代拍' },
    { id: '3d9d2059-71b1-4db3-aeeb-5024afe4ed0a', name: '好易美娱乐' },
    { id: 'a1b2c3d4-0001-4000-8000-000000000001', name: '湖畔暴富的蓝环章鱼' },
    { id: 'a1b2c3d4-0002-4000-8000-000000000002', name: '超能水手代拍' },
    { id: 'a1b2c3d4-0003-4000-8000-000000000003', name: '追梦的镇宇' }
  ];

// ===== 拉取账号 =====
// 如果本机配了 localAccounts（学员机器：中台按人下发的名下店铺），就【直接用，不去问远程】——
// 远程那个接口返回的是老板的全量账号，学员不该看到别人的店。
async function fetchAccounts() {
  if (Array.isArray(LOCAL_CFG.localAccounts) && LOCAL_CFG.localAccounts.length) {
    return LOCAL_CFG.localAccounts.filter(function (a) { return EXCLUDE_ACCOUNTS.indexOf(a.name) < 0; });
  }
  return new Promise((resolve, reject) => {
    const opts = {
      hostname: ADMIN_HOST,
      path: '/api/xianyu-accounts',
      headers: { 'X-API-Key': API_KEY }
    };
    https.get(opts, (r) => {
      let d = '';
      r.on('data', c => d += c);
      r.on('end', () => {
        try {
          const json = JSON.parse(d);
          resolve((json.data || []).filter(function(a) { return EXCLUDE_ACCOUNTS.indexOf(a.name) < 0; }));
        } catch (e) { reject(e); }
      });
    }).on('error', (e) => {
      console.log('[agent] ⚠ 远程账号服务器不可用，使用本地兜底: ' + e.message);
      resolve((LOCAL_ACCOUNTS || []).filter(function(a) { return EXCLUDE_ACCOUNTS.indexOf(a.name) < 0; }));
    });
  });
}

function escHtml(s) {
  return (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ===== API =====

// 拉取账号列表（从好易美）
app.get('/api/agent/accounts', auth, async (req, res) => {
  try {
    accountsCache = await fetchAccounts();
    res.json({ ok: true, data: accountsCache });
  } catch (e) {
    res.json({ ok: false, error: e.message, data: accountsCache });
  }
});

// 启动浏览器 + 加载默认账号
app.post('/api/agent/start-all', auth, async (req, res) => {
  try {
    accountsCache = await fetchAccounts();

    if (agent) {
      agent.setAccounts(accountsCache);
      return res.json({
        ok: true,
        data: {
          active: agent.currentAccount ? agent.currentAccount.name : null,
          state: agent.state,
          total: accountsCache.length
        }
      });
    }

    agent = new XianyuAgent();
    await agent.init(accountsCache);

    res.json({
      ok: true,
      data: {
        active: agent.currentAccount ? agent.currentAccount.name : null,
        state: agent.state,
        total: accountsCache.length
      }
    });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 登录当前账号
app.post('/api/agent/login', auth, async (req, res) => {
  if (!agent) return res.status(404).json({ error: '请先调用 start-all' });

  try {
    await agent.login();
    res.json({ ok: true, state: agent.state, name: agent.currentAccount?.name });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 切换账号（通过 storeName 或 accountId）
app.post('/api/agent/switch', auth, async (req, res) => {
  if (!agent) return res.status(404).json({ error: '请先调用 start-all' });

  const { accountId, storeName } = req.body;

  let target = null;
  if (accountId) {
    target = agent.findAccount(accountId);
  } else if (storeName) {
    target = agent.findAccountByName(storeName);
  }

  if (!target) {
    accountsCache = await fetchAccounts();
    agent.setAccounts(accountsCache);
    if (accountId) {
      target = agent.findAccount(accountId);
    } else if (storeName) {
      target = agent.findAccountByName(storeName);
    }
  }

  if (!target) {
    return res.status(404).json({ error: '账号未找到: ' + (storeName || accountId) });
  }

  try {
    const state = await agent.switchTo(target);
    res.json({ ok: true, name: target.name, state });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 获取当前状态
app.get('/api/agent/status', auth, (req, res) => {
  if (!agent) {
    return res.json({ ok: true, data: { running: false, active: null, total: accountsCache.length } });
  }

  res.json({
    ok: true,
    data: {
      running: true,
      active: agent.currentAccount ? {
        id: agent.currentAccount.id,
        name: agent.currentAccount.name,
        username: agent.currentAccount.username
      } : null,
      state: agent.state,
      total: agent.accounts ? Object.keys(agent.accounts).length : 0
    }
  });
});

// 注入管理面板到当前页面
app.post('/api/agent/inject-monitor', auth, async (req, res) => {
  if (!agent) return res.status(404).json({ error: '代理未启动' });
  try {
    var target = req.body.page === 'goofish' ? agent.pages.goofish : (req.body.page === 'dayu' ? agent.pages.dayu : null);
    await agent.injectMonitor(target);
    res.json({ ok: true });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 导航到指定页面并注入管理面板
app.post('/api/agent/navigate', auth, async (req, res) => {
  if (!agent || !agent.page) return res.status(404).json({ error: '浏览器未启动' });
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: '需要 url 参数' });
    await agent.page.goto(url, { waitUntil: 'domcontentloaded', timeout: 20000 });
    await agent.page.waitForTimeout(2000);
    await agent.injectMonitor();
    res.json({ ok: true, url: agent.page.url() });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 截图当前页面
app.get('/api/agent/screenshot', auth, async (req, res) => {
  if (!agent || !agent.page) return res.status(404).json({ error: '浏览器未启动' });
  try {
    const buf = await agent.screenshot();
    res.type('png').send(buf);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 保存当前账号 Cookie
app.post('/api/agent/save-cookie', auth, async (req, res) => {
  if (!agent) return res.status(404).json({ error: '浏览器未启动' });
  try {
    if (req.body.store) {
      var s = agent.stores[req.body.store];
      if (!s) return res.status(404).json({ error: '店铺未就绪' });
      await s.context.storageState({ path: agent.getStatePath(s.account.id) });
    } else {
      await agent.saveCookies();
    }
    res.json({ ok: true });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 关闭浏览器
// 发布日志（操作台调用，空实现即可）
app.post('/api/system/publish-log', auth, (req, res) => {
  res.json({ ok: true });
});
app.get('/api/system/publish-log', auth, (req, res) => {
  res.json({ ok: true });
});

app.post('/api/agent/stop', auth, async (req, res) => {
  if (!agent) return res.json({ ok: true });
  try {
    await agent.saveCookies();
    await agent.close();
    agent = null;
    res.json({ ok: true });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 健康检查
app.get('/health', (req, res) => {
  res.json({ ok: true, running: !!agent, active: agent?.currentAccount?.name || null });
});

app.get('/api/agent/debug-stores', auth, (req, res) => {
  if (!agent) return res.json({});
  var info = {};
  for (var k in agent.stores) {
    var s = agent.stores[k];
    var ctxId = s.context ? 'ctx_'+String(s.context).slice(-8) : 'noctx';
    info[k] = { hasCtx: !!s.context, hasGoofish: !!s.pages?.goofish, accountName: s.account?.name, ctxId: ctxId };
  }
  res.json(info);
});

// ===== 账号切换页面（服务端渲染） =====
app.get('/api/agent/switcher', auth, async (req, res) => {
  try {
    const data = await fetchAccounts();
    const activeName = agent?.currentAccount?.name || '无';
    const stateStr = agent?.state || 'idle';

    const cards = data.map(a => {
      const isActive = a.name === activeName;
      const isRunning = !!(agent && agent.stores && agent.stores[a.name]);
      return `<div class="card">
        <div>
          <div class="name">${isActive ? '👉 ' : ''}${escHtml(a.name)}</div>
          <div class="user">${escHtml(a.username || '')}</div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <span class="status ${isRunning ? 'status-active' : 'status-idle'}">${isRunning ? '运行中' : '未启动'}</span>
          <button class="btn btn-start" data-name="${escHtml(a.name)}" style="background:#27ae60;color:#fff;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-size:12px;">启动</button>
          <button class="btn btn-show" data-name="${escHtml(a.name)}" style="background:#e67e22;color:#fff;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-size:12px;">👁 显示</button>
          ${isActive ? '' : `<a href="/api/agent/switch-form?name=${encodeURIComponent(a.name)}" class="btn" style="background:#4A90D9;">切换</a>`}
        </div>
      </div>`;
    }).join('\n');

    res.set('Content-Type', 'text/html; charset=utf-8');
    res.send(`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>闲鱼账号管理</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,sans-serif;background:#f5f6fa;padding:24px;max-width:800px;margin:0 auto}
h1{font-size:20px;margin-bottom:8px}
.status-bar{text-align:center;padding:12px;font-size:13px;color:#666;margin-bottom:16px;display:flex;justify-content:center;align-items:center;gap:12px}
.card{background:#fff;border-radius:10px;padding:16px;margin-bottom:12px;box-shadow:0 2px 8px rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:space-between}
.card .name{font-size:15px;font-weight:600}
.card .user{font-size:12px;color:#999;margin-top:2px}
.card .status{font-size:12px;padding:3px 8px;border-radius:4px}
.status-active{background:#e8f5e9;color:#2e7d32}
.status-idle{background:#fff3e0;color:#e65100}
.card a.btn,.card button.btn{padding:8px 16px;cursor:pointer;font-size:13px;text-decoration:none;display:inline-block;border-radius:6px;border:none;color:#fff}
.card a.btn{background:#4A90D9}
.card a.btn:hover{background:#357ABD}
.card button.btn-start{background:#27ae60}
.card button.btn-start:hover{background:#219a52}
.card button.btn-start:disabled{background:#ccc;cursor:not-allowed}
.btn-all{background:#e67e22;color:#fff;border:none;border-radius:6px;padding:10px 20px;cursor:pointer;font-size:14px;font-weight:500}
.btn-all:hover{background:#d35400}
.btn-all:disabled{background:#ccc;cursor:not-allowed}
.toast{position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#27ae60;color:#fff;padding:10px 24px;border-radius:8px;font-size:14px;z-index:9999;display:none}
.nav{text-align:right;margin-bottom:12px}
.nav a{color:#4A90D9;text-decoration:none;font-size:13px}
.tabs{display:flex;gap:4px;margin-bottom:12px}
.tab{padding:8px 20px;border:none;border-radius:6px 6px 0 0;cursor:pointer;font-size:13px;background:#e8e8e8;color:#666}
.tab.active{background:#4A90D9;color:#fff}
.tab-content{display:none}
.tab-content.active{display:block}
#iframe-dashboard{width:100%;height:85vh;border:none;border-radius:0 8px 8px 8px;background:#fff}
</style>
</head>
<body>
<h1>🐟 闲鱼操作台</h1>
<div class="tabs">
  <button class="tab active" onclick="switchTab('accounts')">👤 账号管理</button>
  <button class="tab" onclick="switchTab('dashboard')">📊 数据看板</button>
</div>
<div class="nav"><a href="/api/agent/switcher">🔄 刷新</a> | <a href="/api/agent/navigate-page?url=https://dayu.goofish.com/">日佑</a> | <a href="/api/agent/navigate-page?url=https://www.goofish.com/">主站</a></div>
<div class="tab-content active" id="tab-accounts">
<div class="status-bar">当前: ${escHtml(activeName)} | 状态: ${stateStr} | <button class="btn-all" id="btn-open-all" onclick="openAll()">🚀 一键启动所有</button></div>
<div id="toast" class="toast"></div>
${cards}
<script>
var API_KEY='${API_KEY}';
async function api(url,body){
  var ctrl=new AbortController();
  setTimeout(function(){ctrl.abort()},120000);
  var res=await fetch(url,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','X-API-Key':API_KEY},body:body?JSON.stringify(body):undefined,signal:ctrl.signal});
  return res.json();
}
function toast(msg,ok){
  var t=document.getElementById('toast');t.textContent=msg;t.style.background=ok?'#27ae60':'#e74c3c';t.style.display='block';
  setTimeout(function(){t.style.display='none'},2000);
}
async function startOne(name){
  var btn=document.querySelector('button[data-name="'+name+'"]');if(btn)btn.disabled=true;btn.textContent='⏳';
  var r=await api('/api/agent/start-one',{name:name});
  toast(r.ok?name+' 已启动':name+' 失败: '+r.error,r.ok);
  if(r.ok){btn.textContent='✅';btn.style.background='#27ae60';btn.disabled=true;
    var card=btn.closest('.card');if(card){var st=card.querySelector('.status');if(st){st.textContent='运行中';st.className='status status-active';}}}
  else {btn.disabled=false;btn.textContent='启动';}
}
async function openAll(){
  var btn=document.getElementById('btn-open-all');btn.disabled=true;btn.textContent='⏳ 启动中...（需1-2分钟）';
  try{
    var r=await api('/api/agent/open-all-stores');
    toast(r.ok?'所有店铺('+r.stores.length+'个)已启动':'失败: '+r.error,r.ok);
    if(r.ok)setTimeout(function(){location.reload()},2000);
    else{btn.disabled=false;btn.textContent='🚀 一键启动所有';}
  }catch(e){
    toast('启动超时，店铺正在后台打开，稍后刷新页面',false);
    btn.disabled=false;btn.textContent='🔄 刷新页面';
    btn.onclick=function(){location.reload()};
  }
}
// 给启动按钮绑定事件
document.querySelectorAll('button.btn-start').forEach(function(b){
  b.onclick=function(){startOne(this.dataset.name)};
});
document.querySelectorAll('button.btn-show').forEach(function(b){
  b.onclick=function(){showStore(this.dataset.name)};
});
async function showStore(name){
  var btn=document.querySelector('button.btn-show[data-name="'+name+'"]');if(btn)btn.disabled=true;
  var r=await api('/api/agent/show-store',{name:name});
  if(btn)btn.disabled=false;
  if(!r.ok)toast('显示失败: '+r.error,false);
}
// 标签切换
function switchTab(name){
  document.querySelectorAll('.tab').forEach(function(t){t.classList.toggle('active',false)});
  document.querySelectorAll('.tab-content').forEach(function(c){c.classList.toggle('active',false)});
  document.querySelector('.tab[onclick*="'+name+'"]').classList.add('active');
  document.getElementById('tab-'+name).classList.add('active');
  if(name==='dashboard'){
    var iframe=document.getElementById('iframe-dashboard');
    if(!iframe.src)iframe.src='/dashboard.html';
  }
}
</script>
</div>
<div class="tab-content" id="tab-dashboard">
  <iframe id="iframe-dashboard" src=""></iframe>
</div>
</body>
</html>`);
  } catch (e) {
    res.status(500).send('Error: ' + e.message);
  }
});

// 切换账号（通过 GET 方式，从切换页面调用）
app.get('/api/agent/switch-form', auth, async (req, res) => {
  if (!agent) return res.redirect('/api/agent/switcher?msg=请先启动服务');
  const name = req.query.name;
  if (!name) return res.redirect('/api/agent/switcher?msg=缺少账号名');
  try {
    const target = agent.findAccountByName(name);
    if (!target) return res.redirect('/api/agent/switcher?msg=账号不存在');
    await agent.switchTo(target);
    res.redirect('/api/agent/switcher?msg=切换成功:' + encodeURIComponent(name));
  } catch (e) {
    res.redirect('/api/agent/switcher?msg=切换失败:' + encodeURIComponent(e.message));
  }
});

// 导航页面（通过 GET 方式，从切换页面调用）
app.get('/api/agent/navigate-page', auth, async (req, res) => {
  if (!agent || !agent.page) return res.redirect('/api/agent/switcher?msg=浏览器未启动');
  const url = req.query.url;
  if (!url) return res.redirect('/api/agent/switcher?msg=缺少URL');
  try {
    await agent.page.goto(url, { waitUntil: 'domcontentloaded', timeout: 20000 });
    await agent.page.waitForTimeout(2000);
    await agent.injectMonitor();
    res.redirect('/api/agent/switcher?msg=已跳转');
  } catch (e) {
    res.redirect('/api/agent/switcher?msg=跳转失败:' + encodeURIComponent(e.message));
  }
});

// ===== 文件上传到发布页 =====
app.post('/api/agent/upload-file', auth, async (req, res) => {
  try {
    if (!agent) return res.status(404).json({ error: '代理未启动' });
    var store = req.body.store;
    var filePath = req.body.filePath;
    var pg = agent.getStorePage(store);
    if (!pg) return res.json({ ok: false, error: '店铺未就绪' });
    await pg.locator('input[type=file]').setInputFiles(filePath);
    res.json({ ok: true });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// ===== 模拟操作发布（绕过 mtop 风控） =====
app.post('/api/agent/publish-ui', auth, async (req, res) => {
  try {
    if (!agent) return res.status(404).json({ error: '代理未启动' });
    var store = req.body.store;
    var filePath = req.body.filePath;
    var desc = req.body.desc || '代拍服务，欢迎咨询';
    var price = req.body.price || '50';
    var pg = agent.getStorePage(store);
    if (!pg) return res.json({ ok: false, error: '店铺「' + store + '」未就绪' });

    console.log('[pub-ui] ' + store + ' 图片: ' + filePath);

    // 1. 导航到发布页
    await pg.evaluate('location.href="https://www.goofish.com/publish"');
    await pg.waitForTimeout(6000);

    // 2. 先选分类为代购（在传图前，避免图片识别覆盖分类）
    console.log('[pub-ui] 切换分类到代购...');
    try {
      // 点击分类区域打开下拉框（找包含"分类"文字的可点击元素）
      var catArea = pg.locator('text=分类').first();
      await catArea.click();
      await pg.waitForTimeout(1500);
      // 在下拉/弹出层中点击"代购"
      var daigou = pg.locator('text=代购').first();
      await daigou.click();
      await pg.waitForTimeout(2000);
      console.log('[pub-ui] ✅ 分类已切换');
    } catch(e) {
      console.log('[pub-ui] ⚠ 分类切换跳过: ' + e.message);
    }

    // 3. 上传图片
    await pg.locator('input[type=file]').setInputFiles(filePath);
    await pg.waitForTimeout(5000);
    console.log('[pub-ui] 图片已上传');

    // 4. 填描述
    await pg.evaluate('var el=document.querySelector(".editor--MtHPS94K");if(el){el.focus();el.click();document.execCommand("selectAll");document.execCommand("insertText",false,' + JSON.stringify(desc) + ');}');
    await pg.waitForTimeout(500);

    // 5. 填价格
    await pg.evaluate('var inp=document.querySelectorAll(".ant-input");if(inp.length>0){inp[0].focus();inp[0].click();document.execCommand("selectAll");document.execCommand("insertText",false,' + JSON.stringify(price) + ');}');
    await pg.waitForTimeout(500);

    // 6. 选发货方式：无需邮寄
    await pg.evaluate('var all=document.querySelectorAll("*");for(var i=0;i<all.length;i++){if((all[i].innerText||"").trim()==="无需邮寄"){all[i].click();break;}}');
    await pg.waitForTimeout(500);

    // 6.5 重新确认分类（必须在传图+填描述之后！）
    //   闲鱼的图片识别/文本识别会把分类改回「演唱会」，而「演唱会」类目【不支持网页发布】，
    //   点发布只会弹「该商品暂不支持网页发布，请到闲鱼APP发布」且不跳转（2026-09-26 实测）。
    //   所以第 2 步选好的分类会被覆盖，这里必须再确认一次；改分类不会清空已填的描述/价格/图片。
    try {
      var catNow = await pg.evaluate('(function(){var s=document.querySelectorAll(".ant-select")[0];return s?(s.innerText||"").trim():"";})()');
      if (catNow && catNow.indexOf('代购') < 0) {
        console.log('[pub-ui] 分类被改成「' + catNow + '」，重新切回代购...');
        await pg.evaluate('(function(){var s=document.querySelectorAll(".ant-select")[0];if(!s)return;var c=s.querySelector(".ant-select-selector")||s;c.dispatchEvent(new MouseEvent("mousedown",{bubbles:true}));c.click();})()');
        await pg.waitForTimeout(1200);
        var picked = await pg.evaluate('(function(){var o=[].slice.call(document.querySelectorAll(".ant-select-item-option"));var t=o.filter(function(e){return (e.innerText||"").trim()==="代购"})[0];if(t){t.click();return true;}return false;})()');
        await pg.waitForTimeout(2000);
        var catAfter = await pg.evaluate('(function(){var s=document.querySelectorAll(".ant-select")[0];return s?(s.innerText||"").trim():"";})()');
        console.log('[pub-ui] 分类重切: ' + (picked ? '已点代购 → 当前「' + catAfter + '」' : '❌ 下拉里没找到「代购」'));
        if (!picked || catAfter.indexOf('代购') < 0) {
          return res.json({ ok: false, error: '分类切不回「代购」（现为「' + catNow + '」）。演唱会类目不支持网页发布，请在APP发布或检查类目' });
        }
      }
    } catch (e) {
      console.log('[pub-ui] ⚠ 分类复核异常: ' + e.message);
    }

    // 7. 检查表单错误
    var errs = await pg.evaluate('var r=[];document.querySelectorAll("[class*=error],[class*=Error]").forEach(function(e){var t=e.innerText.trim();if(t.length>0&&t.length<60)r.push(t);});r');
    if (errs && errs.length > 0) {
      return res.json({ ok: false, error: '表单错误: ' + errs.join('; ') });
    }

    // 8. 点发布
    var btnState = await pg.evaluate('(function(){var b=document.querySelector(".publish-button--KBpTVopQ");if(!b)return "no button";if(b.disabled)return "disabled";b.click();return "clicked";})()');
    console.log('[pub-ui] 发布按钮: ' + btnState);
    if (btnState !== 'clicked') {
      return res.json({ ok: false, error: '发布按钮不可用: ' + btnState });
    }

    // 9. 轮询等待跳转（最多30秒）
    var itemId = '';
    for (var w = 0; w < 15; w++) {
      await pg.waitForTimeout(2000);
      var url = await pg.evaluate('location.href');
      var m = String(url).match(/id=(\d+)/);
      if (m) { itemId = m[1]; break; }
      var err = await pg.evaluate('document.body.innerText.indexOf("失败")>=0||document.body.innerText.indexOf("ABORT")>=0');
      if (err) break;
    }

    if (itemId) {
      console.log('[pub-ui] ✅ 发布成功 itemId=' + itemId);
      res.json({ ok: true, itemId: itemId });
    } else {
      // 闲鱼的校验提示走 ant-message（不是 [class*=error]），单独抓一下，否则只剩一句"未跳转"
      var toast = '';
      try { toast = await pg.evaluate('(function(){var e=document.querySelector(".ant-message-notice-content");return e?(e.innerText||"").trim():"";})()'); } catch (e2) { }
      var body = await pg.evaluate('document.body.innerText.slice(0,200)');
      console.log('[pub-ui] ❌ 未跳转' + (toast ? '  toast=' + toast : ''));
      res.json({ ok: false, error: '发布未成功' + (toast ? '：' + toast : '') + ' ｜ 页面: ' + String(body).slice(0, 80) });
    }
  } catch (e) {
    console.log('[pub-ui] 异常: ' + e.message);
    res.json({ ok: false, error: e.message });
  }
});

// ===== API 抓取（探查未知 mtop 接口，如下架商品） =====
const API_CAPTURE_FILE = path.join(__dirname, '_apicap.txt');

// 读取抓取到的 mtop 请求（?only=关键词 过滤，?limit=N 取最后N条）
app.get('/api/agent/api-capture', auth, async (req, res) => {
  try {
    if (!fs.existsSync(API_CAPTURE_FILE)) return res.json({ ok: true, items: [], total: 0 });
    var lines = fs.readFileSync(API_CAPTURE_FILE, 'utf8').split('\n').filter(Boolean);
    var items = [];
    for (var i = 0; i < lines.length; i++) { try { items.push(JSON.parse(lines[i])); } catch(e) {} }
    if (req.query.only) { var k = String(req.query.only); items = items.filter(function(x){ return x.api && x.api.indexOf(k) >= 0; }); }
    var total = items.length;
    var limit = parseInt(req.query.limit) || 60;
    res.json({ ok: true, total: total, items: items.slice(-limit) });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// 清空抓取文件（开始一次"手动操作-抓包"前调用）
app.post('/api/agent/api-capture-clear', auth, async (req, res) => {
  try { fs.writeFileSync(API_CAPTURE_FILE, ''); res.json({ ok: true }); }
  catch (e) { res.json({ ok: false, error: e.message }); }
});

// ===== Native Host 转发（调用 Python 脚本处理文件读写） =====
const { execFile } = require('child_process');
const NATIVE_HOST_SCRIPT = (function () {
  var beside = path.join(__dirname, '..', 'xianyu-monitor', 'native_host.py');
  try { if (fs.existsSync(beside)) return beside; } catch (e) {}
  return 'C:/Users/43462/Desktop/xianyu-monitor/native_host.py';
})();

app.post('/api/agent/native-host', auth, async (req, res) => {
  try {
    // 用临时文件避免 stdin 编码问题
    const tmpFile = path.join(__dirname, '_nh_tmp_input_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8) + '.bin');
    const json = JSON.stringify(req.body);
    const jsonBuf = Buffer.from(json, 'utf8');
    const lenBuf = Buffer.alloc(4);
    lenBuf.writeUInt32LE(jsonBuf.length, 0);
    fs.writeFileSync(tmpFile, Buffer.concat([lenBuf, jsonBuf]));

    const python = await new Promise((resolve, reject) => {
      const child = execFile('python', [NATIVE_HOST_SCRIPT, '--file', tmpFile], {
        maxBuffer: 50 * 1024 * 1024,
        timeout: 60000,
        encoding: 'buffer'
      }, (err, stdout, stderr) => {
        if (err) { reject(err); return; }
        resolve(stdout);
      });
    });
    try { fs.unlinkSync(tmpFile); } catch(e) {}
    // native_host.py 输出格式：4字节长度前缀 + JSON
    const msgLen = python.readUInt32LE(0);
    const raw = python.slice(4, 4 + msgLen).toString('utf8');
    const result = JSON.parse(raw);
    res.json({ ok: true, data: result });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// ===== 多店铺并行 =====

// 启动单个账号
app.post('/api/agent/start-one', auth, async (req, res) => {
  console.log('[http] POST /api/agent/start-one', JSON.stringify(req.body));
  if (!agent) return res.status(404).json({ error: '请先调用 start-all' });
  try {
    var name = req.body.name;
    var account = agent.findAccountByName(name);
    if (!account) return res.status(404).json({ error: '账号不存在: ' + name });
    var result = await agent.switchTo(account);
    res.json({ ok: true, name: name, state: result.state });
    // ⚠️ 2026-11-13：这个 catch 只把错误返回给调用方，【不负责重置 agent.state】。
    //   所以 agent.js 的 _switchTo() 内部【必须】自己 catch 并把 state 设成 error ——
    //   否则一旦切换中途抛异常（newContext 失败 / 页面导航打断注入 …），
    //   state 会永远停在 switching，后续所有 store-ready / 发布全部 180 秒超时，
    //   只有重启 8093 才恢复。那天就是这么卡死的，日志里还看着一切正常。
    //   别把 agent.js 里那个 try/catch 删掉。
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// 搬运店铺：导航到指定 URL
app.post('/api/agent/move', auth, async (req, res) => {
  if (!agent) return res.status(404).json({ error: 'no agent' });
  try {
    var store = req.body.store;
    var url = req.body.url;
    var account = agent.findAccountByName(store);
    if (!account) return res.status(404).json({ error: '账号不存在: ' + store });
    // 确保店铺已启动
    await agent.switchTo(account);
    // 导航 goofish 页面到目标 URL
    var page = agent.getStorePage(store);
    if (!page) return res.status(404).json({ error: '店铺页面未就绪' });
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    var title = await page.title();
    res.json({ ok: true, store: store, title: title, url: url });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// 前台显示指定店铺窗口
app.post('/api/agent/show-store', auth, async (req, res) => {
  if (!agent) return res.status(404).json({ error: 'no agent' });
  try {
    var page = agent.getStorePage(req.body.name);
    if (!page) return res.status(404).json({ error: '店铺未就绪' });
    await page.bringToFront();
    res.json({ ok: true });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

// 预打开所有店铺页面
app.post('/api/agent/open-all-stores', auth, async (req, res) => {
  if (!agent) return res.status(404).json({ error: '代理未启动' });
  try {
    await agent.openAllStores();
    res.json({ ok: true, stores: Object.keys(agent.stores) });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// 在指定店铺页面上执行 JS
app.post('/api/agent/eval-on-store', auth, async (req, res) => {
  if (!agent) return res.status(404).json({ error: '代理未启动' });

  // 🚫 删除守卫（2026-09-20 加入）
  // 起因：agent 判定「>24h 0 曝光 = 死计划」并批量删了 22 个擦亮计划，
  // 判据用了不存在的字段（impressionPv / pv，真实字段是 todayAdDataDetail.showPv），
  // 导致判据恒真、全量误删；闲鱼广告计划删除后无法恢复。
  // 扩展侧 monitor.js 的审批弹框拦不住这条路（这里是直调 mtop，绕过 UI），
  // 所以在此硬拦：删除类操作一律拒绝，必须由人在闲鱼页面上手动执行。
  var DELETE_GUARD = /idle\.ad\.campaign\.(delete|cancel)/i;
  if (typeof req.body.code === 'string' && DELETE_GUARD.test(req.body.code)) {
    try {
      require('fs').appendFileSync(
        'D:/DSH/achun/delete-guard-audit.log',
        JSON.stringify({
          ts: new Date().toISOString(),
          store: req.body.store,
          digest: require('crypto').createHash('sha256').update(req.body.code).digest('hex').slice(0, 16),
          len: req.body.code.length
        }) + '\n'
      );
    } catch (e) { /* 审计失败不影响拦截 */ }
    console.warn('[DELETE-GUARD] 拦截删除擦亮计划的 eval-on-store 调用 store=' + req.body.store);
    return res.status(403).json({
      ok: false,
      blocked: true,
      error: 'BLOCKED_BY_DELETE_GUARD: 删除擦亮计划不可恢复，已禁止经 eval-on-store 执行。' +
             '请在闲鱼页面上手动删除（扩展侧会弹框列出计划供确认）。'
    });
  }

  try {
    var result = await agent.evalOnStore(req.body.store, req.body.code);
    res.json({ ok: true, result: result });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

app.post('/api/agent/eval', auth, async (req, res) => {
  if (!agent) return res.status(404).json({ error: 'no browser' });
  var pg = req.body.page === 'goofish' ? agent.pages.goofish : (req.body.page === 'dayu' ? agent.pages.dayu : agent.page);
  if (!pg) return res.status(404).json({ error: 'page not found' });
  try { var result = await pg.evaluate(req.body.code); res.json({ ok: true, result: result }); }
  catch (e) { res.json({ ok: false, error: e.message }); }
});

// 图片转存闲鱼图床：服务端用店铺 context.request 带 cookie 直传，绕过页面 CORS（stream-upload 从页面 fetch 会被拦）
app.post('/api/agent/upload-image', auth, async (req, res) => {
  try {
    var store = req.body.store;
    var sd = agent && agent.stores[store];
    if (!sd) return res.status(404).json({ ok: false, error: '店铺「' + store + '」未启动' });
    var b64 = String(req.body.imageB64 || '').replace(/^data:image\/[^;]+;base64,/, '');
    if (!b64) return res.json({ ok: false, error: '缺少图片数据' });
    var buf = Buffer.from(b64, 'base64');
    var r, txt;
    async function doUpload() {
      r = await sd.context.request.post('https://stream-upload.goofish.com/api/upload.api?floderId=0&appkey=fleamarket&_input_charset=utf-8', {
        headers: { 'Referer': 'https://www.goofish.com/', 'Origin': 'https://www.goofish.com' },
        multipart: { file: { name: 'upload.jpg', mimeType: 'image/jpeg', buffer: buf } }
      });
      txt = await r.text();
    }
    async function parseUrl() {
      var j = null; try { j = JSON.parse(txt); } catch(e) {}
      return (j && j.object && j.object.url) || (j && j.url);
    }
    await doUpload();
    var url = await parseUrl();
    // 若返回登录页/非JSON页面（闲鱼会话瞬间失效），用店铺上下文开临时页刷新会话后重试一次（不打断主发布页）
    if (!url && (/<!DOCTYPE html>/i.test(txt) || /login\.html/i.test(txt) || /tb-nav/i.test(txt))) {
      try {
        var _p = await sd.context.newPage();
        await _p.goto('https://www.goofish.com/', { waitUntil: 'domcontentloaded' });
        await _p.close();
        await doUpload();
        url = await parseUrl();
      } catch(e) {}
    }
    if (url && url.indexOf('http') === 0) res.json({ ok: true, url: url });
    else res.json({ ok: false, error: '图床返回异常(HTTP ' + r.status() + '): ' + txt.substring(0, 240) });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// CASA家居搬运：在新页面抓取店铺商品（不影响goofish发布页）
app.post('/api/agent/scrape-shop', auth, async (req, res) => {
  if (!agent) return res.status(404).json({ error: 'no agent' });
  var scrapePage = null;
  try {
    var store = req.body.store;
    var url = req.body.url;
    var mode = req.body.mode || 'tmall'; // 'xianyu' | 'tmall'
    var limit = parseInt(req.body.limit) || 20;
    var account = agent.findAccountByName(store);
    if (!account) return res.status(404).json({ error: '账号不存在: ' + store });
    await agent.switchTo(account);
    var sd = agent.stores[store];
    if (!sd) return res.status(404).json({ error: '店铺未就绪' });
    scrapePage = await sd.context.newPage();

    // 1. 导航到店铺页
    await scrapePage.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await scrapePage.waitForTimeout(3000);
    // 2. 滚动加载全部商品
    for (var si = 0; si < 5; si++) {
      await scrapePage.evaluate('window.scrollTo(0,document.body.scrollHeight)');
      await scrapePage.waitForTimeout(1500);
    }
    // 3. 抓取商品列表
    var items = [];
    if (mode === 'xianyu') {
      items = await scrapePage.evaluate(function() {
        var p = [], s = {};
        document.querySelectorAll('a[href*="item"]').forEach(function(a) {
          var h = a.href, m = h.match(/id=(\w+)/);
          if (!m || s[m[1]]) return;
          var c = a.closest('[class*="item"],[class*="card"],[class*="feed"]') || a.parentElement;
          var t = (a.textContent || a.title || '').trim().split('\n')[0];
          if ((!t || t.length < 3) && c) { var te = c.querySelector('[class*="title"],[class*="desc"]'); if (te) t = te.textContent.trim(); }
          if (!t || t.length < 3) return;
          var im = (c || a).querySelector('img');
          var iu = im ? (im.src || '') : '';
          var pe = c ? c.querySelector('[class*="price"],[class*="Price"]') : null;
          var pr = 0; if (pe) { var pm = (pe.textContent||'').match(/[\d.]+/); if (pm) pr = parseFloat(pm[0]); }
          s[m[1]] = 1;
          p.push({ title: t.substring(0,120), price: pr, image: iu, url: h });
        });
        return p;
      });
    } else {
      items = await scrapePage.evaluate(function() {
        var p = [], s = {};
        document.querySelectorAll('a[href*="item.htm"]').forEach(function(a) {
          var h = a.href, m = h.match(/[?&]id=(\d+)/);
          if (!m || s[m[1]]) return;
          var c = a.closest('dl,div[class*="item"],div[class*="card"],li') || a.parentElement;
          var t = (a.title || '').trim();
          if ((!t || t.length < 3) && c) { var te = c.querySelector('[class*="title"],[class*="name"]'); if (te) t = te.textContent.trim(); }
          if (!t || t.length < 3) return;
          var im = c ? c.querySelector('img') : null;
          var iu = im ? (im.src || im.getAttribute('data-src') || '') : '';
          var pe = c ? c.querySelector('[class*="price"],[class*="Price"],em') : null;
          var pr = 0; if (pe) { var pm = (pe.textContent||'').match(/[\d.]+/); if (pm) pr = parseFloat(pm[0]); }
          s[m[1]] = 1;
          p.push({ id: m[1], title: t.substring(0,120), price: pr, image: iu, url: h });
        });
        return p;
      });
    }
    if (!items || items.length === 0) {
      if (scrapePage) try { await scrapePage.close(); } catch(e){}
      return res.json({ ok: false, error: '未找到商品，请检查网址是否正确' });
    }
    if (items.length > limit) items = items.slice(0, limit);
    // 4. 逐个抓取详情图片
    for (var i = 0; i < items.length; i++) {
      try {
        await scrapePage.goto(items[i].url, { waitUntil: 'domcontentloaded', timeout: 20000 });
        await scrapePage.waitForTimeout(2000);
        if (mode === 'xianyu') {
          var det = await scrapePage.evaluate(function() {
            var d = ''; var de = document.querySelector('[class*="desc"],[class*="detail"]');
            if (de) d = (de.textContent || '').trim().substring(0, 800);
            var imgs = [];
            document.querySelectorAll('img').forEach(function(img) {
              var s = img.src || '';
              if ((s.indexOf('alicdn') >= 0 || s.indexOf('goofish') >= 0) && s.indexOf('avatar') < 0 && s.indexOf('logo') < 0 && imgs.indexOf(s) < 0) imgs.push(s);
              if (imgs.length >= 9) return;
            });
            return { desc: d, images: imgs.slice(0, 9) };
          });
          items[i].description = (det && det.desc) || '';
          items[i].images = (det && det.images) || [];
          if (!items[i].image && det && det.images.length > 0) items[i].image = det.images[0];
        } else {
          var imgs2 = await scrapePage.evaluate(function() {
            var r = [];
            document.querySelectorAll('#J_UlThumb img,[class*="thumb"] img,[class*="Thumb"] img').forEach(function(img) {
              var s = img.src || img.getAttribute('data-src') || '';
              s = s.replace(/_\d+x\d+[^.]*\./, '.').replace(/\.q\d+/, '');
              if (s.indexOf('http') === 0 && r.indexOf(s) < 0) r.push(s);
              if (r.length >= 5) return;
            });
            if (r.length === 0) {
              document.querySelectorAll('img').forEach(function(img) {
                var s = img.src || '';
                if (s.indexOf('alicdn') >= 0 && r.indexOf(s) < 0) r.push(s);
                if (r.length >= 5) return;
              });
            }
            return r.slice(0, 5);
          });
          items[i].images = imgs2 || [];
          if (!items[i].image && imgs2 && imgs2.length > 0) items[i].image = imgs2[0];
        }
      } catch(e) {
        items[i].images = items[i].image ? [items[i].image] : [];
        if (mode === 'xianyu') items[i].description = items[i].description || '';
      }
    }
    if (scrapePage) try { await scrapePage.close(); } catch(e){}
    scrapePage = null;
    res.json({ ok: true, items: items, count: items.length });
  } catch (e) {
    if (scrapePage) try { await scrapePage.close(); } catch(e){}
    res.json({ ok: false, error: e.message });
  }
});

// ===== 飞书机器人推送（海报交互卡片）=====
const FEISHU_WEBHOOK_URL = process.env.POSTER_WEBHOOK_URL || '';

async function pushFeishuCard(info) {
  if (!FEISHU_WEBHOOK_URL) return { ok: false, error: '未配置POSTER_WEBHOOK_URL' };
  var fields = [
    { is_short: true, text: { tag: 'lark_md', content: '**城市**\n' + (info.city || '-') } },
    { is_short: true, text: { tag: 'lark_md', content: '**明星**\n' + (info.star || '-') } },
    { is_short: true, text: { tag: 'lark_md', content: '**场次**\n' + (info.variant || '-') } },
    { is_short: true, text: { tag: 'lark_md', content: '**店铺**\n' + (info.store || '-') } }
  ];
  if (info.date) fields.push({ is_short: true, text: { tag: 'lark_md', content: '**时间**\n' + info.date } });
  if (info.venue) fields.push({ is_short: true, text: { tag: 'lark_md', content: '**场馆**\n' + info.venue } });
  if (info.price) fields.push({ is_short: true, text: { tag: 'lark_md', content: '**票价**\n' + info.price } });

  var actions = [];
  if (info.imageUrl) actions.push({ tag: 'button', text: { tag: 'plain_text', content: '🖼 查看海报图' }, url: info.imageUrl, type: 'primary' });
  if (info.goofishUrl) actions.push({ tag: 'button', text: { tag: 'plain_text', content: '🐟 闲鱼商品' }, url: info.goofishUrl, type: 'default' });

  var card = {
    config: { wide_screen_mode: true },
    header: { title: { tag: 'plain_text', content: '🎨 海报生成：' + (info.city || '') + '·' + (info.star || '') + ' ' + (info.variant || '') }, template: 'orange' },
    elements: [
      { tag: 'div', fields: fields },
      { tag: 'hr' }
    ]
  };
  if (actions.length > 0) card.elements.push({ tag: 'action', actions: actions });

  const resp = await fetch(FEISHU_WEBHOOK_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ msg_type: 'interactive', card: card })
  });
  if (!resp.ok) {
    var t = ''; try { t = await resp.text(); } catch(e) {}
    return { ok: false, error: '飞书推送失败 HTTP ' + resp.status + ' ' + t.substring(0, 120) };
  }
  var j = ''; try { j = await resp.json(); } catch(e) {}
  if (j && j.code && j.code !== 0) return { ok: false, error: '飞书返回: ' + (j.msg || JSON.stringify(j)).substring(0, 120) };
  return { ok: true };
}

// 推送飞书卡片（CDN上传后调用，带公网图片URL）
app.post('/api/poster/notify', auth, async (req, res) => {
  try {
    var r = await pushFeishuCard({
      city: req.body.city || '', star: req.body.star || '', variant: req.body.variant || '',
      date: req.body.date || '', venue: req.body.venue || '', price: req.body.price || '',
      store: req.body.store || '', imageUrl: req.body.imageUrl || '', goofishUrl: req.body.goofishUrl || ''
    });
    res.json(r);
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// ===== 海报生成（演唱会作图闭环）=====
let posterBrowser = null;
let posterBrowserIdle = null;
// 2026-09-28：常驻 Chromium 原来【永不关闭】—— 9 个进程常占 ~723MB，在 16GB 机器上很要命。
// 现在加空闲回收：超过 IDLE 没被用到就关掉，下次用到再懒加载（多花约 1s 启动，换回内存）。
// 可用环境变量 POSTER_BROWSER_IDLE_MS 覆盖（自检用，例如设成 30000 验证回收是否真的发生）。
const POSTER_BROWSER_IDLE_MS = parseInt(process.env.POSTER_BROWSER_IDLE_MS || '', 10) || 10 * 60 * 1000;

function _posterBrowserScheduleClose(reason) {
  if (posterBrowserIdle) { clearTimeout(posterBrowserIdle); posterBrowserIdle = null; }
  posterBrowserIdle = setTimeout(function () { _posterBrowserMaybeClose(reason); }, POSTER_BROWSER_IDLE_MS);
  if (posterBrowserIdle.unref) posterBrowserIdle.unref();   // 别让定时器吊住进程
}

function _posterBrowserMaybeClose(reason) {
  posterBrowserIdle = null;
  if (!posterBrowser) return;
  // 还有打开的页面 = 出图/搜索正在进行 → 不能掐断，推迟一分钟再看
  var pages = 0;
  try { posterBrowser.contexts().forEach(function (c) { pages += c.pages().length; }); } catch (e) { }
  console.log('[poster] 空闲回收检查：打开页面数=' + pages + (pages > 0 ? ' → 推迟 60s' : ' → 关闭'));
  if (pages > 0) {
    posterBrowserIdle = setTimeout(function () { _posterBrowserMaybeClose(reason); }, 60 * 1000);
    if (posterBrowserIdle.unref) posterBrowserIdle.unref();
    return;
  }
  var b = posterBrowser; posterBrowser = null;
  // b.close() 是异步的，而且 try/catch 抓不住 Promise reject —— 必须显式 then/catch，
  // 否则关失败会静默（2026-09-28 自检时就是：日志说"已关闭"，但进程还活着）。
  Promise.resolve()
    .then(function () { return b.close(); })
    .then(function () { console.log('[poster] 常驻 Chromium 已关闭，内存已回收'); })
    .catch(function (e) { console.log('[poster] 关闭失败: ' + (e && e.message || e)); });
}

async function getPosterBrowser() {
  if (posterBrowserIdle) { clearTimeout(posterBrowserIdle); posterBrowserIdle = null; }
  if (posterBrowser && posterBrowser.isConnected && posterBrowser.isConnected()) {
    _posterBrowserScheduleClose('空闲 ' + Math.round(POSTER_BROWSER_IDLE_MS / 60000) + ' 分钟');
    return posterBrowser;
  }
  const { chromium } = require('playwright');
  posterBrowser = await chromium.launch({ headless: true });
  _posterBrowserScheduleClose('空闲 ' + Math.round(POSTER_BROWSER_IDLE_MS / 60000) + ' 分钟');
  return posterBrowser;
}

// 标题采集：大麦近期演唱会（搜"演唱会"+分城市，取城市/明星/场次/开抢状态）
async function collectDamai() {
  const { chromium } = require('playwright');
  const b = await chromium.launch({ headless: true });
  const ctx = await b.newContext({ userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1', viewport: { width: 390, height: 844 }, isMobile: true });
  const p = await ctx.newPage();
  const kws = ['演唱会','北京 演唱会','上海 演唱会','成都 演唱会','广州 演唱会','杭州 演唱会','南京 演唱会','西安 演唱会','兰州 演唱会','长沙 演唱会','武汉 演唱会'];
  const seen = {};
  for (const kw of kws) {
    let items = [];
    const h = async r => { if (/mtop\.damai\.wireless\.search\.search/.test(r.url())) { try { const j = JSON.parse(await r.text()); if (j.data && j.data.projectInfo) items = j.data.projectInfo; } catch(e){} } };
    p.on('response', h);
    try { await p.goto('https://m.damai.cn/damai/search/index.html?keyword=' + encodeURIComponent(kw), { waitUntil: 'networkidle', timeout: 30000 }).catch(()=>{}); await p.waitForTimeout(2200); } catch(e){}
    p.off('response', h);
    items.forEach(it => { if ((it.categoryName === '演唱会' || it.guideCategoryName === '音乐现场') && it.showTime) seen[it.id] = it; });
  }
  await b.close();
  return Object.values(seen).sort((a,b) => (a.nearestPerformTime || 0) - (b.nearestPerformTime || 0)).map(x => ({
    city: x.cityName, star: (x.actores || x.name || '').split(';')[0], name: x.name, showTime: x.showTime,
    status: (x.showStatus && x.showStatus.desc) || '', venue: (x.venueName || '').slice(0, 20), id: x.id, nearest: x.nearestPerformTime
  }));
}
app.get('/api/poster/campaigns', auth, async (req, res) => {
  try {
    if (!agent) { try { accountsCache = await fetchAccounts(); } catch(e){} agent = new XianyuAgent(); await agent.init(accountsCache || LOCAL_ACCOUNTS); }
    const store = req.query.store || '好易美代拍';
    const account = agent.findAccountByName(store);
    if (!account) return res.json({ ok: false, error: '账号不存在: ' + store });
    await agent.switchTo(account);
    const sd = agent.stores[store]; if (!sd) return res.json({ ok: false, error: '店铺未就绪' });
    const p = await sd.context.newPage();
    await p.goto('https://dayu.goofish.com/?site=FISHAD', { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(()=>{});
    await p.waitForTimeout(3500);
    const out = await p.evaluate(async () => {
      try {
        const body = { pageNum: 1, pageSize: 100, startDate: '', endDate: '', includeEndDate: true, campaignStatus: [-6,-5,-4,-3,-2,1,2,3,4,5,6,99], statusGroup: [] };
        const r = await window.lib.mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', data: { requestJson: JSON.stringify(body) }, type: 'POST' });
        if (!r || !r.ret || !r.ret[0] || !r.ret[0].startsWith('SUCCESS')) return { err: 'search: ' + ((r && r.ret && r.ret[0]) || 'fail') };
        return { list: (r.data && r.data.campaigns) || [] };
      } catch(e) { return { err: e.message }; }
    });
    await p.close();
    if (out.err) return res.json({ ok: false, error: out.err });
    res.json({ ok: true, store: store, count: out.list.length, items: out.list.map(c => ({ id: c.campaignId, name: c.campaignName || c.title || ((c.entityList && c.entityList[0] && c.entityList[0].title) || ''), status: c.status, pauseStatus: c.pauseStatus, bid: (c.infoTab && c.infoTab.bidPrice) || (c.bidPrice) || '', budget: (c.infoTab && c.infoTab.maxDayBudget) || '', title: (c.entityList && c.entityList[0] && c.entityList[0].title) || '' })) });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});
app.get('/api/poster/burn-plans', auth, async (req, res) => {
  try {
    const tok = await hymToken();
    let all = [], off = 0;
    for (let pg = 0; pg < 8; pg++) {
      const r = await fetch('https://manager.hympro.cn/api/admin-data?table=xianyu_campaigns&limit=200&offset=' + off, { headers: { Authorization: 'Bearer ' + tok } });
      const j = await r.json(); const d = (j && j.data) || []; if (!d.length) break; all = all.concat(d); off += 200;
    }
    const by = {};
    all.forEach(x => { const id = x.campaign_id || '?'; if (!by[id]) by[id] = { cost: 0, click: 0, chat: 0, inq: 0, days: 0, name: x.campaign_name || id }; const b = by[id]; b.cost += Number(x.cost) || 0; b.click += Number(x.click_pv) || 0; b.chat += Number(x.chat_pv) || 0; b.inq += Number(x.inquiries) || 0; b.days++; });
    const arr = Object.values(by);
    const burn = arr.map(x => { const thr = 100 * 0.3 * Math.max(x.days, 1); const costYuan = x.cost / 100; const cpi = x.inq > 0 ? (x.cost / x.inq / 100) : 0; return { id: x.name, cost: costYuan, days: x.days, click: x.click, chat: x.chat, inq: x.inq, costPerInquiry: cpi, costPerOrder: cpi, burn: x.cost < thr, suggest: (x.cost < thr ? '调价×1.1' : '正常') }; }).filter(x => x.burn).sort((a,b)=>b.cost-a.cost);
    res.json({ ok: true, total: arr.length, burn: burn });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

app.get('/api/title/collect-damai', auth, async (req, res) => { try { res.json({ ok: true, items: await collectDamai() }); } catch(e) { res.json({ ok: false, error: e.message }); } });

// ===== 闲鱼演唱会 最近活跃采集（复用店铺登录 context，抓闲鱼搜索 mtop 响应）=====
// 第一版：逐 item 打印 Object.keys + 前400字符（探测浏览量/想要字段真实位置），用 wantCount/viewCount 候选做热度
const CONCERT_CITY_LIST = ['北京','上海','成都','广州','深圳','杭州','南京','西安','武汉','长沙','重庆','天津','苏州','郑州','合肥','厦门','昆明','青岛','大连','沈阳','福州'];
const CONCERT_KWS_DEFAULT = ['演唱会抢票','演唱会 抢票','北京 演唱会','上海 演唱会','成都 演唱会','广州 演唱会','深圳 演唱会'];

function parseCountNum(v) {
  if (v === undefined || v === null) return 0;
  if (typeof v === 'number') return v;
  var s = String(v).trim();
  var m = s.match(/[\d.]+/);
  var n = m ? parseFloat(m[0]) : 0;
  if (s.indexOf('亿') >= 0) n *= 100000000;
  else if (s.indexOf('万') >= 0) n *= 10000;
  return n;
}

// 在 item 上按候选字段名取热度数字
function pickNum(item, aliases) {
  for (var i = 0; i < aliases.length; i++) {
    var k = aliases[i];
    if (item[k] !== undefined && item[k] !== null && item[k] !== '') return parseCountNum(item[k]);
  }
  return 0;
}

// 从 keyword / title 提取城市（优先命中关键字里显式城市）
function extractConcertCity(kw, title) {
  var t = String(title || '');
  for (var i = 0; i < CONCERT_CITY_LIST.length; i++) {
    var c = CONCERT_CITY_LIST[i];
    if (kw.indexOf(c) >= 0 || t.indexOf(c) >= 0) return c;
  }
  return '';
}

// 从 title 提取明星（去掉【】/括号内容，截到 演唱会/巡演/年份/live 之前）
function extractConcertStar(title) {
  var t = String(title || '').trim().replace(/[【\[（(].*?[】\]）)]/g, ' ').replace(/\s+/g, ' ').trim();
  var m = t.match(/^(.{1,12}?)(?:年度|2[0-9]{3}|世界|全国|巡回|巡演|演唱会|live|Live|LIVE|音乐节|音乐嘉年华|站)/);
  if (m && m[1].trim().length >= 2) return m[1].trim();
  var m2 = t.match(/[\u4e00-\u9fa5]{2,12}/);
  if (m2) return m2[0];
  return t.substring(0, 12);
}

// 从 title 提取场次（日期 / 场馆）
function extractConcertSession(title) {
  var t = String(title || '');
  var session = '';
  var dm = t.match(/202[0-9][\-/.]?\d{1,2}[\-/.]?\d{1,2}/) || t.match(/\d{1,2}月\d{1,2}[日号]/) || t.match(/\d{1,2}-\d{1,2}[日号]/);
  if (dm) session = dm[0];
  var venue = '';
  var vm = t.match(/[（(]([^()（）]{2,15}(?:馆|场|中心|体育|剧院|演出[^()（）]*))[)）]/);
  if (vm) venue = vm[1];
  var vm2 = t.match(/([\u4e00-\u9fa5]{2,12}(?:体育馆|体育场|大剧院|剧场|演艺中心|会展中心|体育中心|奥体中心|文化中心))/);
  if (!venue && vm2) venue = vm2[1];
  return (session && venue) ? (session + ' ' + venue) : (session || venue);
}

// 从 item 取价格（候选字段，无则 0）
function extractConcertPrice(item) {
  var aliases = ['price','salePrice','reservePrice','priceText','priceShow','priceShowStr','priceStr','displayPrice','priceTextStr','minPrice'];
  for (var i = 0; i < aliases.length; i++) {
    var v = item[aliases[i]];
    if (v === undefined || v === null || v === '') continue;
    if (typeof v === 'number') return v;
    var m = String(v).match(/[\d.]+/);
    if (m) return parseFloat(m[0]);
  }
  return 0;
}

async function collectXianyuConcerts(opts) {
  if (!agent) throw new Error('请先调用 start-all');
  var store = opts.store;
  var kws = (Array.isArray(opts.kws) && opts.kws.length) ? opts.kws : CONCERT_KWS_DEFAULT;
  var threshold = opts.threshold !== undefined ? Number(opts.threshold) : 50000;
  var limit = opts.limit !== undefined ? Number(opts.limit) : 20;
  var probe = opts.probe !== false;

  var account = agent.findAccountByName(store);
  if (!account) throw new Error('账号不存在: ' + store);
  await agent.switchTo(account);
  var sd = agent.stores[store];
  if (!sd || !sd.context) throw new Error('店铺未就绪: ' + store);
  var p = await sd.context.newPage();

  var seen = {};
  var collected = [];
  for (var ki = 0; ki < kws.length; ki++) {
    var kw = kws[ki];
    var raw = [];
    var h = async function(r) {
      try {
        if (/mtop\.taobao\.idle\..*search/i.test(r.url())) {
          var j = JSON.parse(await r.text());
          var list = j && j.data && (j.data.items || j.data.result);
          if (Array.isArray(list)) { for (var x = 0; x < list.length; x++) raw.push(list[x]); }
        }
      } catch(e) {}
    };
    p.on('response', h);
    try {
      await p.goto('https://www.goofish.com/search?q=' + encodeURIComponent(kw), { waitUntil: 'networkidle', timeout: 30000 }).catch(function(){});
      await p.waitForTimeout(2500);
    } catch(e) {}
    p.off('response', h);

    for (var ri = 0; ri < raw.length; ri++) {
      var it = raw[ri];
      if (!it) continue;
      var itemId = it.itemId || it.id || (it.item && (it.item.itemId || it.item.id)) || '';
      if (!itemId) continue;
      if (seen[itemId]) continue;
      seen[itemId] = 1;
      if (probe) {
        console.log('[collect-concerts] kw=' + kw + ' itemId=' + itemId + ' keys:', Object.keys(it));
        console.log('[collect-concerts] item(' + itemId + ') 前400字符: ' + JSON.stringify(it).substring(0, 400));
      }
      collected.push({ kw: kw, item: it, itemId: itemId });
    }
  }
  try { await p.close(); } catch(e) {}

  // 探测：字段出现频率，帮助确认真实字段名位置
  if (probe) {
    var keyCounter = {};
    for (var di = 0; di < collected.length; di++) {
      Object.keys(collected[di].item).forEach(function(k) { keyCounter[k] = (keyCounter[k] || 0) + 1; });
    }
    console.log('[collect-concerts] 字段出现频率(前40): ' + JSON.stringify(Object.entries(keyCounter).sort(function(a, b) { return b[1] - a[1]; }).slice(0, 40)));
  }

  var result = [];
  for (var ii = 0; ii < collected.length; ii++) {
    var it = collected[ii].item;
    var title = it.title || it.name || it.itemTitle || (it.item && it.item.title) || '';
    if (!/演唱会|抢票|巡演|巡回|live|音乐节/i.test(String(title))) continue;
    var view = pickNum(it, ['viewCount','viewNum','view','views','browseCount','browseNum','pv','ipvuv','watchCount','readCount','view_cnt','view_count','viewTotal']);
    var want = pickNum(it, ['wantCount','wantNum','want','collectCount','collectNum','favoriteCount','favCount','likeCount','want_cnt','want_count','wantTotal']);
    var hot = Math.max(view, want);
    if (hot < threshold) continue;
    result.push({
      city: extractConcertCity(collected[ii].kw, String(title)),
      star: extractConcertStar(String(title)),
      session: extractConcertSession(String(title)),
      view: view,
      want: want,
      price: extractConcertPrice(it),
      itemId: collected[ii].itemId,
      url: 'https://www.goofish.com/item?id=' + collected[ii].itemId
    });
  }
  result.sort(function(a, b) { return b.view - a.view; });
  if (result.length > limit) result = result.slice(0, limit);
  return result;
}

// 闲鱼演唱会 最近活跃采集：POST /api/agent/collect-concerts（复用店铺登录 context，无需新起浏览器）
app.post('/api/agent/collect-concerts', auth, async (req, res) => {
  try {
    var store = req.body.store;
    if (!store) {
      // 默认取第一个账号
      var accs = Object.values(agent ? agent.accounts : {});
      if (accs.length === 0 && accountsCache.length) accs = accountsCache;
      if (accs.length === 0 && LOCAL_ACCOUNTS.length) accs = LOCAL_ACCOUNTS;
      if (accs.length === 0) return res.json({ ok: false, error: '无可用账号，请先调用 start-all' });
      store = accs[0].name;
    }
    var items = await collectXianyuConcerts({
      store: store,
      kws: req.body.kws,
      threshold: req.body.threshold,
      limit: req.body.limit,
      probe: req.body.probe !== false
    });
    console.log('[collect-concerts] ✅ 完成 store=' + store + ' kws=' + (Array.isArray(req.body.kws) ? req.body.kws.length : '默认') + ' count=' + items.length);
    res.json({ ok: true, count: items.length, items: items });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 标题采集（情报站）：好易美后台 intelligence_events → 城市+明星+场次
app.get('/api/title/collect-intel', auth, async (req, res) => {
  try {
    const tok = await hymToken();
    let all = [], off = 0;
    for (let pg = 0; pg < 8; pg++) {
      const r = await fetch('https://manager.hympro.cn/api/admin-data?table=intelligence_events&limit=200&offset=' + off, { headers: { Authorization: 'Bearer ' + tok } });
      const j = await r.json(); const d = (j && j.data) || []; if (!d.length) break; all = all.concat(d); off += 200;
    }
    const items = all.filter(x => x.event_type === 'ticket' && x.extracted && x.extracted.city).map(x => ({ star: x.artist_name, city: x.extracted.city, date: x.extracted.date || '', venue: x.extracted.venue || '', name: x.title || '' }));
    res.json({ ok: true, items: items });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

// 标题采集（热度>5万）：情报站 明星+城市 → 大麦搜项目 ipvuv → 筛 >5万
app.get('/api/title/collect-intel-hot', auth, async (req, res) => {
  try {
    const tok = await hymToken();
    let all = [], off = 0;
    for (let pg = 0; pg < 4; pg++) {
      const r = await fetch('https://manager.hympro.cn/api/admin-data?table=intelligence_events&limit=200&offset=' + off, { headers: { Authorization: 'Bearer ' + tok } });
      const j = await r.json(); const d = (j && j.data) || []; if (!d.length) break; all = all.concat(d); off += 200;
    }
    const stars = []; all.forEach(x => { if (x.event_type === 'ticket' && x.artist_name && stars.indexOf(x.artist_name) < 0) stars.push(x.artist_name); });
    const out = [];
    const { chromium } = require('playwright');
    const b = await chromium.launch({ headless: true });
    const ctx = await b.newContext({ userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1', viewport: { width: 390, height: 844 }, isMobile: true });
    const p = await ctx.newPage();
    for (const star of stars.slice(0, 15)) {
      let items = [];
      const h = async r => { if (/mtop\.damai\.wireless\.search\.search/.test(r.url())) { try { const j = JSON.parse(await r.text()); if (j.data && j.data.projectInfo) items = j.data.projectInfo; } catch(e){} } };
      p.on('response', h);
      try { await p.goto('https://m.damai.cn/damai/search/index.html?keyword=' + encodeURIComponent(star), { waitUntil: 'networkidle', timeout: 25000 }).catch(()=>{}); await p.waitForTimeout(1500); } catch(e){}
      p.off('response', h);
      const hot = items.filter(it => (it.categoryName === '演唱会' || it.guideCategoryName === '音乐现场') && (parseInt(it.ipvuv) || 0) >= 50000);
      hot.forEach(it => out.push({ star: star, city: it.cityName, name: it.name, showTime: it.showTime, ipvuv: it.ipvuv, venue: (it.venueName || '').slice(0, 20) }));
    }
    await b.close();
    res.json({ ok: true, items: out });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

// 海报合成画布页（Canvas 绘制，中文用系统字体）
const POSTER_HTML = `<!doctype html><html><head><meta charset="utf-8"></head>
<body style="margin:0"><canvas id="c" width="1020" height="1360"></canvas>
<script>
function rr(ctx,x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}
function st(ctx,txt,x,y,font,fill,stroke,sw,align){
  ctx.save();
  ctx.font=font;
  ctx.textAlign=align||'center';
  ctx.textBaseline='middle';
  ctx.lineJoin='round';
  if(stroke){ctx.lineWidth=sw||5;ctx.strokeStyle=stroke;ctx.strokeText(txt,x,y);}
  ctx.fillStyle=fill;ctx.fillText(txt,x,y);
  ctx.restore();
}
// 模板模式：直接用模板原图，只替换文字
window.drawPoster=function(p){
  var img=new Image();
  img.onload=function(){
    var c=document.getElementById('c');
    c.width=img.naturalWidth;c.height=img.naturalHeight;
    var ctx=c.getContext('2d');
    ctx.imageSmoothingEnabled=true; ctx.imageSmoothingQuality='high';
    var W=c.width,H=c.height;
    // 1. 画出完整模板原图（保留所有设计元素）
    ctx.drawImage(img,0,0,W,H);
    // 1.5 版式贴纸模式：贴徐良原图扣下的四个色块 PNG 的 alpha 形状，全部重铺纯色 + 代码重写字。
    // 形状（两端斜切/圆角/倾角）与原版 100% 一致；烘焙原字/残影被纯色完全盖掉；文字代码写零错字。
    if(p.cutouts&&p.cutouts.length){
      var sx=W/1020, sy=H/1360;
      var sFit=sx; // 尺寸只按宽度等比缩，保持贴纸不变形；位置按各自轴缩放
      var loads=p.cutouts.map(function(co){return new Promise(function(res){var ci=new Image();ci.onload=function(){res(ci);};ci.onerror=function(){res(null);};ci.src='data:image/png;base64,'+co.src;});});
      Promise.all(loads).then(function(imgs){
        p.cutouts.forEach(function(co,i){
          var ci=imgs[i]; if(!ci)return;
          var dw=co.dw||Math.round(co.w*sFit), dh=co.dh||Math.round(co.h*sFit);
          // 位置取整：非整数坐标会触发 Canvas 子像素插值，把字边再糊一道（960底图实测差异6~11%的根源）
          var dx0=Math.round(co.x*sx), dy0=Math.round(co.y*sy);
          if(!co.purple){
            // 黄块原样搬运，零改动：描边/字/阴影/一切与原模板一致（服务端已预缩到精确尺寸，此处 1:1 贴）
            ctx.drawImage(ci, dx0, dy0, dw, dh);
            return;
          }
          // 紫块：alpha 形状重铺纯紫（含透明区 RGB，防脏边）+ 沿带轴写{城市}{明星}
          var pc=document.createElement('canvas');
          pc.width=ci.naturalWidth||ci.width; pc.height=ci.naturalHeight||ci.height;
          var pctx=pc.getContext('2d'); pctx.drawImage(ci,0,0);
          var pd=pctx.getImageData(0,0,pc.width,pc.height);
          var CR=co.color[0], CG=co.color[1], CB=co.color[2];
          for(var pi=0;pi<pd.data.length;pi+=4){
            pd.data[pi]=CR; pd.data[pi+1]=CG; pd.data[pi+2]=CB;
          }
          pctx.putImageData(pd,0,0);
          ctx.drawImage(pc, dx0, dy0, dw, dh);
          var cxp=dx0+dw/2+(co.tx||0)*sx, cyp=dy0+dh/2+(co.ty||0)*sy;
          ctx.save();
          ctx.translate(cxp,cyp); ctx.rotate((co.rot||0)*Math.PI/180);
          var tw0=dw, th0=dh;
          var txt=p.city+p.star;
          var fsp=Math.round(th0*0.53);
          ctx.font='bold '+fsp+'px "Microsoft YaHei"';
          while(ctx.measureText(txt).width>tw0*0.9&&fsp>10){fsp-=2;ctx.font='bold '+fsp+'px "Microsoft YaHei"';}
          st(ctx,txt,0,0,ctx.font,'#fff','rgba(0,0,0,0.35)',Math.max(2,Math.round(fsp*0.06)));
          ctx.restore();
        });
        window.__done(c.toDataURL(p.png?'image/png':'image/jpeg',p.png?undefined:0.97));
      });
      return;
    }
    // 2. 紫色块「城市+明星」：rel 模式=中心点+宽高+旋转角（斜切飘带，徐良原图实测）；旧绝对坐标兼容不旋转
    (p.blocks||[]).forEach(function(b){
      if(b.rel){
        var cx0=b.cx*W, cy0=b.cy*H, bw0=b.w*W, bh0=b.h*H, r0=b.r*W;
        ctx.save();
        ctx.translate(cx0,cy0); ctx.rotate((b.rot||0)*Math.PI/180);
        ctx.shadowColor='rgba(0,0,0,0.45)'; ctx.shadowBlur=Math.round(bh0*0.18); ctx.shadowOffsetY=Math.round(bh0*0.06);
        ctx.beginPath(); rr(ctx,-bw0/2,-bh0/2,bw0,bh0,r0);
        ctx.fillStyle=b.color||'#C828F0';ctx.fill();
        ctx.shadowColor='transparent';
        var fs0=Math.round(bh0*0.52);
        st(ctx,p.city+p.star,0,0,'bold '+fs0+'px "Microsoft YaHei"','#fff','rgba(0,0,0,0.35)',Math.max(2,Math.round(fs0*0.06)));
        ctx.restore();
        return;
      }
      var pad=6;
      ctx.save();
      ctx.shadowColor='rgba(0,0,0,0.45)'; ctx.shadowBlur=Math.round(b.h*0.18); ctx.shadowOffsetY=Math.round(b.h*0.06);
      ctx.beginPath();
      rr(ctx,b.x-pad,b.y-pad,b.w+pad*2,b.h+pad*2,b.r||20);
      ctx.fillStyle=b.color||'#C828F0';ctx.fill();
      ctx.restore();
      var fs=Math.round(b.h*0.52);
      st(ctx,p.city+p.star,b.x+b.w/2,b.y+b.h/2,'bold '+fs+'px SimHei','#fff',null,0);
    });
    // 3. 黄色横幅：rel 模式=中心+宽高+旋转（斜切飘带）；图标3/红中都在旋转坐标系内画
    (p.tags||[]).forEach(function(t,idx){
      var isRel=!!t.rel;
      var label=isRel?(t.label||''):((idx===2)?(p.city+p.star):(t.label||''));
      if(isRel){
        var cx1=t.cx*W, cy1=t.cy*H, tw1=t.w*W, th1=t.h*H, tr1=t.r*W;
        ctx.save();
        ctx.translate(cx1,cy1); ctx.rotate((t.rot||0)*Math.PI/180);
        ctx.shadowColor='rgba(0,0,0,0.35)'; ctx.shadowBlur=Math.round(th1*0.15); ctx.shadowOffsetY=Math.round(th1*0.05);
        ctx.beginPath(); rr(ctx,-tw1/2,-th1/2,tw1,th1,tr1);
        ctx.fillStyle=t.color||'#ffdd11';ctx.fill();
        ctx.shadowColor='transparent';
        var fs1=Math.round(th1*(t.fontRatio||0.42));
        var textL=-tw1/2, textR=tw1/2;
        // 左侧蓝色数字3图标（3千+好评块用）
        if(t.icon3){
          var i31=Math.round(th1*0.62), i3x1=-tw1/2+th1*0.12;
          ctx.beginPath();rr(ctx,i3x1,-i31/2,i31,i31,Math.round(i31*0.2));ctx.fillStyle='#6688aa';ctx.fill();
          st(ctx,'3',i3x1+i31/2,0,'bold '+Math.round(i31*0.52)+'px "Microsoft YaHei"','#fff',null,0);
          textL=i3x1+i31+th1*0.15;
        }
        // 右端红中：米白底方块 + 红「中」
        if(t.zhong){
          var zs1=Math.round(th1*0.72), zx1=tw1/2-zs1-th1*0.15;
          ctx.beginPath();rr(ctx,zx1,-zs1/2,zs1,zs1,Math.round(zs1*0.18));ctx.fillStyle='#FBF6EC';ctx.fill();
          st(ctx,'中',zx1+zs1/2,0,'bold '+Math.round(zs1*0.72)+'px "Microsoft YaHei"','#D0342C',null,0);
          textR=zx1-th1*0.15;
        }
        st(ctx,label,(textL+textR)/2,0,'bold '+fs1+'px "Microsoft YaHei"',t.textColor||'#1a1a1a',null,0);
        ctx.restore();
        return;
      }
      var pad=3;
      var tx=t.x, ty=t.y, tw=t.w, th=t.h;
      ctx.save();
      ctx.shadowColor='rgba(0,0,0,0.35)'; ctx.shadowBlur=Math.round(th*0.15); ctx.shadowOffsetY=Math.round(th*0.05);
      ctx.beginPath();
      rr(ctx,tx-pad,ty-pad,tw+pad*2,th+pad*2,t.r||12);
      ctx.fillStyle='#F0F028';ctx.fill();
      ctx.restore();
      var fs2=Math.round(th*0.42);
      st(ctx,label,tx+tw/2,ty+th/2,'bold '+fs2+'px "Microsoft YaHei"','#333',null,0);
    });
    window.__done(c.toDataURL(p.png?'image/png':'image/jpeg',p.png?undefined:0.97));
  };
  img.src=p.template;
};
</script></body></html>`;

// 下载图片转 base64
async function downloadImageB64(url) {
  const resp = await fetch(url, { redirect: 'follow', headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36' } });
  if (!resp.ok) throw new Error('HTTP ' + resp.status);
  const buf = Buffer.from(await resp.arrayBuffer());
  return buf.toString('base64');
}

// 必应图片搜索演唱会海报（官方画像打分：站点白名单+关键词加分/排除+竖版高清；strict=只留官方信号）
async function searchPosterBing(star, city, customQuery, strict) {
  const browser = await getPosterBrowser();
  const page = await browser.newPage();
  try {
    const q = encodeURIComponent(customQuery || (star + ' ' + city + ' 演唱会 海报'));
    await page.goto('https://cn.bing.com/images/search?q=' + q, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(2500);
    const items = await page.evaluate(function(a) {
      var starName = a.star, cityName = a.city, strictMode = a.strict;
      var POS = ['演唱会','巡回','巡演','官方','主办','承办','售票','开票','发布会','世界巡','演唱会海报','poster','concert','promo','tour','live','官宣','宣传','场次','门票'];
      // 现场演出图/无关垃圾/农业大麦 一律重罚，只留真正海报
      var NEG = ['应援','饭拍','壁纸','写真','头像','粉丝','唯美','高清图','cosplay','手绘','插画','饭绘','自制','桌布','表情包','表情','素材','灯牌','接机','路透','同款','周边',
                 '现场','实拍','演出','舞台','台下','观众','人海','灯海','荧光','彩排','谢幕','返场','歌迷','现场图','图集','组图','演唱会现场','狂欢','荧光棒','狂欢夜','唱响',
                 '简笔画','书法','字帖','起源','来历','历史','六官','尚书','意思','解释','阅读','练习题','答案','教程','模板','高清下载','含义','源头','农家','粮食','麦穗','谷物','农田','植物','农作物','小麦','种植',
                 '攻略','代拍','代抢','盘点','还将在','哪些城市','举办','活动公告','邀请函','虚假信息','声明','辟谣','称其'];
      var OST_DOM = ['maoyan.com','damai.cn','piao.com','showstart.com','gewara.com','weibo.com','weibo.cn','sinaimg.cn','qq.com','163.com','sohu.com','ifeng.com','people.com.cn','cctv.com','jvrmusic.com','warner','sonymusic','umg','oneday','bilibili','music'];
      function hostOf(u) { try { return new URL(u).hostname; } catch(e) { return ''; } }
      // 大麦官方图托管在阿里云 OSS（damai-mx-partner-admin.oss-cn-beijing.aliyuncs.com）及 damai.cn，高清竖版干净演出图，适合当出图底图
      function isDamai(host) { return host.indexOf('damai') >= 0; }
      function score(it) {
        var s = 0, t = (it.t || '').toLowerCase(), host = hostOf(it.murl);
        for (var i = 0; i < POS.length; i++) if (t.indexOf(POS[i]) >= 0) s += 8;
        if (t.indexOf(String(starName).toLowerCase()) >= 0) s += 6;
        else if (strictMode) s -= 40; // 严格模式：标题无明星名 → 疑似别家/无关海报，重罚（配合鉴真退 aigen）
        else s -= 24; // 非严格：标题无明星全名 → 多为「周」字错配垃圾(周深/周姓/周朝/周楷书)或无关，重罚
        if (cityName && t.indexOf(String(cityName).toLowerCase()) >= 0) s += 12; // 标题含目标城市 → 强加权，让目标城市海报压过南宁/上海/厦门等别站图
        for (var j = 0; j < NEG.length; j++) if (t.indexOf(NEG[j]) >= 0) s -= 12;
        if (it.h > it.w) s += 5; else if (it.w > it.h) s -= 2;
        for (var k = 0; k < OST_DOM.length; k++) if (host.indexOf(OST_DOM[k]) >= 0) s += 3;
        if (isDamai(host)) s += 8;
        if (strictMode) { if (host === 'maoyan.com' || host.indexOf('maoyan') >= 0) s += 6; }
        if (it.w >= 800 && it.h >= 800) s += 4; else if (it.w >= 400) s += 2;
        return s;
      }
      var r = [];
      document.querySelectorAll('.iusc').forEach(function(el) {
        try {
          var m = JSON.parse(el.getAttribute('m') || '{}');
          var imgEl = el.querySelector('img.mimg');
          var w = imgEl ? parseInt(imgEl.getAttribute('width') || '0') : 0;
          var h = imgEl ? parseInt(imgEl.getAttribute('height') || '0') : 0;
          if (m.murl && m.t) r.push({ url: m.murl, w: w, h: h, t: (m.t || '').substring(0, 80) });
        } catch(e) {}
      });
      var scored = r.map(function(it) { return { s: score(it), it: it }; });
      scored.sort(function(a, b) { if (b.s !== a.s) return b.s - a.s; return (b.it.w * b.it.h) - (a.it.w * a.it.h); });
      if (strictMode) {
        var good = scored.filter(function(x) { return x.s >= 6; });
        return (good.length ? good : scored).slice(0, 8).map(function(x) { return { url: x.it.url, w: x.it.w, h: x.it.h, t: x.it.t, s: x.s }; });
      }
      return scored.slice(0, 8).map(function(x) { return { url: x.it.url, w: x.it.w, h: x.it.h, t: x.it.t, s: x.s }; });
    }, { star: star, city: city, strict: !!strict });
    return items;
  } finally {
    try { await page.close(); } catch(e) {}
  }
}

// ===== 版式模板库（图生图垫图 + 固定 prompt，发布台可自助新增）=====
const POSTER_TPL_DIR = path.join(__dirname, 'assets', 'templates');
const POSTER_TPL_CONFIG = path.join(__dirname, 'assets', 'poster-templates.json');
function loadPosterTemplates() {
  try { var l = JSON.parse(fs.readFileSync(POSTER_TPL_CONFIG, 'utf8')); return Array.isArray(l) ? l : []; }
  catch(e) { return []; }
}
function findPosterTemplate(id) {
  var l = loadPosterTemplates();
  for (var i = 0; i < l.length; i++) if (l[i].id === id) return l[i];
  return l.length > 0 ? l[0] : null; // 不传/传错 → 默认第一个
}

// 版式贴纸 v2（2026-08-19 换新模板）：底图/贴纸从佛山徐良首开.jpg 重新提取，边缘内收 3px，
// 与验收版终图逐像素一致（黄块 0.0000% 差异）；紫字改雅黑 Bold、字宽上限 0.85、倾角 5.2°（文字回归实测）
const CUTOUT_DIR = path.join(__dirname, 'assets', 'templates', 'cutouts');
function loadCutouts() {
  var read = function(f) { try { return fs.readFileSync(path.join(CUTOUT_DIR, f)).toString('base64'); } catch(e) { return ''; } };
  return [
    // 黄块：文案固定（7级店铺/3千+好评/命中率百分百中），原样贴，字=模板原字，字体/位置/颜色/阴影 100% 一致
    { src: read('tag1.png'),   x: 245, y: 145, w: 546, h: 215 },
    { src: read('tag2.png'),   x: 105, y: 332, w: 829, h: 288 },
    { src: read('tag3.png'),   x: 10,  y: 862, w: 995, h: 201 },
    // 紫块：文案要变（{城市}{明星}），重铺纯紫 + 代码写字
    { src: read('purple.png'), x: 235, y: 590, w: 545, h: 225, purple: true, rot: 5.2, color: [216, 26, 248], tx: -1.5, ty: 0.5 }
  ].filter(function(c) { return c.src; });
}

app.get('/api/poster/templates', auth, function(req, res) {
  res.json({ ok: true, items: loadPosterTemplates().map(function(t) { return { id: t.id, name: t.name, layers: t.layers || [], stickers: t.stickers || [] }; }) });
});

// 中台版式模板 / 贴图素材 代理（读 manager.museav.top，本租户资产，供发布台图片工坊从中台取）
app.get('/api/poster/central-templates', auth, async function(req, res) {
  try { res.json({ ok: true, items: (await hymPosterTemplates()).map(function(t) { return { id: t.id, name: t.name, prompt: t.prompt, url: t.url }; }) }); }
  catch (e) { res.json({ ok: false, error: e.message }); }
});
app.get('/api/poster/stickers', auth, async function(req, res) {
  try { res.json({ ok: true, items: (await hymStickers()).map(function(s) { return { id: s.id, name: s.name, url: s.url }; }) }); }
  catch (e) { res.json({ ok: false, error: e.message }); }
});
// 自建横幅贴纸（四横幅紫块，透明 PNG），供贴图版式加载
app.get('/api/poster/banner-sticker', auth, function(req, res) {
  var f = path.join(__dirname, 'assets', 'banner_stickers', 'hb_banner.png');
  if (!fs.existsSync(f)) return res.status(404).json({ ok: false, error: 'banner sticker not found' });
  res.set('Content-Type', 'image/png').send(fs.readFileSync(f));
});

app.get('/api/poster/badge-7', auth, function(req, res) {
  var f = path.join(__dirname, 'assets', 'badge7.png');
  if (!fs.existsSync(f)) return res.status(404).json({ ok: false, error: 'badge7 not found' });
  res.set('Content-Type', 'image/png').send(fs.readFileSync(f));
});

// 【2026-10-07 加】好易美票务Hope 的自建贴纸（老板给的白底样板逆向出来的透明 PNG）
//   hope-burst = 红色爆炸贴   hope-swash = 黄色笔刷条
// 走这两个路由的贴纸会被 _bakeStickers() 在**服务端**叠到官方底图上，
// 这样不管哪个客户端出图都能看到（和 banner-sticker 同一套机制）。
app.get('/api/poster/hope-burst', auth, function(req, res) {
  var f = path.join(__dirname, 'assets', 'burst_stickers', 'hope_burst.png');
  if (!fs.existsSync(f)) return res.status(404).json({ ok: false, error: 'hope_burst not found' });
  res.set('Content-Type', 'image/png').send(fs.readFileSync(f));
});
app.get('/api/poster/hope-swash', auth, function(req, res) {
  var f = path.join(__dirname, 'assets', 'burst_stickers', 'hope_swash.png');
  if (!fs.existsSync(f)) return res.status(404).json({ ok: false, error: 'hope_swash not found' });
  res.set('Content-Type', 'image/png').send(fs.readFileSync(f));
});

app.post('/api/poster/templates', auth, function(req, res) {
  try {
    var name = (req.body.name || '').trim();
    var promptText = (req.body.prompt || '').trim();
    var b64 = (req.body.imageB64 || '').replace(/^data:image\/[^;]+;base64,/, '');
    if (!name || !promptText || !b64) return res.json({ ok: false, error: '缺少名称/版式描述/底图' });
    if (promptText.indexOf('{城市}') < 0 && promptText.indexOf('{明星}') < 0) {
      return res.json({ ok: false, error: '版式描述里要包含 {城市} 或 {明星} 占位符，否则无法替换' });
    }
    var id = 'tpl_' + Date.now().toString(36);
    fs.mkdirSync(POSTER_TPL_DIR, { recursive: true });
    fs.writeFileSync(path.join(POSTER_TPL_DIR, id + '.jpg'), Buffer.from(b64, 'base64'));
    var list = loadPosterTemplates();
    var tplEntry = { id: id, name: name, file: id + '.jpg', prompt: promptText };
    if (Array.isArray(req.body.layers) && req.body.layers.length) tplEntry.layers = req.body.layers;
    if (Array.isArray(req.body.stickers) && req.body.stickers.length) tplEntry.stickers = req.body.stickers;
    list.push(tplEntry);
    fs.writeFileSync(POSTER_TPL_CONFIG, JSON.stringify(list, null, 2));
    res.json({ ok: true, id: id });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// 共享版式到好易美后台中台版式库：museav poster-templates add
// 入参二选一：{ id }（已存本地版式，自动取底图+描述）或 { name, prompt, imageB64 }（当前底图直接推）
app.post('/api/poster/share-to-hym', auth, async function(req, res) {
  try {
    var name = (req.body.name || '').trim();
    var promptText = (req.body.prompt || '').trim();
    var b64 = (req.body.imageB64 || '').replace(/^data:image\/[^;]+;base64,/, '');
    var filePath = null;

    if (req.body.id) {
      var tpl = loadPosterTemplates().find(function(t) { return t.id === req.body.id; });
      if (!tpl) return res.json({ ok: false, error: '找不到本地版式: ' + req.body.id });
      filePath = path.join(POSTER_TPL_DIR, tpl.file || (tpl.id + '.jpg'));
      if (!fs.existsSync(filePath)) return res.json({ ok: false, error: '版式底图不存在: ' + filePath });
      if (!name) name = tpl.name || tpl.id;
      if (!promptText) promptText = tpl.prompt || '';
      if (!promptText) return res.json({ ok: false, error: '该版式没有描述，请补充含 {城市} {明星} 的占位描述' });
    } else {
      if (!name || !promptText || !b64) return res.json({ ok: false, error: '缺少名称/描述/底图' });
      if (promptText.indexOf('{城市}') < 0 && promptText.indexOf('{明星}') < 0) {
        return res.json({ ok: false, error: '描述里要包含 {城市} 或 {明星} 占位符' });
      }
      filePath = path.join(__dirname, '_hym_tpl_share_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8) + '.jpg');
      fs.writeFileSync(filePath, Buffer.from(b64, 'base64'));
    }

    // ⚠️ 重复检测：入库前先查中台版式库同名版式；未显式 force 时命中则拒绝硬推
    if (!req.body.force) {
      try {
        var existing = (await hymPosterTemplates()).filter(function(t) { return String(t.name || '').trim() === String(name).trim(); });
        if (existing && existing.length > 0) {
          return res.json({ ok: false, duplicate: true, existing: existing.map(function(t) { return { id: t.id, name: t.name }; }), error: '中台已存在同名版式「' + name + '」（id=' + existing[0].id + '）。如需覆盖请确认后再共享（会生成重复项）' });
        }
      } catch(e) { /* 中台查询失败则继续原流程，避免因检测失败阻塞共享 */ }
    }

    // cmd.exe 双引号内：中文/{} 正常，仅需把 " 转成 ""
    var safeName = name.replace(/"/g, '""');
    var safePrompt = promptText.replace(/"/g, '""');
    var cmd = 'museav poster-templates add "' + filePath + '" --name "' + safeName + '" --prompt "' + safePrompt + '"';
    var out = await execAsync(cmd, { timeout: 90000, maxBuffer: 1024 * 1024 });
    var txt = ((out.stdout || '') + '\n' + (out.stderr || '')).trim();
    var idMatch = txt.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
    res.json({ ok: true, id: idMatch ? idMatch[0] : '', name: name, message: txt });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// ===== 版式四块（rel 默认值）=====
// 中心点/宽高按徐良原图贴纸包围盒实测(1020x1360)，颜色按原图像素采样；
// 供 /api/poster/make（贴纸缺失兜底绘制）与 /api/poster/block-layout（版式块编辑器默认值）共用。
var OVERLAY_BLOCK = { rel: true, cx: 0.4975, cy: 0.5158, w: 0.66, h: 0.18, r: 0.02, rot: 5.9, color: '#dd11ff' };
var OVERLAY_TAGS = [
  { rel: true, cx: 0.5108, cy: 0.1893, w: 0.6039, h: 0.1581, r: 0.02, label: '7级店铺', rot: -14.2, fontRatio: 0.45 },
  { rel: true, cx: 0.5387, cy: 0.3342, w: 0.9108, h: 0.1772, r: 0.02, label: '3千+好评', icon3: true, rot: 19.7, fontRatio: 0.42 },
  { rel: true, cx: 0.4966, cy: 0.7077, w: 0.9775, h: 0.1537, r: 0.02, label: '命中率百分百', zhong: true, rot: 0.2, fontRatio: 0.5 }
];

// 返回某版式的可编辑块列表（编辑器默认值）。按 templateId：
//  - customTpl（首开/一开，带 blocks）→ 用它自己的 blocks/tags
//  - xuliang-v1（传统贴纸版式）→ 把贴纸转换成 rel blocks/tags 默认值（贴近原版）
//  - 其它/未知 → 统一四块默认
app.post('/api/poster/block-layout', auth, function(req, res) {
  try {
    var tid = (req.body.templateId || '').trim();
    var tpl = null;
    var items = loadPosterTemplates();
    for (var i = 0; i < items.length; i++) if (items[i].id === tid) { tpl = items[i]; break; }
    var blocks, tags, name = tid || '版式';
    if (tpl && Array.isArray(tpl.blocks) && tpl.blocks.length) {
      blocks = JSON.parse(JSON.stringify(tpl.blocks));
      tags = JSON.parse(JSON.stringify(Array.isArray(tpl.tags) ? tpl.tags : []));
      name = tpl.name;
    } else if (tid === 'xuliang-v1') {
      blocks = JSON.parse(JSON.stringify([OVERLAY_BLOCK]));
      tags = JSON.parse(JSON.stringify(OVERLAY_TAGS));
      name = tpl ? tpl.name : '徐良版式';
    } else {
      blocks = JSON.parse(JSON.stringify([OVERLAY_BLOCK]));
      tags = JSON.parse(JSON.stringify(OVERLAY_TAGS));
      if (tpl) name = tpl.name;
    }
    res.json({ ok: true, templateId: tid, name: name, blocks: blocks, tags: tags });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// AI出图主力：图生图垫版式模板图，AI 照排版画新城市明星；prompt 里 {城市}{明星} 自动替换
const SUPPORT_TEMPLATE_ID = '0694b7d1-24fa-41af-9e08-9d079271cd0a';
const LAYOUT_REF_FILE = path.join(__dirname, 'assets', 'templates', 'xuliang-v1.jpg');

// 垫图语义：--ref 会保持垫图人物形象。所以垫图必须用目标明星自己的海报（保人物正确），
// 版式由模板 prompt 文字固定描述；不再垫徐良图（会把人画成徐良）。
const STAR_REF_TMP = path.join(__dirname, '_star_ref_tmp.jpg');

async function searchStarPosterFile(star, city) {
  try {
    var items = await searchPosterBing(star, city, '猫眼 ' + star + ' ' + city + ' 演唱会 官方海报');
    if (!items || items.length === 0) items = await searchPosterBing(star, city, star + ' ' + city + ' 演唱会 官方海报 微博');
    if (!items || items.length === 0) return null;
    for (var i = 0; i < Math.min(items.length, 3); i++) {
      try {
        var b64 = await downloadImageB64(items[i].url);
        fs.writeFileSync(STAR_REF_TMP, Buffer.from(b64, 'base64'));
        return STAR_REF_TMP;
      } catch(e) {}
    }
  } catch(e) {}
  return null;
}

function buildPosterPrompt(star, city) {
  return '竖版' + city + star + '演唱会代拍票务宣传海报，背景为' + star + city + '演唱会官方海报，保持垫图人物形象与构图不变；' +
    '前景严格叠加版式元素：顶部黄色圆角块黑字写7级店铺、中部黄色块黑字写3千+好评、中央紫色圆角块白字写' + city + star +
    '、下方通宽黄色横幅黑字写命中率百分百右端放一枚红中麻将、底部印时间地点票价、边缘装饰大字。' +
    '现代电商营销海报风格，3:4竖版，高清平面海报质感';
}

async function genPosterAI(star, city, refFile, tplPrompt) {
  var promptText = tplPrompt ? String(tplPrompt).replace(/\{城市\}/g, city).replace(/\{明星\}/g, star) : buildPosterPrompt(star, city);
  var cmd = 'museav gen';
  if (refFile && fs.existsSync(refFile)) cmd += ' --ref "' + refFile + '"';
  cmd += ' --prompt "' + promptText.replace(/"/g, '""') + '" --ratio 3:4';
  var { stdout, stderr } = await execAsync(cmd, { timeout: 300000, maxBuffer: 1024 * 1024 });
  var url = ((stdout || '') + '\n' + (stderr || '')).trim().split('\n').filter(function(l) { return l.indexOf('http') === 0; }).pop();
  if (!url) throw new Error('AI出图未返回有效URL');
  return url.trim();
}

// 好易美后台 token4ai 出图：登 manager.hympro.cn 拿 JWT → /api/generate 提交 → 轮询 Supabase generation_records 拿 cdn_url。
// 绕开 museav 账户 credits=0 的限制，用好易美后台额度。
let _hymJwt = null, _hymJwtAt = 0;
const HYM_AUTH = { username: cfgVal('hymUser'), password: cfgVal('hymPass') };
const HYM_SUPA_URL = cfgVal('supaUrl') || 'https://tcxknssrqyfqwtnhoplx.supabase.co';
// ⛔ 这里原来是明文 service_role key（等于整库读写）。已进过 git 历史，必须去 Supabase 后台轮换。
const HYM_SUPA_KEY = cfgVal('supaKey');
async function hymToken() {
  if (!HYM_AUTH.username || !HYM_AUTH.password) {
    throw new Error('好易美后台账号未配置：请在 ' + CFG_FILE + ' 里填 hymUser / hymPass');
  }
  if (_hymJwt && Date.now() - _hymJwtAt < 7 * 24 * 3600 * 1000) return _hymJwt;
  const r = await fetch('https://manager.hympro.cn/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(HYM_AUTH) });
  const j = await r.json();
  if (!j.ok || !j.token) throw new Error('好易美后台登录失败: ' + (j.error || ''));
  _hymJwt = j.token; _hymJwtAt = Date.now();
  return _hymJwt;
}
async function hymGenerate(prompt, ratio) {
  var tok = await hymToken();
  var r = await fetch('https://manager.hympro.cn/api/generate', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + tok }, body: JSON.stringify({ prompt: prompt, ratio: ratio }) });
  var j = await r.json();
  if (j.error) throw new Error('好易美出图失败: ' + j.error);
  if (!j.id) throw new Error('好易美未返回任务id');
  var id = j.id;
  for (var i = 0; i < 40; i++) {
    var qr = await fetch(HYM_SUPA_URL + '/rest/v1/generation_records?id=eq.' + id + '&select=status,cdn_url,error_msg', { headers: { 'apikey': HYM_SUPA_KEY, 'Authorization': 'Bearer ' + HYM_SUPA_KEY } });
    var list = await qr.json();
    var rec = Array.isArray(list) ? list[0] : list;
    if (rec && rec.status === 'success' && rec.cdn_url) return rec.cdn_url;
    if (rec && rec.status === 'failed') throw new Error('好易美出图失败: ' + (rec.error_msg || ''));
    await new Promise(function(rs) { setTimeout(rs, 5000); });
  }
  throw new Error('好易美出图超时');
}
// AI出图底图：好易美后台 token4ai 出无字演唱会舞台底图（绕开 museav credits=0）
const HYM_BASE = 'https://manager.museav.top';
// ⛔ 这里原来是明文 tenant key。已进过 git 历史，必须去中台轮换。
const HYM_KEY = cfgVal('hymKey');
// 中台 API 直连出图（X-API-Key 认证）：POST /api/generate → jobId → 轮询 /api/jobs?id= → cdn_url
async function hymGenDirect(prompt, ratio) {
  var r = await fetch(HYM_BASE + '/api/generate', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-API-Key': HYM_KEY }, body: JSON.stringify({ prompt: prompt, ratio: ratio }) });
  var j = await r.json();
  if (j.error) throw new Error('中台出图失败: ' + j.error);
  var jobId = j.jobId; if (!jobId) throw new Error('中台未返回 jobId');
  for (var i = 0; i < 100; i++) {
    await new Promise(function(rs) { setTimeout(rs, 3000); });
    var jr = await fetch(HYM_BASE + '/api/jobs?id=' + encodeURIComponent(jobId), { headers: { 'X-API-Key': HYM_KEY } });
    var job = await jr.json();
    if (job.status === 'done' && job.cdn_url) return job.cdn_url;
    if (job.status === 'failed') throw new Error('出图失败: ' + (job.error || ''));
  }
  throw new Error('出图超时');
}
// 中台 API 直连逆向：POST /api/reverse {image_url}
async function hymRevDirect(imageUrl) {
  var r = await fetch(HYM_BASE + '/api/reverse', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-API-Key': HYM_KEY }, body: JSON.stringify({ image_url: imageUrl }) });
  var j = await r.json();
  if (j.error) throw new Error('中台逆向失败: ' + j.error);
  return j;
}
// 中台 API 直连图生模板：POST /api/image-to-template（同步返回结果本体，含文字层 text_layers / 字段 fields）
async function hymImgToTpl(imageUrl) {
  var r = await fetch(HYM_BASE + '/api/image-to-template', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-API-Key': HYM_KEY }, body: JSON.stringify({ image_url: imageUrl }) });
  var j = await r.json();
  if (j.error) throw new Error('图生模板失败: ' + j.error);
  return j;
}
// 中台 API 直连：贴图素材 / 版式模板列表（租户级资产，X-API-Key 认证，无分页）
async function hymStickers() {
  var r = await fetch(HYM_BASE + '/api/stickers', { headers: { 'X-API-Key': HYM_KEY, 'X-Museav-Client': 'museav-cli/2.8.0', 'X-Studio-Client': 'museav-cli/2.8.0' } });
  if (!r.ok) throw new Error('中台 /api/stickers ' + r.status);
  var j = await r.json(); return Array.isArray(j) ? j : (j.items || []);
}
async function hymPosterTemplates() {
  var r = await fetch(HYM_BASE + '/api/poster-templates', { headers: { 'X-API-Key': HYM_KEY, 'X-Museav-Client': 'museav-cli/2.8.0', 'X-Studio-Client': 'museav-cli/2.8.0' } });
  if (!r.ok) throw new Error('中台 /api/poster-templates ' + r.status);
  var j = await r.json(); return Array.isArray(j) ? j : (j.items || []);
}
// 图生模板端点：上传图 → 提取文字层（可换字模板）
app.post('/api/agent/image-to-template', auth, async (req, res) => {
  try {
    var b64 = String(req.body.imageB64 || '').replace(/^data:image\/[^;]+;base64,/, '');
    var url = (req.body.imageUrl || '').trim();
    if (!url && b64) url = await museavUpload(b64);
    if (!url) return res.json({ ok: false, error: '缺少图片（imageB64 或 imageUrl）' });
    var j = await hymImgToTpl(url);
    res.json({ ok: true, text_layers: j.text_layers || [], fields: j.fields || [], prompt_cn: j.prompt_cn, description: j.description, style_tags: j.style_tags, sculpt: j.sculpt });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});
async function genAIBase(star, city) {
  var promptText = 'Vertical 3:4 concert poster background, the idol ' + star + ' performing on a concert stage at ' + city + ' show, dramatic spotlights, concert atmosphere, crowd/audience lights, cinematic realistic photography, high detail, no text no watermark no logo';
  var url = await hymGenDirect(promptText, '3:4');
  return url.trim();
}

// 图片逆向：base64 图 → museav upload 转公网 url → 好易美后台 /api/reverse-prompt 返 prompt/美学拆解
async function museavUpload(b64) {
  var tmp = path.join(__dirname, '_hym_up_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8) + '.png');
  fs.writeFileSync(tmp, Buffer.from(b64, 'base64'));
  try {
    var u = await execAsync('museav upload "' + tmp + '"', { timeout: 60000, maxBuffer: 1024 * 1024 });
    var txt = (u.stdout || '') + '\n' + (u.stderr || '');
    var url = txt.trim().split('\n').filter(function(l) { return l.indexOf('http') === 0; }).pop();
    if (!url) throw new Error('museav upload 未返回 url: ' + txt.slice(-120));
    return url.trim();
  } finally { try { fs.unlinkSync(tmp); } catch(e) {} }
}
function parseReversePrompt(txt) {
  var en = '', cn = '';
  var enM = txt.match(/英文\s*prompt:\s*([^\r\n]+)/); if (enM) en = enM[1].trim();
  var cnM = txt.match(/中文\s*prompt:\s*([^\r\n]+)/); if (cnM) cn = cnM[1].trim();
  if (!en && !cn) {
    var lines = txt.split('\n').filter(function(l) { return l.trim(); });
    en = lines.length ? lines[lines.length - 1].trim() : '';
    cn = en;
  }
  return { prompt: en, prompt_cn: cn };
}
// 图片逆向（museav 识图，用好易美中台 apiKey；识图不占出图限流）
async function museavReverse(pathOrUrl) {
  var u = await execAsync('museav reverse "' + pathOrUrl + '"', { timeout: 120000, maxBuffer: 1024 * 1024 });
  var txt = (u.stdout || '') + '\n' + (u.stderr || '');
  var p = parseReversePrompt(txt);
  if (!p.prompt && !p.prompt_cn) throw new Error('逆向未返回 prompt');
  return p;
}
// 图片逆向端点：上传图(或给 imageUrl) → museav upload 转公网 url → 中台 /api/reverse 返 prompt
app.post('/api/agent/reverse-prompt', auth, async (req, res) => {
  try {
    var b64 = String(req.body.imageB64 || '').replace(/^data:image\/[^;]+;base64,/, '');
    var url = (req.body.imageUrl || '').trim();
    if (!url && b64) url = await museavUpload(b64);
    if (!url) return res.json({ ok: false, error: '缺少图片（imageB64 或 imageUrl）' });
    var rev = await hymRevDirect(url);
    res.json({ ok: true, prompt: rev.prompt, prompt_cn: rev.prompt_cn });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// ===== 出图模板（museav 36 模板）=====
let templatesCache = null;
let templatesCacheTime = 0;

function parseTemplatesList(stdout) {
  var out = [];
  String(stdout || '').split('\n').forEach(function(l) {
    var m = l.match(/^\s*([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\s+(.+?)\s+(\S+)\s+(\d+:\d+|article)\s+\[(\S+)\]/);
    if (m) out.push({ id: m[1], name: m[2], category: m[3], ratio: m[4], type: m[5] === '图片' ? 'image' : 'article' });
  });
  return out;
}

app.get('/api/studio/templates', auth, async (req, res) => {
  try {
    if (!templatesCache || Date.now() - templatesCacheTime > 10 * 60 * 1000) {
      var { stdout, stderr } = await execAsync('museav templates --type image', { timeout: 60000, maxBuffer: 1024 * 1024 });
      // 表格输出在 stderr，stdout 只有 UUID 列表，两者合并解析
      templatesCache = parseTemplatesList((stdout || '') + '\n' + (stderr || ''));
      templatesCacheTime = Date.now();
    }
    res.json({ ok: true, items: templatesCache || [] });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

app.post('/api/studio/gen-template', auth, async (req, res) => {
  try {
    var tid = (req.body.templateId || '').trim();
    if (!tid) return res.json({ ok: false, error: '缺少模板ID' });
    var fields = req.body.fields || {};
    var cmd = 'museav gen --template ' + tid;
    if (fields && typeof fields === 'object' && Object.keys(fields).length > 0) {
      // cmd.exe 下双引号内转义：" → ""
      cmd += ' --fields "' + JSON.stringify(fields).replace(/"/g, '""') + '"';
    }
    var { stdout, stderr } = await execAsync(cmd, { timeout: 240000, maxBuffer: 1024 * 1024 });
    var url = ((stdout || '') + '\n' + (stderr || '')).trim().split('\n').filter(function(l) { return l.indexOf('http') === 0; }).pop();
    if (!url) return res.json({ ok: false, error: '未返回图片URL' });
    res.json({ ok: true, url: url.trim() });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// ===== 出图工坊直连端点（museav 个人登录，无需租户 apiKey）=====

// AI出图：prompt → 图片URL
app.post('/api/agent/studio-gen', auth, async (req, res) => {
  try {
    var prompt = (req.body.prompt || '').trim();
    if (!prompt) return res.json({ ok: false, error: '缺少 prompt' });
    var ratio = (req.body.ratio || '3:4').trim();
    // cmd.exe 下双引号内转义：" → ""
    var safePrompt = prompt.replace(/"/g, '""');
    var cmd = 'museav gen --prompt "' + safePrompt + '" --ratio ' + ratio;
    var { stdout, stderr } = await execAsync(cmd, { timeout: 600000, maxBuffer: 1024 * 1024 });
    var url = ((stdout || '') + '\n' + (stderr || '')).trim().split('\n').filter(function(l) { return l.indexOf('http') === 0; }).pop();
    if (!url) return res.json({ ok: false, error: '未返回图片URL' });
    res.json({ ok: true, url: url.trim() });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 图片逆向：网络图片URL → 英文 prompt（约1分钟）
app.post('/api/agent/studio-reverse', auth, async (req, res) => {
  try {
    var url = (req.body.url || '').trim();
    if (!url) return res.json({ ok: false, error: '缺少 url' });
    if (!/^https?:\/\//i.test(url)) return res.json({ ok: false, error: '只支持网络图片URL（blob本地缓存图无法逆向）' });
    // cmd.exe 下双引号内转义：" → ""，去换行防注入
    var safeUrl = url.replace(/"/g, '""').replace(/[\r\n]/g, '');
    var cmd = 'museav reverse "' + safeUrl + '"';
    var { stdout, stderr } = await execAsync(cmd, { timeout: 300000, maxBuffer: 1024 * 1024 });
    // CLI 约定 stdout 只输出最终 prompt；为空时兜底取 stderr 最后一行
    var prompt = (stdout || '').trim();
    if (!prompt) {
      var lines = (stderr || '').split('\n').filter(function(l) { return l.trim(); });
      prompt = lines.length ? lines[lines.length - 1].trim() : '';
    }
    if (!prompt) return res.json({ ok: false, error: '逆向未返回 prompt' });
    res.json({ ok: true, prompt: prompt });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 余额（个人 credits，来自 whoami）
let creditsCache = null;
let creditsCacheTime = 0;
app.get('/api/agent/studio-balance', auth, async (req, res) => {
  try {
    if (!creditsCache || Date.now() - creditsCacheTime > 5 * 60 * 1000) {
      var { stdout, stderr } = await execAsync('museav whoami', { timeout: 30000, maxBuffer: 1024 * 1024 });
      var jsonLine = ((stdout || '') + '\n' + (stderr || '')).split('\n').filter(function(l) { return l.indexOf('{') === 0; })[0];
      if (!jsonLine) return res.json({ ok: false, error: 'whoami 未返回账户信息（可能未登录，跑 museav login）' });
      var info = JSON.parse(jsonLine);
      creditsCache = { credits: info.creation_credits, nickname: info.nickname, brand: info.brand && info.brand.name };
      creditsCacheTime = Date.now();
    }
    res.json(Object.assign({ ok: true }, creditsCache));
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 近期出图记录
app.post('/api/agent/studio-jobs', auth, async (req, res) => {
  try {
    var { stdout, stderr } = await execAsync('museav jobs', { timeout: 60000, maxBuffer: 1024 * 1024 });
    var text = ((stdout || '') + '\n' + (stderr || '')).trim();
    var arrStart = text.indexOf('[');
    var arrEnd = text.lastIndexOf(']');
    if (arrStart < 0 || arrEnd <= arrStart) return res.json({ ok: true, data: [] });
    var jobs = JSON.parse(text.substring(arrStart, arrEnd + 1));
    res.json({ ok: true, data: Array.isArray(jobs) ? jobs : [] });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 搜索海报（返回候选列表）
app.post('/api/poster/search', auth, async (req, res) => {
  try {
    var star = (req.body.star || '').trim();
    var city = (req.body.city || '').trim();
    if (!star) return res.json({ ok: false, error: '缺少明星名' });
    var items = await searchPosterBing(star, city);
    res.json({ ok: true, items: items });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// 检测模板中的紫色块和黄色标签区域
async function detectTemplateRegions(imagePath) {
  var sh = require(path.join(__dirname, 'node_modules', 'sharp'));
  var { data, info } = await sh(imagePath).raw().toBuffer({ resolveWithObject: true });
  var w = info.width, h = info.height, ch = info.channels;
  // 紫色块
  var pminx = w, pminy = h, pmaxx = 0, pmaxy = 0, pcount = 0;
  for (var y = 0; y < h; y += 2) for (var x = 0; x < w; x += 2) {
    var i = (y * w + x) * ch, R = data[i], G = data[i+1], B = data[i+2];
    if (R > 150 && B > 170 && R > G * 1.4 && B > G * 1.3 && Math.abs(R - B) < 80) {
      if (x < pminx) pminx = x; if (x > pmaxx) pmaxx = x;
      if (y < pminy) pminy = y; if (y > pmaxy) pmaxy = y; pcount++;
    }
  }
  var blocks = [];
  if (pcount > 200) blocks.push({ x: pminx, y: pminy, w: pmaxx - pminx, h: pmaxy - pminy, r: 22, color: '#C828F0' });
  // 黄色标签（按列扫描找分段）
  var yCols = []; for (var x = 0; x < w; x++) yCols[x] = false;
  var ymin = h, ymax = 0;
  for (var y2 = Math.floor(h * 0.5); y2 < Math.floor(h * 0.85); y2 += 2) {
    for (var x2 = 0; x2 < w; x2 += 2) {
      var i2 = (y2 * w + x2) * ch, R2 = data[i2], G2 = data[i2+1], B2 = data[i2+2];
      if (R2 > 210 && G2 > 210 && B2 < 100) { yCols[x2] = true; if (y2 < ymin) ymin = y2; if (y2 > ymax) ymax = y2; }
    }
  }
  var segs = [], segStart = -1;
  for (var x3 = 0; x3 < w; x3++) {
    if (yCols[x3] && segStart < 0) segStart = x3;
    if (!yCols[x3] && segStart >= 0) { if (x3 - segStart > 50) segs.push({ xmin: segStart, xmax: x3 - 1 }); segStart = -1; }
  }
  if (segStart >= 0 && w - segStart > 50) segs.push({ xmin: segStart, xmax: w - 1 });
  var tags = segs.map(function(s) { return { x: s.xmin, y: ymin, w: s.xmax - s.xmin, h: ymax - ymin, r: 12 }; });
  return { blocks: blocks, tags: tags };
}

// 找模板文件（优先留白模板）
function findTemplateFile(star, variant) {
  // 2026-11-12：并排优先 —— 学员安装后可以把模板放在
  //   xianyu-install-xxx\闲鱼演唱会模板\  （和服务、achun 同级）
  // 找不到再回落本机历史位置。原来只认 Desktop，学员机器上等于没有这个能力。
  var dirs = [
    path.join(__dirname, '..', '闲鱼演唱会模板-留白'),
    path.join(__dirname, '..', '闲鱼演唱会模板'),
    path.join(__dirname, '..', 'xianyu-achun', '闲鱼演唱会模板-留白'),
    path.join(__dirname, '..', 'xianyu-achun', '闲鱼演唱会模板'),
    'C:/Users/43462/Desktop/闲鱼演唱会模板-留白',
    'C:/Users/43462/Desktop/闲鱼演唱会模板',
  ];
  for (var d = 0; d < dirs.length; d++) {
    var dir = dirs[d];
    if (!fs.existsSync(dir)) continue;
    var files = fs.readdirSync(dir).filter(function(f) { return /\.(jpg|jpeg|png)$/i.test(f); });
    for (var i = 0; i < files.length; i++) {
      if (files[i].indexOf(star) >= 0 && files[i].indexOf(variant) >= 0) return path.join(dir, files[i]);
    }
    for (var i = 0; i < files.length; i++) {
      if (files[i].indexOf(star) >= 0) return path.join(dir, files[i]);
    }
  }
  return null;
}

// 候选底图：筛选后的真海报列表（缩略图 + 底图 base64），供发布台点选一张再合成
app.post('/api/poster/candidates', auth, async (req, res) => {
  try {
    var city = (req.body.city || '').trim(), star = (req.body.star || '').trim(), source = req.body.source || 'search';
    if (!city || !star) return res.json({ ok: false, error: '城市和明星必填' });
    var items;
    if (source === 'ai') {
      items = await searchPosterBing(star, city, star + ' ' + city + ' 演唱会 官方海报 主办方 巡演', true);
      if (!items || items.length === 0) items = await searchPosterBing(star, city, star + ' ' + city + ' 演唱会 海报 官方', true);
    } else if (source === 'damai') {
      items = await searchPosterBing(star, city, '大麦 ' + star + ' ' + city + ' 演唱会 海报', false);
      if (!items || items.length === 0) items = await searchPosterBing(star, city, '大麦网 ' + star + ' ' + city + ' 演唱会 海报', false);
    } else {
      var seen = {}, cmb = [];
      var qs = ['猫眼 ' + star + ' ' + city + ' 演唱会 官方海报', star + ' ' + city + ' 演唱会 官方海报 微博', '大麦 ' + star + ' ' + city + ' 演唱会 海报'];
      for (var qi = 0; qi < qs.length; qi++) {
        try {
          var one = await searchPosterBing(star, city, qs[qi], false);
          if (one && one.length) for (var oi = 0; oi < one.length; oi++) { var u = one[oi].url; if (!seen[u]) { seen[u] = 1; cmb.push(one[oi]); } }
        } catch(e) {}
      }
      items = cmb;
    }
    if (!items || items.length === 0) return res.json({ ok: true, items: [] });
    var sh = require(path.join(__dirname, 'node_modules', 'sharp'));
    var out = [];
    for (var i = 0; i < items.length && out.length < 12; i++) {
      var it = items[i];
      if ((it.s || 0) < 20) continue; // 只收相关度较高（城市+明星+官方信号加权的分）
      if (city && (it.t || '').indexOf(city) < 0) continue; // 硬过滤：标题不含目标城市 → 非本站海报(南宁/上海等)剔除
      try {
        var b64 = await downloadImageB64(it.url);
        var buf = Buffer.from(b64, 'base64');
        var dim = await sh(buf).metadata();
        if ((dim.width || 0) >= 400 && (dim.height || 0) >= 400) {
          var thumb;
          try { thumb = (await sh(buf).rotate().resize({ width: 150, withoutEnlargement: true }).jpeg({ quality: 70 }).toBuffer()).toString('base64'); }
          catch(e) { thumb = b64; }
          out.push({ url: it.url, b64: b64, w: dim.width, h: dim.height, s: it.s || 0, t: (it.t || '').slice(0, 90), thumb: 'data:image/jpeg;base64,' + thumb });
        }
      } catch(e) {}
    }
    res.json({ ok: true, items: out });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// 大麦官方海报（三级）：1) 目标城市今年官方海报 → 2) 该明星今年其他在架城市官方海报 → 3) empty(大麦无在架站，由调用方兜底 AI 出图)
var _dmCache = {}; // 内存缓存：star|city -> {b64,match,city,at}，避免热门明星重复慢搜
// 大麦项目名经常和用户叫法对不上（GAPDAYS vs gapday / GAG DAYS…），搜不到会静默降级成 AI 出图，
// 界面上看不出来。这里加「别名表 + 拉丁词干模糊」两级兜底，并把命中情况回传，让调用方能提示。
var _DM_ALIAS = {
  'gapdays': 'gapday',   // 2026gapday音乐节·常州站
  'gagdays': 'gapday',
  'gagday': 'gapday',
  'gag days': 'gapday',
  'gap day': 'gapday'
};
function _dmKeywords(star) {
  var out = [star];
  var k = String(star || '').trim().toLowerCase();
  if (_DM_ALIAS[k] && _DM_ALIAS[k] !== k) out.push(_DM_ALIAS[k]);
  if (/\s/.test(k)) out.push(k.replace(/\s+/g, '')); // "GAG DAYS" → "gagdays"
  return out.filter(function (v, i, a) { return v && a.indexOf(v) === i; });
}
function _dmLatinKey(s) {
  var m = String(s || '').toLowerCase().match(/[a-z0-9]+/g);
  return m ? m.join('') : '';
}
// 拉丁词干模糊命中：GAPDAYS(gapdays) ↔ gapday；先整串互含，再去掉结尾复数 s 比一次
function _dmFuzzyHit(nm, star) {
  var a = _dmLatinKey(star), b = _dmLatinKey(nm);
  if (!a || a.length < 4 || !b) return false;
  if (b.indexOf(a) >= 0 || a.indexOf(b) >= 0) return true;
  var a2 = a.replace(/s$/, '');
  return a2.length >= 4 && b.indexOf(a2) >= 0;
}
// 项目名是否命中（关键词逐个试：原名 + 别名 + 去空格名；大小写不敏感；再叠加词干模糊）
function _dmHit(nm, kws, star) {
  var nml = String(nm || '').toLowerCase();
  for (var i = 0; i < kws.length; i++) {
    var k = String(kws[i] || '');
    if (!k) continue;
    if (nm.indexOf(k) >= 0 || nml.indexOf(k.toLowerCase()) >= 0) return true;
  }
  if (_dmFuzzyHit(nm, star)) return true;
  for (var j = 0; j < kws.length; j++) { if (_dmFuzzyHit(nm, kws[j])) return true; }
  return false;
}

async function getDamaiOfficialPoster(star, city) {
  try {
    var _ck = star + '|' + city;
    if (_dmCache[_ck] && Date.now() - _dmCache[_ck].at < 30 * 60 * 1000) return { b64: _dmCache[_ck].b64, match: _dmCache[_ck].match, city: _dmCache[_ck].city, name: _dmCache[_ck].name, fuzzy: _dmCache[_ck].fuzzy };
    const browser = await getPosterBrowser();
    const ctx = await browser.newContext({ userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1', viewport: { width: 390, height: 844 }, isMobile: true });
    const page = await ctx.newPage();
    var pics = []; // 该明星在大麦在架的所有站点海报（严格命中）
    var loose = []; // 模糊命中兜底（GAPDAYS → gapday）
    var detailPic = null; // 项目详情页高清官方海报
    var _kws = _dmKeywords(star); // 原名 + 别名 + 去空格名（别名也要参与命中判定，否则 GAGDAYS 搜到也认不出来）
    page.on('response', async (resp) => {
      var u = resp.url();
      if (/mtop\.damai\.cn\/h5\/mtop\.damai\.wireless\.search\.search/.test(u)) {
        try {
          const t = await resp.text(); const j = JSON.parse(t);
          const list = j.data && j.data.projectInfo;
          if (Array.isArray(list)) for (var i = 0; i < list.length; i++) {
            var it = list[i];
            // 只收演唱会/巡演类，且项目名精准含该明星（排除景点/餐饮/展览/应援饮品/联名周边等）
            var nm = it.name || '';
            var isShow = (it.categoryName === '演唱会') || (it.guideCategoryName === '音乐现场') || /演唱会|巡演|巡回/.test(nm);
            var badName = /演出|票务|代拍|饮品|联名|周边|应援|招募|开票/.test(nm);
            var row = { pid: it.projectId || it.id, name: nm, city: it.cityName || '', vpic: it.verticalPic };
            if (isShow && !badName && it.verticalPic) {
              if (_dmHit(nm, _kws, star)) pics.push(row);
              else if (_dmFuzzyHit(nm, star)) loose.push(row);
            }
          }
        } catch(e) {}
      } else if (/mtop\.damai\.cn\/h5\/mtop\.damai\.wireless\.project\.detail/.test(u)) {
        try {
          const t = await resp.text(); const j = JSON.parse(t);
          var d = j.data || {};
          var vp = (d.result && d.result.verticalPic) || d.verticalPic || (d.itemDO && d.itemDO.verticalPic) || (d.item && d.item.verticalPic);
          if (vp) detailPic = vp;
        } catch(e) {}
      }
    });
    for (var ki = 0; ki < _kws.length; ki++) {
      if (pics.length) break;
      try { await page.goto('https://m.damai.cn/damai/search/index.html?keyword=' + encodeURIComponent(_kws[ki]), { waitUntil: 'domcontentloaded', timeout: 25000 }); } catch(e) {}
      await page.waitForTimeout(3000);
    }
    var fuzzyUsed = false;
    if (!pics.length && loose.length) { pics = loose; fuzzyUsed = true; }
    if (!pics.length) { try { await ctx.close(); } catch(e) {} return { empty: true }; }
    // 1) 目标城市 2) 同明星其它城市（按项目出现顺序，尽量选最新/最大）
    var target = pics.find(function(p) { return p.city === city || p.name.indexOf(city) >= 0; });
    var pick = target || pics[0];
    // 高清：去项目详情页，拦截 project.detail 拿大图（失败则回退搜索缩略图并剥尺寸后缀）
    try {
      await page.goto('https://m.damai.cn/damai/detail.html?id=' + encodeURIComponent(pick.pid || pick.vpic), { waitUntil: 'domcontentloaded', timeout: 30000 });
      await page.waitForTimeout(2500);
    } catch(e) {}
    try { await ctx.close(); } catch(e) {}
    var upic = detailPic || pick.vpic;
    // 剥阿里云尺寸后缀（_WxH.jpg / @WxH.jpg）拿原图
    upic = String(upic || '').replace(/@\d+w_\d+h\.jpg/i, '').replace(/_\d+x\d+\.jpg/i, '').replace(/_\d+w\d+h\.jpg/i, '');
    try {
      var b64 = await downloadImageB64(upic);
      var _res = { b64: b64, match: target ? 'target' : 'other', city: pick.city, name: pick.name, fuzzy: fuzzyUsed };
      if (b64) _dmCache[_ck] = { b64: b64, match: _res.match, city: pick.city, name: pick.name, fuzzy: fuzzyUsed, at: Date.now() };
      return _res;
    } catch(e) { return { empty: true }; }
  } catch(e) { return { empty: true }; }
}

// 生成海报：优先用模板原图替换文字，无模板时用搜索底图
// 版式贴纸 url → 本地文件（三紫块横幅横幅贴纸）
function _stickerFile(url) {
  if (!url) return null;
  if (String(url).indexOf('banner-sticker') >= 0) return path.join(__dirname, 'assets', 'banner_stickers', 'hb_banner.png');
  if (String(url).indexOf('badge-7') >= 0) return path.join(__dirname, 'assets', 'badge7.png');
  // 【2026-10-07 加】hope 店的两个自建贴纸
  if (String(url).indexOf('hope-burst') >= 0) return path.join(__dirname, 'assets', 'burst_stickers', 'hope_burst.png');
  if (String(url).indexOf('hope-swash') >= 0) return path.join(__dirname, 'assets', 'burst_stickers', 'hope_swash.png');
  return null;
}
// 服务端烘焙版式贴纸(如三紫块横幅)：把贴纸叠到底图上，不依赖前端JS——任何客户端出图都能看到三条紫横幅
async function _bakeStickers(baseB64, templateId) {
  try {
    if (!templateId) return baseB64;
    var tpls; try { tpls = JSON.parse(fs.readFileSync(path.join(__dirname, 'assets', 'poster-templates.json'), 'utf8')); } catch(e){ return baseB64; }
    var ver = (tpls || []).filter(function(v){ return v.id === templateId; })[0];
    if (!ver || !Array.isArray(ver.stickers) || !ver.stickers.length) return baseB64;
    var sh = require(path.join(__dirname, 'node_modules', 'sharp'));
    var buf = Buffer.from(baseB64, 'base64');
    var meta = await sh(buf).metadata();
    var W = meta.width, H = meta.height, inputs = [];
    for (var i = 0; i < ver.stickers.length; i++) {
      var st = ver.stickers[i];
      var f = _stickerFile(st.url); if (!f || !fs.existsSync(f)) continue;
      var sm = await sh(f).metadata();
      var stW = Math.round(W * (st.w || 0.22));
      var stH = Math.round(stW * sm.height / sm.width);
      var sx = Math.round(W * (st.x != null ? st.x : 50) / 100 - stW / 2);
      var sy = Math.round(H * (st.y != null ? st.y : 50) / 100 - stH / 2);
      if (stW > W || stH > H) { stW = Math.min(stW, W); stH = Math.round(stW * sm.height / sm.width); }
      // sharp composite 不允许比底图大；先 resize 到目标尺寸再合成
      var resized = await sh(f).resize({ width: stW, height: stH }).png().toBuffer();
      inputs.push({ input: resized, left: sx, top: sy });
    }
    if (!inputs.length) return baseB64;
    var out = await sh(buf).composite(inputs).png().toBuffer();
    return out.toString('base64');
  } catch(e) { return baseB64; }
}

app.post('/api/poster/make', auth, async (req, res) => {
  try {
    var city = (req.body.city || '').trim();
    var star = (req.body.star || '').trim();
    var variant = req.body.variant || '首开';
    if (!city || !star) return res.json({ ok: false, error: '城市和明星必填' });

    // 统一版式四块：中心/宽高按徐良原图贴纸包围盒实测（1020x1360），颜色按原图像素采样
    // 紫块 #dd11ff 白字 / 黄块 #ffdd11 黑字 / 数字3图标蓝 #6688aa。常量在模块级定义（OVERLAY_BLOCK / OVERLAY_TAGS）。
    // 用户前端主动编辑版式块时，用 req.body.blocks / req.body.tags 覆盖默认（贴纸/自定义版式逻辑不生效）；
    // 数组（含空数组）都视为用户显式指定，未传才走默认。
    var userBlocks = Array.isArray(req.body.blocks) ? req.body.blocks : null;
    var userTags = Array.isArray(req.body.tags) ? req.body.tags : null;
    var hasUserBlocks = !!userBlocks;
    var hasUserTags = !!userTags;
    var useUserLayout = hasUserBlocks || hasUserTags;
    // 底图来源标记：'damai'=大麦官方图命中；'ai'=大麦没搜到→AI兜底（前端必须提示，别让人以为是官方图）
    var _baseOrigin = '';

    const browser = await getPosterBrowser();
    const page = await browser.newPage();
    try {
      await page.setContent(POSTER_HTML, { waitUntil: 'load' });
      var params, imageB64;

      {
        // 按来源获取底图（search/ai/posterB64 本地上传）
        var source = req.body.source || 'search';
        var posterB64 = req.body.posterB64 || '';
        if (!posterB64) {
          var url = (req.body.posterUrl || '').trim();
          if (url) {
            posterB64 = await downloadImageB64(url);
          } else if (source === 'aigen') {
            // 真AI出图：搜明星真海报当垫图保人物 → AI重绘无文字底图；
            // 不能落回搜索分支：会搜到同行成品海报（带别家logo/城市）直接当底图，2026-08-19 三亚周杰伦实测翻车
            var aiUrl = await genAIBase(star, city);
            posterB64 = await downloadImageB64(aiUrl);
          } else if (source === 'damai_official' || source === 'maoyan_official') {
            // 官方海报（大麦/猫眼票务同款官方主视觉）：1) 目标城市今年官方海报 → 2) 该明星今年其他在架城市官方海报 → 3) 系统AI出图(无文字底图保人物)
            // 猫眼搜索被 WAF 挡，官方海报与票务平台共用同一张主办方主视觉，故复用大麦官方图源
            var dm = await getDamaiOfficialPoster(star, city);
            if (dm && dm.b64) {
              posterB64 = dm.b64;
              _baseOrigin = 'damai';
              if (dm.fuzzy) console.log('[damai] 模糊命中：搜索词 "' + star + '" → 项目「' + (dm.name || '') + '」');
            } else {
              console.log('[damai] ⚠ 未命中官方海报（star=' + star + ' city=' + city + '），改用 AI 兜底出图');
              _baseOrigin = 'ai';
              // 大麦无任何在架站 → 系统AI出图兜底（无文字底图保人物）
              try {
                var aiBaseUrl = await genAIBase(star, city);
                posterB64 = await downloadImageB64(aiBaseUrl);
                if (!posterB64) throw new Error('AI底图下载为空');
              } catch(e) {
                return res.json({ ok: false, error: '该明星大麦无在架站，AI兜底出图失败: ' + e.message });
              }
            }
          } else if (source === 'damai') {
            // 大麦渠道：屏蔽「大麦」歧义（Bing 误当农作物 barley），完整词+宽松模式，damai 域名 +8 强加权
            // 级联兜底：大麦 → 猫眼/微博合并 → 好易美中台AI出图（无文字底图保人物）
            var dItems = await searchPosterBing(star, city, '大麦 ' + star + ' ' + city + ' 演唱会 海报', false);
            if (!dItems || dItems.length === 0) dItems = await searchPosterBing(star, city, '大麦网 ' + star + ' ' + city + ' 演唱会 海报', false);
            if (!dItems || dItems.length === 0) {
              // 大麦没有 → 猫眼/微博合并去重
              var seen2 = {}, cmb2 = [];
              var qs2 = ['猫眼 ' + star + ' ' + city + ' 演唱会 官方海报', star + ' ' + city + ' 演唱会 官方海报 微博'];
              for (var qi2 = 0; qi2 < qs2.length; qi2++) {
                try { var one2 = await searchPosterBing(star, city, qs2[qi2], false); if (one2 && one2.length) for (var oi2 = 0; oi2 < one2.length; oi2++) { var u2 = one2[oi2].url; if (!seen2[u2]) { seen2[u2] = 1; cmb2.push(one2[oi2]); } } } catch(e) {}
              }
              dItems = cmb2;
            }
            if (!dItems || dItems.length === 0) {
              // 大麦/猫眼都没有 → 好易美中台AI出图兜底
              try {
                var aiBaseUrl2 = await genAIBase(star, city);
                posterB64 = await downloadImageB64(aiBaseUrl2);
                if (!posterB64) throw new Error('AI底图下载为空');
              } catch(e) {
                return res.json({ ok: false, error: '大麦/猫眼都没搜到，好易美中台AI出图兜底失败: ' + e.message });
              }
            } else {
              var dsh = require(path.join(__dirname, 'node_modules', 'sharp'));
              var dFallback = '';
              for (var di = 0; di < dItems.length; di++) {
                try {
                  var db = await downloadImageB64(dItems[di].url);
                  if (!dFallback) dFallback = db;
                  var ddim = await dsh(Buffer.from(db, 'base64')).metadata();
                  if (ddim.width >= 400) { posterB64 = db; break; }
                } catch(e) {}
              }
              if (!posterB64) posterB64 = dFallback;
            }
          } else {
            // search=合并猫眼+大麦渠道去重；ai=官方海报严格（主办方/猫眼/大麦/巡演，排除带字成品）。
            // 底图取到后版式四块全矢量重绘。
            var strictSearch = (source === 'ai');
            var items;
            if (strictSearch) {
              var q1s = star + ' ' + city + ' 演唱会 官方海报 主办方 巡演';
              items = await searchPosterBing(star, city, q1s, true);
              if (!items || items.length === 0) items = await searchPosterBing(star, city, star + ' ' + city + ' 演唱会 海报 官方', true);
            } else {
              // 猫眼 + 大麦 合并去重（damai 域名已在 searchPosterBing 里 +8 加权，官方图自然靠前）
              var seen = {}, cmb = [];
              var qs = [
                '猫眼 ' + star + ' ' + city + ' 演唱会 官方海报',
                star + ' ' + city + ' 演唱会 官方海报 微博',
                '大麦 ' + star + ' ' + city + ' 演唱会 海报'
              ];
              for (var qi = 0; qi < qs.length; qi++) {
                try {
                  var one = await searchPosterBing(star, city, qs[qi], false);
                  if (one && one.length) for (var oi = 0; oi < one.length; oi++) {
                    var u = one[oi].url;
                    if (!seen[u]) { seen[u] = 1; cmb.push(one[oi]); }
                  }
                } catch(e) {}
              }
              items = cmb;
            }
            if (!items || items.length === 0) return res.json({ ok: false, error: '没搜到海报，也没找到模板文件。请把模板放到「闲鱼演唱会模板」文件夹，或手动填海报链接' });
            // 优先高清：下载后读真实尺寸，宽<400 换下一张；全部偏小则兑底用第一张
            var sh = require(path.join(__dirname, 'node_modules', 'sharp'));
            var fallbackB64 = '';
            for (var i = 0; i < items.length; i++) {
              try {
                var b = await downloadImageB64(items[i].url);
                if (!fallbackB64) fallbackB64 = b;
                var dim = await sh(Buffer.from(b, 'base64')).metadata();
                if (dim.width >= 400) { posterB64 = b; break; }
              } catch(e) {}
            }
            if (!posterB64) posterB64 = fallbackB64;
            // 半自动鉴真（仅 ai 严格模式）：最佳候选官方信号弱(s<5)或没取到 → 退回真AI出图（保人物），避免拿别家成品/饭拍当底图
            if (strictSearch && (!posterB64 || (items[0] && (items[0].s || 0) < 5))) {
              try {
                var aiU = await genAIBase(star, city);
                posterB64 = await downloadImageB64(aiU);
              } catch(e) {}
            }
          }
        }
        // 自定义版式（首开/一开）：直接用版式底图，跳过 search/AI 来源
        var tid2 = (req.body.templateId || '').trim();
        // 仅带 blocks 的才当作「自定义版式」（首开/一开：直接用版式底图+代码叠块，不搜图）。
        // 徐良版式虽有 file 但无 blocks，是传统版式——必须走搜底图+三黄块一紫块+重写城市/明星，不能当固定底图。
        var customTpl = loadPosterTemplates().find(function(t) { return t.id === tid2 && (t.blocks || (t.id && t.id.indexOf('tpl_') === 0 && t.file)); });
        // 贴图版式（带 stickers 且无 blocks/file）：不叠默认三黄块+一紫块，底图保持干净，贴纸/文字由前端 _iwApplyText 叠
        var _allTpl = loadPosterTemplates().find(function(t) { return t.id === tid2; });
        // 【2026-10-07 加】显式开关 skipDefaultBlocks：
        //   hope 的几套版式自己用 layers 的 bg 画色块（粉条/黄块），再叠一层默认「三黄块+一紫块」会互相打架
        //   （实测：官方海报上叠了默认黄块紫块，人一眼就看出是老版式的残留）。
        //   ⚠️ 故意做成**显式开关**而不是"有 layers 就跳过" ——
        //     tpl_redtext / tpl_suibian2 / tpl_suibian3 等老版式一直带着默认块在线上跑，
        //     顺手改会动到线上，不能这么干。
        var _skipDefault = _allTpl && (_allTpl.skipDefaultBlocks || (_allTpl.stickers && _allTpl.stickers.length)) && !_allTpl.blocks && !_allTpl.file;
        if (_skipDefault) {
          userBlocks = []; userTags = []; hasUserBlocks = true; hasUserTags = true; useUserLayout = true;
        }
        if (customTpl) {
          var tplFile = path.join(POSTER_TPL_DIR, customTpl.file);
          if (fs.existsSync(tplFile)) posterB64 = fs.readFileSync(tplFile).toString('base64');
        }
        // 中台版式（manager.museav.top：仅 url+prompt，无 blocks）→ 下载其封面 url 当固定底图；下方默认四色块叠 {城市}{明星}
        if (!customTpl && tid2) {
          try {
            var ct = (await hymPosterTemplates()).find(function(t) { return String(t.id) === String(tid2); });
            if (ct && ct.url) {
              var ctB64 = await downloadImageB64(ct.url);
              if (ctB64) posterB64 = ctB64;
            }
          } catch(e) { /* 中台查询失败则继续默认 */ }
        }
        if (!posterB64) return res.json({ ok: false, error: '图片获取失败' });
        // ratio=3:4：底图居中裁成 3:4（偏高裁上下、偏宽裁左右），画布即 3:4，贴纸坐标回到 1:1 等比；不传则保持底图原比例
        if (req.body.ratio === '3:4' && !customTpl) {
          var shCrop = require(path.join(__dirname, 'node_modules', 'sharp'));
          var bufCrop = Buffer.from(posterB64, 'base64');
          var metaCrop = await shCrop(bufCrop).metadata();
          // EXIF orientation ≥5 时宽高互换：extract 在 rotate() 后的坐标系取框，必须按旋转后尺寸算裁切框
          var swapWH = metaCrop.orientation && metaCrop.orientation >= 5;
          var w0 = swapWH ? metaCrop.height : metaCrop.width;
          var h0 = swapWH ? metaCrop.width : metaCrop.height;
          var cw = w0, ch = h0;
          if (w0 / h0 > 3 / 4) cw = Math.round(h0 * 3 / 4);
          else ch = Math.round(w0 * 4 / 3);
          if (cw !== w0 || ch !== h0) {
            var leftCrop = Math.floor((w0 - cw) / 2), topCrop = Math.floor((h0 - ch) / 2);
            posterB64 = (await shCrop(bufCrop).rotate().extract({ left: leftCrop, top: topCrop, width: cw, height: ch }).jpeg({ quality: 95 }).toBuffer()).toString('base64');
          } else if (swapWH) {
            // 已是 3:4 但带 EXIF 旋转，仅归一化方向
            posterB64 = (await shCrop(bufCrop).rotate().jpeg({ quality: 95 }).toBuffer()).toString('base64');
          }
        }
        // 版式四块：贴纸 alpha 形状重铺纯色（两端斜切/圆角与原版100%一致）+ 代码重写字；
        // 贴纸文件缺失时退回几何绘制（颜色/尺寸按原图采样）。用户自定义块时跳过贴纸，避免重绘冲突。
        // [FIX] 命中 customTpl（含 tpl_* 逆向版式=完整成品海报）一律不叠默认 三黄块+一紫块 贴纸，避免与版式自身设计重叠。
        var cutouts = (customTpl || useUserLayout) ? [] : loadCutouts();
        if (cutouts.length) {
          // 高质量预缩放：sharp lanczos3 把贴纸缩到精确目标尺寸，Canvas 1:1 贴不再插值。
          // （Canvas 默认低质量插值在 0.94× 缩放时会把文字边缘糊掉，这是"字不一致"的根源）
          var sharpMod = require(path.join(__dirname, 'node_modules', 'sharp'));
          var baseMeta = await sharpMod(Buffer.from(posterB64, 'base64')).metadata();
          var sFitS = baseMeta.width / 1020;
          for (var ck = 0; ck < cutouts.length; ck++) {
            var co2 = cutouts[ck];
            var tw2 = Math.max(1, Math.round(co2.w * sFitS));
            var th2 = Math.max(1, Math.round(co2.h * sFitS));
            co2.src = (await sharpMod(Buffer.from(co2.src, 'base64')).resize({ width: tw2, height: th2, kernel: 'lanczos3' }).png().toBuffer()).toString('base64');
            co2.dw = tw2; co2.dh = th2;
          }
        }
        params = { template: 'data:image/jpeg;base64,' + posterB64, city: city, star: star, png: !!req.body.png,
          blocks: hasUserBlocks ? userBlocks : (customTpl ? (customTpl.blocks || []) : (cutouts.length ? [] : [OVERLAY_BLOCK])),
          tags: hasUserTags ? userTags : (customTpl ? (customTpl.tags || []) : (cutouts.length ? [] : OVERLAY_TAGS)),
          cutouts: useUserLayout ? undefined : ((customTpl && customTpl.blocks) ? undefined : (cutouts.length ? cutouts : undefined)) };
      }

      imageB64 = await page.evaluate(function(params) {
        return new Promise(function(resolve, reject) {
          window.__done = function(b64) { resolve(b64.replace(/^data:image\/[a-z]+;base64,/, '')); };
          setTimeout(function() { reject(new Error('合成超时')); }, 20000);
          window.drawPoster(params);
        });
      }, params);
      // 服务端烘焙版式贴纸(如三紫块横幅)：叠到返回的底图上，不依赖前端JS
      imageB64 = await _bakeStickers(imageB64, (req.body.templateId || '').trim());
      res.json({ ok: true, imageB64: imageB64, mode: source, baseOrigin: _baseOrigin });
    } finally {
      try { await page.close(); } catch(e) {}
    }
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

app.listen(PORT, '127.0.0.1', () => {
  console.log('[agent] 闲鱼单浏览器多账号服务 端口 ' + PORT);
  console.log('[agent] 账号来源: ' + ADMIN_HOST + '/api/xianyu-accounts');
  // 自动启动
  setTimeout(async () => {
    try {
      accountsCache = await fetchAccounts();
      if (accountsCache.length > 0) {
        agent = new XianyuAgent();
        await agent.init(accountsCache);
        console.log('[agent] ✅ 启动完成，' + accountsCache.length + ' 个账号，当前: ' + (agent.currentAccount?.name || '无'));
      } else {
        console.log('[agent] ⚠ 没有账号');
      }
    } catch (e) { console.log('[agent] 自启动失败:', e.message); }
  }, 500);
});
