@echo off
REM ================================================
REM  Xianyu Playwright Service launcher (port 8093)
REM  Auto-restart on exit. Logs appended to startup.log
REM ================================================
REM  ASCII only on purpose: cmd.exe decodes this file in the OEM codepage (936),
REM  so a Chinese comment here gets split into garbage commands.
cd /d "%~dp0"

REM Poster webhook (leave empty to disable notifications)
set POSTER_WEBHOOK_URL=https://open.feishu.cn/open-apis/bot/v2/hook/3043d99e-c2b7-4b4e-bb0d-5007560a6a1a

REM Port unified to 8093 (wake-publish-sleep.ps1 and bridge_direct.js both expect 8093)
set PORT=8093

REM ---- resolve node without hardcoding a version or a user path ----
REM Order: %XY_NODE% > %XY_NODE_VERSIONS%\current > newest non-dot dir > PATH
set "N="
set "VD=%XY_NODE_VERSIONS%"
if "%VD%"=="" set "VD=%USERPROFILE%\.workbuddy\binaries\node\versions"
if defined XY_NODE if exist "%XY_NODE%" set "N=%XY_NODE%"
if not defined N if exist "%VD%\current" for /f "usebackq delims=" %%v in ("%VD%\current") do if exist "%VD%\%%v\node.exe" set "N=%VD%\%%v\node.exe"
if not defined N if exist "%VD%" for /f "delims=" %%d in ('dir /b /ad /o-d "%VD%" 2^>nul ^| findstr /v /b /l /c:"." ^| findstr /v /i /l /c:"locks"') do if not defined N if exist "%VD%\%%d\node.exe" set "N=%VD%\%%d\node.exe"
if not defined N for /f "delims=" %%n in ('where node 2^>nul') do if not defined N set "N=%%n"
if not defined N (
  echo [start.bat] no node found. Set XY_NODE, or put node on PATH. >> "%~dp0startup.log"
  echo [start.bat] no node found. Set XY_NODE, or put node on PATH.
  pause
  exit /b 1
)

REM ---- 2026-11-13: two fixes for startup.log ----
REM 1) Rotation. This file reached 94 MB with no rotation -- impossible to open,
REM    and "look at the last few lines" became useless advice for students.
REM 2) ASCII timestamp only. %date% on a Chinese Windows prints "2026/11/13 ??????"
REM    where the weekday name is GBK bytes, while node writes UTF-8. Appending both
REM    to one file produces mixed encoding: half the lines mojibake whichever way
REM    you open it. %date:~0,10% keeps just "2026/11/13" (pure ASCII).
REM Rotate: keep the last 2000 lines, then DELETE the original.
REM (Renaming alone still leaves a 94MB file on disk -- measured 94.7MB + a stray
REM  24MB .bak_big on 2026-11-13, 119MB total for a log nobody reads in full.)
for %%A in ("%~dp0startup.log") do if %%~zA GTR 10485760 (
  powershell -NoProfile -Command "Get-Content '%~dp0startup.log' -Tail 2000 -Encoding UTF8 | Set-Content '%~dp0startup.old.log' -Encoding UTF8; Remove-Item '%~dp0startup.log' -Force"
)

:loop
REM Timestamp via PowerShell: %date% format varies by locale (this machine prints
REM "Fri 2026/11/13" with the weekday FIRST and in GBK), so slicing by position is
REM unreliable. Get ISO format instead -- pure digits, no locale dependency.
for /f "delims=" %%t in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HH:mm:ss"') do set "TS=%%t"
if not defined TS set "TS=no-time"
echo [%TS%] starting... >> "%~dp0startup.log"
"%N%" server.js >> "%~dp0startup.log" 2>&1
echo [%TS%] service exited, restart in 5s >> "%~dp0startup.log"
timeout /t 5 >nul
goto loop
