/* probe-damai.js — 临时探针：打印大麦搜索返回的全部演出条目（名称/城市/分类/项目ID） */
const path = require('path');
const { chromium } = require(path.join(__dirname, 'node_modules', 'playwright'));

(async () => {
  const kw = process.argv[2] || '周杰伦';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
    viewport: { width: 390, height: 844 }, isMobile: true,
  });
  const page = await ctx.newPage();
  const seen = {};
  page.on('response', async (resp) => {
    if (!/mtop\.damai\.cn\/h5\/mtop\.damai\.wireless\.search\.search/.test(resp.url())) return;
    try {
      const j = JSON.parse(await resp.text());
      const list = j.data && j.data.projectInfo;
      if (Array.isArray(list)) for (const it of list) {
        if (seen[it.id || it.projectId]) continue;
        seen[it.id || it.projectId] = true;
        console.log(JSON.stringify({
          name: it.name, city: it.cityName, cat: it.categoryName,
          guide: it.guideCategoryName, pid: it.projectId || it.id,
          showTime: it.showTime, pic: it.verticalPic,
        }));
      }
    } catch (e) {}
  });
  await page.goto('https://m.damai.cn/damai/search/index.html?keyword=' + encodeURIComponent(kw), { waitUntil: 'domcontentloaded', timeout: 25000 }).catch(() => {});
  await page.waitForTimeout(6000);
  if (Object.keys(seen).length === 0) {
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 25000 }).catch(() => {});
    await page.waitForTimeout(6000);
  }
  await browser.close();
  console.log('--- probe done, kw=' + kw);
})();
