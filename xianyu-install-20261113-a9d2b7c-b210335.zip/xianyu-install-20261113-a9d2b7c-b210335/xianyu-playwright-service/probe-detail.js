/* probe-detail.js — 临时探针：按项目 ID 进大麦详情页，拦 project.detail 拿官方海报地址 */
const path = require('path');
const { chromium } = require(path.join(__dirname, 'node_modules', 'playwright'));

(async () => {
  const pid = process.argv[2] || '1077189102025';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
    viewport: { width: 390, height: 844 }, isMobile: true,
  });
  const page = await ctx.newPage();
  let got = null;
  page.on('response', async (resp) => {
    if (!/mtop\.damai\.cn\/h5\/mtop\.damai\.wireless\.project\.detail/.test(resp.url())) return;
    try {
      const j = JSON.parse(await resp.text());
      const d = j.data || {};
      const vp = (d.result && d.result.verticalPic) || d.verticalPic || (d.itemDO && d.itemDO.verticalPic) || (d.item && d.item.verticalPic)
        || (d.result && d.result.headPoster && d.result.headPoster.url) || (d.result && d.result.pic) || '';
      const name = (d.result && d.result.name) || d.name || '';
      if (vp && !got) { got = { pic: vp, name: name }; }
    } catch (e) {}
  });
  await page.goto('https://m.damai.cn/damai/detail.html?id=' + encodeURIComponent(pid), { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(6000);
  if (!got) {
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(6000);
  }
  await browser.close();
  console.log(JSON.stringify(got || { empty: true }));
})();
