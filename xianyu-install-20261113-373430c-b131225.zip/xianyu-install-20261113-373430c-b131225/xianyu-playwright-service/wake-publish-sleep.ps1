﻿# 唤醒发布脚本：定时任务每 30 分钟唤醒电脑后运行
# 流程：等网络 → 确保 8093 服务 → 切换店铺(重建页面注入最新代码) → 发布 1 单 → 用户空闲则休眠
# 用法：powershell -NoProfile -ExecutionPolicy Bypass -File wake-publish-sleep.ps1 [-Store 好易美代拍]
param([string]$Store = '好易美代拍', [int]$PublishTimeoutSec = 360, [switch]$NoSleep)

$ErrorActionPreference = 'Continue'
$SvcBase = 'http://127.0.0.1:8093'
$LogFile = Join-Path $PSScriptRoot 'wake-publish.log'

function Log([string]$m) {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' | ' + $m
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
}

Log "=== 唤醒轮次开始 Store=$Store ==="

# 1. 等网络恢复（休眠唤醒后 WiFi 要几秒到几十秒）
$netOk = $false
for ($i = 0; $i -lt 30; $i++) {
    try {
        $resp = Invoke-WebRequest -Uri 'https://www.goofish.com' -UseBasicParsing -TimeoutSec 5
        if ($resp.StatusCode -eq 200) { $netOk = $true; break }
    } catch {}
    Start-Sleep -Seconds 3
}
if (-not $netOk) { Log '网络不可用（90秒未恢复），跳过本轮'; exit }

# 2. 确保 8093 服务在跑（机器重启后服务不会自启，这里兜底拉起）
$svcOk = $false
try {
    $h = Invoke-RestMethod -Uri ($SvcBase + '/health') -TimeoutSec 5
    if ($h.ok) { $svcOk = $true }
} catch {}
if (-not $svcOk) {
    Log '服务未运行，启动 start.bat...'
    Start-Process -FilePath (Join-Path $PSScriptRoot 'start.bat') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden
    for ($i = 0; $i -lt 60; $i++) {
        Start-Sleep -Seconds 3
        try {
            $h = Invoke-RestMethod -Uri ($SvcBase + '/health') -TimeoutSec 5
            if ($h.ok -and $h.running) { $svcOk = $true; break }
        } catch {}
    }
}
if (-not $svcOk) { Log '服务 3 分钟未能就绪，跳过本轮'; exit }

# 2.5 暂停开关
# 【2026-09-29 改·老板要求】原来是「用户活跃（空闲 <300 秒）就跳过发布」，
#   等于把发布绑在「人不在电脑前」上。老板要求【守在电脑前也要发】，故去掉空闲判断，
#   改成一个显式的暂停文件：只要 D:\DSH\achun\PAUSE-PUBLISH 存在，本轮就只保活不发布。
#   想暂停：双击 D:\DSH\achun\暂停发布.cmd     想恢复：双击 D:\DSH\achun\继续发布.cmd
# 注意：IdleCheck 类型仍要定义 —— 后面「要不要让电脑休眠」那一步还在用它。
try {
    Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class IdleCheck{ [DllImport("user32.dll")] public static extern bool GetLastInputInfo(ref LASTINPUTINFO ii); [StructLayout(LayoutKind.Sequential)] public struct LASTINPUTINFO{ public uint cbSize; public uint dwTime; } }' -ErrorAction Stop
} catch {}
if (Test-Path 'D:\DSH\achun\PAUSE-PUBLISH') {
    Log '发现暂停开关 PAUSE-PUBLISH —— 本轮只保活，不发布'
    exit
}

# 3. 切换到目标店铺（重建页面 → 注入桌面目录里最新的 publish.js）
try {
    $b1 = @{ name = $Store } | ConvertTo-Json -Compress
    Invoke-RestMethod -Method Post -Uri ($SvcBase + '/api/agent/start-one') -ContentType 'application/json; charset=utf-8' -Body $b1 -TimeoutSec 90 | Out-Null
    Start-Sleep -Seconds 6
} catch { Log ('start-one 异常: ' + $_.Exception.Message) }

# 3.5 刷新页面，并【确认】两样东西都在：地址库(ADDRESS_DB) + 发布程序(kunPublish)
#
# 为什么不再自己 reload 后干等 90 秒：
#   reload 会把 ADDRESS_DB 和 kunPublish 一起清掉。原来只 reload 然后等，
#   等不到就白跑一轮（日志里的「页面未就绪（新代码未加载）」）。
#   而缺 ADDRESS_DB 更危险：findAddress() 返回 null，发布直接抛「addr not found」。
# 现在交给 Node 脚本（tools/ensure-page-ready.js）主动把两个装回去并逐一校验：
#   两样都在 -> 退出码 0，继续发布； 缺任何一样 -> 退出码 2，跳过本轮。
# 逻辑写在 Node 里是因为两个文件合计 140KB 且含中文，走 PowerShell 的 JSON 有编码风险。
$node = 'C:\Users\43462\scoop\apps\nodejs\current\node.exe'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
$ready = $false
try {
    $eo = & $node 'D:\DSH\achun\tools\ensure-page-ready.js' 2>&1 | Out-String
    Log ('就绪检查: ' + ($eo.Trim() -replace '\s+', ' '))
    if ($LASTEXITCODE -eq 0) { $ready = $true }
} catch { Log ('就绪检查异常: ' + $_.Exception.Message) }
if (-not $ready) { Log '页面未就绪（缺地址库或发布程序）—— 跳过本轮，不用残缺页面发布'; exit }

# 4. 触发发布 1 单（runBatchPublish(1)：有 maxCount 参数则只发 1 单）
$storeJson = ConvertTo-Json -InputObject $Store -Compress
$jsCode = "(async function(){try{window.kunPublish.setStore($storeJson);await window.kunPublish.syncTasksFromDisk();var st=window.kunPublish.getDailyStatus?window.kunPublish.getDailyStatus():null;if(st&&st.running){return 'daily-running,skip';}window.kunPublish.runBatchPublish(1);return 'started';}catch(e){return 'err:'+e.message;}})()"
try {
    $b2 = @{ store = $Store; code = $jsCode } | ConvertTo-Json -Compress
    $r = Invoke-RestMethod -Method Post -Uri ($SvcBase + '/api/agent/eval-on-store') -ContentType 'application/json; charset=utf-8' -Body $b2 -TimeoutSec 90
    Log ('触发发布结果: ' + ($r.result))
    if ($r.result -and $r.result -like 'daily-running*') { Log '每日发布循环正在跑，本轮不抢单'; }
    if ($r.result -and $r.result -like 'err:*') {
        Log '页面可能未就绪，等待 10 秒后重试一次'
        Start-Sleep -Seconds 10
        $r = Invoke-RestMethod -Method Post -Uri ($SvcBase + '/api/agent/eval-on-store') -ContentType 'application/json; charset=utf-8' -Body $b2 -TimeoutSec 90
        Log ('重试触发结果: ' + ($r.result))
    }
} catch { Log ('触发发布异常: ' + $_.Exception.Message) }

# 5. 轮询批量状态直到结束（最多 PublishTimeoutSec 秒）
$stCode = '(function(){try{var s=window.kunPublish.getBatchStatus?window.kunPublish.getBatchStatus():{running:false};return JSON.stringify(s);}catch(e){return JSON.stringify({running:false});}})()'
$finalStatus = ''
for ($i = 0; $i -lt [math]::Floor($PublishTimeoutSec / 10); $i++) {
    Start-Sleep -Seconds 10
    try {
        $b3 = @{ store = $Store; code = $stCode } | ConvertTo-Json -Compress
        $rr = Invoke-RestMethod -Method Post -Uri ($SvcBase + '/api/agent/eval-on-store') -ContentType 'application/json; charset=utf-8' -Body $b3 -TimeoutSec 30
        $st = $rr.result | ConvertFrom-Json
        if ($st.running -eq $false) {
            $finalStatus = 'done=' + $st.done + ' failed=' + $st.failed + ' total=' + $st.total
            Log ('本轮发布完成: ' + $finalStatus)
            break
        }
    } catch { Log ('状态查询异常: ' + $_.Exception.Message) }
}

# 6. 用户空闲才休眠（防止把正在用电脑的人睡掉）
try {
    $lii = New-Object IdleCheck+LASTINPUTINFO
    $lii.cbSize = 8
    [IdleCheck]::GetLastInputInfo([ref]$lii) | Out-Null
    $idleSec = [Environment]::TickCount - $lii.dwTime
    if ($idleSec -lt 180) {
        Log ('用户正在操作电脑（空闲 ' + $idleSec + ' 秒），跳过休眠')
        exit
    }
} catch { Log ('空闲检测失败，按空闲处理: ' + $_.Exception.Message) }

Log '进入睡眠（S3），等待下一次 30 分钟唤醒'
if ($NoSleep) { Log '已配置不休眠（-NoSleep），跳过休眠'; exit }
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class SuspendHelper{ [DllImport("powrprof.dll")] public static extern bool SetSuspendState(bool hibernate, bool forceCritical, bool disableWakeEvent); }' -ErrorAction SilentlyContinue
try {
    [SuspendHelper]::SetSuspendState($false, $true, $false) | Out-Null
} catch {
    Log ('睡眠调用失败: ' + $_.Exception.Message)
}
