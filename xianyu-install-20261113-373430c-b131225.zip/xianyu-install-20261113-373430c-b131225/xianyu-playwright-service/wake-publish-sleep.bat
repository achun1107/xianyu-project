@echo off
REM NoSleep flag: publish but never suspend the machine
REM %~dp0 instead of a hardcoded absolute path - this used to break on any other machine.
powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0wake-publish-sleep.ps1" -NoSleep