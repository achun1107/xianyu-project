@echo off
REM ================================================
REM  Xianyu Playwright Service launcher (port 8093)
REM  Auto-restart on exit. Logs appended to startup.log
REM ================================================
REM  ASCII only on purpose: cmd.exe decodes this file in the OEM codepage (936),
REM  so a Chinese comment here gets split into garbage commands.
cd /d "%~dp0"

REM Poster webhook (leave empty to disable notifications)
set POSTER_WEBHOOK_URL=https://open.feishu.cn/open-apis/bot/v2/hook/3043d99e-c2b7-4b4e-bb0d-5007560a6a1a

REM Port unified to 8093 (wake-publish-sleep.ps1 and bridge_direct.js both expect 8093)
set PORT=8093

REM ---- resolve node without hardcoding a version or a user path ----
REM Order: %XY_NODE% > %XY_NODE_VERSIONS%\current > newest non-dot dir > PATH
set "N="
set "VD=%XY_NODE_VERSIONS%"
if "%VD%"=="" set "VD=%USERPROFILE%\.workbuddy\binaries\node\versions"
if defined XY_NODE if exist "%XY_NODE%" set "N=%XY_NODE%"
if not defined N if exist "%VD%\current" for /f "usebackq delims=" %%v in ("%VD%\current") do if exist "%VD%\%%v\node.exe" set "N=%VD%\%%v\node.exe"
if not defined N if exist "%VD%" for /f "delims=" %%d in ('dir /b /ad /o-d "%VD%" 2^>nul ^| findstr /v /b /l /c:"." ^| findstr /v /i /l /c:"locks"') do if not defined N if exist "%VD%\%%d\node.exe" set "N=%VD%\%%d\node.exe"
if not defined N for /f "delims=" %%n in ('where node 2^>nul') do if not defined N set "N=%%n"
if not defined N (
  echo [start.bat] no node found. Set XY_NODE, or put node on PATH. >> "%~dp0startup.log"
  echo [start.bat] no node found. Set XY_NODE, or put node on PATH.
  pause
  exit /b 1
)

:loop
echo [%date% %time%] starting... >> "%~dp0startup.log"
"%N%" server.js >> "%~dp0startup.log" 2>&1
echo [%date% %time%] service exited, restart in 5s >> "%~dp0startup.log"
timeout /t 5 >nul
goto loop