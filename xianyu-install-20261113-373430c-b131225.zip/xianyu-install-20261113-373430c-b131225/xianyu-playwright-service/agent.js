// 闲鱼多账号管理代理（单浏览器多 Context 版）
// 一个浏览器进程，每账号独立 Context（不同指纹）
// Context 不关闭 → session Cookie 不丢失
// 切换时用 storageState 保存/加载完整登录态

const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const PROFILES_DIR = path.join(__dirname, 'browser-profiles');
const DAYU_URL = 'https://dayu.goofish.com/';
const EXTENSION_PATH = (function () {
  // 浏览器扩展目录（发布要用）。同样：并排优先，回落本机历史位置。
  var beside = path.join(__dirname, '..', 'xianyu-monitor');
  try { if (fs.existsSync(beside)) return beside; } catch (e) {}
  return 'C:/Users/43462/Desktop/xianyu-monitor';
})();

// 空闲回收（2026-09-28）：
// 原来浏览器进程【永不关闭】—— 服务一启动就常驻约 10 个 Chromium / 700MB。
// 登录态存在 browser-profiles/<accountId>/state.json（storageState = cookies + localStorage），
// 不依赖浏览器进程存活，所以“关掉再开”是安全的：重开后 _switchTo 第 6 步 loadState 会把 cookies 灌回去。
// 可用环境变量 AGENT_IDLE_MS 覆盖（自检用，例如设成 30000 验证回收是否真的发生）。
const AGENT_IDLE_MS = parseInt(process.env.AGENT_IDLE_MS || '', 10) || 20 * 60 * 1000;

/**
 * 根据 accountId 分配一致的指纹参数
 * 同一账号每次拿到一样的 viewport/timezone/locale
 */
function getFingerprintParams(accountId) {
  const seed = accountId.split('').reduce((s, c) => s + c.charCodeAt(0), 0);

  const viewports = [
    { width: 1280, height: 800 },
    { width: 1366, height: 768 },
    { width: 1440, height: 900 },
    { width: 1920, height: 1080 },
  ];
  const timezones = [
    'Asia/Shanghai',
    'Asia/Shanghai',
    'Asia/Shanghai',
    'Asia/Chongqing',
  ];
  const locales = [
    'zh-CN',
    'zh-CN',
    'zh-CN',
    'zh-Hans-CN',
  ];

  return {
    viewport: viewports[seed % viewports.length],
    timezoneId: timezones[seed % timezones.length],
    locale: locales[seed % locales.length],
  };
}

class XianyuAgent {
  constructor() {
    this.browser = null;         // 共享浏览器进程（按需拉起；空闲 AGENT_IDLE_MS 后回收，见 _ensureBrowser/_idleClose）
    this._idleTimer = null;      // 空闲回收定时器
    this._lastUse = 0;           // 最后一次操作时间（诊断用）
    this.context = null;         // 当前账号的 browser context
    this.page = null;            // 当前活跃页
    this.pages = {};             // 多标签页 { dayu, goofish }
    this.stores = {};            // 多店铺并行 { storeName: { context, pages: { goofish }, account } }
    this.state = 'idle';         // idle | switching | logging_in | waiting_verify | ready | error
    this.currentAccount = null;  // { id, name, username, password, notes }
    this.accounts = {};          // { accountId: account }
    this._injecting = new Set(); // 防重入：正在注入脚本的页面
    this._switchLock = Promise.resolve(); // 串行锁：确保 switchTo 不会并发
  }

  // ===== 初始化 =====

  async init(accounts) {
    this.accounts = {};
    this.stores = {};  // 清空旧店铺记录
    for (const a of accounts) {
      this.accounts[a.id] = a;
    }

    if (!fs.existsSync(PROFILES_DIR)) {
      fs.mkdirSync(PROFILES_DIR, { recursive: true });
    }

    // 【2026-09-28 改】原来在这里就 chromium.launch() 并 switchTo 默认店铺，
    // 导致服务一启动就常驻约 10 个 Chromium / 700MB，而闲鱼操作其实是间歇性的。
    // 现在改成【按需拉起】：第一次真正操作（switchTo / login / evalOnStore）时才启动，
    // 之后空闲 AGENT_IDLE_MS 会被自动回收。
    // 想恢复“启动即预热”的老行为，设环境变量 AGENT_WARM_ON_INIT=1。
    if (process.env.AGENT_WARM_ON_INIT === '1' && accounts.length > 0) {
      var def = accounts.find(function(a) { return a.name === '好易美代拍'; }) || accounts[0];
      await this.switchTo(def);
    } else {
      this.state = 'idle';
      console.log('[agent] 已加载 ' + accounts.length + ' 个账号（浏览器按需启动，空闲 ' + Math.round(AGENT_IDLE_MS / 60000) + ' 分钟自动回收）');
    }
  }

  // ===== 浏览器生命周期：按需拉起 + 空闲回收 =====

  /** 确保浏览器在运行；不在就拉起来。所有需要浏览器的方法都应先调它。 */
  async _ensureBrowser() {
    if (this.browser && this.browser.isConnected && this.browser.isConnected()) return this.browser;
    console.log('[agent] 拉起浏览器进程');
    this.browser = await chromium.launch({
      headless: false,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-blink-features=AutomationControlled',
        '--proxy-server=direct://',
      ],
    });
    console.log('[agent] 浏览器已启动');
    return this.browser;
  }

  /** 记录一次使用，并重置空闲回收定时器。 */
  _touch() {
    this._lastUse = Date.now();
    if (this._idleTimer) { clearTimeout(this._idleTimer); this._idleTimer = null; }
    if (!this.browser) return;
    var self = this;
    this._idleTimer = setTimeout(function () { self._idleClose(); }, AGENT_IDLE_MS);
    if (this._idleTimer.unref) this._idleTimer.unref();
  }

  /**
   * 空闲回收：登录态落盘 → 关 context → 关浏览器。
   * 等价于一次服务重启（重启后 stores 本来就是空的，各流程已能处理），所以是安全的。
   */
  async _idleClose() {
    this._idleTimer = null;
    if (!this.browser) return;
    // 切换中/登录中不回收，避免打断进行中的操作
    if (this.state === 'switching' || this.state === 'logging_in') {
      var self = this;
      this._idleTimer = setTimeout(function () { self._idleClose(); }, 60 * 1000);
      if (this._idleTimer.unref) this._idleTimer.unref();
      return;
    }
    console.log('[agent] ⏰ 空闲 ' + Math.round(AGENT_IDLE_MS / 60000) + ' 分钟，回收浏览器进程（释放约 700MB）');
    // 1) 当前账号 + 所有店铺的登录态落盘（否则关掉就丢）
    try { await this.saveState(); } catch (e) { }
    for (var nm in this.stores) {
      try {
        var st = this.stores[nm];
        if (!st || !st.context || !st.account) continue;
        var dir = path.join(PROFILES_DIR, String(st.account.id));
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        await st.context.storageState({ path: this.getStatePath(st.account.id) });
      } catch (e) { console.log('[agent] 存店铺「' + nm + '」状态失败: ' + e.message); }
    }
    // 2) 关 context 和浏览器
    try { await this._closeContext(); } catch (e) { }
    this.stores = {};   // context 随浏览器一起没了；下次 switchTo 会重建
    this.pages = {};
    this.page = null;
    var b = this.browser; this.browser = null;
    try { await b.close(); } catch (e) { }
    this.currentAccount = null;
    this.state = 'idle';
    console.log('[agent] ✅ 浏览器已回收，下次操作会自动重开并从 state.json 恢复登录态');
  }

  // ===== 账号管理 =====

  setAccounts(accounts) {
    this.accounts = {};
    for (const a of accounts) {
      this.accounts[a.id] = a;
    }
  }

  findAccount(accountId) {
    return this.accounts[accountId] || null;
  }

  findAccountByName(name) {
    for (const [id, a] of Object.entries(this.accounts)) {
      if (a.name === name) return a;
    }
    return null;
  }

  // ===== 状态持久化（storageState = cookies + localStorage） =====

  getStatePath(accountId) {
    return path.join(PROFILES_DIR, String(accountId), 'state.json');
  }

  /** 保存当前账号的 storageState */
  async saveState() {
    if (!this.context || !this.currentAccount) return;
    try {
      const dir = path.join(PROFILES_DIR, String(this.currentAccount.id));
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      await this.context.storageState({ path: this.getStatePath(this.currentAccount.id) });
      console.log(`[agent] 💾 已保存「${this.currentAccount.name}」登录态`);
    } catch (e) {
      console.log(`[agent] 保存状态失败:`, e.message);
    }
  }

  /** 手动保存（对外接口） */
  async saveCookies() {
    await this.saveState();
  }

  /** 加载指定账号的 storageState 到当前 context */
  async loadState(accountId) {
    const statePath = this.getStatePath(accountId);
    if (!fs.existsSync(statePath)) return false;
    try {
      const raw = fs.readFileSync(statePath, 'utf8');
      const state = JSON.parse(raw);
      if (state.cookies && state.cookies.length > 0) {
        await this.context.addCookies(state.cookies);
        console.log(`[agent] 📂 已恢复 ${state.cookies.length} 个 Cookie`);
      }
      // 恢复 localStorage
      if (state.origins && state.origins.length > 0) {
        for (const origin of state.origins) {
          if (!origin.origin) continue;
          // 瘦身：跳过 淘宝/天猫 等非必要 origin(闲鱼 localStorage 主要在 goofish/dayu)，避免多开淘宝/天猫空白页
          if (/taobao\.com|tmall\.com|tmall\.hk|m\.tmall/i.test(origin.origin)) continue;
          if (origin.localStorage && origin.localStorage.length > 0) {
            // 需要先导航到该 origin 的任意页面才能设置 localStorage
            const page = await this.context.newPage();
            try {
              await page.goto(origin.origin, { waitUntil: 'domcontentloaded', timeout: 8000 });
              for (const item of origin.localStorage) {
                await page.evaluate(({k, v}) => { try { localStorage.setItem(k, v); } catch(e) {} }, {k: item.name, v: item.value});
              }
            } catch(e) {}
            await page.close();
          }
        }
        console.log('[agent] 📂 已恢复 localStorage');
      }
      return true;
    } catch (e) {
      console.log(`[agent] 加载状态失败:`, e.message);
    }
    return false;
  }

  // ===== 账号切换 =====

  /**
   * 切换到指定账号：
   * 1. 保存当前账号的 storageState（cookies + localStorage）
   * 2. 关闭当前 context（浏览器进程不关，session Cookie 在 state 里已存）
   * 3. 用该账号的指纹参数创建新 context
   * 4. 加载该账号的 storageState
   * 5. 导航到闲鱼大佑检查登录态
   */
  async switchTo(account) {
    await this._ensureBrowser();   // 浏览器可能已被空闲回收，先确保它在
    this._touch();
    // 串行锁：防止两个 start-one 并发导致状态冲突
    var self = this;
    var prev = this._switchLock;
    var unlock;
    this._switchLock = new Promise(function(r) { unlock = r; });
    await prev;
    try {
      return await self._switchTo(account);
    } finally {
      unlock();
    }
  }
  async _switchTo(account) {
    this.state = 'switching';

    // 1. 保存当前账号状态
    if (this.context && this.currentAccount) {
      await this.saveState();
      // 存档到 stores map（不关闭，保留给并行发布）
      this.stores[this.currentAccount.name] = {
        context: this.context,
        pages: Object.assign({}, this.pages),
        account: this.currentAccount
      };
      console.log(`[agent] 📦 存档店铺「${this.currentAccount.name}」页面`);
    }

    // 2. 检查是否已有该店铺的存档，有则复用
    var existing = this.stores[account.name];
    if (existing) {
      try {
        if (existing.pages.goofish && existing.pages.goofish.isClosed()) throw new Error('closed');
        this.context = existing.context;
        this.pages = existing.pages;
        this.page = existing.pages.dayu || existing.pages.goofish;
        this.currentAccount = existing.account;
        this.state = 'ready';
        await this.page.bringToFront();
        return { name: account.name, state: this.state };
      } catch(e) {
        console.log('[agent]「' + account.name + '」页面已关闭，重新创建');
        delete this.stores[account.name];
      }
    }

    // 3. 切换账号引用
    this.currentAccount = account;

    // 4. 获取该账号专属指纹参数
    const fp = getFingerprintParams(account.id);
    console.log(`[agent] 创建「${account.name}」上下文（${fp.viewport.width}x${fp.viewport.height}）`);

    // 5. 创建新 context（不同指纹）
    this.context = await (await this._ensureBrowser()).newContext({
      viewport: fp.viewport,
      locale: fp.locale,
      timezoneId: fp.timezoneId,
    });
    // Chrome 142+ 的「本地网络访问(LNA)」限制：公共页面(goofish.com) → localhost 会被拦截，
    // 未授权时 fetch 会一直挂起（不是报错），导致页面读不到本地服务和本地图片。
    // 授予 local-network-access 权限（Playwright 1.61+ 原生支持）解除拦截。
    try {
      await this.context.grantPermissions(['local-network-access']);
      console.log(`[agent] 🔓「${account.name}」已授予 local-network-access 权限`);
    } catch (e) {
      console.log('[agent] ⚠ 授予 local-network-access 失败(可能Playwright版本不支持): ' + e.message);
    }
    // 设唯一标识验证隔离
    await this.context.addInitScript({ content: 'window.__CTX_ID = "' + account.name + '_' + Date.now() + '"' });

    // 6. 加载已保存的登录态
    const hasState = await this.loadState(account.id);

    // 7. 同时打开日佑 + 闲鱼主站两个标签页
    this.pages = {};

    // 7a. 打开日佑（主标签）
    this.page = await this.context.newPage();
    this.pages.dayu = this.page;
    this._attachApiCapture(this.page, account.name + '/dayu'); // 抓 mtop 请求供探查接口
    // 网络捕获：监听 dayu 页 idle.ad API 响应，写盘供外部读取(擦亮/宝贝数据抓取)
    const NETCAP = path.join(__dirname, '_netcap.txt');
    this.page.on('response', async (resp) => {
      try {
        const u = resp.url();
        if (/mtop\.taobao\.idle\.ad\./.test(u)) {
          const api = (u.match(/mtop\.taobao\.idle\.ad\.[a-zA-Z0-9_.]+/) || [''])[0];
          const t = await resp.text();
          fs.appendFileSync(NETCAP, '\n=== ' + api + ' ===\n' + t.slice(0, 3000));
        }
      } catch(e) {}
    });
    // 监听页面加载/刷新，自动重新注入脚本
    this.page.on('load', async () => {
      if (this._injecting.has('dayu')) return;
      this._injecting.add('dayu');
      try {
        console.log('[agent] 日佑页面已加载，自动注入脚本');
        await this.page.waitForTimeout(2000);
        await this.injectMonitor(this.page);
      } finally {
        this._injecting.delete('dayu');
      }
    });
    await this.page.goto(DAYU_URL, { waitUntil: 'domcontentloaded', timeout: 15000 });
    await this.page.waitForTimeout(2500);
    await this.injectMonitor(this.page);

    // 7b. 打开闲鱼主站（发布用）
    const goofishPage = await this.context.newPage();
    this.pages.goofish = goofishPage;
    this._attachApiCapture(goofishPage, account.name + '/goofish'); // 抓 mtop 请求供探查接口(如下架)
    // 监听页面加载/刷新，自动重新注入脚本
    goofishPage.on('load', async () => {
      if (this._injecting.has('goofish')) return;
      this._injecting.add('goofish');
      try {
        console.log('[agent] 闲鱼主站页面已加载，自动注入脚本');
        await goofishPage.waitForTimeout(2000);
        await this.injectMonitor(goofishPage);
      } finally {
        this._injecting.delete('goofish');
      }
    });
    await goofishPage.goto('https://www.goofish.com/', { waitUntil: 'domcontentloaded', timeout: 15000 });
    await goofishPage.waitForTimeout(2500);
    await this.injectMonitor(goofishPage);

    // 存档到并行店铺列表
    this.stores[account.name] = {
      context: this.context,
      pages: Object.assign({}, this.pages),
      account: account
    };

    // 切回日佑作为当前活跃页

    // 检查登录态（用日佑的页面）
    const loggedIn = await this.checkLoginState();
    if (loggedIn) {
      this.state = 'ready';
      console.log(`[agent] ✅「${account.name}」已登录，已就绪`);
      // 只在恢复已有状态时保存（避免覆盖未登录的空白状态）
      if (hasState) await this.saveState();
    } else if (hasState) {
      this.state = 'idle';
      console.log(`[agent] ⚠「${account.name}」登录已过期，需要重新登录`);
    } else {
      this.state = 'idle';
      console.log(`[agent]「${account.name}」首次使用，需要手动登录`);
    }

    await this.page.bringToFront();
    await this.updateTitle();
    return { name: account.name, state: this.state };
  }

  /** 关闭当前 context（不关浏览器进程） */
  async _closeContext() {
    if (this.context) {
      try {
        await this.context.close();
      } catch (e) {
        console.log('[agent] 关闭 context 轻微错误:', e.message);
      }
    }
    this.context = null;
    this.pages = {};
    this.page = null;
  }

  // ===== 多店铺并行 =====

  /** 预打开所有店铺的浏览器页面 */
  async openAllStores() {
    var names = Object.keys(this.accounts).map(function(k) { return this.accounts[k].name; }.bind(this));
    console.log('[agent] 并行打开所有店铺:', names.join(', '));
    for (var i = 0; i < names.length; i++) {
      var name = names[i];
      if (this.stores[name]) { console.log('[agent] 「' + name + '」已就绪，跳过'); continue; }
      var account = this.findAccountByName(name);
      if (!account) { console.log('[agent] 「' + name + '」账号不存在，跳过'); continue; }
      console.log('[agent] 正在启动「' + name + '」...');
      await this.switchTo(account);
    }
    // 切回默认店铺
    var first = this.findAccountByName(names[0]);
    if (first) await this.switchTo(first);
    console.log('[agent] ✅ 所有店铺已就绪:', Object.keys(this.stores).join(', '));
  }

  /** 获取指定店铺的 goofish 页面 */
  getStorePage(name) {
    this._touch();
    var s = this.stores[name];
    return s ? s.pages.goofish : null;
  }

  /** 在指定店铺的页面上执行 JS */
  async evalOnStore(name, code) {
    await this._ensureBrowser();
    this._touch();
    var pg = this.getStorePage(name);
    if (!pg) throw new Error('店铺「' + name + '」未就绪');
    return pg.evaluate(code);
  }

  // ===== 登录 =====

  async login() {
    await this._ensureBrowser();
    this._touch();
    // 懒启动后 currentAccount 可能是空的：先切到默认店铺再走登录流程
    if (!this.currentAccount) {
      var def = this.findAccountByName('好易美代拍') || this.accounts[Object.keys(this.accounts)[0]];
      if (!def) return;
      await this.switchTo(def);
    }
    if (!this.currentAccount) return;
    const { name, username, password } = this.currentAccount;
    this.state = 'logging_in';

    console.log(`[agent]「${name}」开始登录流程`);

    // 先检查是否已登录
    const alreadyLoggedIn = await this.checkLoginState();
    if (alreadyLoggedIn) {
      console.log(`[agent]「${name}」已登录，跳过`);
      this.state = 'ready';
      await this.saveState();
      await this.updateTitle();
      return;
    }

    // 导航到闲鱼首页（登录入口）
    await this.page.goto('https://www.goofish.com/', { waitUntil: 'domcontentloaded' });
    await this.page.waitForTimeout(2000);

    // 点击登录入口
    await this.tryClickLogin();
    await this.page.waitForTimeout(2000);

    // 尝试填账号密码
    await this.tryFillCredentials(username, password);

    // 等待手动验证
    console.log(`[agent]「${name}」====== 请完成滑块/短信验证 ======`);
    this.state = 'waiting_verify';

    try {
      await this.page.waitForFunction(() => {
        const text = document.body.innerText || '';
        return text.includes('消息') || text.includes('发布');
      }, { timeout: 300000 }); // 5 分钟
      console.log(`[agent] ✅「${name}」登录成功`);
      this.state = 'ready';
      await this.saveState();
      await this.updateTitle();
    } catch (e) {
      console.log(`[agent]「${name}」登录超时`);
      this.state = 'timeout';
    }
  }

  async tryClickLogin() {
    const selectors = [
      'text=登录',
      'a:has-text("登录")',
      'button:has-text("登录")',
      '[class*="login"]',
      '#login-btn',
      '.login-btn'
    ];
    for (const sel of selectors) {
      try {
        await this.page.click(sel, { timeout: 3000 });
        console.log(`[agent] 点击登录按钮: ${sel}`);
        return true;
      } catch (e) { /* 继续尝试下一个 */ }
    }
    return false;
  }

  async tryFillCredentials(username, password) {
    if (!username || !password) return;
    const phoneSelectors = [
      'input[placeholder*="手机"]',
      'input[type="tel"]',
      'input[name*="phone"]',
      'input[name*="mobile"]',
      'input[placeholder*="账号"]'
    ];
    const pwdSelectors = [
      'input[type="password"]',
      'input[placeholder*="密码"]',
      'input[name*="password"]',
      'input[name*="pwd"]'
    ];

    for (const sel of phoneSelectors) {
      const el = await this.page.$(sel);
      if (el) {
        await el.fill(username.trim());
        console.log(`[agent] 填手机号: ${username.trim()}`);
        break;
      }
    }
    for (const sel of pwdSelectors) {
      const el = await this.page.$(sel);
      if (el) {
        await el.fill(password);
        console.log(`[agent] 填密码: ****`);
        break;
      }
    }
  }

  // ===== 管理面板注入（代替扩展加载） =====

  /** 根据当前网址注入对应的管理脚本 */
  /**
   * 抓取该页面发出的 mtop 请求（API 名 + 参数），写盘供探查未知接口用。
   * 用途：在店铺页面手动操作(如手动下架商品)一次，即可从 _apicap.txt 拿到对应 API 与参数。
   */
  _attachApiCapture(page, tag) {
    const APICAP = path.join(__dirname, '_apicap.txt');
    page.on('request', (req) => {
      try {
        const u = req.url();
        const m = u.match(/mtop\.[a-zA-Z0-9_.]+/);
        if (!m) return;
        let body = '';
        try { body = req.postData() || ''; } catch (e) {}
        try { // 超过 2MB 先清空，避免无限增长
          if (fs.existsSync(APICAP) && fs.statSync(APICAP).size > 2 * 1024 * 1024) fs.writeFileSync(APICAP, '');
        } catch (e) {}
        fs.appendFileSync(APICAP, JSON.stringify({ t: Date.now(), tag: tag, api: m[0], body: body.slice(0, 1500) }) + '\n');
      } catch (e) {}
    });
  }

  async injectMonitor(targetPage) {
    const pg = targetPage || this.page;
    if (!pg) return;
    try {
      const url = pg.url() || '';
      const isDayu = url.includes('dayu.goofish.com');
      const isGoofish = url.includes('www.goofish.com');

      // 用直连版 bridge（不走扩展，直接调 API）
      const scripts = ['bridge_direct.js'];

      if (isDayu) {
        // 监控面板
        scripts.push('monitor.js', 'm_top.js');
      }
      if (isGoofish) {
        // 发布面板
        scripts.push('address_db.js', 'publish.js', 'publish_ui.js');
      }

      for (const name of scripts) {
        const filePath = path.join(EXTENSION_PATH, name);
        if (!fs.existsSync(filePath)) continue;
        const code = fs.readFileSync(filePath, 'utf8');
        await pg.addScriptTag({ content: code });
      }
      // 自动设置店铺列表（避免 localStorage 丢失）
      if (isGoofish) {
        var storeNames = Object.values(this.accounts).map(function(a) { return a.name; });
        var setupCode = '(function(){var stores=' + JSON.stringify(storeNames) + ';localStorage.setItem("kun_stores",JSON.stringify(stores));if(window.kunPublish){window.kunPublish.setStore(stores[0]||"");}})();';
        await pg.addScriptTag({ content: setupCode });
        console.log('[agent] 🏪 店铺已设置: ' + storeNames.join(', '));
      }
    } catch (e) {
      console.log(`[agent] 注入管理面板失败:`, e.message);
    }
  }

  // ===== 工具方法 =====

  async checkLoginState() {
    try {
      return await this.page.evaluate(() => {
        const text = document.body.innerText || '';
        return text.includes('消息') || text.includes('发布') || text.includes('我的');
      });
    } catch (e) {
      return false;
    }
  }

  async updateTitle() {
    if (!this.page || !this.currentAccount) return;
    const name = this.currentAccount.name;
    const icon = this.state === 'ready' ? '✅' : '⚠';
    await this.page.evaluate(([n, i]) => { document.title = `🐟 ${i} ${n} - 闲鱼`; }, [name, icon]);
  }

  async screenshot() {
    if (!this.page) return null;
    return await this.page.screenshot({ type: 'png', fullPage: false });
  }

  getStatus() {
    return {
      currentAccount: this.currentAccount ? this.currentAccount.name : null,
      currentAccountId: this.currentAccount ? this.currentAccount.id : null,
      state: this.state
    };
  }

  async close() {
    if (this._idleTimer) { clearTimeout(this._idleTimer); this._idleTimer = null; }
    await this.saveState();
    await this._closeContext();
    if (this.browser) {
      try { await this.browser.close(); } catch (e) {}
      this.browser = null;
    }
    this.currentAccount = null;
    this.state = 'idle';
  }
}

module.exports = { XianyuAgent };
