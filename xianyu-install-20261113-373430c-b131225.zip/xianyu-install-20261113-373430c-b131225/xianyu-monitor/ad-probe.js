// 擦亮「只读体检」探针 —— 只查询，绝不改动任何计划
// 用法：
//   POST http://127.0.0.1:8093/api/agent/eval-on-store
//   body: { "store": "好易美代拍", "code": <本文件全文（务必原样单行传入）> }
//
// 输出：
//   days  = 最近 N 天账户级真实数据（showPv/clickPv/cost，cost 单位「分」）
//   plans = 当前计划清单（id / 标题 / 状态 / 绑定商品 / 起止时间 / 日预算）
//
// ⚠️ 坑1：campaign.search 的日期参数不生效，它的 todayShowPv 只反映「当前统计日」，
//        23:00–08:00 归零窗口内查必为 0 —— 禁止用它判「死计划」。
// ⚠️ 坑2：本文件必须整段作为 code 传入，且服务端要求单行；若报
//        "SyntaxError: Unexpected identifier 'Object'"，说明传成了多行/带注释。
(async()=>{const m=async(a,b)=>{const r=await window.lib.mtop.request({api:a,v:'1.0',data:{requestJson:JSON.stringify(b)},type:'GET'});const t=r&&r.ret&&r.ret[0];if(!t||t.indexOf('SUCCESS')!==0)throw new Error(t||'fail');return r.data};const find=(o,k)=>{if(!o||typeof o!=='object')return null;if(o[k]!==undefined&&typeof o[k]!=='object')return o[k];for(const i in o){const v=find(o[i],k);if(v!==null)return v}return null};const out={now:new Date().toLocaleString(),days:{},plans:[]};const ds=[];for(let i=0;i<7;i++){const d=new Date(Date.now()-i*86400000);ds.push(d.getFullYear()+String(d.getMonth()+1).padStart(2,'0')+String(d.getDate()).padStart(2,'0'))};for(const d of ds){try{const r=await m('mtop.taobao.idle.ad.member.data.query',{startDate:d,endDate:d,includeEndDate:true});out.days[d]={showPv:find(r,'showPv'),clickPv:find(r,'clickPv'),cost:find(r,'cost')}}catch(e){out.days[d]='ERR '+String(e&&e.message||e)}};try{let all=[],p=1;while(true){const r=await m('mtop.taobao.idle.ad.campaign.search',{pageNum:p,pageSize:50,startDate:ds[0],endDate:ds[0],includeEndDate:true,campaignStatus:[-6,-5,-4,-3,-2,1,2,3,4,6,99],statusGroup:[]});const l=(r&&r.result)||[];if(!l.length)break;l.forEach(c=>all.push(c));if(!r.nextPage)break;p++;if(p>10)break};out.plans=all.map(c=>({id:c.campaignId,title:c.title,st:c.status,item:c.itemId,start:c.startTime,end:c.endTime,price:c.price,dayBudget:c.maxDayBudget,bid:c.bidTarget}))}catch(e){out.errPlans=String(e&&e.message||e)};return out})()
