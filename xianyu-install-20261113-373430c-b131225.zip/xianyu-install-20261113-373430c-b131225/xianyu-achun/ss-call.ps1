﻿# ss-call.ps1 -- 通用 CLI 桥：Node 写 JSON 文件，这里用 --json 调 wecom-cli，结果落盘
#
# WHY: 直接从 Node 调 wecom-cli.cmd 在本环境下静默失败（exit null）；
#      而 PowerShell 内联中文/引号又会被吃掉。所以固定成这条链路：
#        Node 写 UTF-8 JSON  ->  本脚本 -replace 转义引号后用 --json 传  ->  输出写 UTF-8 文件  ->  Node 读
#
# 用法: powershell -File ss-call.ps1 -Cmd "smartsheet records add" -JsonFile <path> -OutFile <path>
param(
  [Parameter(Mandatory=$true)][string]$Cmd,
  [Parameter(Mandatory=$true)][string]$JsonFile,
  [Parameter(Mandatory=$true)][string]$OutFile
)
$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'lib\ps\Config.ps1')
$cli = Get-XyPath 'node.wecomCli'

# 【必须】CLI 输出是 UTF-8，但计划任务上下文里 [Console]::OutputEncoding 默认是 OEM(936)，
# 会把中文按 GBK 解码成乱码（"重要安全提示" -> "閲嶈瀹夊叏鎻愮ず"）。这里强制成 UTF-8。
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
$OutputEncoding = [Text.Encoding]::UTF8

$raw = [System.IO.File]::ReadAllText($JsonFile, [Text.Encoding]::UTF8).Trim()
# 两步缺一不可：
#   1) 内层双引号转义成 \" （否则 native 解析会把 JSON 的引号吃掉）
#   2) 整体再包一层双引号 （否则 JSON 文本里的【空格】会把参数拆成多个，
#      实测报错：unexpected argument '擦亮宝贝20260927113406' found）
# PowerShell 传原生命令【不会】自动加引号，必须自己包。
$esc = '"' + ($raw -replace '"', '\"') + '"'

$parts = $Cmd -split '\s+'
# 【必须】不能用 Out-String：它按【控制台宽度】折行，会在 JSON 字符串中间插进真实换行
#  -> JSON 非法。计划任务里控制台宽度只有 80，所以定时跑必挂(退出码1)、交互跑却正常。
$lines = & $cli @parts --json $esc 2>&1
$out = (($lines | ForEach-Object { if ($_ -is [string]) { $_ } else { $_.ToString() } }) -join "`n")
[System.IO.File]::WriteAllText($OutFile, $out, (New-Object System.Text.UTF8Encoding($false)))
Write-Host ('ss-call: ' + $Cmd + ' -> ' + $OutFile)
