// ad-rerun.js —— 重跑今日擦亮全量快照（实时口径 + 正确指标名）
// 依赖：先停在 计划管理 页
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const n = v => { const x = Number(String(v == null ? 0 : v).replace(/[^\d.\-]/g, '')); return isFinite(x) ? x : 0; };
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const out = { 时刻: new Date().toLocaleString('zh-CN'), 诊断: {} };

  // ---------- A. 表格：先把每页条数调到最大 ----------
  out.诊断.分页选项 = !!document.querySelector('.ant-pagination-options');
  const sel = document.querySelector('.ant-pagination-options .ant-select');
  if (sel) {
    click1(sel); await sleep(1500);
    const opts = [].slice.call(document.querySelectorAll('.ant-select-item-option'))
      .map(e => ({ el: e, t: (e.innerText || '').trim() }))
      .filter(x => /条/.test(x.t));
    out.诊断.可选条数 = opts.map(x => x.t);
    const big = opts.map(x => ({ ...x, num: n(x.t) })).sort((a, b) => b.num - a.num)[0];
    if (big) { click1(big.el); await sleep(4000); out.诊断.已设为 = big.t; }
  }

  const all = {};
  const grab = () => [].slice.call(document.querySelectorAll('tbody tr')).forEach(tr => {
    const c = [].slice.call(tr.querySelectorAll('td')).map(x => (x.innerText || '').replace(/\s+/g, ' ').trim());
    if (c.length < 20) return;
    if (/^\d{7,9}$/.test(c[2])) all[c[2]] = c;
  });
  grab();
  const pager = document.querySelector('.ant-pagination');
  const log = [];
  for (let p = 2; p <= 8; p++) {
    const pg = document.querySelector('.ant-pagination');
    if (!pg) break;
    const btn = [].slice.call(pg.querySelectorAll('.ant-pagination-item'))
      .find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === String(p));
    if (!btn) { log.push('无第' + p + '页'); break; }
    const before = Object.keys(all).length;
    click1(btn); await sleep(4000);
    grab();
    const after = Object.keys(all).length;
    log.push('第' + p + '页 ' + before + '→' + after);
    if (after === before) { // 再试一次（控件重渲染导致失效）
      const pg2 = document.querySelector('.ant-pagination');
      const b2 = pg2 && [].slice.call(pg2.querySelectorAll('.ant-pagination-item'))
        .find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === String(p));
      if (b2) { click1(b2); await sleep(4500); grab(); log.push('  重试后 ' + Object.keys(all).length); }
    }
  }
  out.诊断.翻页 = log;
  out.表格抓到 = Object.keys(all).length;
  out.表格行 = Object.keys(all).map(k => all[k].slice(1, 35));

  // ---------- B. API：实时花费 + 缓存明细 + 宝贝标签 ----------
  const mtop = window.lib.mtop;
  const cr = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
  const plans = (cr.data || {}).result || [];
  const ir = await mtop.request({ api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, tab: 'all', needTabs: true }) } });
  const items = ((ir.data || {}).result || {}).itemList || [];
  const byId = {}; items.forEach(it => byId[String(it.itemId)] = it);
  out.计划数 = plans.length;
  out.计划 = plans.map(c => {
    const t = c.todayAdDataDetail || {};
    const it = c.infoTab || {};
    const ids = (c.entityList || []).map(e => String(e.entityId));
    return {
      id: String(c.campaignId), name: c.title, target: c.bidTarget,
      cpm: n(c.cpm) / 100, budget: n(c.maxDayBudget) / 100,
      实时花费: n(it.todayCost) / 100,               // ← infoTab.todayCost 是实时值
      缓存花费: n(t.cost) / 100,
      缓存时间: t.time, 缓存曝光: n(t.showPv), 缓存询单: n(t.chatPv), 缓存下单: n(t.payPv), 缓存交易额: n(t.payAmount) / 100,
      宝贝数: ids.length, tags: ids.map(i => ((byId[i] || {}).tags || []).join('/') || '-').join('|'),
      成交: ids.reduce((s, i) => s + n((byId[i] || {}).saleCnt), 0),
    };
  });
  return JSON.stringify(out);
})()
