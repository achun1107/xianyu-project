/**
 * ad-retry-order-notify.js — 订单量计划终于建成时，发企业微信告警
 *
 * 由 ad-retry-order.ps1 在检测到 SUCCESS 时调用。
 *
 * ⚠️ 2026-09-27 修正：原来用 Node 的 execFileSync 直接调 wecom-cli.cmd，
 *    实测在本环境下**不回显、静默失败**（exit status null）。
 *    现改为：中文写进 UTF-8 临时文件 → 交给 wecom-send.ps1 发送（那条路已验证可用）。
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const { ROOT } = require('./lib/env');

const D = ROOT + '/';
const SENDER = path.join(D, 'wecom-send.ps1');
const TMP = path.join(D, 'wecom-outbox-retry-order.md');

let pending = [];
try {
  const j = JSON.parse(fs.readFileSync(D + 'plans-pending-order.json', 'utf8'));
  pending = Array.isArray(j) ? j : (j.cfgs || j.plans || []);
} catch (e) { }

const lines = [
  '## ✅ 订单量推广已可开通（平台已恢复）',
  '',
  '**' + new Date().toLocaleString('zh-CN') + '** 探测到「订单量」目标可以切了，以下计划已创建：',
  '',
];
pending.forEach(c => lines.push('- `' + (c.planName || c.name) + '` 提升' + (c.improvePct || '?') + '% 预算¥' + (c.budget || '?')));
lines.push('');
lines.push('⚠️ 请核对：**出价**是否 ≤ ¥35（永久规则）、**预算/时段/宝贝**是否正确。');
lines.push('（自动重试已改为每天一次，成功后不会再重试。）');

fs.writeFileSync(TMP, lines.join('\n'), 'utf8');
console.log('通知内容已写入 ' + TMP);

try {
  execFileSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', SENDER, '-File', TMP],
    { stdio: 'inherit' });
  console.log('[notify] 发送流程结束（详见上方 wecom-send 输出）');
} catch (e) {
  console.log('[notify] 发送失败: ' + (e && e.message) + '  —— 内容已留在 ' + TMP);
}
