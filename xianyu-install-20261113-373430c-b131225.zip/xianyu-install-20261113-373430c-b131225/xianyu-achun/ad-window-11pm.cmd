@echo off
rem ===== Close the ad window - pause ALL campaigns =====
rem Used by BOTH the daily 23:00 task (XianyuAdWindow11PM) and one-off "pause now"
rem tasks, so the log label deliberately carries no clock time.
rem Logic lives in tools\ad-window.js. --off ignores PAUSE-ADS on purpose: stopping is
rem safe, and it makes "boss says stop" take effect immediately.
rem
rem ASCII ONLY ON PURPOSE - see the long note in ad-window-8am.cmd.
rem Do NOT reference DATE or TIME in this file either.
cd /d D:\DSH\achun
set LOG=D:\DSH\achun\ad-window.log
echo. >> "%LOG%"
echo ===== WINDOW OFF begin ===== >> "%LOG%"
call D:\DSH\achun\run-node.cmd "D:\DSH\achun\tools\ensure-agent.js" >> "%LOG%" 2>&1
call D:\DSH\achun\run-node.cmd "D:\DSH\achun\tools\ad-window.js" --off >> "%LOG%" 2>&1
echo ===== WINDOW OFF done (exit %ERRORLEVEL%) ===== >> "%LOG%"
exit /b %ERRORLEVEL%