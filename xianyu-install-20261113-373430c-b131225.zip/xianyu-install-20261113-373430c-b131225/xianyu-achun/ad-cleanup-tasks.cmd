@echo off
rem ===== Delete the one-off 2026-10-07 ad scheduling tasks =====
rem They were a stop-gap for a single day and are superseded by the daily tasks
rem XianyuAdWindow8AM / XianyuAdWindow11PM (both driven by tools\ad-window.js).
rem
rem ASCII ONLY - this file has no "chcp 65001", so cmd.exe decodes it in the OEM
rem codepage (936). A UTF-8 Chinese byte sequence re-decoded as GBK can land on an
rem ASCII metacharacter, the comment gets split, and cmd tries to RUN the fragments.
rem If you want Chinese output here, put "chcp 65001" on line 2 first.
rem
rem schtasks is used instead of PowerShell cmdlets on purpose: no execution-policy
rem dependency, and it deletes tasks that a previous session registered.
cd /d D:\DSH\achun
set LOG=D:\DSH\achun\ad-schedule-1007.log
echo. >> "%LOG%"
schtasks /delete /tn "XianyuAdResume9AM_1007" /f >> "%LOG%" 2>&1
schtasks /delete /tn "XianyuAdPause5PM_1007" /f >> "%LOG%" 2>&1
schtasks /delete /tn "XianyuAdPause1700_1007" /f >> "%LOG%" 2>&1
rem Delete this task last. The running instance still finishes; the task entry goes away.
schtasks /delete /tn "XianyuAdCleanup_1007" /f >> "%LOG%" 2>&1
echo ===== CLEANUP done ===== >> "%LOG%"
exit /b 0