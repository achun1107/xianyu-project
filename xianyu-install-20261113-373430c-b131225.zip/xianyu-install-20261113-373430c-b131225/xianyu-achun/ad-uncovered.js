const fs = require('fs');
const W = 'D:\\DSH\\achun\\';
const load = p => { try { return JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '')); } catch (e) { return null; } };

const cov = load(W + 'ad-coverage.json');
const comb = load(W + 'combined.json');
const onsale = load(W + 'onsale.json');
const cur = load(W + 'items-cur2.json');
const want2 = load(W + 'items-want-v2.json');

const adv = cov.可擦亮商品 || [];
const covered = cov.覆盖明细 || {};
const coveredIds = new Set(Object.keys(covered));

// 近7日商品级流量
const flow = {};
((comb && comb.流量商品) || []).forEach(x => { flow[String(x.itemId)] = x; });

// 想要数
const want = {};
((cur && cur.商品) || []).forEach(x => { if (x.想要 != null) want[String(x.itemId)] = x.想要; });
((want2 && want2.rows) || []).forEach(x => { if (x.want != null && want[String(x.itemId)] == null) want[String(x.itemId)] = x.want; });

// 在售标题（更全）
const titleOf = {};
((cur && cur.商品) || []).forEach(x => { titleOf[String(x.itemId)] = (x.标题 || ''); });
((onsale) || []).forEach(x => { if (!titleOf[x.id]) titleOf[x.id] = x.title; });

const num = v => { const n = Number(String(v == null ? 0 : v).replace(/[^0-9.-]/g, '')); return isFinite(n) ? n : 0; };
const days = t => t ? Math.round((Date.now() - t) / 86400000) : null;

console.log(`可擦亮商品 ${adv.length} 个 | 已被计划覆盖 ${coveredIds.size} 个\n`);

const un = adv.filter(x => !coveredIds.has(x.itemId));
const rows = un.map(x => {
  const f = flow[x.itemId] || {};
  return {
    itemId: x.itemId, 标题: (titleOf[x.itemId] || x.title || '').slice(0, 40),
    tags: x.tags || '', 销量: x.saleCnt, 想要: want[x.itemId] == null ? null : want[x.itemId],
    曝光7日: f.曝光 == null ? null : num(f.曝光), 浏览7日: f.浏览 == null ? null : num(f.浏览),
    成交7日: f.成交 == null ? null : num(f.成交), 支付额7日: f.支付额 == null ? null : num(f.支付额),
    上架天: days(x.publishTime),
  };
}).sort((a, b) => (b.支付额7日 || 0) - (a.支付额7日 || 0) || (b.曝光7日 || 0) - (a.曝光7日 || 0));

console.log('=== 未覆盖的 ' + rows.length + ' 个可擦亮商品（按近7日支付额/曝光排序）===');
console.log('  #  itemId          tags        销量 想要  曝光7日 浏览 成交 支付额  上架天  标题');
rows.forEach((r, i) => {
  console.log('  ' + String(i + 1).padStart(2) + ' ' + [
    r.itemId.padEnd(15),
    (r.tags || '-').padEnd(10),
    String(r.销量 == null ? '-' : r.销量).padStart(4),
    String(r.想要 == null ? '-' : r.想要).padStart(4),
    String(r.曝光7日 == null ? '-' : r.曝光7日).padStart(7),
    String(r.浏览7日 == null ? '-' : r.浏览7日).padStart(4),
    String(r.成交7日 == null ? '-' : r.成交7日).padStart(4),
    String(r.支付额7日 == null ? '-' : r.支付额7日).padStart(7),
    String(r.上架天 == null ? '-' : r.上架天).padStart(6),
    ' ' + r.标题,
  ].join(' '));
});

// 已覆盖的也列出来做对照
console.log('\n=== 已被覆盖的 ' + coveredIds.size + ' 个（对照）===');
adv.filter(x => coveredIds.has(x.itemId)).forEach(x => {
  const f = flow[x.itemId] || {};
  console.log('  ' + x.itemId.padEnd(15) + ' 曝光' + String(f.曝光 == null ? '-' : f.曝光).padStart(7) +
    '  成交' + String(f.成交 == null ? '-' : f.成交).padStart(3) +
    '  ¥' + String(f.支付额 == null ? '-' : f.支付额).padStart(8) +
    '  ← ' + (covered[x.itemId] || []).join('+') + '  | ' + (titleOf[x.itemId] || x.title || '').slice(0, 30));
});

fs.writeFileSync(W + 'ad-uncovered.json', JSON.stringify({ 未覆盖: rows, 已覆盖: adv.filter(x => coveredIds.has(x.itemId)).map(x => ({ itemId: x.itemId, 计划: covered[x.itemId], 标题: titleOf[x.itemId] || x.title })) }, null, 2), 'utf8');
console.log('\n已写 ad-uncovered.json');
