﻿# ============================================================
# ad-balance-watch.ps1 —— 超级擦亮余额监控，跌破阈值时生成告警
#
# 用途：定时检查擦亮账户余额，跌到 ¥200 / ¥100 时写告警文件，
#       由 WorkBuddy 转发到企微。
#
# 读取方式：走 8093 的 eval-on-store，在 seller.goofish.com 页读控制台余额
#
# 为什么不用企微 API 直接发：
#   企微应用 API 报 60020（IP 不在可信 IP 白名单），本机公网 IP 未被授权。
#   所以改为「写告警文件 + WorkBuddy 转发」，走它已有的 wecomaibot 通道。
#
# 阈值与去重：每个阈值只告警一次（记录在 state 文件），余额回升后重置。
# ============================================================
param(
  [int]$Threshold1 = 200,
  [int]$Threshold2 = 100,
  [string]$Store = '好易美代拍'
)

$ErrorActionPreference = 'Continue'

# 统一用「UTF-8 无 BOM」写状态/告警文件（PS 5.1 的 Out-File -Encoding UTF8 会带 BOM）。
. (Join-Path $PSScriptRoot 'lib\ps\Writes.ps1')
. (Join-Path $PSScriptRoot 'lib\ps\Config.ps1')

# param() 默认值在脚本体之前求值，那时 Get-XyPath 还没定义，所以显式传参优先、其余走配置。
if (-not $PSBoundParameters.ContainsKey('Store')) { $Store = Get-XyPath 'store.default' '好易美代拍' }

$work      = Get-XyPath 'paths.work'
$stateFile = Join-Path $work 'ad-balance-state.json'
$alertFile = Join-Path $work 'ad-balance-alert.json'
$node      = Get-XyPath 'node.path'
$evalStore = Join-Path (Get-XyPath 'paths.xianyuMonitor') 'console-tools\eval-store.js'

# 确保 8093 的页面在卖家工作台（余额在那儿）
$navCode = "(function(){if(location.href.indexOf('seller.goofish.com')<0){location.href='https://seller.goofish.com/?site=COMMONPRO#/seller-ad/home';return 'navigating';}return 'ok'})()"
& $node $evalStore $Store -e $navCode 2>&1 | Out-Null
Start-Sleep -Seconds 3

# 读余额（注意：控制台文本里数字可能含空格，如 "562 .21"）
$readCode = @'
(function(){
  var b = document.body ? document.body.innerText : '';
  function grab(k){
    var re = new RegExp(k + '[^0-9]{0,12}([0-9][0-9, ]*\\.?[0-9]*)');
    var m = b.match(re);
    return m ? m[1].replace(/[ ,]/g, '') : null;
  }
  return JSON.stringify({
    url: location.href,
    余额: grab('可用余额'),
    今日花费: grab('今日花费'),
    擦亮中: (b.match(/擦亮中计划\s*(\d+)/) || [])[1] || null
  });
})()
'@

$raw = & $node $evalStore $Store -e $readCode 2>&1 | Out-String
$balance = $null
try {
  $j = $raw.Trim() | ConvertFrom-Json
  $balance = [double]$j.余额
} catch {
  [Console]::Error.WriteLine("ad-balance-watch: 读取余额失败 -> $($raw.Trim().Substring(0,[Math]::Min(160,$raw.Trim().Length)))")
  exit 1
}

if (-not $balance) {
  [Console]::Error.WriteLine('ad-balance-watch: 余额为空（可能页面未加载或未登录）')
  exit 1
}

Write-Output "当前余额 ¥$balance"

# 读上次状态
$state = @{ lastAlerted = @(); lastBalance = $null }
if (Test-Path $stateFile) {
  try { $state = Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch {}
}

# 余额回升到阈值以上 → 重置该阈值的告警标记
foreach ($t in @($Threshold1, $Threshold2)) {
  if ($balance -gt $t) {
    $state.lastAlerted = @($state.lastAlerted | Where-Object { $_ -ne $t })
  }
}

# 判断是否要告警
$toAlert = @()
foreach ($t in @($Threshold2, $Threshold1)) {   # 低于 100 优先
  if ($balance -le $t -and ($state.lastAlerted -notcontains $t)) {
    $toAlert += $t
  }
}

if ($toAlert.Count -gt 0) {
  $lowest = ($toAlert | Measure-Object -Minimum).Minimum
  $alert = [ordered]@{
    时间     = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    店铺     = $Store
    余额     = $balance
    触发阈值 = $lowest
    今日花费 = $j.今日花费
    擦亮中计划 = $j.擦亮中
    消息     = "⚠️ 超级擦亮余额告警：$Store 账户余额仅剩 ¥$balance（阈值 ¥$lowest）。请及时充值，否则计划将停投。"
  }
  Write-Utf8NoBom -Path $alertFile -Text ($alert | ConvertTo-Json -Depth 4)
  $state.lastAlerted = @($state.lastAlerted) + $toAlert
  Write-Output "已生成告警（阈值 ¥$lowest）"
} else {
  Write-Output '未触发告警'
}

$state.lastBalance = $balance
$state.lastCheck = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
Write-Utf8NoBom -Path $stateFile -Text ($state | ConvertTo-Json -Depth 4)
exit 0
