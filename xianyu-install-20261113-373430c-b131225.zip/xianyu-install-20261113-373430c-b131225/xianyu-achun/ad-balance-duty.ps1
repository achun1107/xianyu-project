﻿# ============================================================
# ad-balance-duty.ps1 —— 超级擦亮余额「值班」脚本（每 3 小时跑一次）
#
# 由 Windows 计划任务 XianyuAdBalanceDuty 定时唤起。
#
# 为什么不是 WorkBuddy 自己定时：
#   WorkBuddy(CodeBuddy) 桌面端没有定时器/调度功能（.workbuddy/tasks 只是待办清单），
#   它的 CLI 也处于未登录状态（Authentication required），无法被计划任务唤起。
#   所以「计时」交给 Windows 计划任务，「发送」仍然走 WorkBuddy 那个企微机器人身份
#   （wecom-cli message aibot send）。
#
# 行为：
#   1. 通过 8093 的 eval-on-store 在 seller.goofish.com 读余额 / 今日花费 / 擦亮中计划数
#   2. 组装一条简短播报，用企微机器人发给用户
#   3. 跌破阈值（默认 ¥200 / ¥100）时追加加粗告警
#   4. 静默时段（默认 01:00–07:00）不发，除非跌破阈值
#
# 退出码：0 = 已发送或已按规则跳过；1 = 读取失败（不发送，避免误导）
#
# ⚠️ 2026-09-20 修复的坑（这个坑让 17:00 和 20:00 两次播报静默失败）：
#   计划任务以「无控制台」方式启动 powershell.exe，活动代码页是 936(GBK)，
#   于是 Node 输出的 UTF-8 JSON 被按 GBK 解码，中文键名变成乱码：
#       {"浣欓":"265","浠婃棩鑺辫垂":"440.9"}   ← 值对，键名烂
#   -> ConvertFrom-Json 后 $j.余额 为 null -> 判「读取失败」-> 一条都不发。
#   我手动跑的时候宿主已经是 UTF-8，所以这个 bug 只在计划任务里暴露。
#
#   两道修法（都用上，互相兜底）：
#     a) 读回来的 JSON **键名全部改成 ASCII**，不再让中文跨进程边界；
#     b) 显式把控制台输出编码设成 UTF-8（也对发送中文有帮助）。
# ============================================================
param(
  [int]$Threshold1   = 200,
  [int]$Threshold2   = 100,
  [string]$Store     = '好易美代拍',
  [string]$ChatId    = '',
  [int]$QuietFrom    = 1,
  [int]$QuietTo      = 7,
  [switch]$DryRun
)

$ErrorActionPreference = 'Continue'

# ---- 编码兜底：计划任务里没有控制台，set 可能抛异常，所以包 try ----
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
try { $OutputEncoding = [Text.Encoding]::UTF8 } catch { }

# 统一用「UTF-8 无 BOM」写状态文件（PS 5.1 的 Out-File -Encoding UTF8 会带 BOM，
# 而带 BOM 的 JSON 会让 Node 侧 JSON.parse(fs.readFileSync()) 直接抛错）。
. (Join-Path $PSScriptRoot 'lib\ps\Writes.ps1')
. (Join-Path $PSScriptRoot 'lib\ps\Config.ps1')

# param() 默认值在脚本体之前求值，那时 Get-XyPath 还没定义，所以显式传参优先、其余走配置。
if (-not $PSBoundParameters.ContainsKey('Store'))  { $Store  = Get-XyPath 'store.default' '好易美代拍' }
# 【2026-10-08 改】这里原来兜底到老板的企微群 id 字面量。分发版绝不能带 ——
# 学员机器上没配 wecom.chatId 时，绝不能把通知发进老板的群。现在读不到就跳过发送并记日志。
if (-not $PSBoundParameters.ContainsKey('ChatId')) { $ChatId = Get-XyPath 'wecom.chatId' }
if (-not $ChatId) { Write-Host '[ad-balance-duty] config.local.json 里没有 wecom.chatId —— 本轮只写日志，不发通知。' }

$work      = Get-XyPath 'paths.work'
$stateFile = Join-Path $work 'ad-balance-state.json'
$logFile   = Join-Path $work 'ad-balance-duty.log'
$node      = Get-XyPath 'node.path'
$evalStore = Join-Path (Get-XyPath 'paths.xianyuMonitor') 'console-tools\eval-store.js'
$wecom     = Get-XyPath 'node.wecomCli'

function Write-Log([string]$msg) {
  $line = "{0}  {1}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $msg
  Add-Content -Path $logFile -Value $line -Encoding UTF8
}

# ---- 放假/停投：PAUSE-ADS 在就什么都不做 ----
# 2026-10-03 补：这个入口之前漏了门 —— 它每 3 小时拉一次浏览器，而 8093 的
#   「空闲 20 分钟回收浏览器进程」只回收【连接】、不杀【进程】，
#   于是累积出 3 个 Chromium 实例（02:00 / 05:00 / 11:00）全都挂着 = 一直弹窗。
#   教训：加统一开关时【必须先枚举全部入口】，见 index/06-运维与故障.md。
if (Test-Path (Join-Path $PSScriptRoot 'PAUSE-ADS')) { Write-Log 'PAUSE-ADS 存在：停投中，本轮不读余额（不导航浏览器）'; exit 0 }

# ---- 用户在用电脑就跳过：本任务要导航那个【可见】的浏览器读卖家后台 → 弹窗 ----
# 你离开后 3 小时内会自然补跑，播报不丢。门槛与 lib/idle.js 同一套。
. (Join-Path $PSScriptRoot 'lib\ps\Idle.ps1')
if (Test-UserBusy) {
  Write-Log ('用户活跃中（空闲 {0} 秒 < 300），跳过本轮（避免导航浏览器弹窗）' -f (Get-IdleSeconds))
  exit 0
}

# ---- 前置：店铺页 context 被回收后接口回「店铺未就绪」，先 ready() 一次 ----
& $node (Join-Path $work 'tools\ensure-agent.js') 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
  Write-Log ('店铺未就绪（ensure-agent 退出码 ' + $LASTEXITCODE + '），跳过本轮')
  exit 1
}

# ---------- 1+2. 确保在卖家工作台，并读余额（失败自动重试） ----------
# ⚠️ 2026-09-23 加固：原来只 Start-Sleep 4 秒且**完全不重试**，只要页面还在加载、
#    或瞬时跳到 /login，就直接判「读取失败」并静默退出 —— 实测 11:14 和 16:10
#    两次失败都是这个原因（16:10 那次 URL 是 seller.goofish.com/#/login?...）。
#    余额在页面上渲染成「386 .97」（数字中间有空格），grab() 已经能处理，
#    所以问题不在正则，在**没有等页面就绪、也没有重试**。
$readCode = @'
(function(){
  var b = document.body ? document.body.innerText : '';
  function grab(k){
    var re = new RegExp(k + '[^0-9]{0,12}([0-9][0-9, ]*\\.?[0-9]*)');
    var m = b.match(re);
    return m ? m[1].replace(/[ ,]/g, '') : null;
  }
  return JSON.stringify({
    url: location.href,
    bodyLen: b.length,
    bal: grab('\u53ef\u7528\u4f59\u989d'),
    spend: grab('\u4eca\u65e5\u82b1\u8d39'),
    liveCnt: (b.match(/\u64e6\u4eae\u4e2d\u8ba1\u5212\s*(\d+)/) || [])[1] || null,
    total: (b.match(/\u5171\s*(\d+)\s*\u6761/) || [])[1] || null
  });
})()
'@

$j = $null
$raw = ''
for ($try = 1; $try -le 4; $try++) {
  # 不在工作台、或正文明显没渲染出来（含被踢到登录页）→ 重新导航
  $navCode = "(function(){var n=(document.body?document.body.innerText:'').length;if(location.href.indexOf('seller.goofish.com')<0||n<200){location.href='https://seller.goofish.com/?site=COMMONPRO#/seller-ad/home';return 'navigating';}return 'ok'})()"
  & $node $evalStore $Store -e $navCode 2>&1 | Out-Null
  Start-Sleep -Seconds 8
  $raw = & $node $evalStore $Store -e $readCode 2>&1 | Out-String
  $j = $null
  try { $j = $raw.Trim() | ConvertFrom-Json } catch { }
  if ($j -and $j.bal) { if ($try -gt 1) { Write-Log "第 $try 次读取成功（前几次页面未就绪）" }; break }
  $bl = if ($j) { $j.bodyLen } else { '?' }
  $ur = if ($j) { $j.url } else { '?' }
  Write-Log "第 $try 次未拿到余额（bodyLen=$bl url=$ur），重试"
  Start-Sleep -Seconds 6
}

if (-not $j -or -not $j.bal) {
  $snip = $raw.Trim(); if ($snip.Length -gt 200) { $snip = $snip.Substring(0, 200) }
  Write-Log "读取失败: $snip"

  # ⚠️ 2026-09-26 新增：读取失败**也必须发企业微信通知**。
  # 起因：09-25 20:00 起闲鱼登录态过期，余额播报连续 6 次、卡住计划监听每 30 分钟全部静默失败，
  # 共约 40 小时无人知晓；期间擦亮花费从 ¥782/天 塌到 ¥39.56，我们完全没接住。
  # 教训：失败时只写日志 = 出事的信号永远到不了人手上。
  # 节流：6 小时内最多发一条失败告警，避免长时间故障时刷屏。
  $now0 = Get-Date
  $lastFail = $null
  try { $lastFail = [datetime](Get-Content $stateFile -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json).lastFailAlert } catch { $lastFail = $null }
  if (-not $lastFail -or ($now0 - [datetime]$lastFail).TotalHours -ge 6) {
    $fb = New-Object System.Text.StringBuilder
    [void]$fb.AppendLine("**⚠️ 擦亮余额播报：读取失败**　$($now0.ToString('MM-dd HH:mm'))")
    [void]$fb.AppendLine("")
    [void]$fb.AppendLine("- 失败原因：``$snip``")
    [void]$fb.AppendLine("- 当前页面：$($j.url)")
    [void]$fb.AppendLine("")
    [void]$fb.AppendLine("> 最常见的原因是**闲鱼登录态过期**（页面跳到 /login）。")
    [void]$fb.AppendLine("> 请在后台浏览器窗口里重新扫码登录 —— 不登录的话余额/计划/商品数据全部读不到，定时任务会一直失败。")
    $failContent = $fb.ToString()
    if ($ChatId) {
      $failOut = & $wecom message aibot send --chat-id $ChatId --msg-type markdown --set "markdown.content=$failContent" 2>&1 | Out-String
      $fok = $failOut -match '"success"\s*:\s*true'
      Write-Log ("失败通知发送" + $(if ($fok) { '成功' } else { '失败' }) + " :: " + ($failOut.Trim() -replace '\s+', ' '))
    } else { Write-Log '未配置 wecom.chatId，跳过失败通知' }
    $st = @{}
    if (Test-Path $stateFile) {
      try { (Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $st[$_.Name] = $_.Value } } catch { }
    }
    $st['lastFailAlert'] = $now0.ToString('yyyy-MM-dd HH:mm:ss')
    $st['lastFailReason'] = $snip
    Write-Utf8NoBom -Path $stateFile -Text ($st | ConvertTo-Json -Depth 4)
  } else {
    Write-Log ("失败告警已节流（上次 $lastFail）")
  }
  Write-Error "ad-balance-duty: 读取余额失败"
  exit 1
}

$balance = [double]$j.bal
$spend = $null; if ($j.spend) { $spend = [double]$j.spend }
$liveCnt = $j.liveCnt

# ---------- 3. 算一下还能跑多久 ----------
$runwayTxt = ''
$now = Get-Date
if ($spend -and $spend -gt 0) {
  $hoursElapsed = $now.Hour + $now.Minute / 60.0
  if ($hoursElapsed -ge 1) {
    $perDay = $spend / $hoursElapsed * 24
    if ($perDay -gt 0) {
      $days = $balance / $perDay
      $runwayTxt = "按今日速度（约 ¥{0:N0}/天）约可跑 {1:N1} 天" -f $perDay, $days
    }
  }
}

# ---------- 4. 判断告警 ----------
$lowest = $null
if ($balance -le $Threshold2) { $lowest = $Threshold2 }
elseif ($balance -le $Threshold1) { $lowest = $Threshold1 }

$inQuiet = ($now.Hour -ge $QuietFrom -and $now.Hour -lt $QuietTo)
if ($inQuiet -and -not $lowest) {
  Write-Log "静默时段跳过（余额 ¥$balance）"
  Write-Output "静默时段跳过（余额 ¥$balance）"
  exit 0
}

# ---------- 5. 组装消息 ----------
$prev = $null
if (Test-Path $stateFile) {
  try { $prev = (Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json).lastBalance } catch { }
}

$sb = New-Object System.Text.StringBuilder
[void]$sb.AppendLine("**💰 超级擦亮余额播报**　$($now.ToString('MM-dd HH:mm'))")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("- 可用余额：**¥$balance**")
if ($spend -ne $null) { [void]$sb.AppendLine("- 今日花费：¥$spend") }
if ($liveCnt) { [void]$sb.AppendLine("- 擦亮中计划：$liveCnt 个") }
if ($runwayTxt) { [void]$sb.AppendLine("- $runwayTxt") }
if ($prev -ne $null) {
  $delta = $balance - [double]$prev
  $sign = if ($delta -ge 0) { '+' } else { '' }
  [void]$sb.AppendLine("- 较上次：$sign{0:N2}" -f $delta)
}
[void]$sb.AppendLine("")
if ($lowest) {
  [void]$sb.AppendLine("> ⚠️ **余额已低于 ¥$lowest，请及时充值**，否则擦亮计划会停投。")
} else {
  [void]$sb.AppendLine("状态正常，无需处理。")
}

$content = $sb.ToString()

# ---------- 6. 发送 ----------
if ($DryRun) {
  Write-Output "=== DRY RUN（未发送）==="
  Write-Output $content
  exit 0
}

# 注意：不能用 --markdown '{"content":"..."}' —— PowerShell 传原生参数会把 JSON 的引号吃掉，
# 报 "不是合法的 JSON: key must be a string"。必须走 --set 深层路径覆盖。
if ($ChatId) {
  $sendOut = & $wecom message aibot send --chat-id $ChatId --msg-type markdown --set "markdown.content=$content" 2>&1 | Out-String
  $ok = $sendOut -match '"success"\s*:\s*true'
  Write-Log ("余额 ¥{0} 发送{1} :: {2}" -f $balance, $(if ($ok) { '成功' } else { '失败' }), ($sendOut.Trim() -replace '\s+', ' '))
} else {
  $ok = $false
  Write-Log ('余额 ¥' + $balance + ' 未发送：config.local.json 里没有 wecom.chatId')
}

if ($ok) {
  Write-Utf8NoBom -Path $stateFile -Text (
    @{ lastBalance = $balance; lastCheck = $now.ToString('yyyy-MM-dd HH:mm:ss'); lastAlerted = $lowest } |
      ConvertTo-Json -Depth 4)
  Write-Output "已发送（余额 ¥$balance）"
  exit 0
} else {
  Write-Error "发送失败: $sendOut"
  exit 1
}
