// ad-live-rows5.js —— 每次点击都重新查询分页控件（避免失效引用）
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const all = {};
  const grab = () => [].slice.call(document.querySelectorAll('tbody tr')).forEach(tr => {
    const c = [].slice.call(tr.querySelectorAll('td')).map(x => (x.innerText || '').replace(/\s+/g, ' ').trim());
    if (c.length < 20) return;
    if (/^\d{7,9}$/.test(c[2])) all[c[2]] = c;
  });
  grab();
  const log = [];
  for (let p = 2; p <= 8; p++) {
    // 每次都重新取分页容器和按钮
    const pager = document.querySelector('.ant-pagination');
    if (!pager) { log.push('无分页'); break; }
    const btn = [].slice.call(pager.querySelectorAll('.ant-pagination-item'))
      .find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === String(p));
    if (!btn) { log.push('无第' + p + '页'); break; }
    if (String(btn.className).indexOf('active') >= 0) { log.push('第' + p + '页已激活'); continue; }
    click1(btn);
    await sleep(4000);
    const before = Object.keys(all).length;
    grab();
    log.push('第' + p + '页: ' + before + '→' + Object.keys(all).length);
  }
  return JSON.stringify({ 时刻: new Date().toLocaleString('zh-CN'), 翻页: log, 抓到: Object.keys(all).length, 行: Object.keys(all).map(k => all[k].slice(1, 35)) });
})()
