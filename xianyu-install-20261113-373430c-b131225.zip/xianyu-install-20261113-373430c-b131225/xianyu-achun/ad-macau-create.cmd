@echo off
rem ===== Create the Macau (Lu Guangzhong) polish plan at 08:05 =====
rem
rem WHY this is a scheduled task instead of "do it now":
rem   2026-10-09 02:40 - tools/run-cfgs.js failed twice with
rem   "form not ready (cannot find clear/add-item/polish-now)". A probe showed the
rem   create-plan route redirects straight back to #/home. The SAME script and the
rem   SAME config worked at 19:08 the previous evening, so the most likely cause is
rem   that the ad backend only allows plan creation inside the delivery window
rem   (08:00-23:00 per the boss). So we create it right after the 08:00 window opens.
rem
rem Runs ONCE (scheduled with /sc once). It flips submit=true, runs the creation,
rem then ALWAYS flips submit back to false - polish plans cannot be deleted via API
rem (server-side DELETE_GUARD), so a duplicate created by a stray re-run is permanent.
rem
rem ASCII ONLY ON PURPOSE - see the long note in ad-window-8am.cmd. cmd.exe decodes
rem this file in OEM 936; Chinese bytes can land on & | < > and get EXECUTED.
cd /d D:\DSH\achun
set LOG=D:\DSH\achun\ad-macau-create.log
set CFGS_JSON=D:\DSH\achun\ad-macau-cfgs.json
set CFGS_LOG=D:\DSH\achun\run-cfgs-log-macau.ndjson

echo. >> "%LOG%"
echo ===== MACAU AD CREATE begin ===== >> "%LOG%"
call D:\DSH\achun\run-node.cmd "D:\DSH\achun\tools\ensure-agent.js" >> "%LOG%" 2>&1

call D:\DSH\achun\run-node.cmd "D:\DSH\achun\tools\ad-cfg-submit.js" "%CFGS_JSON%" true >> "%LOG%" 2>&1
call D:\DSH\achun\run-node.cmd "D:\DSH\achun\run-cfgs.js" 0 1 >> "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
rem Always reset submit, even if the run failed - a re-run must not duplicate.
call D:\DSH\achun\run-node.cmd "D:\DSH\achun\tools\ad-cfg-submit.js" "%CFGS_JSON%" false >> "%LOG%" 2>&1

echo ===== MACAU AD CREATE done (exit %RC%) ===== >> "%LOG%"
exit /b %RC%
