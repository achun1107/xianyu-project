/**
 * sheet-command-runner.js — 读「指令」子表，执行机械命令，回写状态/回复
 *
 * 支持的机械命令（可自动执行）：
 *   日报                           → 立即生成一次日报，回复结果
 *   暂停 <计划名或计划ID>           → 暂停该计划
 *   降出价 <计划名或计划ID> <数值>   → 把该计划的自定义出价改成指定值
 *   帮助                           → 回复命令清单
 *
 * 其它内容一律标为「待人工」并企微提醒 —— 自由文本需要我在会话里理解后处理，
 * 定时脚本办不到（这一条必须说清，不能假装全自动）。
 *
 * 用法: node sheet-command-runner.js [--dry]
 */
const fs = require('fs');
const http = require('http');
const path = require('path');
const { execFileSync } = require('child_process');
const sheet = require('./wecom-sheet.js');
const idle = require('./lib/idle');
const { SVC, ROOT, STORE } = require('./lib/env');

const D = ROOT + '/';
const KEY = SVC.apiKey;
const DRY = process.argv.indexOf('--dry') >= 0;
const LOG = D + 'sheet-command.log';
const STATE = D + 'sheet-command-state.json';

function log(s) { const l = new Date().toLocaleString('zh-CN') + '  ' + s; console.log(l); try { fs.appendFileSync(LOG, l + '\n', 'utf8'); } catch (e) { } }
function post(p, body, t) {
  return new Promise((res, rej) => {
    const pl = JSON.stringify(body);
    const rq = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(pl), 'x-api-key': KEY } },
      r => { let b = ''; r.on('data', c => b += c); r.on('end', () => { try { res(JSON.parse(b)); } catch (e) { rej(new Error(b.slice(0, 200))); } }); });
    rq.on('error', rej); rq.setTimeout(t || 300000, () => rq.destroy(new Error('超时'))); rq.write(pl); rq.end();
  });
}
async function evalStore(code) {
  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage"; "ok"' }, 60000);
  await new Promise(r => setTimeout(r, 16000));
  const r = await post('/api/agent/eval-on-store', { store: STORE, code });
  if (!r.ok) throw new Error(r.error || 'eval 失败');
  return r.result;
}
const txt = v => Array.isArray(v) ? (v[0] && v[0].text) : (v == null ? '' : String(v));

const HELP = '可用命令：日报 / 暂停 <计划名或ID> / 降出价 <计划名或ID> <数值> / 帮助。其它内容会转人工。';

// 拉运行中的计划（含 id/name/bid/target）
async function pullPlans() {
  const code = `(async () => {
    const r = await window.lib.mtop.request({ api:'mtop.taobao.idle.ad.campaign.search', v:'1.0', type:'GET',
      data:{ requestJson: JSON.stringify({ pageNum:1, pageSize:100, campaignStatus:[], statusGroup:[] }) } });
    if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS')===0)) throw { ret: r && r.ret };
    return JSON.stringify(((r.data||{}).result||[]).map(c => ({ id:String(c.campaignId), name:c.title, bid:Number(c.cpm)/100, pause:String(c.pauseStatus||'') })));
  })()`;
  const raw = await evalStore(code);
  return typeof raw === 'string' ? JSON.parse(raw) : raw;
}
function matchPlans(plans, key) {
  const k = String(key).trim();
  let hit = plans.filter(p => p.id === k);
  if (!hit.length) hit = plans.filter(p => p.name === k);
  if (!hit.length) hit = plans.filter(p => p.name.indexOf(k) >= 0);
  return hit;
}

(async () => {
  // 用户在用电脑就跳过：执行表格指令（暂停/降出价）会导航那个【可见的】浏览器 → 弹窗。
  // 你离开后 15 分钟内自然会补跑；--dry 不受限（不碰浏览器）。
  if (idle.skipIfBusy('企微指令轮询', { force: DRY })) { process.exit(0); }

  // 2026-10-03 补：这个入口之前漏了门。停投期间的指令（暂停/降出价）没有对象可操作，
  // 而【执行】指令会导航那个可见的浏览器 → 弹窗。整轮跳过，连表都不读。
  // （教训：加统一开关时必须先枚举全部入口 —— 7 个入口见 index/06-运维与故障.md。）
  if (!DRY && require('fs').existsSync(require('path').join(__dirname, 'PAUSE-ADS'))) {
    log('PAUSE-ADS 存在：停投中，跳过本轮指令轮询（不导航浏览器）');
    process.exit(0);
  }

  log('=== 指令轮询 (dry=' + DRY + ') ===');
  const rows = sheet.listRows('指令');
  log('指令表共 ' + rows.length + ' 行');

  let st = {};
  try { st = JSON.parse(fs.readFileSync(STATE, 'utf8')); } catch (e) { }

  const todo = rows.filter(r => {
    const s = txt((r.values || {})['状态']).trim();
    return (s === '' || s === '待办') && !st[r.record_id];
  });
  if (!todo.length) { log('没有待办指令'); process.exit(0); }
  log('待办 ' + todo.length + ' 条');

  for (const row of todo) {
    const v = row.values || {};
    // 解码：写入侧为了防止 PowerShell 拆参数，会把半角空格换成中点 '·'（见 wecom-sheet.js）。
    // 所以读入侧必须换回来 —— 否则 "降出价 刘宪华北京 2.5" 会变成 "降出价·刘宪华北京·2.5" 匹配不上。
    // （真人在企微里直接打字不含这个转换，但容错要做。）
    const cmd = txt(v['指令']).trim().replace(/[\u00B7\u00A0]/g, ' ');
    const R = { 状态: '', 回复: '' };
    log('── ' + row.record_id + ': ' + cmd);

    try {
      if (/^帮助|^\?|^help$/i.test(cmd)) {
        R.状态 = '已完成'; R.回复 = HELP;

      } else if (/^日报$/.test(cmd)) {
        if (DRY) { R.状态 = '已完成'; R.回复 = '[dry] 会生成日报'; }
        else {
          execFileSync(process.execPath, [path.join(D, 'ad-daily-report.js')], { stdio: 'ignore' });
          R.状态 = '已完成'; R.回复 = '已生成日报并写入「日报」子表';
        }

      } else if (/^暂停\s+/.test(cmd)) {
        const key = cmd.replace(/^暂停\s+/, '').trim();
        const plans = await pullPlans();
        const hit = matchPlans(plans, key);
        if (!hit.length) { R.状态 = '失败'; R.回复 = '没找到计划：' + key; }
        else if (hit.length > 1) { R.状态 = '待人工'; R.回复 = '匹配到多条，请写完整计划名：' + hit.map(x => x.name).join('、'); }
        else if (/^擦亮宝贝/.test(hit[0].name)) { R.状态 = '待人工'; R.回复 = '目标是主/副集合计划，按规矩不自动动，请人工确认'; }
        else if (DRY) { R.状态 = '已完成'; R.回复 = '[dry] 会暂停 ' + hit[0].name; }
        else {
          await evalStore(`(async () => { const r = await window.lib.mtop.request({ api:'mtop.taobao.idle.ad.campaign.pause', v:'1.0', type:'POST', data:{ requestJson: JSON.stringify({ campaignIds:['${hit[0].id}'], pauseStatus:1 }) } }); return JSON.stringify(r&&r.ret); })()`);
          R.状态 = '已完成'; R.回复 = '已暂停 ' + hit[0].name + '（' + hit[0].id + '）';
        }

      } else if (/^(降出价|降价|调价)\s+/.test(cmd)) {
        const rest = cmd.replace(/^(降出价|降价|调价)\s+/, '').trim();
        const m = rest.match(/^(.*?)\s+([\d.]+)$/);
        if (!m) { R.状态 = '失败'; R.回复 = '格式应为：降出价 <计划名或ID> <数值>'; }
        else {
          const key = m[1].trim(), val = Number(m[2]);
          const plans = await pullPlans();
          const hit = matchPlans(plans, key);
          if (!hit.length) { R.状态 = '失败'; R.回复 = '没找到计划：' + key; }
          else if (hit.length > 1) { R.状态 = '待人工'; R.回复 = '匹配到多条：' + hit.map(x => x.name).join('、'); }
          else if (/^擦亮宝贝/.test(hit[0].name)) { R.状态 = '待人工'; R.回复 = '目标是主/副集合计划，按规矩不自动动'; }
          else if (val > 4 && hit[0].name.indexOf('咨询') >= 0) { R.状态 = '失败'; R.回复 = '咨询量出价上限 ¥4（永久规则），' + val + ' 超限'; }
          else if (DRY) { R.状态 = '已完成'; R.回复 = '[dry] 会把 ' + hit[0].name + ' 出价 ' + hit[0].bid + ' → ' + val; }
          else {
            // 复用 set-bid.js（含"目标/预算不漂移"校验）
            const runner = path.join(D, 'sb-cmd-' + hit[0].id + '.js');
            fs.writeFileSync(runner, 'window.__SB = ' + JSON.stringify([{ planName: hit[0].name, planId: hit[0].id, newBid: val }]) + ';\n' +
              fs.readFileSync(path.join(D, 'set-bid.js'), 'utf8'), 'utf8');
            execFileSync(process.execPath, [path.join(D, 'run-on-console.js'), "window.__X=1; 'set'", runner], { stdio: 'ignore' });
            const out = fs.readdirSync(D).filter(f => /^console-out-/.test(f)).sort().pop();
            const j = JSON.parse(fs.readFileSync(path.join(D, out), 'utf8'))[0];
            R.状态 = j.fatal ? '失败' : (j.已保存 ? '已完成' : '待人工');
            R.回复 = j.fatal ? j.fatal : ('出价 ' + j.改前.bid + ' → ' + j.改后出价 + '，预算 ' + j.改后预算);
          }
        }

      } else {
        R.状态 = '待人工';
        R.回复 = '这条需要我在会话里理解后处理（定时脚本办不到）。' + HELP;
      }
    } catch (e) {
      R.状态 = '失败'; R.回复 = String(e && e.message || e).slice(0, 200);
    }

    log('   → ' + R.状态 + '  ' + R.回复);
    if (!DRY) {
      try {
        sheet.updateRow('指令', row.record_id, { 时间: txt(v['时间']) || new Date().toLocaleString('zh-CN'), 状态: R.状态, 回复: R.回复 });
      } catch (e) { log('   ⚠ 回写失败: ' + e.message); }
      st[row.record_id] = R.状态;
    }
  }

  fs.writeFileSync(STATE, JSON.stringify(st, null, 2), 'utf8');
  log('=== 完成 ===');
})().catch(e => { log('❌ ' + (e && e.message || e)); process.exit(1); });
