﻿# ============================================================
# ask-dsh.ps1 —— 把一句话交给 DSH headless 会话，返回最终回复
#
# 给 WorkBuddy（或任何程序）当「问 DSH」的桥：
#   WorkBuddy 收到微信消息 → 调本脚本 → 拿到回复 → 发回微信
#
# 用法：
#   powershell -NoProfile -ExecutionPolicy Bypass -File ask-dsh.ps1 -Prompt "你的问题"
#
# 三个必须知道的实测坑（2026-09-20 验证）：
#   1) DSH_PERMISSION_MODE 必须是 danger-full-access
#      默认 workspace-write 要给工作区改 ACL，会以
#      SetNamedSecurityInfoW failed (Win32 5) 失败 → headless 没有 shell。
#   2) 必须用 cmd /c "..." 2>nul 做重定向
#      dsh 是 .cmd 批处理，PowerShell 的 2>$null 挡不住它的 stderr，
#      会把 reasoning 混进 stdout。
#   3) 长提示词走文件（本脚本内部就是这么做的），避开引号转义。
#
# 输出：DSH 的最终回复写到 stdout；reasoning 已丢弃。退出码 0 成功 / 1 失败。
# ============================================================
param(
  [string]$Prompt = '',
  [string]$PromptFile = '',
  [int]$TimeoutSec = 600
)

$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot 'lib\ps\Config.ps1')

# --- 关键 1：启用 shell ---
$env:DSH_PERMISSION_MODE = 'danger-full-access'
$env:NO_COLOR = '1'

# --- 取提示词 ---
if ($PromptFile -and (Test-Path $PromptFile)) {
  $Prompt = Get-Content $PromptFile -Raw -Encoding UTF8
}
if (-not $Prompt -or $Prompt.Trim().Length -eq 0) {
  [Console]::Error.WriteLine('ask-dsh: 空提示词')
  exit 1
}

# --- 关键 3：提示词落盘，让 headless 自己读，避免命令行引号问题 ---
# 关键 5：把「数据后端」说明拼在前面。
# 起因：headless 会话虽然有了 shell，但不知道自己该去查闲鱼数据，
# 曾回答"我没有你的消费记录"——桥通了但内容不对。此处注入操作说明。
$backendDoc = Join-Path (Get-XyPath 'paths.work') 'dsh-data-backend-prompt.md'
$work = Join-Path $env:TEMP ('ask-dsh-' + [guid]::NewGuid().ToString('N').Substring(0,8))
New-Item -ItemType Directory -Path $work -Force | Out-Null
$promptPath = Join-Path $work 'prompt.txt'

$full = ''
if (Test-Path $backendDoc) {
  $full += (Get-Content $backendDoc -Raw -Encoding UTF8)
  $full += "`n`n# ===== 下面是用户的实际问题 =====`n`n"
} else {
  [Console]::Error.WriteLine("ask-dsh: 警告 未找到后端说明 $backendDoc")
}
$full += $Prompt
[IO.File]::WriteAllText($promptPath, $full, (New-Object Text.UTF8Encoding($false)))

$stamp = Get-Date -Format 'HH:mm:ss'
[Console]::Error.WriteLine("ask-dsh: $stamp 调用 headless ...")

# headless 的指令本身保持极短且无中文引号
$instruction = "读取文件 $promptPath ，把文件内容当作要问你的问题并回答。把最终答复作为最终回复输出，不要复述文件路径，不要解释。"

# --- 关键 4：自己定位 dsh，不依赖调用方 PATH ---
# 实测：dsh.cmd 不把自己所在目录加入 PATH，且路径带 gen 哈希会随更新变化。
# 调用方（WorkBuddy 等）PATH 里通常没有它，直接写 `dsh` 会以退出码 1 失败。
$dshCandidates = @()
$cmdInfo = Get-Command dsh -ErrorAction SilentlyContinue
if ($cmdInfo) { $dshCandidates += $cmdInfo.Source }
$hc = Join-Path $env:APPDATA 'DSH Desktop\host-commands\desktop'
if (Test-Path $hc) {
  $gens = Get-ChildItem "$hc\generations" -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending
  foreach ($g in $gens) { $dshCandidates += (Join-Path $g.FullName 'bin\dsh.cmd') }
  $dshCandidates += (Join-Path $hc 'bin\dsh.cmd')
}
$dsh = $dshCandidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $dsh) {
  [Console]::Error.WriteLine('ask-dsh: 找不到 dsh（候选：' + ($dshCandidates -join '; ') + '）')
  Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue
  exit 1
}
[Console]::Error.WriteLine("ask-dsh: 使用 dsh = $dsh")

# --- 关键 2：cmd /c + 2>nul 才能干净分离 stdout ---
$out = $null
try {
  $out = cmd /c "`"$dsh`" --profile headless `"$instruction`" 2>nul"
} catch {
  [Console]::Error.WriteLine("ask-dsh: 执行失败 $($_.Exception.Message)")
  Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue
  exit 1
}

Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue

$reply = ($out | Out-String).Trim()
if (-not $reply) {
  [Console]::Error.WriteLine('ask-dsh: headless 未返回内容')
  exit 1
}

Write-Output $reply
exit 0
