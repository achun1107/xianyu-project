// ad-add-baby.js —— 给已存在的擦亮计划「添加宝贝」，并且保护日预算不被保存时冲掉
//
// 两个必须处理的坑：
//  1. 编辑抽屉保存会提交**所有**字段，预算会回落到默认档。
//     实测：改宝贝后 96201189 的预算从 ¥150 被写成 ¥50。所以保存前必须显式重设预算并回读校验。
//  2. 宝贝选择层的「添加」按钮是按行的，且默认落在「平台推荐」tab；得先切「全部」再搜标题。
(async () => {
  const cfg = window.__ABCFG || {};
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const R = { steps: [] };
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  function setNative(el, val) {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    d.set.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const drawers = () => [].slice.call(document.querySelectorAll('.ant-drawer-content')).filter(d => d.getBoundingClientRect().width > 200);
  const outer = () => drawers().find(d => /编辑计划/.test(d.innerText || ''));
  const picker = () => drawers().find(d => d.querySelector && d.querySelector('input[placeholder*="请输入宝贝标题"]'));
  const titles = od => [].slice.call(od.querySelectorAll('[class*=goodsTitle]')).map(e => (e.innerText || '').trim());

  try {
    const rows = [].slice.call(document.querySelectorAll('tbody tr'));
    const row = rows.find(r => (r.innerText || '').indexOf(cfg.planName) >= 0);
    if (!row) throw new Error('找不到计划行 ' + cfg.planName);
    click1([].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑'));
    let od = null;
    for (let i = 0; i < 15; i++) { await sleep(1000); od = outer(); if (od && od.querySelector('[class*=goodsTitle]')) break; }
    if (!od) throw new Error('编辑抽屉没打开');
    R.修改前 = titles(od);

    // ---- 打开宝贝选择层 ----
    click1([].slice.call(od.querySelectorAll('div,span,button,a')).find(e => e.children.length === 0 && (e.innerText || '').trim() === '编辑宝贝'));
    let pk = null;
    for (let i = 0; i < 12; i++) { await sleep(900); pk = picker(); if (pk) break; }
    if (!pk) throw new Error('宝贝选择层没打开');

    // ---- 切「全部」tab ----
    const tabAll = [].slice.call(pk.querySelectorAll('*')).find(e => e.children.length === 0 && (e.innerText || '').trim() === '全部');
    if (tabAll) { click1(tabAll); await sleep(2500); R.切到全部 = true; }

    // ---- 搜索标题 ----
    const si = [].slice.call(pk.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('请输入宝贝标题') >= 0);
    if (si) {
      setNative(si, cfg.searchKey);
      await sleep(400);
      si.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
      si.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
      await sleep(3500);
      R.已搜索 = cfg.searchKey;
    }

    // ---- 找到目标行（按 宝贝ID 精确匹配）----
    let added = false;
    for (let attempt = 0; attempt < 4 && !added; attempt++) {
      pk = picker() || pk;
      const rowEls = [].slice.call(pk.querySelectorAll('*'))
        .filter(e => e.children.length === 0 && (e.innerText || '').indexOf('宝贝ID:' + cfg.addItemId) >= 0);
      if (rowEls.length) {
        // 从「宝贝ID:xxx」这个叶子往上找到整行
        let item = rowEls[0];
        for (let i = 0; i < 8 && item.parentElement && item !== pk; i++) {
          item = item.parentElement;
          if (item.querySelector && [].slice.call(item.querySelectorAll('div,span,button,a'))
            .some(b => b.children.length === 0 && (b.innerText || '').trim() === '添加')) break;
        }
        const btn = [].slice.call(item.querySelectorAll('div,span,button,a'))
          .find(b => b.children.length === 0 && (b.innerText || '').trim() === '添加');
        R.找到行 = true;
        R.找到添加按钮 = !!btn;
        if (btn) { click1(btn); added = true; await sleep(2500); }
      } else {
        R['未找到_第' + (attempt + 1) + '次'] = true;
        await sleep(2000);
      }
    }
    if (!added) throw new Error('没找到 ' + cfg.addItemId + ' 的「添加」按钮');

    // ---- picker 确定 ----
    const pkOk = [].slice.call(pk.querySelectorAll('div,span,button')).find(e => e.children.length === 0 && /^确\s*定$/.test((e.innerText || '').trim()));
    if (!pkOk) throw new Error('宝贝层找不到确定');
    click1(pkOk);
    await sleep(4500);
    R.picker已关 = drawers().length;

    // ---- 回读宝贝 ----
    od = outer();
    if (!od) throw new Error('确定后编辑抽屉丢了');
    R.修改后 = titles(od);
    R.badge = ((od.innerText || '').match(/已选宝贝\(([^)]*)\)/) || [])[1];
    if (R.修改后.length !== (R.修改前 || []).length + 1) throw new Error('宝贝数没加成功：' + R.修改前.length + ' → ' + R.修改后.length);

    // ---- 保护预算：显式重设并回读 ----
    if (cfg.budget) {
      const grp = od.querySelector('[class*=radioGroup--eEugUXoZ]');
      if (!grp) throw new Error('找不到日花费上限控件');
      const box = [].slice.call(grp.querySelectorAll('[class*=radio--]'));
      R.预算档位 = box.map(e => (e.innerText || '').trim());
      const want = '¥' + cfg.budget;
      const custom = box[box.length - 1];
      const customTxt = (custom.innerText || '').trim();
      const preset = box.slice(0, -1).find(e => (e.innerText || '').trim() === want);

      if (preset) {
        click1(preset); await sleep(1600);
        R.预算走预设 = true;
        R.预算回读 = want;
      } else if (customTxt === want) {
        // ⚠️ 自定义槽已经显示目标值 = 它本来就是选中的、预算已经对。
        // 这时**绝不能去点它**：点一下会把输入清空（实测踩过）。
        R.预算走预设 = false;
        R.预算已是目标值 = true;
        R.预算回读 = customTxt;
      } else {
        click1(custom); await sleep(1800);
        let bi = grp.querySelector('input');
        if (!bi) throw new Error('自定义预算槽没有输入框');
        setNative(bi, cfg.budget); await sleep(700);
        bi.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
        bi.dispatchEvent(new Event('blur', { bubbles: true }));
        await sleep(1800);
        // ⚠️ 必须重新取节点：输入后 React 会重建这个 input，旧引用读出来是空的
        bi = grp.querySelector('input');
        R.预算走预设 = false;
        R.预算回读 = bi ? String(bi.value || '').trim() : '';
      }
      if (R.预算回读 !== want) throw new Error('预算回读=' + R.预算回读 + '，期望 ' + cfg.budget + '，未保存');
    }

    // ---- 保存 ----
    const wrap = od.closest('.ant-drawer');
    const foot = wrap && wrap.querySelector('.ant-drawer-footer');
    const ok = foot && [].slice.call(foot.querySelectorAll('div,span,button'))
      .find(e => e.children.length === 0 && /^确\s*定$/.test((e.innerText || '').trim()));
    if (!ok) throw new Error('找不到外层确定');
    click1(ok);
    R.已保存 = true;
    await sleep(6000);
    R.提示 = ((document.body.innerText || '').match(/[^\n]*(成功|失败|错误|不能|至少|超过)[^\n]*/g) || []).slice(0, 3);
    return JSON.stringify(R, null, 1);
  } catch (e) {
    R.fatal = e.message;
    return JSON.stringify(R, null, 1);
  }
})()
