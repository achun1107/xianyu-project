// ad-check-4new.js —— 检查 凤凰传奇北京 / 李大奔广州 这 4 条是否已进可投放池
(async () => {
  const mtop = window.lib.mtop;
  const want = {
    '1087425616452': '凤凰传奇北京①',
    '1086394229152': '凤凰传奇北京②',
    '1085305986288': '李大奔广州①',
    '1087401860257': '李大奔广州②',
  };
  const r = await mtop.request({
    api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, tab: 'all', needTabs: true }) },
  });
  const list = ((r.data || {}).result || {}).itemList || [];
  const byId = {}; list.forEach(it => byId[String(it.itemId)] = it);
  const out = { ret: (r.ret || [])[0], 可投放总数: list.length, 检查: {} };
  for (const id in want) {
    const it = byId[id];
    out.检查[id] = it
      ? { 说明: want[id], 在池: true, supportAd: it.supportAd, tags: it.tags, price: Number(it.price) / 100, notSupport: it.notSupportAdInfo, 标题: String(it.title).slice(0, 36) }
      : { 说明: want[id], 在池: false, 结论: '❌ 还没进可投放池（审核中）' };
  }
  // 顺便看看池子里有没有别的凤凰传奇/李大奔
  out.池内的凤凰传奇李大奔 = list.filter(it => /凤凰传奇|李大奔/.test(String(it.title))).map(it => String(it.itemId) + ' ' + String(it.title).slice(0, 34));
  return JSON.stringify(out, null, 1);
})()
