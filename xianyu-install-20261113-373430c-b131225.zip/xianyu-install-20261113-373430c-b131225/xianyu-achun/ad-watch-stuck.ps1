﻿# ad-watch-stuck.ps1
# Runs every 30 min via scheduled task XianyuWatchStuck.
# 1) find plans stuck at statusDescCode=16 (partial-item-abnormal) and retry resuming them
# 2) log the result to ad-watch-stuck.log
# 3) if the stuck count drops to 0 (and was >0 before), send one WeCom notification
# 本文件含中文，必须带 UTF-8 BOM（改完跑 node tools/utf8-check.js --fix 补齐）。
# The notification body lives in stuck-recovered-msg.md (UTF-8) and is read explicitly as UTF-8.

$ErrorActionPreference = 'Continue'

# 计划任务里 powershell.exe 的活动码页是 936(GBK)，而 node.exe 输出的是 UTF-8。
# 不设这两行，$raw 抓回来的中文会被按 GBK 解码，写进日志就成了「鎵ц澶辫触」
# （11:30 之前那四行就是）。同 ad-retry-order.ps1 / ad-balance-duty.ps1 的修法。
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
try { $OutputEncoding = [Text.Encoding]::UTF8 } catch { }

# Shared UTF-8 (no BOM) writer. See lib/ps/Writes.ps1.
. (Join-Path $PSScriptRoot 'lib\ps\Writes.ps1')
. (Join-Path $PSScriptRoot 'lib\ps\Config.ps1')
$work = Get-XyPath 'paths.work'
$node = Get-XyPath 'node.path'
$evalStore = Join-Path (Get-XyPath 'paths.xianyuMonitor') 'console-tools\eval-store.js'
$js   = Join-Path $work 'stuck-plan.js'
$log  = Join-Path $work 'ad-watch-stuck.log'
$state= Join-Path $work 'ad-watch-stuck-state.json'
$msg  = Join-Path $work 'stuck-recovered-msg.md'
$wecom = Get-XyPath 'node.wecomCli'
$ChatId = Get-XyPath 'wecom.chatId'
if (-not $ChatId) { Write-Host '[ad-watch-stuck] config.local.json 里没有 wecom.chatId —— 本轮只写日志，不发通知。' }
$Store = Get-XyPath 'store.default' '好易美代拍'

function Write-Log([string]$m) {
  $line = ('{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m)
  Add-Content -Path $log -Value $line -Encoding UTF8
}

# ---- 放假停投：PAUSE-ADS 在就什么都不做 ----
# 本任务会把卡住的计划【恢复在跑】= 把停投又拉起来，放假期间必须挡住。
# 与 PAUSE-PUBLISH 同一套约定：删掉文件即恢复，不用改计划任务。
if (Test-Path (Join-Path $work 'PAUSE-ADS')) { Write-Log 'PAUSE-ADS 存在：停投中，本轮不恢复任何计划'; exit 0 }

# ---- 请求预算闸门（2026-10-13 加）----
# 本任务会把卡住的计划【恢复在跑】= 直接打闲鱼的广告接口。若闸门正处于
# 【疲劳限流退避】中（2026-10-13 就是这么被我手工轮询打限流的），继续发只会把
# 限流压得更死；而且那样会把"被闸门挡住"记成一次任务失败 —— 那是【假失败】，
# 正是「守护报了警却没人看」的老毛病源头。
# 所以先问闸门：被挡就干净跳过（exit 0），原因写进日志。
# 闸门详情：lib/req-gate.js；查看：node tools/req-gate.js --status|--report
$gateOut = & $node (Join-Path $work 'tools\req-gate.js') --status --json 2>&1 | Out-String
if ($LASTEXITCODE -eq 2) {
  Write-Log ('闸门在退避中，本轮跳过（避免把限流压得更死；这不是失败）：' + ($gateOut.Trim() -replace '\s+', ' '))
  exit 0
}

# 用户在用电脑就跳过：本来就要导航那个【可见的】浏览器 → 弹窗。
# 你离开后 30 分钟内会自然补跑，功能不少。门槛与 lib/idle.js 同一套。
. (Join-Path $PSScriptRoot 'lib\ps\Idle.ps1')
if (Test-UserBusy) {
  Write-Log ('用户活跃中（空闲 {0} 秒 < 300），跳过本轮（避免导航浏览器弹窗）' -f (Get-IdleSeconds))
  exit
}

# 前置：店铺页的 context 被回收后，8093 会直接回「执行失败: 店铺「好易美代拍」未就绪」，
# 10:00 / 10:30 / 11:00 / 11:30 四次失败全是这个。先 ready() 一次再导航。
& $node (Join-Path $work 'tools\ensure-agent.js') 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
  Write-Log ('店铺未就绪（ensure-agent 退出码 ' + $LASTEXITCODE + '），跳过本轮')
  exit 1
}

# previous stuck count
$prev = 0
try { $prev = [int](Get-Content $state -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json).stuckCount } catch { $prev = 0 }

# ask the browser (navigate first in case the page moved away)
$nav = "(function(){if(location.href.indexOf('dayu.goofish.com')<0){location.href='https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage';return 'nav';}return 'ok'})()"
& $node $evalStore $Store -e $nav 2>&1 | Out-Null
Start-Sleep -Seconds 6

# ---- Inject the exclude list (added 2026-10-08) ----
# WHY: this task RESUMES plans that are paused AND carry statusDescCode=16, which
#   silently undoes a manual pause the boss asked for. Observed: Quanzhou Xu Liang
#   98104495 was paused, then this task switched it back on.
#   Names come from the SAME AD-EXCLUDE.json that ad-window.js uses -> one source of
#   truth for "plans the boss wants stopped".
#   Build JSON by hand: ConvertTo-Json turns a 1-element array into a scalar.
$excludeIds = @()
$excludeFile = Join-Path $work 'AD-EXCLUDE.json'
if (Test-Path $excludeFile) {
  try {
    $parsed = (Get-Content $excludeFile -Raw -Encoding UTF8 | ConvertFrom-Json).ids
    if ($parsed) { $excludeIds = @($parsed) }
  } catch { $excludeIds = @() }
}
$excludeJson = '[' + (($excludeIds | ForEach-Object { '"' + $_ + '"' }) -join ',') + ']'
& $node $evalStore $Store -e "window.__AD_EXCLUDE=$excludeJson; 'ok'" 2>&1 | Out-Null
Write-Log ("exclude injected: " + $excludeIds.Count + " ids")
$raw = & $node $evalStore $Store -e (Get-Content $js -Raw -Encoding UTF8) 2>&1 | Out-String
$j = $null
try { $j = $raw.Trim() | ConvertFrom-Json } catch { }

if (-not $j) {
  $snip = $raw.Trim(); if ($snip.Length -gt 200) { $snip = $snip.Substring(0, 200) }
  Write-Log "read failed: $snip"
  exit 1
}

Write-Log ("stuck={0} stillStuck={1} total={2} online={3} paused={4} excluded={5} list={6} excludedList={7}" -f $j.stuckCount, $j.stillStuck, $j.total, $j.online, $j.paused, $j.excludedCount, $j.stuck, $j.excluded)

Write-Utf8NoBom -Path $state -Text (
  @{ stuckCount = [int]$j.stuckCount; lastCheck = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') } |
    ConvertTo-Json)

# notify once when everything cleared
if ([int]$j.stuckCount -eq 0 -and $prev -gt 0) {
  $body = ''
  if (Test-Path $msg) { $body = (Get-Content $msg -Raw -Encoding UTF8) }
  if (-not $body) { $body = 'All stuck polish plans recovered.' }
  $content = $body + "`n`n- plans online: $($j.online) / $($j.total)"
  if ($ChatId) {
    $sendOut = & $wecom message aibot send --chat-id $ChatId --msg-type markdown --set "markdown.content=$content" 2>&1 | Out-String
    Write-Log ('notify sent :: ' + ($sendOut.Trim() -replace '\s+', ' ').Substring(0, [Math]::Min(160, ($sendOut.Trim() -replace '\s+', ' ').Length)))
  } else { Write-Log '未配置 wecom.chatId，跳过通知' }
}
exit 0
