// ad-table-dump.js —— 只读：原样 dump「计划管理」表格的表头和前几行单元格文本
//
// 为什么需要它：ad-live-rows.js 假设 计划ID 在第 2 列、每行 td > 10 个（2026-09-22 的表结构）。
//   实测它抓 0 行，而页面明明有 21 个 tbody tr —— 说明列结构变了或行里 td 数不够。
//   与其猜「投放时段」在第几列，不如把表头和各行的单元格原样打出来。
//
// 由 ad-creative-run.js 驱动（CREATIVE_DRIVER=ad-table-dump.js），返回 JSON 字符串。
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // 表格可能还在渲染，等它出内容
  for (let i = 0; i < 10; i++) {
    if (document.querySelectorAll('tbody tr').length) break;
    await sleep(1000);
  }
  const rows = [].slice.call(document.querySelectorAll('tbody tr'));
  const heads = [].slice.call(document.querySelectorAll('thead tr')).map(tr =>
    [].slice.call(tr.querySelectorAll('th,td')).map(x => (x.innerText || '').replace(/\s+/g, ' ').trim()));
  const out = {
    时刻: new Date().toLocaleString('zh-CN'),
    href: location.href,
    tbody行数: rows.length,
    thead列数: heads.map(h => h.length),
    行形状: rows.map((tr, i) => {
      const tds = [].slice.call(tr.querySelectorAll('td'));
      const norm = s => String(s || '').replace(/\s+/g, ' ').trim().slice(0, 26);
      return {
        i,
        td: tds.length,
        c0: norm(tds[0] && tds[0].innerText),
        c1: norm(tds[1] && tds[1].innerText),
        c2: norm(tds[2] && tds[2].innerText),
        c3: norm(tds[3] && tds[3].innerText),
        // 这一行里像「时段」的格子（不管在第几列）
        时段格: tds.map(x => norm(x.innerText)).filter(t => /时段/.test(t)),
      };
    }),
  };
  return JSON.stringify(out, null, 1);
})()
