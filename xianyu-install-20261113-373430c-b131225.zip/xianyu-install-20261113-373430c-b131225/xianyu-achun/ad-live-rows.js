// ad-live-rows.js —— 翻页抓「计划管理」表格的实时列（控制台上你看到的就是这些）
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const readRows = () => [].slice.call(document.querySelectorAll('tbody tr')).map(tr => {
    const td = [].slice.call(tr.querySelectorAll('td'));
    return td.map(x => (x.innerText || '').replace(/\s+/g, ' ').trim());
  }).filter(c => c.length > 10);

  const all = {};
  const grab = () => readRows().forEach(c => {
    // 【2026-10-09 修·列错位】原注释写「计划ID 在第 1 列」，实测错了：
    //   thead 第一行有【第 0 列空的选择列】，所以 计划ID 在 index 2、计划名称 3、投放时段 8。
    //   而且计划行是 36 个 td、展开的宝贝子表行只有 11 个 —— 原来 `c.length > 10` 把子表行也放进来，
    //   再取 c[1] 取不到计划ID，整张表【静默返回 0 行】，看着像「后台没有计划」。
    //   判据改成「td 数 ≥ 20 且第 3 列是纯数字」。
    if (c.length < 20) return;
    const id = c[2];
    if (/^\d{6,}$/.test(id)) all[id] = c;
  });
  grab();
  const pages = [].slice.call(document.querySelectorAll('.ant-pagination-item'))
    .map(e => (e.getAttribute('title') || e.innerText || '').trim()).filter(t => /^\d+$/.test(t));
  for (const p of pages) {
    if (p === '1') continue;
    const it = [].slice.call(document.querySelectorAll('.ant-pagination-item'))
      .find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === p);
    if (!it) continue;
    click1(it);
    await sleep(3000);
    grab();
  }
  const ids = Object.keys(all);
  return JSON.stringify({
    时刻: new Date().toLocaleString('zh-CN'),
    抓到计划数: ids.length,
    列序: ['', '擦亮状态', '计划ID', '计划名称', '宝贝', '今日预算', '出价', '投放日期', '投放时段', '计划类型', '实时擦亮花费', '实时曝光数', '擦亮花费', '曝光数', '点击数', '询单量', '下单笔数', '交易额', '咨询数'],
    行: ids.map(id => all[id].slice(0, 19)),
  });
})()
