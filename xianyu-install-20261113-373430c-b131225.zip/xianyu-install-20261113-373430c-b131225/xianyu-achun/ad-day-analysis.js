// ad-day-analysis.js —— 一次拉全：大盘（今日/昨日）+ 逐计划 + 宝贝级标签
(async () => {
  const mtop = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const out = { url: location.href, 时刻: new Date().toLocaleString('zh-CN') };

  // ---------- 1. 大盘：从首页指标卡解析「指标 / 今日 / 昨日」 ----------
  try {
    const body = (document.body.innerText || '').replace(/[ \t]+/g, ' ');
    const re = /([\u4e00-\u9fa5A-Za-z()（）%]{2,14})\n([\d,]+\.?\d*%?)\n昨日([\d,]+\.?\d*%?)/g;
    const seen = {}, cards = [];
    let m;
    while ((m = re.exec(body))) {
      const k = m[1].trim();
      if (seen[k]) continue;
      seen[k] = 1;
      cards.push({ 指标: k, 今日: m[2], 昨日: m[3] });
    }
    out.大盘 = cards;
  } catch (e) { out.大盘错误 = e.message; }

  // ---------- 2. 逐计划 ----------
  const cr = await mtop.request({
    api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) },
  });
  const plans = (cr.data || {}).result || [];

  // ---------- 3. 宝贝级标签 ----------
  const ir = await mtop.request({
    api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, tab: 'all', needTabs: true }) },
  });
  const items = ((ir.data || {}).result || {}).itemList || [];
  const byId = {};
  items.forEach(it => byId[String(it.itemId)] = it);

  out.概览 = { 总计划: plans.length, 在跑: 0, 已暂停: 0, 可投放宝贝: items.length };
  const rows = plans.map(c => {
    const t = c.todayAdDataDetail || {};
    const ids = (c.entityList || []).map(e => String(e.entityId));
    const sales = ids.map(i => n((byId[i] || {}).saleCnt));
    const tags = ids.map(i => ((byId[i] || {}).tags || []).join('/') || '-');
    if (String(c.pauseStatus) === '1') out.概览.已暂停++; else out.概览.在跑++;
    return {
      id: String(c.campaignId), name: c.title, target: c.bidTarget,
      cpm: n(c.cpm) / 100, budget: n(c.maxDayBudget) / 100, 宝贝数: ids.length,
      tags: tags.join('|'), 成交: sales.reduce((a, b) => a + b, 0),
      花费: n(t.cost) / 100, 曝光: n(t.showPv), 点击: n(t.clickPv), 咨询: n(t.chatPv), 下单: n(t.payPv),
      支付额: n(t.payAmount) / 100, 咨询成本: n(t.chatPv) ? +(n(t.cost) / n(t.chatPv) / 100).toFixed(2) : null,
      paused: String(c.pauseStatus) === '1', start: c.startTime,
    };
  });
  out.计划 = rows;
  return JSON.stringify(out);
})()
