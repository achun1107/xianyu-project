// ad-live-rows4.js —— 用「下一页」按钮翻页，抓全部计划的实时列
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const all = {};
  const grab = () => [].slice.call(document.querySelectorAll('tbody tr')).forEach(tr => {
    const c = [].slice.call(tr.querySelectorAll('td')).map(x => (x.innerText || '').replace(/\s+/g, ' ').trim());
    if (c.length < 20) return;
    const id = c[2];
    if (/^\d{7,9}$/.test(id)) all[id] = c;
  });
  grab();
  const pager = document.querySelector('.ant-pagination');
  const log = [];
  for (let i = 0; i < 10; i++) {
    const next = pager && pager.querySelector('.ant-pagination-next');
    if (!next || String(next.className).indexOf('disabled') >= 0) { log.push('结束@' + i); break; }
    click1(next.querySelector('button') || next);
    await sleep(3500);
    grab();
    log.push('第' + (i + 2) + '页累计' + Object.keys(all).length);
  }
  return JSON.stringify({ 时刻: new Date().toLocaleString('zh-CN'), 翻页: log, 抓到: Object.keys(all).length, 行: Object.keys(all).map(k => all[k].slice(1, 35)) });
})()
