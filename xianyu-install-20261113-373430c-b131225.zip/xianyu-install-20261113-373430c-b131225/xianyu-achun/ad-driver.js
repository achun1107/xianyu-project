// ad-driver.js —— 按 window.__ADCFG 驱动「新建擦亮计划」，带提交前自检
// cfg = { searchKey, items:[], target:'chat'|'order', improvePct:120, expectedBid:'2.80',
//         budget:50, planName:'', startHour:8, endHour:22, submit:false }
(async () => {
  const cfg = window.__ADCFG || {};
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const R = { steps: [], errors: [] };
  const step = s => R.steps.push(s);

  function realClick(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    // 注意：这里绝不能追加 el.click()。展开/收起、时段格子都是 toggle，
    // dispatchEvent 已经在同一个 tick 触发了 React 处理器；再补一次原生 click
    // 会变成「开→关」双击，净效果为零（实测踩过）。
    return true;
  }
  function setNative(el, val) {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    d.set.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const byText = (t, root) => [].slice.call((root || document).querySelectorAll('div,span,button,a'))
    .find(e => e.children.length === 0 && (e.innerText || '').trim() === t);
  const visibleModal = () => {
    for (const m of [].slice.call(document.querySelectorAll('.ant-modal-content'))) {
      const r = m.getBoundingClientRect();
      if (r.width > 50 && r.height > 30) return m;
    }
    return null;
  };
  // 宝贝选择弹层其实是个全屏 drawer，靠搜索框认它
  const picker = () => {
    const inp = [].slice.call(document.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('请输入宝贝标题') >= 0);
    if (!inp) return null;
    let el = inp;
    for (let i = 0; i < 12 && el; i++) {
      if (/ant-drawer-content|ant-modal-content/.test(String(el.className))) return el;
      el = el.parentElement;
    }
    return null;
  };
  const badge = () => ((document.body.innerText || '').match(/选择宝贝\(([^)]*)\)/) || [])[1];
  const imps = () => [].slice.call(document.querySelectorAll('[class*=improveNum]')).map(e => (e.innerText || '').trim());

  try {
    // ---------- -1. 就绪闸门 ----------
    // 必须等表单真的渲染出来。否则后面「清空」找不到会被 `if (clr)` 静默跳过，
    // 于是表单保留默认的 10 个宝贝，最后在自检里才炸（实测踩过：计划②卡在 10/10）。
    let ready = false;
    for (let i = 0; i < 12 && !ready; i++) {
      ready = !!byText('清空') && !!byText('立即擦亮') && !!byText('新增宝贝');
      if (!ready) await sleep(2500);
    }
    R.formReady = ready;
    if (!ready) throw new Error('表单没就绪（找不到 清空/新增宝贝/立即擦亮）');

    // ---------- 0. 清空默认 10 个宝贝 ----------
    const clr = byText('清空');
    if (!clr) throw new Error('找不到「清空」按钮');
    {
      realClick(clr); await sleep(1800);
      const vm = visibleModal();
      if (vm) {
        const ok = [].slice.call(vm.querySelectorAll('button')).find(b => /确\s*定|确认/.test((b.innerText || '').trim()));
        if (ok) realClick(ok);
      }
      await sleep(1800);
      step('清空 → ' + badge());
    }

    // ---------- 1. 新增宝贝（搜索必须带 Enter） ----------
    let modal = null;
    R.addDiagnostics = [];
    for (let i = 0; i < 4 && !modal; i++) {
      const a = byText('新增宝贝');
      realClick(a); await sleep(4000);
      modal = picker();
      R.addDiagnostics.push({
        try: i, foundBtn: !!a, picker: !!modal,
        searchInputs: [].slice.call(document.querySelectorAll('input')).filter(e => /宝贝标题/.test(e.placeholder || '')).length,
      });
    }
    if (!modal) throw new Error('新增宝贝弹层打不开');
    const search = [].slice.call(modal.querySelectorAll('input')).find(e => (e.placeholder || '').indexOf('请输入宝贝标题') >= 0);
    if (!search) throw new Error('找不到宝贝搜索框');

    // 弹层默认停在「平台推荐」tab，它的搜索结果条数可能少于「全部」，
    // 会让部分目标商品根本不出现（实测：3 个商品只列出 2 个）。
    // 先切到「全部」，再搜；仍然缺就重搜几次（新商品可擦亮状态本身会闪）。
    const pickerTab = t => [].slice.call(modal.querySelectorAll('div,span,li'))
      .find(e => e.children.length === 0 && (e.innerText || '').trim() === t);
    let allTab = pickerTab('全部');
    if (allTab) { realClick(allTab); await sleep(1500); R.clickedAllTab = true; }
    step('切到「全部」tab: ' + !!allTab);

    const collectRows = () => {
      const m = {};
      [].slice.call(modal.querySelectorAll('tr,li,div')).forEach(e => {
        const t = (e.innerText || '').replace(/\s+/g, ' ').trim();
        const mm = t.match(/宝贝ID:(\d{10,})/);
        if (mm && t.length < 500 && !m[mm[1]]) m[mm[1]] = e;
      });
      return m;
    };
    let rowsMap = {};
    const searchAttempts = [];
    for (let attempt = 0; attempt < 4; attempt++) {
      setNative(search, cfg.searchKey || '徐良');
      search.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
      search.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
      await sleep(4000);
      rowsMap = collectRows();
      const missing = cfg.items.filter(id => !rowsMap[id]);
      searchAttempts.push({ attempt, n: Object.keys(rowsMap).length, missing });
      if (!missing.length) break;
      R.errors.push('第' + (attempt + 1) + '次搜索仍缺: ' + missing.join(','));
      await sleep(2500);
    }
    R.searchAttempts = searchAttempts;
    R.rowsAvailable = Object.keys(rowsMap);
    for (const id of cfg.items) {
      const row = rowsMap[id];
      if (!row) { R.errors.push('列表里没有 ' + id); continue; }
      let scope = row, hit = false;
      for (let i = 0; i < 6 && scope && !hit; i++) {
        const b = [].slice.call(scope.querySelectorAll('button,a,span')).find(x => (x.innerText || '').trim() === '添加');
        if (b) { realClick(b); hit = true; }
        scope = scope.parentElement;
      }
      if (!hit) R.errors.push('点不到添加 ' + id);
      await sleep(700);
    }
    await sleep(800);
    const okBtn = [].slice.call(modal.querySelectorAll('button')).find(b => /^确\s*定$/.test((b.innerText || '').trim()));
    if (okBtn) realClick(okBtn);
    await sleep(2500);
    step('已选宝贝 ' + badge());
    // 保险：宝贝一个都没选上就立刻停。否则会拿「0 个宝贝的建议价」继续算，
    // 解出一个看似合理其实无意义的出价（实测踩过：searchKey 写错 → 0/10 → 解出 ¥2.31）
    // 【2026-10-04 改】原来是「个数对不上就 throw」，于是订单量计划里只要有 1 个商品
    // 平台侧开不了，整个计划就废掉，还会被判失败、被 ad-retry-order 反复重试。
    // 老板口径：「订单量部分商品开不了，就不开」。
    // 改成：按【实际选上的个数】继续，只有 0 个时才停。少选的那几个记进 R.skippedItems。
    const _selM = String(badge() || '').match(/^(\d+)\s*\/\s*10/);
    const _selN = _selM ? Number(_selM[1]) : 0;
    cfg.selCount = _selN;
    if (_selN === 0) {
      throw new Error('宝贝一个都没选上：期望 ' + cfg.items.length + ' 个（搜索词 "' + (cfg.searchKey || '徐良') + '" 可用：' + (R.rowsAvailable || []).join(',') + '）');
    }
    if (_selN !== cfg.items.length) {
      R.warnings = R.warnings || [];
      R.warnings.push('宝贝没选够：期望 ' + cfg.items.length + ' 个，实际 ' + _selN + ' 个，按实际个数继续');
      R.skippedItems = cfg.items.filter(id => !rowsMap[id]);
      step('少选 ' + (cfg.items.length - _selN) + ' 个，跳过继续');
    }

    // ---------- 2. 更想获得 ----------
    // 2026-09-23 加固：选完宝贝后页面会重渲染「更想获得」，单击可能被撤销
    //（实测：凤凰传奇北京-订单120 连续两次回读都是 chat、出价 ¥2.6）。
    // 改成「点完回读确认，不中就再点」，最多 5 次。
    let targetOk = false;
    for (let i = 0; i < 5 && !targetOk; i++) {
      const radio = document.querySelector('input[type=radio][value="' + cfg.target + '"]');
      if (!radio) throw new Error('找不到目标类型 ' + cfg.target);
      if (radio.checked) { targetOk = true; break; }
      realClick(radio.closest('label') || radio);
      await sleep(2200);
      const now = document.querySelector('input[type=radio][value="' + cfg.target + '"]');
      targetOk = !!(now && now.checked);
      R['目标尝试' + (i + 1)] = targetOk;
    }
    if (!targetOk) throw new Error('目标类型切不到 ' + cfg.target);
    await sleep(800);
    step('目标 ' + cfg.target);

    // ---------- 3. 选中「自定义」出价 radio ----------
    const il = [].slice.call(document.querySelectorAll('[class*=improveNum]'));
    if (il.length < 2) throw new Error('预计提升元素不足 2 个');
    let row = il[1];
    for (let i = 0; i < 10 && row && !row.querySelector('input[type=radio]'); i++) row = row.parentElement;
    if (row) { realClick(row.querySelector('label')); await sleep(1200); }
    R.suggestPrice = (document.querySelector('[class*=price--]') || {}).innerText;

    // ---------- 4. 反解出价：以「控制台显示的预计提升」为唯一权威 ----------
    // 教训：不要用 bid.estimates 接口自己拼 entityList 去算——startTime 等字段跟控制台
    // 实际提交的不一致，算出来的基准会偏（三角洲实测：接口说 120%，控制台显示 170%）。
    // 这里改成把控制台当尺子：改值 → blur → 读回显示值 → 二分。
    const bid = document.querySelector('input[placeholder="自定义出价"]');
    if (!bid) throw new Error('找不到自定义出价输入框');
    const readImp = () => { const a = imps(); return a.length > 1 ? parseInt(a[1], 10) : null; };
    async function probe(v) {
      const s = (Math.round(v * 100) / 100).toFixed(2);
      // 必须每次重新取！React 在估算返回后会重建这个 input，
      // 之前的引用会脱离 DOM，setNative/focusout 全部落空（实测：只有第一次探测真发了请求）
      const el = document.querySelector('input[placeholder="自定义出价"]');
      if (!el) throw new Error('出价输入框消失了');
      const before = readImp();
      el.focus();
      setNative(el, s);
      await sleep(350);
      el.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      // 等读数真的变化再返回。订单目标的估算接口慢一些，
      // 固定等待会读到上一次的旧值，把二分带偏（实测：26.66 读成 120%，重读其实是 105%）
      for (let i = 0; i < 12; i++) {
        await sleep(650);
        const cur = readImp();
        if (cur !== null && cur !== before) { await sleep(800); return readImp(); }
      }
      return readImp();
    }
    const target = cfg.improvePct;
    const suggestYuan = parseFloat(((document.querySelector('[class*=price--]') || {}).innerText || '').replace(/[^0-9.]/g, ''));
    R.suggestYuan = suggestYuan;
    const curve = {};
    let lo = suggestYuan, hi = Math.max(parseFloat(cfg.expectedBid) || suggestYuan * 1.3, suggestYuan * 1.05);
    curve[lo] = await probe(lo);
    let pHi = await probe(hi);
    curve[hi] = pHi;
    let guard = 0;
    while (pHi < target && guard++ < 8) {
      lo = hi; hi = Math.round(hi * 1.5 * 100) / 100;
      pHi = await probe(hi); curve[hi] = pHi;
    }
    if (pHi < target) throw new Error('出价放大到 ¥' + hi + ' 仍达不到 ' + target + '%（当前 ' + pHi + '%）');
    for (let i = 0; i < 14 && hi - lo > 0.011; i++) {
      const mid = Math.round((lo + hi) / 2 * 100) / 100;
      if (mid === lo || mid === hi) break;
      const p = await probe(mid); curve[mid] = p;
      if (p >= target) hi = mid; else lo = mid;
    }
    let finalBid = Math.round(hi * 100) / 100;
    R.finalImprove = await probe(finalBid);
    curve[finalBid] = R.finalImprove;
    // 估算接口的返回值有抖动：同一个出价前后两次探测可能差 1–2 个百分点。
    // 所以二分收敛后必须再校正一次，向上微调直到 >= 目标（不再要求"精确等于"）。
    const stepUp = Math.max(0.1, Math.round(suggestYuan * 0.02 * 100) / 100);
    for (let k = 0; k < 12 && R.finalImprove < target; k++) {
      finalBid = Math.round((finalBid + stepUp) * 100) / 100;
      R.finalImprove = await probe(finalBid);
      curve[finalBid] = R.finalImprove;
    }
    R.finalBid = finalBid;
    R.curve = curve;
    // 出价吸附到一位小数（用户约定 2026-09-21）。若吸附后掉到目标以下，按 0.1 往上补。
    finalBid = Math.round(finalBid * 10) / 10;
    R.finalImprove = await probe(finalBid);
    curve[finalBid] = R.finalImprove;
    for (let k = 0; k < 20 && R.finalImprove < target; k++) {
      finalBid = Math.round((finalBid + 0.1) * 10) / 10;
      R.finalImprove = await probe(finalBid);
      curve[finalBid] = R.finalImprove;
    }
    R.finalBid = finalBid;
    R.curve = curve;
    if (R.finalImprove < target) throw new Error('收敛失败：¥' + finalBid + ' 只到 ' + R.finalImprove + '%（目标 ' + target + '%）');
    R.improveAfter = imps();
    step('反解出价 ¥' + finalBid.toFixed(2) + ' → 预计提升 ' + R.finalImprove + '%');

    // ---------- 4.8 出价上限校验（永久规则 2026-09-27，fail-closed）----------
    // 咨询量 ≤ ¥4 / 订单量 ≤ ¥35。见 出价上限规则-永久.md
    // 硬约束：超限就不提交，宁可这笔不做。
    {
      const BID_CAPS = Object.assign({ chat: 4, order: 35 }, (typeof window !== 'undefined' && window.__BID_CAPS) || {});
      const cap = BID_CAPS[cfg.target];
      R.出价上限 = cap === undefined ? '(该目标未设上限)' : cap;
      if (cap !== undefined && finalBid > cap + 1e-9) {
        throw new Error('出价 ¥' + finalBid.toFixed(2) + ' 超过「' + cfg.target + '」上限 ¥' + cap + '（永久规则），未提交');
      }
      if (cap !== undefined) step('上限校验 ' + cfg.target + '：¥' + finalBid.toFixed(2) + ' ≤ ¥' + cap + ' ✅');
    }

    // ---------- 5. 日花费上限（预设随目标类型变：chat=50/150，order=96/288）----------
    const group = document.querySelector('[class*=radioGroup--eEugUXoZ]');
    if (!group) throw new Error('找不到日花费上限控件');
    const box = [].slice.call(group.querySelectorAll('[class*=radio--]'));
    R.budgetOptions = box.map(e => (e.innerText || '').trim());
    const ex = box.find(e => (e.innerText || '').trim() === '¥' + cfg.budget);
    if (ex) {
      realClick(ex); await sleep(1500);
      step('预算 ¥' + cfg.budget + '（预设）');
    } else {
      const custom = box.find(e => /自定义/.test(e.innerText || ''));
      if (!custom) throw new Error('找不到「自定义」预算，选项：' + R.budgetOptions.join(','));
      realClick(custom); await sleep(1800);
      const inp = group.querySelector('input');
      if (!inp) throw new Error('选了自定义但没出现预算输入框');
      setNative(inp, cfg.budget);
      await sleep(1500);
      R.budgetInputVal = inp.value;
      step('预算 ¥' + cfg.budget + '（自定义）');
    }

    // ---------- 6. 计划名称 ----------
    const nameInp = document.querySelector('input[maxlength="20"]');
    if (!nameInp) throw new Error('找不到计划名称输入框');
    setNative(nameInp, cfg.planName); await sleep(900);
    step('命名 ' + cfg.planName);

    // ---------- 7. 高级设置 → 关创意优化 → 定向设置 → 时段 ----------
    let sbtn = null;
    R.advDiag = [];
    for (let i = 0; i < 5 && !sbtn; i++) {
      const exp = byText('展开');
      if (exp) { realClick(exp); await sleep(2500); }
      sbtn = document.querySelector('[class*=settingsBtn]');
      R.advDiag.push({ try: i, hadExpand: !!exp, hadCollapse: !!byText('收起'), sbtn: !!sbtn });
      if (!sbtn) {
        const h = byText('高级设置');
        if (h) { realClick(h); await sleep(2200); }
        sbtn = document.querySelector('[class*=settingsBtn]');
        R.advDiag[i].sbtnAfterHeader = !!sbtn;
      }
    }

    // ---------- 7.5 关掉「创意优化」 ----------
    // 默认是开的（ant-switch role=switch aria-checked=true）。开着的话系统会
    // 自动生成/轮换创意素材 —— 做主图/标题 A-B 测试时它就变成了额外变量，
    // 测到的不是你自己那张图。所以测试类计划必须关掉。
    if (cfg.creativeOptOff) {
      const findSwitch = () => {
        const lab = [].slice.call(document.querySelectorAll('[class*=label]'))
          .find(e => (e.innerText || '').trim() === '创意优化');
        if (lab) {
          let row = lab;
          for (let i = 0; i < 6 && row; i++) {
            const sw = row.querySelector && row.querySelector('button[role=switch],.ant-switch');
            if (sw) return sw;
            row = row.parentElement;
          }
        }
        return document.querySelector('button[role=switch],.ant-switch');
      };
      let sw = findSwitch();
      R.creativeSwitchFound = !!sw;
      R.creativeBefore = sw ? sw.getAttribute('aria-checked') : null;
      if (sw && sw.getAttribute('aria-checked') === 'true') {
        realClick(sw); await sleep(1800);
      }
      sw = findSwitch();
      R.creativeAfter = sw ? sw.getAttribute('aria-checked') : null;
      step('创意优化 ' + R.creativeBefore + ' → ' + R.creativeAfter);
      if (R.creativeAfter === 'true') throw new Error('创意优化没关掉（仍为 aria-checked=true），中止');
    }

    if (!sbtn) throw new Error('找不到定向设置按钮');
    realClick(sbtn); await sleep(3000);
    const drawer = document.querySelector('.ant-drawer-content');
    if (!drawer) throw new Error('时段抽屉没打开');
    const cbtn = byText('清 空', drawer) || byText('清空', drawer);
    if (cbtn) { realClick(cbtn); await sleep(1500); }
    const cells = [].slice.call(drawer.querySelectorAll('[class*=timePointPartItem]'));
    R.cellCount = cells.length;
    if (cells.length !== 24) throw new Error('时段格子数不是 24：' + cells.length);
    for (let h = cfg.startHour; h <= cfg.endHour; h++) {
      const c = cells[h];
      if (c && !/selected--/.test(String(c.className))) { realClick(c); await sleep(120); }
    }
    await sleep(1000);
    R.timeSelected = (drawer.innerText.match(/已选择投放时间：([^\n]*)/) || [])[1];
    step('时段 ' + R.timeSelected);
    const dok = [].slice.call(drawer.querySelectorAll('button')).find(x => /^确\s*定$/.test((x.innerText || '').trim()));
    if (dok) { realClick(dok); await sleep(2000); }

    // ---------- 8. 回读 + 自检 ----------
    await sleep(1500);
    const body = (document.body.innerText || '').replace(/[ \t]+/g, ' ');
    const activeBudget = [].slice.call(document.querySelectorAll('[class*=radioGroup--eEugUXoZ] [class*=radio--]'))
      .filter(e => /radioActive/.test(String(e.className))).map(e => (e.innerText || '').trim())[0];
    R.readback = {
      选择宝贝: badge(),
      更想获得: (([].slice.call(document.querySelectorAll('input[type=radio]')).filter(e => e.checked && ['exposure', 'click', 'follow_collect', 'chat', 'order'].indexOf(e.value) >= 0)[0]) || {}).value,
      建议价: (document.querySelector('[class*=price--]') || {}).innerText,
      预计提升: imps()[1],
      自定义出价: document.querySelector('input[placeholder="自定义出价"]').value,
      日花费上限生效: activeBudget,
      计划名: document.querySelector('input[maxlength="20"]').value,
      定向设置: (body.match(/定向设置\s*([^\n]{0,24})/) || [])[1],
      预计花费: (body.match(/预计花费：\s*¥\s*([0-9.]+)/) || [])[1],
      余额: (body.match(/账户可用余额:\s*¥\s*([0-9.]+)/) || [])[1],
    };
    const rb = R.readback;
    const checks = {
      // 以实际选上的个数为准（cfg.selCount）：平台开不了的商品已被跳过，见第 146 行附近
      宝贝数对: String(rb.选择宝贝) === cfg.selCount + '/10',
      目标对: rb.更想获得 === cfg.target,
      // 估算接口读数有 ±1~2 个点的噪声（实测同一区间 26.87→119、26.99→121、27.03→120），
      // 所以「精确等于目标」不可能，判据放宽到「达到或超过目标」
      出价已反解: R.finalImprove >= cfg.improvePct,
      提升对: parseInt(rb.预计提升, 10) >= cfg.improvePct,
      预算对: Math.abs(parseFloat(rb.预计花费) - cfg.budget) < 0.01,
      命名对: rb.计划名 === cfg.planName,
      创意优化关: !cfg.creativeOptOff || R.creativeAfter === 'false',
    };
    R.checks = checks;
    const allOk = Object.keys(checks).every(k => checks[k]);
    R.selfCheckPassed = allOk;

    if (!allOk) {
      R.aborted = '自检未通过，未提交';
      return JSON.stringify(R, null, 1);
    }
    if (!cfg.submit) { R.aborted = 'dry run，未提交'; return JSON.stringify(R, null, 1); }

    // ---------- 9. 提交 ----------
    const go = byText('立即擦亮');
    if (!go) throw new Error('找不到「立即擦亮」');
    realClick(go);
    R.submitted = true;
    step('已点「立即擦亮」');
    // 轮询确认：URL 跳到 campaign-manage 或出现成功弹窗才算真成功
    let confirmed = false, lastTxt = '';
    for (let i = 0; i < 12 && !confirmed; i++) {
      await sleep(1500);
      lastTxt = (document.body.innerText || '');
      if (/campaign-manage/.test(location.href) || /擦亮任务已开启|创建成功/.test(lastTxt)) confirmed = true;
    }
    R.submitConfirmed = confirmed;
    R.afterSubmit = {
      url: location.href,
      toast: (lastTxt.match(/[^\n]*(擦亮任务已开启|创建成功|失败|错误|请选择|不能为空|超出)[^\n]*/g) || []).slice(0, 6),
      modals: [].slice.call(document.querySelectorAll('.ant-modal-content,.ant-message-notice,.ant-notification-notice'))
        .map(e => (e.innerText || '').replace(/\s+/g, ' ').slice(0, 200)).filter(t => t && !/确认要清空/.test(t)),
    };
    return JSON.stringify(R, null, 1);
  } catch (e) {
    R.fatal = e.message;
    return JSON.stringify(R, null, 1);
  }
})()
