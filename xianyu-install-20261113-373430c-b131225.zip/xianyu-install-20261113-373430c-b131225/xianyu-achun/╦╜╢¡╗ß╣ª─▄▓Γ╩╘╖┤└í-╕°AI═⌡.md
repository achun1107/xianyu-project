# 好易美后台 · 私董会功能 测试反馈

> **测试方式**：业务方在后台手工测试 + **DSH 用管理员账号登录后读取 API 实测数据**
> **测试日期**：2026-10-04
> **整理**：DSH
> **流程**：小美过目 → 一起发 AI 王
>
> ✅ **本版与上一版的区别**：上一版是「从现象推断」，本版是**读了后台活数据后的定位** ——
> 每条都带**实际字段名和值**，可以直接照着修。

---

## 一、结论先说（按修复优先级）

| 优先级 | 条目 | 定位 | 依据 |
|:---:|---|---|---|
| **P0** | 发布市场报「未关联私董会成员」 | **`club_members.admin_username` 为 null** | 实测该字段为 null，且 `admin_users` 表**无任何**关联字段 |
| **P1** | 「保存权益」500 | **写接口崩**（GET 正常） | `GET club-entitlements` ✅ / 保存 ❌ |
| **P1** | 「挂归属」500 | **写接口崩** | |
| **P1** | **后端缺全局异常处理** | **机制缺失** | 报错只有「未捕获异常」，无可定位信息 |
| **P2** | 加积分 / 创建合作单：弹必填但无输入框 | **纯前端** | 两个接口 **GET 都完全正常** |
| — | 入会登记 / 推荐人链 | ✅ 正常 | 数据齐全，符合设计 |
| **P3** | 分润（`club-profit`） | **返回空数组** | 待确认是否未做 |

---

## 二、P0 · 根因确认：`admin_username` 是 null

### 实测数据

`GET /api/club-members` 返回：

```json
{
  "id": "7c1d3a9c-5b9b-4ab3-bec1-8d91286ada7c",
  "party_id": "d66db6b2-ba04-4d6d-9aea-e1f86a7d2a71",
  "name": "潘春兴",
  "status": "在会",
  "joined_at": "2026-10-04",
  "expires_at": "2027-10-04",
  "entry_fee_paid": 0,
  "referrer_party_id": "985b7048-cbe3-4373-ad3a-6e4f97d19256",
  "invite_code": null,
  "admin_username": null          ← ❌ 就是它
}
```

### 为什么它是唯一的桥

`GET /api/admin-data?table=admin_users` 的**全部字段**：

```
id, username, created_at, role, nickname, avatar_url, business_group,
failed_attempts, locked_until, feishu_open_id, default_push_groups,
decision_score, tags, departments, sso_clients, feishu_union_id,
feishu_tenant_key, feishu_bound_at, last_login_at
```

> **`admin_users` 表里没有任何 `party_id` / `club_member_id` 之类的关联字段。**
>
> 所以「后台登录账号 ↔ 私董会成员」**唯一的关联点就是 `club_members.admin_username`**。
> 它是 null → 登录账号解析不到成员 → 发布市场报「当前账号未关联私董会成员」。

### 修复方向（两个选一）

1. **入会登记时写入 `admin_username`**（登记表单加一个「关联后台账号」字段）
2. **或在权益页加一个「绑定后台账号」入口**（事后补绑）

**建议做 1** —— 事后补绑容易漏，而且第 2 条报错说明前端已经在查这个关联了。

---

## 三、P1 · 两个 500 + 一个机制缺失

### 3.1 保存权益 → 500

```json
GET /api/club-entitlements?party_id=d66db6b2-…  →  ✅ 200
{
  "member_id": "7c1d3a9c-…",
  "template_id": "61f7796a-d052-44f0-a9ac-b64eb4b9dd0c",
  "overrides": {},
  "full_system_access": true,
  "brand_enabled": false,
  "deploy_status": "未部署"
}
```

**读正常、写就 500** → 问题在 `POST club-entitlements` 那条路。

**注意**：测试时「**所有按钮**都报同一个错」→ 说明是整个保存接口挂了，不是某个字段。

### 3.2 挂归属 → 500

读写都涉及 `order` / `club-profit` 那条链。`GET club-profit` 返回**空数组** `[]`。

### 3.3 【机制缺失】后端没有全局异常处理

现在的表现：前端只能拿到「**服务器内部错误（未捕获异常）**」—— **没有任何可定位信息**。

**这是框架默认吐的兜底文案，不是业务错误。**

**建议先做这个，再修上面两个接口：**

1. **全局异常兜底**（统一捕获 → 转成可读错误码）
2. **异常写日志**（堆栈、请求参数、用户、时间）
3. 返回给前端的错误带 **traceId**，便于对账

> 否则下次出问题，前端还是只显示「服务器内部错误」，排查只能靠猜。

---

## 四、P2 · 弹必填但无输入框 —— **纯前端，两条是同一个 bug**

### 实测：两个接口都是好的

```json
GET /api/club-points?party_id=d66db6b2-…   → ✅ 200
{ "account": { "balance": 0, "total_recharged": 0,
               "total_earned": 0, "total_spent": 0, "version": 0 },
  "ledger": [] }

GET /api/club-credit?party_id=d66db6b2-…   → ✅ 200
{ "dispute_count": 0, "cancelled_count": 0, "completed_count": 0,
  "cooperation_count": 0, "fulfillment_score": null }
```

### 所以

| 操作 | 弹窗 | 真相 |
|---|---|---|
| 积分账户 → 加积分 | 「金额不能为空」 | **后端没参与** —— 输入框没渲染 |
| 合作单 → 创建 | 「对方与事由必填」 | 同上 |

**同一个模式**：表单**提交时校验了必填**，但**输入框没渲染出来**。

**常见原因三个**：
- 组件没挂载
- 权限判断把字段隐藏了
- 渲染条件写反了

**建议一起查** —— 大概率同一个表单组件，修一处好两处。

> ⚠️ **上一版报告我猜「可能是 P0 连带」，读了数据后**否定**了 ——
> 这两个接口完全正常，所以**跟成员关联无关，是纯前端问题**。

---

## 五、P3 · 分润未落地

```json
GET /api/club-profit?party_id=d66db6b2-…  →  { "ok": true, "data": [] }
```

**返回空数组。**

**请确认**：是还没做，还是藏在别处？

> ⚠️ 尤其确认 **「逐级下切」**（每个上级只从**自己那份**里分给下级）。
> 它是唯一能保证**平台永不倒贴**的会计规则 ——
> 不做，私董会给下级定多高的分成，平台都可能倒贴。

---

## 六、正常的部分（附实测数据）

### 6.1 入会登记 ✅ 一次建了五行

| 表 | 结果 |
|---|---|
| `club_members` | ✅ 建了 |
| `club_entitlements` | ✅ 建了（`full_system_access: true`） |
| `club_points` | ✅ 建了（account 已开） |
| `club_credit` | ✅ 建了 |
| `club_branding` | ✅ 建了 |
| **入会事件** | ✅ 记了 `event_type:"入会"`, `handler:"<见 playwright-service/service.local.json: hymUser>"`, `reason:"入会登记"` |

**做得好的一点**：`fulfillment_score` 返回 `null` 时，接口带了说明 ——
「**`fulfillment_score` 为 null 表示样本不足（<3 次已完成），不是 0 分**」。
这个细节处理得很对，避免了下游把「没数据」误读成「信用差」。

### 6.2 推荐人链 ✅ 完全符合设计

```json
"referrer": { "id": "985b7048-…",
              "display_name": "好易美（平台）",
              "party_type": "platform" }
```

第一个成员的推荐人指向**平台占位** —— **正确**。

---

## 七、跟字段表的对照 —— 四个缺口

| 我们要求的 | 后台 | 状态 |
|---|---|---|
| 基础身份 | ✅ `club_members` | 做了 |
| 会员关系 | ✅ `club_members` | 做了（含 `expires_at` 一年期） |
| 权益配置 | ✅ `club_entitlements` | 做了 |
| 积分账户 | ✅ `club_points` | 做了 |
| 信用履约 | ✅ `club_credit` | 做了 |
| 白标 | ✅ `club_branding` | 做了 |
| **发布市场** | ⚠️ `club_market` | 表在，**报 P0** |
| **分润** | ⚠️ `club_profit` | **返回空** |
| **推荐人链 / 邀请码** | ⚠️ `referrer_party_id` 有，**`invite_code: null`** | 邀请码没生成 |
| **入会费实收** | ⚠️ `entry_fee_paid: 0` | 字段在，值 0（利润私谈还没录？） |

> **`invite_code` 为 null 值得单独一提** ——
> 推荐链是「引新」的载体，而引新是私董会防绕单的护城河。
> 邀请码没生成，等于**引新只能手工做**。

---

## 八、给 AI 王的修复顺序

```
1【P0】入会登记时写入 club_members.admin_username（或在权益页加绑定入口）
       —— 这条不修，发布市场整块废掉

2【P1】加全局异常兜底 + 异常写日志 + 错误带 traceId
       —— 先做机制，再修接口

3【P1】修 club-entitlements 的写接口（读正常、写 500）
        修「挂归属」对应的写接口

4【P2】修表单字段没渲染（积分 / 合作单两处一起查）—— 纯前端

5【P3】确认 club_profit 是否已做（尤其「逐级下切」规则）

6【补】 invite_code 生成逻辑；entry_fee_paid 录入入口
```

---

## 附：测试覆盖

| 功能 | 测了 | 结果 |
|---|---|---|
| 入会登记 | ✅ | ✅ 正常（五行都建了） |
| 发布市场 | ✅ | ❌ P0 |
| 订单归属与结算 | ✅ | ❌ 写接口 500 |
| 积分账户 | ✅ | ❌ 纯前端 |
| 合作单与信用 | ✅ | ❌ 纯前端 |
| 权益与白标配置 | ✅ | ❌ 写接口 500 |
| 推荐人链 | ✅ | ✅ 正常 |
| 分润 | — | ⚠️ 接口存在但返回空 |
