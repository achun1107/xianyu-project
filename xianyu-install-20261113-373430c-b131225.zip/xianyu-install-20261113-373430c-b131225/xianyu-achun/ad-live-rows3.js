// ad-live-rows3.js —— 只翻「计划」表的分页，抓全部计划的实时列
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  // 只认第一组分页（计划表的）
  const pagers = [].slice.call(document.querySelectorAll('.ant-pagination'));
  const planPager = pagers[0];
  const pages = planPager ? [].slice.call(planPager.querySelectorAll('.ant-pagination-item'))
    .map(e => (e.getAttribute('title') || e.innerText || '').trim()).filter(t => /^\d+$/.test(t)) : [];

  const all = {};
  const grab = () => [].slice.call(document.querySelectorAll('tbody tr')).forEach(tr => {
    const c = [].slice.call(tr.querySelectorAll('td')).map(x => (x.innerText || '').replace(/\s+/g, ' ').trim());
    if (c.length < 20) return;
    const id = c[2];
    if (/^\d{7,9}$/.test(id)) all[id] = c;
  });
  grab();
  for (const p of pages) {
    if (p === '1') continue;
    const it = [].slice.call(planPager.querySelectorAll('.ant-pagination-item'))
      .find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === p);
    if (!it) continue;
    click1(it); await sleep(3200); grab();
  }
  const ids = Object.keys(all);
  return JSON.stringify({
    时刻: new Date().toLocaleString('zh-CN'),
    页码: pages, 抓到: ids.length,
    行: ids.map(id => all[id].slice(1, 35)),   // 去掉勾选列，[0]=擦亮状态
  });
})()
