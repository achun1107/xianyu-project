﻿# ad-retry-order.ps1  (v2, 2026-09-27)
#
# Purpose: the platform has DISABLED the ORDER-quantity (订单量) target for most items.
#          The driver fails closed, so retrying is safe - it will never submit a wrong plan.
#          This job simply waits for the official fix and creates the plans the moment it lands.
#
# v2 changes (why):
#   - Ran every 6h since 09-23 and failed 15/15 times with the SAME error (target radio disabled).
#     That is pure waste, so: once a day instead of every 6 hours.
#   - Log only when the outcome CHANGES (plus a weekly heartbeat), so the log stays readable.
#   - On SUCCESS -> send a WeCom alert (v1 was silent; a silent success is as bad as a silent failure).
#
# ASCII-only on purpose: .ps1 files with Chinese need UTF-8 BOM, which the editor strips.

$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'lib\ps\Config.ps1')
$work = Get-XyPath 'paths.work'
$log  = Join-Path $work 'ad-retry-order.log'
$state = Join-Path $work 'ad-retry-order-state.json'
$node = Get-XyPath 'node.path'

# Force UTF-8 when decoding native-command output (node.exe writes UTF-8).
# Why: PowerShell 5.1 decodes a native program's stdout using [Console]::OutputEncoding,
# which defaults to the OEM code page (936 here) inside Task Scheduler. Chinese then
# becomes mojibake, and Add-Content faithfully writes that mojibake out as UTF-8.
# In an interactive shell the console is already UTF-8, so it only breaks under the
# scheduler -- which is why the log looked fine at first and rotted later.
# Same bug and same fix as ss-call.ps1.
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
$OutputEncoding = [Text.Encoding]::UTF8
# Shared UTF-8 (no BOM) writer. See lib/ps/Writes.ps1.
. (Join-Path $PSScriptRoot 'lib\ps\Writes.ps1')

$env:CFGS_JSON = Join-Path $work 'plans-pending-order.json'
$env:CFGS_LOG  = Join-Path $work 'ad-retry-order.ndjson'

function Write-Log([string]$m) {
  $line = ('{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m)
  Add-Content -Path $log -Value $line -Encoding UTF8
}

function Get-Sig([string]$text) {
  # Coarse signature of the failure reason, used to suppress repeated identical lines.
  if ($text -match 'cannot switch target|切不到') { return 'target-disabled' }
  if ($text -match 'not enough items|没选够')      { return 'items-not-enough' }
  if ($text -match 'no form|表单没就绪')            { return 'form-not-ready' }
  if ($text -match 'Execution context was destroyed|navigation') { return 'page-navigated' }
  if ($text -match 'FATAL')                         { return 'other-fatal' }
  return 'unknown'
}

# Skip outside advertising hours (08:00-23:00).
$h = (Get-Date).Hour
if ($h -lt 8 -or $h -ge 23) { exit 0 }

$pending = Join-Path $work 'plans-pending-order.json'
$count = 0
try { $count = @(Get-Content $pending -Raw -Encoding UTF8 | ConvertFrom-Json).Count } catch { $count = 0 }
if ($count -le 0) { exit 0 }

# ---- 放假停投：PAUSE-ADS 在就不建计划 ----
# 本任务会【自动创建】订单量计划 = 真花钱，所以放假期间必须挡住。
# 与 PAUSE-PUBLISH 同一套约定：删掉文件即恢复，不用改计划任务。
if (Test-Path (Join-Path $work 'PAUSE-ADS')) { Write-Log 'PAUSE-ADS 存在：停投中，本轮不建计划'; exit 0 }

# ---- 用户在用电脑就跳过：本任务要导航那个【可见】的浏览器 → 弹窗 ----
# 你离开后 24 小时内会自然补跑，抢官方修复的时机不丢。门槛与 lib/idle.js 同一套。
. (Join-Path $PSScriptRoot 'lib\ps\Idle.ps1')
if (Test-UserBusy) {
  Write-Log ('用户活跃中（空闲 {0} 秒 < 300），跳过本轮（避免导航浏览器弹窗）' -f (Get-IdleSeconds))
  exit 0
}

# ---- 前置：店铺页 context 被回收后接口回「店铺未就绪」，先 ready() 一次 ----
& $node (Join-Path $work 'tools\ensure-agent.js') 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
  Write-Log ('店铺未就绪（ensure-agent 退出码 ' + $LASTEXITCODE + '），跳过本轮')
  exit 0
}

$out = & $node (Join-Path $work 'run-cfgs.js') 0 $count 2>&1 | Out-String
$flat = ($out -replace '\s+', ' ')

# Success = the driver actually submitted / self-check passed. Keep the original heuristic
# (it has been reliable) but require it to NOT be a FATAL line.
$isSuccess = ($out -match 'submitted|submitConfirmed|"submitted"\s*:\s*true|submit ok') -and ($out -notmatch 'FATAL')

# -- load previous state --
$prevSig = ''; $prevSuccess = $false; $lastLog = ''
if (Test-Path $state) {
  try {
    $s = Get-Content $state -Raw -Encoding UTF8 | ConvertFrom-Json
    $prevSig = [string]$s.sig; $prevSuccess = [bool]$s.success; $lastLog = [string]$s.lastLogDate
  } catch { }
}

if ($isSuccess) {
  if (-not $prevSuccess) {
    Write-Log ('SUCCESS: order plans created now. ' + $flat.Substring(0, [Math]::Min(500, $flat.Length)))
    # Chinese message lives in a UTF-8 file and is sent by Node (PowerShell would mangle it).
    & $node (Join-Path $work 'ad-retry-order-notify.js') 2>&1 | Out-Null
  }
  $now = [pscustomobject]@{ sig = 'success'; success = $true; lastLogDate = (Get-Date -Format 'yyyy-MM-dd') }
  Write-Utf8NoBom -Path $state -Text ($now | ConvertTo-Json -Compress)
  exit 0
}

$sig = Get-Sig $out
$today = (Get-Date -Format 'yyyy-MM-dd')
$newDay = ($lastLog -ne $today)

if ($sig -ne $prevSig -or $prevSuccess -or $newDay) {
  Write-Log ('still not created [' + $sig + ']: ' + $flat.Substring(0, [Math]::Min(240, $flat.Length)))
}
$now = [pscustomobject]@{ sig = $sig; success = $false; lastLogDate = $today }
Write-Utf8NoBom -Path $state -Text ($now | ConvertTo-Json -Compress)
exit 0
