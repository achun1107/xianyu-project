@echo off
rem XianyuPublishSchedule -- every 15 min, publish the slot that is due.
rem ASCII only: .cmd with non-ASCII bytes gets mangled by the console codepage.
cd /d D:\DSH\achun
node tools\publish-schedule.js
