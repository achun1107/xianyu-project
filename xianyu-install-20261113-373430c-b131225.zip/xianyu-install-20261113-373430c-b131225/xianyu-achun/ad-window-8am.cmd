@echo off
rem ===== Daily 08:00 - open the ad window (customer service comes on duty) =====
rem Logic lives in tools\ad-window.js - rule based, no campaignId list to go stale.
rem
rem ASCII ONLY ON PURPOSE. cmd.exe reads a .cmd file in the OEM codepage (936 here),
rem so Chinese bytes get re-decoded and some of them land on command separators.
rem The comment line is then split into fragments that cmd tries to RUN, and the
rem final "exit /b %ERRORLEVEL%" carries that garbage code out.
rem Real incident 2026-10-07: the 23:00 task returned 0xFF this way, never wrote its
rem log line, and the ad window never closed. Keep every Chinese string inside .js.
rem
rem Do NOT reference DATE or TIME in this file either - a localized weekday leaks in.
rem Why ensure-agent first: the store page context gets recycled, and eval-store.js
rem would just answer "store not ready" and burn a whole round.
cd /d D:\DSH\achun
set LOG=D:\DSH\achun\ad-window.log
echo. >> "%LOG%"
echo ===== WINDOW ON begin ===== >> "%LOG%"
rem ===== Lift the NIGHTLY quiet flags (set by night-quiet.cmd at 23:00) =====
rem Boss 2026-10-12: "from 11pm to 8am, stop activity."
rem Lifting happens HERE, directly before --on, on purpose:
rem   a) 08:00 IS the end of the quiet window he named;
rem   b) XianyuAdRelease (07:45) turned out to be a ONE-TIME trigger with an empty
rem      NextRunTime - it has not been running daily at all. Hanging the lift on it
rem      would have stranded PAUSE-ADS and blocked the 08:00 open forever;
rem   c) lift + open inside ONE script can never drift apart.
rem ONLY flags whose first line is NIGHT-QUIET-SET are lifted: a manual holiday
rem PAUSE-ADS / PAUSE-PUBLISH carries no marker and is deliberately left alone.
findstr /b /c:"NIGHT-QUIET-SET" "D:\DSH\achun\PAUSE-ADS" >nul 2>&1 && del /q "D:\DSH\achun\PAUSE-ADS" && echo NIGHT QUIET lifted: PAUSE-ADS >> "%LOG%"
findstr /b /c:"NIGHT-QUIET-SET" "D:\DSH\achun\PAUSE-PUBLISH" >nul 2>&1 && del /q "D:\DSH\achun\PAUSE-PUBLISH" && echo NIGHT QUIET lifted: PAUSE-PUBLISH >> "%LOG%"
call D:\DSH\achun\run-node.cmd "D:\DSH\achun\tools\ensure-agent.js" >> "%LOG%" 2>&1
call D:\DSH\achun\run-node.cmd "D:\DSH\achun\tools\ad-window.js" --on >> "%LOG%" 2>&1
echo ===== WINDOW ON done (exit %ERRORLEVEL%) ===== >> "%LOG%"
exit /b %ERRORLEVEL%