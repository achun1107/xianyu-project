/**
 * ad-creative-run.js —— 驱动 ad-creative-toggle.js 关闭「宝贝创意优化」，并打印完整回读
 *
 * 为什么单独写：ad-editor-run.js 只打印「加宝贝」用到的字段（beforeBadge/added/...），
 *   而 ad-creative-toggle.js 返回的是 当前状态 / 关闭后状态 / 成功 —— 会被吞掉，
 *   只剩一句「编辑前: 宝贝 ?」，等于白跑。这里原样打印完整 JSON。
 *
 * 用法:
 *   CREATIVE_CFGS_JSON=<配置文件> node ad-creative-run.js [from] [to]
 * 配置文件（数组）: [ { "planName": "广州徐良-咨询120-创意关" } ]
 *
 * 判定成功的唯一依据是 R.成功（脚本内部会用「关闭后状态」自证），
 *   而不是「点了开关」——点了不代表生效。
 */
const http = require('http');
const fs = require('fs');
const { SVC, STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const URL = 'https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage';

const CFGS = process.env.CREATIVE_CFGS_JSON
  ? JSON.parse(fs.readFileSync(process.env.CREATIVE_CFGS_JSON, 'utf8'))
  : [];
if (!CFGS.length) { console.log('用法: CREATIVE_CFGS_JSON=<配置文件> node ad-creative-run.js [from] [to]'); process.exit(2); }
const LOG = process.env.CREATIVE_CFGS_LOG || 'D:\\DSH\\achun\\ad-creative-log.ndjson';
const DRIVER_FILE = process.env.CREATIVE_DRIVER || 'ad-creative-toggle.js';
function ev(code, timeoutMs) {
  return new Promise((resolve) => {
    const payload = JSON.stringify({ store: STORE, code });
    const req = http.request({ host: '127.0.0.1', port: SVC.port, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: b.slice(0, 300) }); } }); });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.setTimeout(timeoutMs || 240000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function log(o) { fs.appendFileSync(LOG, JSON.stringify({ ts: new Date().toISOString(), ...o }) + '\n', 'utf8'); }

/**
 * 导航到广告后台，并【轮询等到位】——不要盲睡固定秒数。
 *
 * 【2026-10-09 修·真实事故】原来这里是 `location.href=广告页` + 盲睡 17 秒。
 *   另一会话在跑 tools/preset-export.js 时会反复把店页导航到 /publish?itemId= 读真实字段，
 *   盲睡结束时页面要么还在导航中（evaluate 报 "Execution context was destroyed"），
 *   要么已经不在广告页上（ad-live-rows.js 抓到 0 行计划，看着像「后台没有计划」，
 *   其实只是没到那儿）。改成轮询判断 href + 表格行数，两个症状一起消失。
 *   （ad-editor-run.js 里有一份同样的实现 —— 两边都是 root 级脚本，暂时各留一份。）
 */
const STATE = `JSON.stringify({href:location.href, rows:document.querySelectorAll('tbody tr').length})`;
async function enterAdConsole() {
  for (let i = 0; i < 6; i++) {
    await ev(`(function(){location.href=${JSON.stringify(URL)};return 'nav'})()`, 90000).catch(() => {});
    for (let k = 0; k < 14; k++) {
      await sleep(2500);
      const r = await ev(STATE, 30000);
      if (!r.ok) continue;
      let s; try { s = typeof r.result === 'string' ? JSON.parse(r.result) : r.result; } catch (e) { continue; }
      if (s && String(s.href).indexOf('dayu.goofish.com') >= 0 && s.rows > 0) {
        console.log(`  已到广告后台（${s.rows} 行，第 ${i + 1} 次尝试）`);
        return true;
      }
    }
    console.log(`  第 ${i + 1} 次导航没到位，重来`);
    await sleep(4000);
  }
  return false;
}

(async () => {
  const from = Number(process.argv[2] || 0), to = Number(process.argv[3] || CFGS.length);
  const DRIVER = fs.readFileSync(__dirname + '\\' + DRIVER_FILE, 'utf8');
  // 注入的全局名可换：ad-creative-toggle 用 __CTCFG，ad-rebid 用 __RCFG，ad-editor 用 __ECFG
  const GLOBAL_NAME = process.env.CREATIVE_GLOBAL || 'window.__CTCFG';
  console.log('驱动器: ' + DRIVER_FILE + '   注入到: ' + GLOBAL_NAME);
  for (let i = from; i < to; i++) {
    const c = CFGS[i];
    console.log(`\n───── [${i + 1}/${CFGS.length}] ${c.planName} ─────`);
    if (!(await enterAdConsole())) { console.log('  ❌ 进不去广告后台'); log({ i, name: c.planName, step: 'nav', err: '进不去广告后台' }); continue; }
    let r = await ev(`${GLOBAL_NAME}=${JSON.stringify(c)}; 'set'`);
    if (!r.ok) { console.log('  cfg 失败 ' + r.error); log({ i, name: c.planName, step: 'cfg', err: r.error }); continue; }
    r = await ev(DRIVER, 300000);
    if (!r.ok) { console.log('  driver 失败 ' + r.error); log({ i, name: c.planName, step: 'driver', err: r.error }); continue; }
    let j; try { j = typeof r.result === 'string' ? JSON.parse(r.result) : r.result; } catch (e) {
      console.log('  解析失败: ' + String(r.result).slice(0, 400)); log({ i, name: c.planName, step: 'parse', raw: String(r.result).slice(0, 500) }); continue;
    }
    console.log(JSON.stringify(j, null, 1));
    log({ i, name: c.planName, result: j });
    await sleep(2000);
  }
  console.log('\n本批完成，日志: ' + LOG);
})().catch((e) => { console.error('FAIL ' + (e && e.stack || e)); process.exit(1); });
