(async () => {
  const mtop = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };

  const ir = await mtop.request({
    api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, tab: 'all', needTabs: true }) },
  });
  const items = ((ir.data || {}).result || {}).itemList || [];

  const cr = await mtop.request({
    api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) },
  });
  const plans = (cr.data || {}).result || [];

  // 孙燕姿相关的所有可投放宝贝（含"孙燕姿"字样）
  const sy = items.filter(it => /孙燕姿/.test(String(it.title || '')));
  // 也把所有"广州"但没写孙燕姿的列出来参考
  const gz = items.filter(it => /广州/.test(String(it.title || '')) && !/孙燕姿/.test(String(it.title || '')));

  const bind = {};
  plans.forEach(c => (c.entityList || []).forEach(e => {
    const id = String(e.entityId);
    (bind[id] = bind[id] || []).push({ 计划: c.title, id: String(c.campaignId), paused: String(c.pauseStatus) === '1', 曝光: n((c.todayAdDataDetail || {}).showPv) });
  }));

  const describe = it => {
    const id = String(it.itemId);
    return {
      宝贝: id, 价: n(it.price) / 100, tags: it.tags,
      标题: String(it.title).slice(0, 40),
      supportAd: it.supportAd,
      绑定计划数: (bind[id] || []).length,
      绑定明细: (bind[id] || []).map(b => b.计划 + (b.paused ? '(暂停)' : '') + ' 曝光' + b.曝光),
    };
  };

  return JSON.stringify({
    时刻: new Date().toLocaleString('zh-CN'),
    可投放总数: items.length,
    孙燕姿的宝贝: sy.map(describe),
    其他含广州的宝贝: gz.map(describe),
  }, null, 1);
})()
