@echo off
rem 07:45 -- release plans created BEFORE 08:00 so the 08:00 window opens them.
rem Two sources: ad-pending.js (Macau/Nanjing) and publish-schedule.js (today's slots).
rem
rem 2026-10-12: also lift the NIGHTLY quiet flags set by night-quiet.cmd (23:00).
rem ONLY flags whose first line is NIGHT-QUIET-SET are lifted. A manual holiday
rem PAUSE-ADS / PAUSE-PUBLISH carries no marker and is deliberately left alone.
rem Keep this file ASCII (see the note in ad-window-8am.cmd).
cd /d D:\DSH\achun
findstr /b /c:"NIGHT-QUIET-SET" "D:\DSH\achun\PAUSE-ADS" >nul 2>&1 && del /q "D:\DSH\achun\PAUSE-ADS" && echo NIGHT QUIET: PAUSE-ADS lifted >> "D:\DSH\achun\ad-window.log"
findstr /b /c:"NIGHT-QUIET-SET" "D:\DSH\achun\PAUSE-PUBLISH" >nul 2>&1 && del /q "D:\DSH\achun\PAUSE-PUBLISH" && echo NIGHT QUIET: PAUSE-PUBLISH lifted >> "D:\DSH\achun\ad-window.log"
node ad-pending.js release
node tools\publish-schedule.js --release
