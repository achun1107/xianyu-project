// ad-act1.js —— 第一批动作：停 3 个零产出计划；之后回读全店复核
//  暂停 95285374 单明星-王力宏-订单120   （实时¥63.47 / 单次询单成本¥8.73 / 0单 / 全店最差）
//  暂停 95309260 热销-Capper北京-咨询130  （实时¥20.04 / ¥6.68 / 0单）
//  暂停 95291265 热销-断眉广州-咨询130    （实时¥8.50 / 0询单 / 0单）
//  严禁触碰：所有 擦亮宝贝2026*（主/副集合）
(async () => {
  const mtop = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const PAUSE = ['95285374', '95309260', '95291265'];
  const 主副集合ID = ['94504869', '95091763', '95125845', '95617910', '95625836', '96375823', '94536787', '95637072'];

  const search = async () => {
    const r = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
    return (r.data || {}).result || [];
  };
  const before = await search();
  const snap = l => {
    const m = {};
    l.forEach(c => { m[String(c.campaignId)] = { name: c.title, pause: String(c.pauseStatus), cost: n((c.infoTab || {}).todayCost) / 100, budget: n(c.maxDayBudget) / 100, target: c.bidTarget }; });
    return m;
  };
  const B = snap(before);

  // ---- 暂停 ----
  const pr = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.pause', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ campaignIds: PAUSE, pauseStatus: 1 }) } });
  const out = { 暂停返回: (pr.ret || [])[0], 平台确认: {} };
  Object.keys(pr.data || {}).forEach(k => {
    const v = pr.data[k] || {};
    out.平台确认[k] = { pauseStatus: v.pauseStatus, statusGroup: v.statusGroup, desc: v.statusDescTitle };
  });

  await sleep(6000);
  const after = await search();
  const A = snap(after);
  out.暂停结果 = PAUSE.map(id => ({ id, 名称: B[id] && B[id].name, 之前: B[id] && B[id].pause, 现在: A[id] && A[id].pause, 实时花费: A[id] && A[id].cost }));
  out.主副集合是否被动过 = 主副集合ID.map(id => {
    const b = B[id], a = A[id];
    if (!a) return { id, 状态: '不在了' };
    return { id, 名称: a.name, 花费变化: (b ? b.cost : 0) + '→' + a.cost, 预算变化: (b ? b.budget : 0) + '→' + a.budget, 暂停态: a.pause, 结论: (b && b.budget === a.budget) ? '未动' : '⚠预算变了' };
  });
  out.全店 = { 计划数: after.length, 在跑: after.filter(c => String(c.pauseStatus) !== '1').length, 已暂停: after.filter(c => String(c.pauseStatus) === '1').length };
  out.当前暂停名单 = after.filter(c => String(c.pauseStatus) === '1').map(c => c.campaignId + ' ' + c.title);
  return JSON.stringify(out, null, 1);
})()
