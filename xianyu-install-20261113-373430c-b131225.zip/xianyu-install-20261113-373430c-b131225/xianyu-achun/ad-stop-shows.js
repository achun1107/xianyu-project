// ad-stop-shows.js —— 按「宝贝」停推广：找出所有引用这些宝贝的计划并暂停
// 本次：广州汪苏泷（1083663598167）+ 常州GAPDAY音乐节（1084747794290 / 1085811221844 / 1085811305293）
(async () => {
  const mtop = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const ITEMS = {
    '1083361507977': '断眉广州',
    '1082911447531': 'Capper北京',
    '1083663598167': '汪苏泷广州(上轮已停，复核)',
  };
  const search = async () => {
    const r = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
    return (r.data || {}).result || [];
  };
  const before = await search();
  const hits = before.filter(c => (c.entityList || []).some(e => ITEMS[String(e.entityId)]));

  const out = {
    时刻: new Date().toLocaleString('zh-CN'),
    涉及的宝贝: ITEMS,
    命中计划: hits.map(c => ({
      id: c.campaignId, name: c.title, 目标: c.bidTarget, 预算: n(c.maxDayBudget) / 100, 暂停态: c.pauseStatus,
      实时花费: n((c.infoTab || {}).todayCost) / 100,
      命中: (c.entityList || []).map(e => ITEMS[String(e.entityId)]).filter(Boolean),
      是主副集合: /^擦亮宝贝/.test(c.title),
    })),
  };
  out['⚠ 被主副集合带着推'] = hits.filter(c => /^擦亮宝贝/.test(c.title)).map(c => c.campaignId + ' ' + c.title);

  const ids = hits.filter(c => String(c.pauseStatus) !== '1').map(c => String(c.campaignId));
  out.将要暂停 = ids;
  if (!ids.length) { out.结果 = '本来就都停着'; return JSON.stringify(out, null, 1); }

  const pr = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.pause', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ campaignIds: ids, pauseStatus: 1 }) } });
  out.平台返回 = (pr.ret || [])[0];
  out.平台确认 = {};
  Object.keys(pr.data || {}).forEach(k => {
    const v = pr.data[k] || {};
    out.平台确认[k] = { pauseStatus: v.pauseStatus, group: v.statusGroup, desc: v.statusDescTitle };
  });

  await sleep(6000);
  const after = await search();
  out.停后复核 = after.filter(c => ids.indexOf(String(c.campaignId)) >= 0)
    .map(c => ({ id: c.campaignId, name: c.title, pause: c.pauseStatus, group: c.statusGroup }));
  out.全店 = {
    计划数: after.length,
    在跑: after.filter(c => c.statusGroup === 'online').length,
    暂停: after.filter(c => String(c.pauseStatus) === '1').length,
    主副集合在跑: after.filter(c => /^擦亮宝贝/.test(c.title) && c.statusGroup === 'online').length,
  };
  out.暂停名单 = after.filter(c => String(c.pauseStatus) === '1').map(c => c.campaignId + ' ' + c.title);
  out.结果 = out.停后复核.every(x => x.pause === '1') ? '✅ 已全部停止' : '⚠ 仍有未停';
  return JSON.stringify(out, null, 1);
})()
