# WorkBuddy 任务书 · 把本地 `post()` 改成委托 `lib/http`（试点 3 个文件）

> 派活人：本地 DSH（运营会话） ｜ 日期：2026-10-13
> 派活依据：约 40 行净改动（3 文件 × 约 13 行）—— 按 `workbuddy-delegation` 技能的 C 规则**先试点**。

---

## 1. 背景

仓库有公共层 `lib/http.js`（访问本机 8093 Playwright 服务的**唯一底层**），
但**大量脚本各自手抄了一份一模一样的 `post()` 样板**。

手抄的代价是真实的：`lib/http.js` 里有一个**别处抄不到的修复** ——
`agent: false`（Node 19+ 的 http 全局 agent 默认 keepAlive=true，会复用已死的 socket，
表现为「PowerShell 能访问、Node 却报 ECONNRESET」）。抄出去的那些没有这一条。

**本任务只做一件事：把指定文件里那份手抄的 `post()` 换成委托给 `lib/http`。**
**试点只有 3 个文件**，验完再派剩下的。

---

## 2. 位置（**只改这 3 个文件、只改 `post()` 这一个函数**）

```
D:\DSH\achun\check-item-images.js      （post 在 ~L31，默认超时 100000）
D:\DSH\achun\confirm-render.js         （post 在 ~L32，默认超时 150000）
D:\DSH\achun\do-offshelf.js            （post 在 ~L18，默认超时 150000）
```

### 2.1 要改的形态（三份都一样，只有超时数值不同）

现在长这样：

```js
function post(p, body, t) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => {
        let b = '';
        res.on('data', (c) => (b += c));
        res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(new Error(b.slice(0, 300))); } });
      });
    req.on('error', reject); req.setTimeout(t || 150000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}
```

### 2.2 改成（**三个文件都是这个形状，只有 `|| 后面的数字` 各自保持原样**）

```js
const { post: httpPost } = require('./lib/http');
function post(p, body, t) { return httpPost(p, body, { timeout: t || 150000 }); }
```

其中 `150000` 要换成**该文件原来的那个默认值**（check-item-images.js 要写 `100000`）。

### 2.3 三条硬要求

1. **签名不能变**：仍然是 `post(p, body, t)`，`t` 仍然是**数字**（毫秒）。
   ⚠️ `lib/http` 的 `post(path, body, opts)` 里 **`opts` 是对象 `{ timeout: N }`** ——
   你必须在中间做这个转换。这是本任务最容易错的一步。
2. **调用点一个字都不要改**（`post('/api/...', {...}, 150000)` 这类保持原样）。
3. **`t || 默认值` 那个默认值必须沿用该文件原来的数字**，不要统一成 `lib/http` 的 180000
   —— 那会静默改变超时行为。

---

## 3. 边界（不要动什么）

- **只动 `post()` 这一个函数**。不要动 `getBuffer`、不要动任何 `http.get(...)`（例如
  `confirm-render.js` 里抓截图那条）—— 那是下一批的事。
- **不要删** `const http = require('http')`、也不要删 `const KEY = SVC.apiKey` ——
  哪怕你判断它们"看起来没用了"。留着无害，删了可能踩到你看不见的用法。
- 不要改 `require('./lib/env')` 那一行。
- 不要格式化、不要重排、不要动注释以外的任何行。
- 不要碰这 3 个文件之外的任何文件。

---

## 4. 验收（你会跑不了命令，如实报告就行）

你的 shell 工具会被拒（这是预期的，**不要去试**）。只报告：

1. 三个文件**各自**改完后，把**新的 `post()` 那两行**贴出来（我要核默认值对不对）
2. 报告**每个文件里 `post(` 被调用的次数**（用读文件数的，不要猜）
3. 报告你**有没有动** `http.get` / `require('http')` / `KEY`（答案应该是"没有"）
4. 报告任何你拿不准的地方

---

## 5. 兜底（**对不上就停下来报告，这一条最重要**）

- **如果某个文件里的 `post()` 跟 §2.1 给的样子不一样**（比如多了分支、错误处理不同、
  参数顺序不同）→ **不要改那个文件**，在原样保留的前提下**单独报告它**，说明差在哪。
  **宁可少改一个，也不要按"大概意思"改。**
- 如果行号对不上 → 按**函数名 `post`** 去找，不要按行号。
- 如果文件里找不到 `post` 函数 → 报告，跳过。

---

## 6. 禁止

- **不要 `git commit` / `git push` / `git add`**
- 不要新建任何文件
- 不要修改这 3 个文件之外的任何东西
- 不要运行任何 shell 命令
