# 任务：从图片工坊里删掉 5 个已废弃的主图版式模板

## 背景（为什么改）

我们的「图片工坊 / 批量出图」里有一套主图版式模板。2026-09-26 用「杭州 那英」把 8 个模板
逐一出了实图做筛选，用户看完后做了决定：

**保留 3 个**（`id` 精确值）：
- `xuliang-v1` —— 三黄块+一紫块版式
- `shoukai-v1` —— 首开紫块样式
- `tpl_redtext` —— 白底红字版

**删除 5 个**（`id` 精确值）：
- `tpl_mt7fdi08` —— 版式3（底图是"徐州 TOP登陆少年"的成品海报，换明星必错）
- `tpl_mt8rix1n` —— 四横幅紫块（底图是"刘宪华厦门站"成品海报，换明星必错）
- `tpl_hb_banner` —— 三紫块横幅
- `tpl_suibian2` —— 随便问红榜版
- `tpl_suibian3` —— 随便问必中版

删除有两个后果，所以必须**同时**改两个文件，否则会出现"选了已删的版式"的坏下拉：
1. 模板清单文件里要去掉这 5 条；
2. `publish_dashboard.js` 里 `_BATCH_STYLES` 硬编码了 `tpl_hb_banner`，
   而 `_pickedBatchStyles()` 的默认值列表里硬编码了 `tpl_suibian2`/`tpl_suibian3`。

## 位置（含原文片段，行号仅供定位）

### 文件 A：`C:\Users\43462\.kun\default_workspace\playwright-service\assets\poster-templates.json`

这是一个顶层 JSON 数组，当前有 **8** 个元素。

**A1** 从数组中**整段移除** `"id"` 字段等于下列 5 个值之一的元素（连同它的 `{}` 和数组里的逗号）：
`tpl_mt7fdi08`、`tpl_mt8rix1n`、`tpl_hb_banner`、`tpl_suibian2`、`tpl_suibian3`

**要求：**
- 剩下的 3 个元素（`xuliang-v1`、`shoukai-v1`、`tpl_redtext`）的**字段内容一字不改**，顺序也不变。
- 结果必须是**合法 JSON 数组，恰好 3 个元素**，2 空格缩进风格与原文件一致。
- 不要重新格式化其它部分，不要改变字段顺序，不要给字段排序。

### 文件 B：`C:\Users\43462\Desktop\xianyu-monitor\publish_dashboard.js`

**B1** 约 L1537–L1541，原文（注意这是嵌套的 JS 对象字面量，不是 JSON）：

```js
        var _BATCH_STYLES = {  // 固定款式定义（kind 决定渲染方式）
          'xuliang-v1': { label: '三黄块+一紫块版式', kind: 'make', templateId: 'xuliang-v1' },
          '__shoukai':  { label: '一紫块+红字', kind: 'layer', layerLib: '⑨ 刘宪华首开样式（紫块白字+红字三行·居中）' },
          'tpl_hb_banner': { label: '三紫块横幅', kind: 'tpl', tplId: 'tpl_hb_banner' }
        };
```

改成（**只删掉最后那个 `tpl_hb_banner` 条目**，其余两行一字不动，注意上一行末尾的逗号也要去掉）：

```js
        var _BATCH_STYLES = {  // 固定款式定义（kind 决定渲染方式）
          'xuliang-v1': { label: '三黄块+一紫块版式', kind: 'make', templateId: 'xuliang-v1' },
          '__shoukai':  { label: '一紫块+红字', kind: 'layer', layerLib: '⑨ 刘宪华首开样式（紫块白字+红字三行·居中）' }
        };
```

**B2** 约 L1557–L1563，原文：

```js
        function _pickedBatchStyles() {
            try { var p = localStorage.getItem(_batchStyleKey); if (p) { var a = JSON.parse(p); if (Array.isArray(a) && a.length) return a; } } catch(e){}
            // 默认 = 固定款式 + 三个配色版式(白底红字/随便问红榜/随便问必中)
            var def = Object.keys(_BATCH_STYLES).slice();
            ['tpl_redtext','tpl_suibian2','tpl_suibian3'].forEach(function(id){ if (def.indexOf(id) < 0) def.push(id); });
            return def;
        }
```

改成：

```js
        function _pickedBatchStyles() {
            // 过滤掉已被删除的版式 id：localStorage 里可能还留着老默认值(如 tpl_suibian2/3、tpl_hb_banner)
            var all = _allBatchStyles();
            try { var p = localStorage.getItem(_batchStyleKey); if (p) { var a = JSON.parse(p); if (Array.isArray(a) && a.length) { a = a.filter(function(id){ return !!all[id]; }); if (a.length) return a; } } } catch(e){}
            // 默认 = 固定款式 + 白底红字（随便问红榜版/随便问必中版已删除）
            var def = Object.keys(_BATCH_STYLES).slice();
            ['tpl_redtext'].forEach(function(id){ if (def.indexOf(id) < 0) def.push(id); });
            return def;
        }
```

说明：`_allBatchStyles()` 定义在本函数**上方**（约 L1550），先声明后使用，不会递归
（`_allBatchStyles` 内部不调用 `_pickedBatchStyles`），所以这样写是安全的。

**B3** 约 L1559 的注释已经写在 B2 的新代码里，不要重复添加。

**B4** 约 L1952，原文：

```js
                    else if (_tplSel && _isPureLayer) { p.templateId = ''; p.blocks = []; p.tags = []; } // 纯文字层版式(白底红字/随便问): 干净底图+叠文字层
```

行尾注释里的"随便问"已经不存在，把注释改成：

```js
                    else if (_tplSel && _isPureLayer) { p.templateId = ''; p.blocks = []; p.tags = []; } // 纯文字层版式(白底红字): 干净底图+叠文字层
```

**只改注释，代码一个字符都不要动。**

## 边界（不要在本次任务里做的事）

- **不要动** `C:\Users\43462\.kun\default_workspace\playwright-service\server.js`。
  它里面的 `/api/poster/banner-sticker` 路由和 `hb_banner.png` 引用在本任务后变成死代码，
  但**本次故意保留**（那是正在跑广告的服务，改动风险大于收益）。
- **不要动** `assets/templates/` 下的任何 `.jpg` / `.png` 文件，也不要新建或删除目录。
  被删的 5 个模板对应的图片文件本次保留在磁盘上作为回退。
- **不要动** `assets/templates/cutouts/` 及其任何 `*_bak*` 目录。
- **不要动** `publish_dashboard.js` 里的 `'__shoukai'` 条目（用户明确要保留"首开紫块样式"）。
- 不要重构、不要格式化整个文件、不要改缩进风格、不要删其它"看起来没用"的代码。
- 不要给 B2 之外的地方加同样的 id 过滤逻辑。

## 验收（做完请贴出证据）

1. 贴出文件 A 改动后的**完整内容**（只有 3 个元素，应当很短），并说明元素个数。
2. 贴出文件 B 中 B1、B2、B4 三处**改动后**的原文片段（带上下文各 3 行）。
3. 贴出你在整个 `C:\Users\43462\.kun\default_workspace\playwright-service\assets\poster-templates.json`
   和 `C:\Users\43462\Desktop\xianyu-monitor\publish_dashboard.js` 里搜索下列 5 个字符串的结果：
   `tpl_mt7fdi08`、`tpl_mt8rix1n`、`tpl_hb_banner`、`tpl_suibian2`、`tpl_suibian3`
   —— 预期：**除 B2 新增的那条注释里提到的 `tpl_suibian2/3` 和 `tpl_hb_banner` 之外，一个都不剩**。
   如果注释里也提到了，请一并报告实际命中位置，不要隐瞒。
4. 报告你对文件 B 每一处改动的**行号**（改后行号）。

## 兜底

**如果任何一处的原文片段跟你看到的实际内容对不上（行号漂移不算，内容不符才算），
立刻停下来，把实际内容贴给我，不要自己推测位置改。**

## 禁止

- 不要 `git commit` / `git push` / `git checkout` / `git stash` / 任何写 git 历史的操作。
- 不要新建任何文件（备份也不要用新文件，我会自己留基线）。
- 不要 modify 上面"边界"里列出的任何文件。
