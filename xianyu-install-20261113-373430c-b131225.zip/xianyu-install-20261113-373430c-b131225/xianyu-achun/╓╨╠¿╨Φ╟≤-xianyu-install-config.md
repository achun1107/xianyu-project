# 中台需求：`/api/xianyu-install-config`（给王恩博）

> 2026-10-08。目的：让一个学员的 agent **自己**把闲鱼自动化装起来，不需要老板一台台远程配。
> 现状：装一套要读 8 个位置的配置，里面混着密钥，所以现在只能人工装。这个端点把这些收成一次请求。

---

## 一、要解决的问题

学员/徒弟/代理/会员几十号人，每人一台电脑。装的时候缺三样东西，这三样**在学员机器上推导不出来**：

1. **这个学员是谁** —— 负责哪些闲鱼店铺、叫什么名字、归属哪个群
2. **共享密钥** —— 中台 key/tenant、企微 chatId、8093 服务密钥
3. **闲鱼账号** —— 这部分**已经**有了：`GET /api/xianyu-accounts`（返回 `{id,name,username,password}`）

其余东西（仓库路径、node 路径、临时目录）都能在学员机器上自动推导，**不用中台管**。

所以要加的其实只是 **1 + 2**：一个"这台机器的学员身份与共享配置"端点。

---

## 二、接口

```
GET /api/xianyu-install-config
Header: X-Install-Code: <学员的一次性安装码>      （或复用现有登录态的会话）
```

**为什么用一次性安装码而不是把 key 写进说明文档**：说明文档会被转发、截图、丢群里。
码可以随时作废、绑机器、限次；key 不行。

### 示例响应

```json
{
  "ok": true,
  "student": {
    "id": "stu_1024",
    "name": "吴卫龙",
    "role": "徒弟班",
    "wecomChatId": "<见 config.local.json: wecom.chatId>"
  },
  "middle": {
    "base": "https://manager.museav.top",
    "tenant": "<见 config.local.json: middle.tenant>",
    "key": "sk-studio-<脱敏占位>"
  },
  "accounts": [
    { "id": "068f2aa5-4ca8-4907-b23d-fdb2f476f04b",
      "name": "好易美票务Hope",
      "username": "<学员手机号>",
      "password": "<见 8093 的 GET /api/agent/accounts>" }
  ],
  "stores": {
    "default": "好易美票务Hope",
    "active": ["好易美票务Hope"]
  },
  "service": {
    "host": "127.0.0.1",
    "port": 8093,
    "apiKey": "xy_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
  },
  "git": {
    "base": "https://gitlab.com/hym-company",
    "token": "<只读 token：能 clone 三个仓库即可，别给 write 权限>"
  },
  "overrides": {
    "thresholds": {},
    "rules": {},
    "urls": {}
  },
  "expiresAt": "2026-10-15T00:00:00+08:00"
}
```

### 字段说明

| 字段 | 必填 | 装到哪 |
|---|---|---|
| `student.*` | 是 | 写进 `config.local.json`，用于日报署名/企微推送/归属 |
| `middle.*` | 是 | `config.local.json` 的 `middle`（中台出图接口） |
| `accounts[]` | 是 | 直接喂给 8093 服务当账号表；**这是现在唯一已有的一块** |
| `stores.default` / `stores.active` | 否 | 写进 `lib/config.json` 的 `store`；不给我就用仓库默认值 |
| `service.apiKey` | 是 | `config.local.json` 的 `service.apiKey`；**必须和这台机器上 8093 服务实际用的密钥一致** |
| `git.base` / `git.token` | 否 | 三个仓库都是 **private**，学员机器要能 clone。token 只要**只读**（`read_repository`）即可，别给 write |
| `overrides.*` | 否 | 覆盖仓库默认阈值/规则；空对象 = 用默认 |
| `expiresAt` | 否 | 安装码有效期；过期后安装器提示重新取码 |

### 失败时的约定（重要）

安装器**不能因为拿不到配置就整个失败**。约定：

| 情况 | 安装器行为 |
|---|---|
| 码无效/过期 | 照常装好代码和依赖，**把缺的项列成清单打印出来**，退出码 0（不是 1） |
| 中台不可达 | 同上 —— 装好骨架，`config.local.json` 写成草稿 |
| 部分字段缺失 | 缺什么列什么，其余照装 |

理由：学员电脑上能自动装的东西（克隆代码、装 8093 服务、建目录）不该被一次网络问题全废掉。

---

## 三、`service.apiKey` 这一项要特别确认

现在 8093 服务的密钥在**两个地方各有一份**：

- 服务端 `playwright-service/server.js` 里（每台机器一个）
- 客户端 `achun/config.local.json` 的 `service.apiKey`（必须跟服务端一致）

**如果中台下发一个固定密钥，就得同时改服务端。** 两个选择：

| 方案 | 做法 | 取舍 |
|---|---|---|
| A（推荐） | 服务端首次启动**自己生成**一个随机密钥并落盘到 `service.local.json`，安装器读那个文件写进 achun 的配置 | 每台机器独立，一台泄漏不影响别人；中台不用管 |
| B | 中台下发固定密钥，安装器同时写服务端和客户端 | 简单，但一把钥匙开所有机器 |

### 已经实现的行为（2026-10-08 实测）

服务端那半边**已经按方案 A 做完了**：`server.js` 启动时如果 `service.local.json` 里没有 `apiKey`，
就生成一个随机值并落盘，同时打日志告诉你去客户端填哪个值。

安装器这边：**以「本机服务实际的密钥」为准**。中台下发的 `service.apiKey` 只是首次的初值；
如果和服务端不一致，安装器会把**服务端那把同步到客户端**，并打一条警告。

> 也就是说：**中台即使不下发 `service.apiKey` 也能跑**，这一项不是必填。
> 反过来，如果中台坚持要下发固定密钥，那就得同时提供改服务端配置的办法（方案 B），
> 否则会被"以服务端为准"这条规则覆盖掉 —— 这是**故意的**，因为客户端密钥写错的表现是
> 所有请求 401，而服务端密钥是唯一事实。

**这一项按 A 就好，不用中台管。**

---

## 四、拿不到这个端点时的临时方案

在端点做出来之前，分发只能靠"老板把 `config.local.json` 手工发给学员"。
可以接受，但**密钥就进了聊天记录**，而且学员换店/换账号都要找老板。
所以这个端点是"开 100 个店"从"能跑"到"能规模化"的那道门。

---

## 五、需要王恩博回的三件事

1. 这个端点**能不能做**、大概什么时候做
2. `service.apiKey` 选 A 还是 B
3. 安装码从哪取 —— 学员自己在后台点"生成安装码"，还是老板统一发

---

## 附：安装器会怎么用（已实现的客户端侧）

```js
// 安装器（install.ps1 里调 node）大致流程
// 1) 读安装码 → GET /api/xianyu-install-config
// 2) 生成 config.local.json（paths 由本机推导；middle/service/student 来自响应）
// 3) 克隆/校验两个依赖仓库（xianyu-playwright-service / xianyu-monitor）
// 4) 装 8093 服务的依赖并启动，探活 /api/agent/status
// 5) 建 stores/ 与 publish-assets/ 骨架
// 6) 跑 node tools/store-init.js --all 自验收
// 7) 打印「剩下要人工的三样」：闲鱼登录 / 主图风格 / 副图
```
