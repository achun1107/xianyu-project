// ad-hours-live.js —— 只读：抓「计划管理」表格里【平台自己显示的投放时段文本】
//
// 为什么需要它：budgetScheduleDurations 是整点数组，语义（[8..22] 到底是 8:00-23:00 还是 8:00-22:00）
//   在仓库里有两套互相矛盾的口径（set-ad-hours.js 说 h=h:00-(h+1):00，probe-plan-status.js 的注释说 16 槽=8:00-23:00）。
//   唯一权威是平台自己渲染的那一列。实测：15 槽的计划平台显示「部分时段 8:00-23:00」。
//
// 表结构（2026-10-09 实测 ad-table-dump.js）：
//   thead 是两层，第一行有 36 列且【第 0 列是空的选择列】；
//   行里 td 也是 36 个，计划ID 在 index 2、计划名称 3、投放时段 8。
//   ⚠ ad-live-rows.js 假设 计划ID 在 c[1] 且 td>10 —— 实测抓 0 行，就是这个偏差。
//
// 由 ad-creative-run.js 驱动（CREATIVE_DRIVER=ad-hours-live.js），返回 JSON 字符串。
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();

  for (let i = 0; i < 10; i++) {
    if (document.querySelectorAll('tbody tr').length) break;
    await sleep(1000);
  }

  // 先把【展开态】的行收起来。
  //   为什么必须收：被展开的计划，它的计划行不再渲染成 36 个 td 的形状，
  //   下面按列号取「投放时段」就会取空（实测：10 条刚编辑过的计划全读成 0）。
  const click1 = (el) => {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  };
  const expanded = () => [].slice.call(document.querySelectorAll('.ant-table-row-expand-icon-expanded'));
  let collapsed = 0;
  for (let round = 0; round < 3 && expanded().length; round++) {
    expanded().forEach(el => { click1(el); collapsed++; });
    await sleep(1500);
  }

  const all = {};
  const grab = () => [].slice.call(document.querySelectorAll('tbody tr')).forEach(tr => {
    const tds = [].slice.call(tr.querySelectorAll('td'));
    // 只认【计划行】。实测：计划行 36 个 td，展开后的「宝贝信息」子表行 11 个 td。
    //   早先只判 <9，结果子表行的「宝贝ID」也是 13 位数字、通过了 id 正则，
    //   把同一个 key 上的计划行覆盖掉 —— 被展开过的计划于是全都读成「0」。
    if (tds.length < 30) return;
    // ⚠ 必须安全取值：表格里有 td 数不足 36 的行（展开的宝贝子表行等），
    //   直接 tds[18].innerText 会抛 TypeError 把整次抓取打掉（实测踩过）。
    const tx = (i) => (tds[i] ? norm(tds[i].innerText) : '');
    const id = tx(2);
    if (!/^\d{6,}$/.test(id)) return;
    all[id] = { id, 状态: tx(1), 名称: tx(3).slice(0, 34),
      宝贝数: tx(4), 日预算: tx(5), 出价: tx(6),
      投放时段文本: tx(8), 今日花费: tx(10), 咨询数: tx(18) };
  });
  grab();

  // 翻页抓全。⚠ 早先只用 .ant-pagination-item 点页码，实测【一个都没点到】，
  //   于是静默只返回第 1 页的 9 条（19 条计划），看着像「后台只有 9 个计划」。
  //   改成优先点「下一页」按钮，点不动就停，并把页数如实报出来。
  let pagesRead = 1;
  for (let p = 2; p <= 6; p++) {
    const next = document.querySelector('.ant-pagination-next:not(.ant-pagination-disabled)')
      || [].slice.call(document.querySelectorAll('.ant-pagination-item'))
        .find(e => norm(e.getAttribute('title') || e.innerText) === String(p));
    if (!next) break;
    const before = Object.keys(all).length;
    click1(next);
    await sleep(3000);
    grab();
    pagesRead++;
    if (Object.keys(all).length === before) break;     // 没翻动，别死循环
  }

  // 把「文本 → 计划」归一下组，方便一眼看出到底有几种时段
  const tally = {};
  Object.keys(all).forEach(id => { const t = all[id].投放时段文本; tally[t] = (tally[t] || 0) + 1; });

  return JSON.stringify({
    时刻: new Date().toLocaleString('zh-CN'),
    抓到计划数: Object.keys(all).length,
    读了页数: pagesRead,
    收起展开行数: collapsed,
    时段文本分布: tally,
    计划: Object.keys(all).map(id => all[id]),
  }, null, 1);
})()
