// ad-resume-all.js —— 一键恢复擦亮（默认排除 6 个待删的 AB-刘宪华 计划）
// 用法：在 8093 的 eval-on-store 里跑本文件。可用 window.__RESUME_EXCLUDE 覆盖排除名单。
(async () => {
  const mtop = window.lib.mtop;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // 用户要删的 6 个 AB，恢复时不要带回来
  const EXCLUDE = (window.__RESUME_EXCLUDE) || [
    '95000884', '94960871', '96694397', '94992341', '95549347', '96727475',
  ];

  const search = async () => {
    const r = await mtop.request({
      api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) },
    });
    return (r.data || {}).result || [];
  };

  const before = await search();
  const paused = before.filter(c => String(c.pauseStatus) === '1' || c.statusGroup === 'paused');
  const target = paused.filter(c => EXCLUDE.indexOf(String(c.campaignId)) < 0);
  const skipped = paused.filter(c => EXCLUDE.indexOf(String(c.campaignId)) >= 0);
  const out = {
    暂停中: paused.length,
    将恢复: target.length,
    排除不恢复: skipped.map(c => c.campaignId + ' ' + c.title),
  };
  if (!target.length) { out.结果 = '没有需要恢复的计划'; return JSON.stringify(out, null, 1); }

  const res = [];
  const ids = target.map(c => String(c.campaignId));
  for (let i = 0; i < ids.length; i += 10) {
    const batch = ids.slice(i, i + 10);
    const pr = await mtop.request({
      api: 'mtop.taobao.idle.ad.campaign.pause', v: '1.0', type: 'POST',
      data: { requestJson: JSON.stringify({ campaignIds: batch, pauseStatus: 0 }) },
    });
    const ok = Object.keys(pr.data || {}).filter(k => (pr.data[k] || {}).pauseStatus === 0).length;
    res.push({ 提交: batch.length, 确认恢复: ok, ret: (pr.ret || [])[0] });
    await sleep(1500);
  }
  out.批次结果 = res;

  await sleep(6000);
  const after = await search();
  const online = after.filter(c => c.statusGroup === 'online');
  out.恢复后 = { 总计划: after.length, 在跑: online.length, 仍暂停: after.filter(c => String(c.pauseStatus) === '1').length };
  out.结果 = online.length === target.length ? '✅ 目标计划已全部恢复在跑' : ('⚠ 在跑 ' + online.length + '，期望 ' + target.length);
  return JSON.stringify(out, null, 1);
})()
