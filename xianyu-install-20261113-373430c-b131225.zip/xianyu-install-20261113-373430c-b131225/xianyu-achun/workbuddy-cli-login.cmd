@echo off
setlocal
title WorkBuddy CLI - login / auth check
rem ============================================================
rem  WORKBUDDY CLI LOGIN ENTRY  (rewritten 2026-11-09)
rem ------------------------------------------------------------
rem  Usage:
rem     workbuddy-cli-login.cmd          -> open interactive UI, type /login
rem     workbuddy-cli-login.cmd check    -> only check auth state
rem
rem  WHY NOT THE BUNDLED bin\codebuddy:
rem    D:\work\WorkBuddy\resources\app.asar.unpacked\cli is the slim CLI
rem    shipped with the desktop app. After an upgrade its cli\dist holds
rem    ONLY codebuddy-lite-wb.mjs (no codebuddy.js), so:
rem      - running bin\codebuddy does require('../dist/codebuddy')
rem        -> Error: Cannot find module '../dist/codebuddy'
rem      - lite-wb is a headless/slim bundle with NO TUI, so the /login
rem        screen can never appear (forcing CODEBUDDY_FORCE_LITE_WB_BUNDLE=1
rem        just exits silently).
rem    Therefore login must go through a FULL package, whose dist has
rem    codebuddy.js (the TUI itself).
rem
rem  WHEN IT BREAKS AGAIN, CHECK IN THIS ORDER:
rem    1. does the full package still ship dist\codebuddy.js ?
rem         dir "<pkg>\dist\codebuddy.js"
rem       only lite-wb/headless left -> TUI stripped: reinstall the full
rem       package, or log in via the WorkBuddy desktop app then run check.
rem    2. did a path get renamed? (past trap: node version dir renamed to
rem       .22.x.deleting.* -> "system cannot find the path"). This script
rem       never hardcodes a version: it probes candidates in order.
rem    3. verify with `workbuddy-cli-login.cmd check`
rem       AUTH-OK = fine; "Authentication required" = really logged out.
rem ============================================================

set "PKG="
set "C1=%USERPROFILE%\scoop\apps\nodejs\current\bin\node_modules\@tencent-ai\codebuddy-code"
set "C2=%APPDATA%\npm\node_modules\@tencent-ai\codebuddy-code"
set "C3=%ProgramFiles%\nodejs\node_modules\@tencent-ai\codebuddy-code"

if exist "%C1%\dist\codebuddy.js" set "PKG=%C1%"
if not defined PKG if exist "%C2%\dist\codebuddy.js" set "PKG=%C2%"
if not defined PKG if exist "%C3%\dist\codebuddy.js" set "PKG=%C3%"
if not defined PKG goto nopkg

set "NODE=%USERPROFILE%\scoop\apps\nodejs\current\node.exe"
if not exist "%NODE%" set "NODE="
if not defined NODE for /f "delims=" %%n in ('where node 2^>nul') do if not defined NODE set "NODE=%%n"
if not defined NODE goto nonode

set "CLI=%PKG%\bin\codebuddy"
set "OUTF=%TEMP%\cbc-auth-check.txt"

echo ============================================================
echo   WorkBuddy CLI
echo   pkg : %PKG%
echo   node: %NODE%
echo ============================================================
echo.

if /i "%~1"=="check" goto check

powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host 'Next, in this window:'; Write-Host '  1) wait for the input box  >'; Write-Host '  2) type  /login  and press Enter'; Write-Host '  3) authorize in browser / scan the QR code'; Write-Host '  4) after it succeeds, type /exit (or Ctrl+C twice)'; Write-Host ''; Write-Host 'Tip: typing / lists commands; /login is described as'; Write-Host '     \"Switch Tencent Cloud CodeBuddy accounts\"'; Write-Host 'If you are already logged in, skip step 2 and just /exit.'"
echo ------------------------------------------------------------
echo.

"%NODE%" "%CLI%"
set "RC=%ERRORLEVEL%"
echo.
echo ------------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host ('CLI exited (code %RC%), re-checking auth state...' -replace '%RC%','%RC%')"
echo.
call :authcheck
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host 'Keep this window open so the text above can be copied.'"
echo ============================================================
pause >nul
endlocal & exit /b 0

:check
call :authcheck
if "%AUTHSTATE%"=="ok" goto exit0
if "%AUTHSTATE%"=="bad" goto exit2
endlocal & exit /b 3
:exit0
endlocal & exit /b 0
:exit2
endlocal & exit /b 2

:authcheck
set "AUTHSTATE=unknown"
"%NODE%" "%CLI%" -p "Reply with exactly: AUTH-OK" > "%OUTF%" 2>&1
findstr /c:"AUTH-OK" "%OUTF%" >nul 2>&1
if not errorlevel 1 set "AUTHSTATE=ok"
if "%AUTHSTATE%"=="ok" goto ac_ok
findstr /c:"Authentication required" "%OUTF%" >nul 2>&1
if not errorlevel 1 set "AUTHSTATE=bad"
if "%AUTHSTATE%"=="bad" goto ac_bad
echo   ================ auth ================
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host '  [unknown] unrecognized output:'; Get-Content -LiteralPath '%OUTF%' | Select-Object -Last 10"
exit /b 0
:ac_ok
echo   ================ auth ================
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host '  [OK] logged in - the CLI can take jobs.'"
exit /b 0
:ac_bad
echo   ================ auth ================
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host '  [expired] still Authentication required - the boss must scan the QR code.'; Write-Host '           run workbuddy-cli-login.cmd and type /login'"
exit /b 0

:nopkg
echo ============================================================
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host '  [no full package found] none of these has dist\codebuddy.js:'; Write-Host '    %C1%'; Write-Host '    %C2%'; Write-Host '    %C3%'; Write-Host ''; Write-Host '  The app-bundled cli only has codebuddy-lite-wb.mjs (no TUI), so'; Write-Host '  it cannot open the /login screen - do not fall back to it.'; Write-Host ''; Write-Host '  Next, either:'; Write-Host '    A. npm i -g @tencent-ai/codebuddy-code   then rerun this script'; Write-Host '    B. log in via the WorkBuddy desktop app, then run:'; Write-Host '       workbuddy-cli-login.cmd check'"
echo ============================================================
pause >nul
endlocal & exit /b 4

:nonode
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host '  [no node] package found at %PKG% but no node.exe on PATH or in scoop.'"
pause >nul
endlocal & exit /b 5