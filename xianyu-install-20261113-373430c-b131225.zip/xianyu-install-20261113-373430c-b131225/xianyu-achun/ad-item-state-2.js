// ad-item-state-2.js —— 凤凰传奇 vs 李大奔 4 条的投放资格对比
(async () => {
  const mtop = window.lib.mtop;
  const ids = {
    '1087425616452': '凤凰传奇北京①(计划正常)',
    '1086394229152': '凤凰传奇北京②(计划正常)',
    '1085305986288': '李大奔广州①(计划被暂停)',
    '1087401860257': '李大奔广州②(计划被暂停)',
  };
  const r = await mtop.request({
    api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, tab: 'all', needTabs: true }) },
  });
  const list = ((r.data || {}).result || {}).itemList || [];
  const byId = {}; list.forEach(it => byId[String(it.itemId)] = it);
  const out = { 可投放总数: list.length, 逐个: {} };
  for (const id in ids) {
    const it = byId[id];
    out.逐个[id] = it ? {
      说明: ids[id],
      在池: true, supportAd: it.supportAd, tags: it.tags,
      价: Number(it.price) / 100,
      不支持原因: it.notSupportAdInfo,
      saleCnt: it.saleCnt,
      上架: it.publishTime,
      最后修改: it.firstModified,
    } : { 说明: ids[id], 在池: false };
  }
  // 也看看这两个宝贝在不在「平台推荐/爆品」等 tab 里
  out.各tab = {};
  for (const tab of ['platReco', 'all', 'new', 'hot']) {
    try {
      const rr = await mtop.request({ api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
        data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, tab, needTabs: false }) } });
      const l = ((rr.data || {}).result || {}).itemList || [];
      const hit = l.map(x => String(x.itemId)).filter(x => ids[x]);
      out.各tab[tab] = { 条数: l.length, 命中: hit };
    } catch (e) { out.各tab[tab] = 'err ' + (e && e.message); }
  }
  return JSON.stringify(out, null, 1);
})()
