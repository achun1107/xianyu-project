# 企业微信 CLI · 能力与授权清单

**探测日期**：2026-09-27
**CLI 版本**：`wecom-cli 1.3.4 (wecom 2026-09-23T11:47:44Z f9b2815)`
**CLI 文件更新时间**：2026-09-27 16:37:18（老板说"好易美后台有更新"，对上了）
**位置**：`C:\Users\43462\.workbuddy\binaries\node\cli-connector-packages\wecom-cli.cmd`

---

## ✅ 当前状态：已恢复（2026-09-27 19:0x）

老板已重新授权，**8 项能力全部复测通过**：

| 能力 | 结果 |
|---|---|
| 消息 message | ✅ 发送成功（`"success": true`，已实发验证） |
| 待办 todo | ✅ 通过 |
| 日程 calendar | ✅ 通过 |
| 会议 meeting | ✅ 通过 |
| 微盘 disk | ✅ 通过 |
| 表格 sheet | ✅ 通过 |
| 智能表格 smartsheet | ✅ 通过 |
| 文档 doc | ✅ 通过（errcode 0） |
| 智能主页 smartpage | ✅ 通过 |
| 通讯录 contact | ✅ 通过 |
| 邮件 mail | ✅ 通过 |
| 会话 chat | 🚫 853006 企业未开通（非过期，点了也没用） |

### 🔎 853006 到底怎么开通（2026-09-27 查证官方文档）

来源：连接器官方仓库 `WecomTeam/wecom-unified` 的
[PR #7 新增 `references/wecomcli-chat.md`](https://github.com/WecomTeam/wecom-unified/pull/7)（原文即"经实机验证"）。

> **权限分水岭 `853006`**：含义是**企业未开通「会话内容存档」权限**，属于企业微信后台功能开通问题
> （**通常需企业认证 + 付费 + 合规双重同意**），**客户端参数无法绕过**。
>
> - 实测结论：**`bot 在群内 + 7 天窗内 + 即时收到的消息` → 可读（返回正常）**；
>   `主动回溯历史 / bot 不在的群` → 可能触发 `853006`。
> - 与「发送消息」是两个**独立权限平面**：bot 能发文（普通机器人能力），
>   不代表能读历史（需会话存档增值能力）。

**所以有两条路：**

| 路线 | 做法 | 能拿到什么 | 成本 |
|---|---|---|---|
| **免费路** | 把这个机器人**拉进群**，等群里有新消息 | 7 天窗内 **bot 即时收到**的消息 | 0 |
| **付费路** | 开通「会话内容存档」 | **可主动回溯历史**、bot 不在的群也能读 | 需企业认证 + 付费 + 合规同意 |

**我们当前的状态**：机器人**不在任何群里**，且我探测时用的是授权人自己的 userid
（`<见 config.local.json: wecom.chatId>`）而不是某个群的 chat_id ——
两个条件都不满足，所以 `groups list` / `messages list` 都是 `853006`。

**待验证**：把机器人拉进一个群、在群里发条消息，再重跑 `chat groups list`。
按官方文档，这条路应该能读到**即时消息**（不需要开通会话存档）。

**⚠️ 纠正之前的说法**：我先前说"企业未开通，点了也没用" —— **结论对了，理由不全**。
官方文档的"免费路"（bot 在群内读即时消息）我实测**不成立**：即使用合法的 7 天窗口，
`chat groups list` 仍返回 `853006`。所以**只能走付费开通「会话内容存档」**。

### 开通「会话内容存档」的完整条件（2026-09-27 查证）

来源：[企业微信会话内容存档怎么开通？](https://developer.aliyun.com/article/1764407)、
[腾讯官方服务协议](https://work.weixin.qq.com/wework_admin/financial/trialApplyNorm)

**它不是"点一下开关"，要落三样东西：**

| # | 条件 | 说明 |
|---|---|---|
| 1 | **企业认证 + 付费** | 只对**企业认证过**的组织开放；**付费能力，按开通账号数计费** |
| 2 | **管理员三项配置** | 超管在后台「会话内容存档」入口设：① **开启范围**（按部门/成员勾选）② **调用来源**（服务器地址白名单）③ **消息加密公钥** —— 三样缺一，接口调不通 |
| 3 | **双方知情同意** | 员工登录客户端会看到告知页并确认；**与外部联系人的会话还需对方同意** |

**还有三条容易踩的：**

- **平台不提供可视化查询界面** —— 只给接口，拉取/解密/入库整条链路要自己搭（CLI 就是这一环）
- **只往后生效** —— **开通之前的历史记录追不回来**。等出问题再开，通常已经晚了
- **私钥由企业自己保管**，平台不解密。私钥丢一次，之前存的就再也解不开

**所以这不是一个"顺手开一下"的功能**：要企业认证、要按人头付费、要员工和客户同意、
要做合规告知，而且**历史追不回来**。

### 💡 更划算的替代：用「在线表格」当双向通道（不需要 chat 权限）

type=1「文档」权限**已经开通了**，而且 CLI 明确允许
**在在线文档/表格/智能表格/智能主页四类上跨身份读写**。

所以完全可以绕开"读聊天记录"：

| 我 → 你 | 你 → 我 |
|---|---|
| 我把日报（花费/咨询/单次咨询成本）写进你的企微**在线表格** | 你在表格里写一行指令，我定时读回来执行 |
| 我建**待办**推给你 | 你完成待办，我能读到状态 |

**这条路 0 成本、0 合规门槛、现在就能用。** 对于"老板给 agent 下指令 / agent 回汇报"
这个真实需求，比开通会话存档划算得多。



**故障窗口**：2026-09-27 08:00 – 19:00，四次余额播报丢失（08:00/11:00/14:00/17:00）。

### 新增的可复用发送器 `wecom-send.ps1`

**为什么需要它**：Node 的 `execFileSync` 直接调 `wecom-cli.cmd` 在本环境下**不回显、静默失败**
（exit status null）—— 我新写的 `ad-retry-order-notify.js` 就是这么坏的。
已验证可用的路径是 PowerShell：中文放 UTF-8 文件 → 读进变量 → `--set "markdown.content=$content"`。

```
powershell -File wecom-send.ps1 -File <utf8-md> [-Chat <id>] [-DryRun]
退出码: 0=成功  2=文件问题  3=发送失败
```

### 兜底：不能用企微报告企微故障

`wecom-send.ps1` 失败时会：
1. **写 marker 文件** `D:\DSH\achun\!企微发送失败.txt`（**它存在 = 当前发送是坏的**；下次成功自动删除）
2. 弹一个桌面气泡通知（best-effort）

这样"企微自己坏了"这件事有了**不依赖企微**的信号 —— 补上了这次静默 10 小时的漏洞。

---


## 一、结论先说

**CLI 本身连得上：**

```
auth show → Status: authorized
Bot ID    → aibSGQ81G0Jk-MD8psGAKj5O-OUCW3qu1b-
授权真人   → <见 config.local.json: wecom.chatId>
             （好易美🚗旗舰店2️⃣Achun（代拍录入邀请函））
```

**但 8 个能力的授权全部过期（`errcode 850003`），现在什么都做不了 —— 包括发消息。**

⚠️ **重要认知**：`auth show: authorized` 只代表**机器人登录有效**，
和**各能力的使用权限**是两件事。以后别被这一行骗了 —— 要看具体调用的 errcode。

---

## 二、能力 × 授权 type 全表

| type | 能力 | 对应命令 | 当前状态 |
|---|---|---|---|
| **1** | 文档 | `doc` / `sheet` / `smartsheet` / `smartpage` | ❌ 850003 授权过期 |
| **2** | 日程 | `calendar` | ❌ 850003 授权过期 |
| **3** | 会议 | `meeting` | ❌ 850003 授权过期 |
| **4** | 通讯录 | `contact` | ❌ 850003 授权过期 |
| **5** | 待办 | `todo` | ❌ 850003 授权过期 |
| **6** | 消息 | `message` | ❌ 850003 授权过期 |
| **7** | 邮件 | `mail` | ❌ 850003 授权过期 |
| **8** | 微盘 | `disk` | ❌ 850003 授权过期 |
| — | 会话（读聊天记录） | `chat groups` / `chat messages` | 🚫 **853006 企业未开通该工具**（不是过期，是真没开） |
| — | 媒体 | `media` | 未报授权错误（可能不需单独授权） |

---

## 三、重新授权（老板操作，你是机器人创建者）

每个能力一个链接，`type` 换成上表的编号即可：

```
https://work.weixin.qq.com/ai/aiHelper/authorizationList?from=chat&forceInnerBrowser=1&aibotid=33776997752279129&str_aibotid=aibSGQ81G0Jk-MD8psGAKj5O-OUCW3qu1b-&type=1&ww_vw=640&ww_vh=640&for_native=true&bar_style_type=3&pc_bar_bg=f6f6f7%2C202021&hide_more_btn=true
```

把 `type=1` 依次换成 **2 / 3 / 4 / 5 / 6 / 7 / 8** 各点一次。

**8 个链接（可直接点）：**

| type | 能力 | 链接 |
|---|---|---|
| 1 | 文档 | [授权文档](https://work.weixin.qq.com/ai/aiHelper/authorizationList?from=chat&forceInnerBrowser=1&aibotid=33776997752279129&str_aibotid=aibSGQ81G0Jk-MD8psGAKj5O-OUCW3qu1b-&type=1&ww_vw=640&ww_vh=640&for_native=true&bar_style_type=3&pc_bar_bg=f6f6f7%2C202021&hide_more_btn=true) |
| 2 | 日程 | [授权日程](https://work.weixin.qq.com/ai/aiHelper/authorizationList?from=chat&forceInnerBrowser=1&aibotid=33776997752279129&str_aibotid=aibSGQ81G0Jk-MD8psGAKj5O-OUCW3qu1b-&type=2&ww_vw=640&ww_vh=640&for_native=true&bar_style_type=3&pc_bar_bg=f6f6f7%2C202021&hide_more_btn=true) |
| 3 | 会议 | [授权会议](https://work.weixin.qq.com/ai/aiHelper/authorizationList?from=chat&forceInnerBrowser=1&aibotid=33776997752279129&str_aibotid=aibSGQ81G0Jk-MD8psGAKj5O-OUCW3qu1b-&type=3&ww_vw=640&ww_vh=640&for_native=true&bar_style_type=3&pc_bar_bg=f6f6f7%2C202021&hide_more_btn=true) |
| 4 | 通讯录 | [授权通讯录](https://work.weixin.qq.com/ai/aiHelper/authorizationList?from=chat&forceInnerBrowser=1&aibotid=33776997752279129&str_aibotid=aibSGQ81G0Jk-MD8psGAKj5O-OUCW3qu1b-&type=4&ww_vw=640&ww_vh=640&for_native=true&bar_style_type=3&pc_bar_bg=f6f6f7%2C202021&hide_more_btn=true) |
| 5 | 待办 | [授权待办](https://work.weixin.qq.com/ai/aiHelper/authorizationList?from=chat&forceInnerBrowser=1&aibotid=33776997752279129&str_aibotid=aibSGQ81G0Jk-MD8psGAKj5O-OUCW3qu1b-&type=5&ww_vw=640&ww_vh=640&for_native=true&bar_style_type=3&pc_bar_bg=f6f6f7%2C202021&hide_more_btn=true) |
| 6 | 消息 | [授权消息](https://work.weixin.qq.com/ai/aiHelper/authorizationList?from=chat&forceInnerBrowser=1&aibotid=33776997752279129&str_aibotid=aibSGQ81G0Jk-MD8psGAKj5O-OUCW3qu1b-&type=6&ww_vw=640&ww_vh=640&for_native=true&bar_style_type=3&pc_bar_bg=f6f6f7%2C202021&hide_more_btn=true) |
| 7 | 邮件 | [授权邮件](https://work.weixin.qq.com/ai/aiHelper/authorizationList?from=chat&forceInnerBrowser=1&aibotid=33776997752279129&str_aibotid=aibSGQ81G0Jk-MD8psGAKj5O-OUCW3qu1b-&type=7&ww_vw=640&ww_vh=640&for_native=true&bar_style_type=3&pc_bar_bar_bg=f6f6f7%2C202021&hide_more_btn=true) |
| 8 | 微盘 | [授权微盘](https://work.weixin.qq.com/ai/aiHelper/authorizationList?from=chat&forceInnerBrowser=1&aibotid=33776997752279129&str_aibotid=aibSGQ81G0Jk-MD8psGAKj5O-OUCW3qu1b-&type=8&ww_vw=640&ww_vh=640&for_native=true&bar_style_type=3&pc_bar_bg=f6f6f7%2C202021&hide_more_btn=true) |

---

## 四、权限边界（CLI 自己声明的规则）

> CLI 调用由**机器人身份**代用户执行。
> - 真人授权用户**创建或拥有**的数据，机器人**可以读取、查询、下载**；
> - **写入/修改**只允许在**在线文档 / 在线表格 / 智能表格 / 智能文档**（doc / sheet / smartsheet / smartpage）四类上跨身份操作；
> - 其它品类**只能写入或修改机器人自己创建的数据**。

对我们的意义：**广告报表可以写进你的企微在线表格**（跨身份允许），
但**改你的待办/日程/邮件不行**（除非是机器人自己建的）。

---

## 五、命令树全貌（供后续选用）

```
auth        init, show
calendar    schedules
chat        groups, messages            ← 企业未开通
contact     users search
disk        files, folders
doc         create, import, search, contents, members, names, rules
mail        get, search, send
media       download, upload
message     send, aibot, files
meeting     cancel, create, get, list, search, update, original, rooms
sheet       create, get, import, contents, ranges, rows, subsheets
smartpage   create, import, blocks, databases, files, images, pages
smartsheet  create, get, import, charts, fields, files, images, records, sheets, views
todo        create, delete, finish, get, list, update
```

**用法坑**：`doc search` 和 `mail search` 的参数是 `--keywords`（复数数组），
不是 `--keyword`；`contact` 只有 `users search`（没有 `users list`）；
`media download` 用 `--media-id`。

---

## 六、🔴 必须补的兜底：不能用企微报告企微故障

`ad-balance-duty.ps1`（每 3 小时播报余额）在**读取失败**时会发企微告警 ——
但这次是**发送本身坏了**（`850003`），**告警发不出去**，所以整个通道静默了 10 小时无人知晓。

已确认的静默失败窗口：2026-09-27 08:00 / 11:00 / 14:00 / 17:00 四次播报全部失败。

**待实现**：连续 N 次发送失败 → 写醒目文件（`D:\DSH\achun\⚠企微发送失败.txt`）+ 桌面通知
（不依赖企微自身的通道）。
