@echo off
cd /d D:\DSH\achun
node ad-pending.js create
