﻿# 【密钥外置 2026-10-07】apiKey 不再硬编码，从 config.local.json 读（Get-XyPath 本机优先）
. (Join-Path $PSScriptRoot 'lib\ps\Config.ps1')

@{
  store = '好易美代拍'
  code  = 'return "guard-probe-ok"; /* probe: mtop.taobao.idle.ad.campaign.delete */'
} | ConvertTo-Json -Depth 3 | Out-File "$env:TEMP\guard-probe.json" -Encoding UTF8
$payload = Get-Content "$env:TEMP\guard-probe.json" -Raw -Encoding UTF8
$bytes = [System.Text.Encoding]::UTF8.GetBytes($payload)

Write-Host "=== 测试 1：含 campaign.delete 的代码（应被拦截）==="
try {
  $r = Invoke-RestMethod -Uri 'http://127.0.0.1:8093/api/agent/eval-on-store' -Method Post `
        -Body $bytes -ContentType 'application/json; charset=utf-8' `
        -Headers @{'X-API-Key'=(Get-XyPath 'service.apiKey')} -TimeoutSec 30
  Write-Host ("响应: " + ($r | ConvertTo-Json -Compress))
} catch {
  $sc = $_.Exception.Response.StatusCode.value__
  Write-Host "HTTP 状态: $sc"
  $sr = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
  Write-Host ("响应体: " + $sr.ReadToEnd())
}
