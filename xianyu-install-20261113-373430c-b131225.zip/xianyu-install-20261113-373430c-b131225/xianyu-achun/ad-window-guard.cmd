@echo off
rem ===== Ad-window guardian =====
rem Checks that the 08:00 open / 23:00 close ACTUALLY took effect.
rem
rem Why this exists: the window has silently failed twice, and both times nobody knew.
rem   2026-10-07 early morning - the 09:00 resume script was never registered as a
rem     scheduled task at all, so plans stayed paused from 01:02 until past 13:00.
rem   2026-10-07 23:00 - the close task returned 0xFF (Chinese comment in a .cmd),
rem     wrote nothing to the log, and the window stayed OPEN all night.
rem Fixing the tasks is not enough; something else has to notice when they fail again.
rem So this runs 40 minutes AFTER each action task and verifies the real state.
rem
rem ASCII ONLY ON PURPOSE - see the long note in ad-window-8am.cmd.
rem 2026-10-08: Chinese rem lines were added here at 05:13 - that is the SAME bug class
rem that broke the 23:00 task (cmd.exe decodes this file in OEM 936, so Chinese bytes can
rem land on & | < > and the comment gets executed as commands). Rewritten in ASCII.
rem KEEP THIS FILE ASCII.
cd /d D:\DSH\achun
set LOG=D:\DSH\achun\ad-window.log
echo. >> "%LOG%"
echo ===== WINDOW GUARD begin ===== >> "%LOG%"
call D:\DSH\achun\run-node.cmd "D:\DSH\achun\tools\ensure-agent.js" >> "%LOG%" 2>&1
call D:\DSH\achun\run-node.cmd "D:\DSH\achun\tools\ad-window.js" --verify >> "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
rem --- non-fatal sweep of campaign status descriptions (added 2026-10-08) ---
rem Why: the two plans created on 2026-10-08 briefly carried a different status text
rem (some items cannot be polished due to abnormal status) instead of the usual
rem manually-paused label. That text also masks the normal label, so planVerdict()
rem reported them as a plain pause. Whether such text blocks delivery is not
rem documented anywhere, so we just record it.
rem RC was captured ABOVE on purpose: this sweep must NOT change the exit code.
call D:\DSH\achun\run-node.cmd "D:\DSH\achun\tools\ad-plan-alert.js" --quiet >> "%LOG%" 2>&1
rem --- daily performance snapshot (added 2026-10-08) ---
rem Runs here so the 23:40 pass captures the full day. Writes data/ad-daily.json
rem keyed by (date, planId) for the statistics/attribution report.
rem RC was captured ABOVE on purpose: this collector must NOT change the exit code.
rem KEEP THIS FILE ASCII - see the note at the top.
call D:\DSH\achun\run-node.cmd "D:\DSH\achun\tools\ad-daily.js" >> "%LOG%" 2>&1
echo ===== WINDOW GUARD done (exit %RC%) ===== >> "%LOG%"
exit /b %RC%