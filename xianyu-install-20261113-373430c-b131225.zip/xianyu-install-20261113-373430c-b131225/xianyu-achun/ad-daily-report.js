/**
 * ad-daily-report.js — 把广告日报写进企微智能表格「日报」子表
 *
 * 数据口径：近 7 日（平台接口最多 7 天）+ 今日实时
 * 写入字段：日期 / 花费 / 咨询 / 单次咨询成本 / 下单 / 支付额 / 状态 / 明细
 *
 * 用法: node ad-daily-report.js [--dry]
 */
const fs = require('fs');
const http = require('http');
const sheet = require('./wecom-sheet.js');
const { SVC, ROOT, STORE } = require('./lib/env');

const D = ROOT + '/';
const KEY = SVC.apiKey;
const DRY = process.argv.indexOf('--dry') >= 0;
const LOG = D + 'ad-daily-report.log';

// 用户在用电脑就跳过：本任务要导航那个【可见】的浏览器读后台 → 弹窗打扰（见 lib/idle.js）。
// --dry 只打印不发请求，不受此限，方便随时手动查。
const idleLib = require('./lib/idle');
if (idleLib.skipIfBusy('广告日报', { force: DRY })) process.exit(0);

// 2026-10-03 补：这个入口之前漏了门。停投期间没有投放数据可报，直接跳过，
// 别去导航那个可见的浏览器。（教训：加统一开关时必须先枚举全部入口 —— 我在这一处漏过两次。）
if (!DRY && require('fs').existsSync(require('path').join(__dirname, 'PAUSE-ADS'))) {
  console.log(new Date().toLocaleString('zh-CN') + '  PAUSE-ADS 存在：停投中，跳过本轮日报（不导航浏览器）');
  process.exit(0);
}

function log(s) { const l = new Date().toLocaleString('zh-CN') + '  ' + s; console.log(l); try { fs.appendFileSync(LOG, l + '\n', 'utf8'); } catch (e) { } }
function post(p, body, t) {
  return new Promise((res, rej) => {
    const pl = JSON.stringify(body);
    const rq = http.request({ host: '127.0.0.1', port: 8093, path: p, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(pl), 'x-api-key': KEY } },
      r => { let b = ''; r.on('data', c => b += c); r.on('end', () => { try { res(JSON.parse(b)); } catch (e) { rej(new Error(b.slice(0, 200))); } }); });
    rq.on('error', rej); rq.setTimeout(t || 300000, () => rq.destroy(new Error('超时'))); rq.write(pl); rq.end();
  });
}
const ymd = d => d.getFullYear().toString() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
const ymdDash = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');

const PULL = (s, e) => `(async () => {
  const mtop = window.lib.mtop;
  const TGT = { chat:'咨询量', order:'订单量' };
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const q = async extra => {
    const req = Object.assign({ pageNum:1, pageSize:100, campaignStatus:[], statusGroup:[] }, extra||{});
    const r = await mtop.request({ api:'mtop.taobao.idle.ad.campaign.search', v:'1.0', type:'GET', data:{ requestJson: JSON.stringify(req) } });
    if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS')===0)) throw { ret: r && r.ret };
    return ((r.data||{}).result)||[];
  };
  const range = await q({ startDate:'${s}', endDate:'${e}', includeEndDate:true });
  const today = await q({});
  const tmap = {}; today.forEach(c => tmap[String(c.campaignId)] = c);
  const rows = range.map(c => {
    const d = c.adDataDetailVO || {}; const t = tmap[String(c.campaignId)] || {}; const it = t.infoTab || {};
    return { id:String(c.campaignId), name:c.title, target:TGT[c.bidTarget]||c.bidTarget,
      花费:n(d.cost)/100, 咨询:n(d.chatPv), 下单:n(d.payPv), 支付额:n(d.payAmount)/100,
      今日:n(it.todayCost)/100, pause:String(c.pauseStatus||'') };
  });
  return JSON.stringify({ rows, 时刻: new Date().toLocaleString('zh-CN') });
})()`;

(async () => {
  const now = new Date();
  const start = new Date(now.getTime() - 6 * 86400000);
  log('=== 写日报 (dry=' + DRY + ') ===');

  await post('/api/agent/eval-on-store', { store: STORE, code: 'location.href="https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage"; "ok"' }, 60000);
  await new Promise(r => setTimeout(r, 16000));
  const r = await post('/api/agent/eval-on-store', { store: STORE, code: PULL(ymd(start), ymd(now)) });
  if (!r.ok) { log('❌ 拉取失败: ' + r.error); process.exit(1); }
  const data = typeof r.result === 'string' ? JSON.parse(r.result) : r.result;
  const rows = data.rows || [];
  log('拉到 ' + rows.length + ' 条计划');

  const sum = k => rows.reduce((a, x) => a + (x[k] || 0), 0);
  const 花费 = +sum('花费').toFixed(2), 咨询 = sum('咨询'), 下单 = sum('下单'), 支付额 = +sum('支付额').toFixed(2);
  const 单次 = 咨询 > 0 ? +(花费 / 咨询).toFixed(2) : 0;
  const 超标 = rows.filter(x => x.咨询 >= 5 && x.花费 / x.咨询 > 4).map(x => x.name + ' ¥' + (x.花费 / x.咨询).toFixed(2) + '/咨询');
  const 状态 = 单次 <= 4 ? '正常' : '超标';
  const top = rows.slice().sort((a, b) => b.花费 - a.花费).slice(0, 5)
    .map(x => x.name + ' ¥' + x.花费.toFixed(0) + '/' + x.咨询 + '咨询').join('；');
  const 明细 = 'Top5 ' + top + (超标.length ? ' ｜ ⚠超标: ' + 超标.join('、') : '') + ' ｜ 合计' + rows.length + '条计划';

  const values = { 日期: ymdDash(now), 花费: String(花费), 咨询: String(咨询), 单次咨询成本: String(单次), 下单: String(下单), 支付额: String(支付额), 状态, 明细 };
  log('汇总: ' + JSON.stringify(values));

  if (DRY) { log('[--dry] 不写入表格'); process.exit(0); }

  // 幂等：同一天已有行就更新，不重复追加
  const exist = sheet.listRows('日报').filter(x => {
    const v = x.values || {}; const t = v['日期'];
    const txt = Array.isArray(t) ? (t[0] && t[0].text) : t;
    return String(txt) === ymdDash(now);
  })[0];
  if (exist) {
    const u = sheet.updateRow('日报', exist.record_id, values);
    log('已有当天行 ' + exist.record_id + '，已更新');
  } else {
    const w = sheet.addRow('日报', values);
    log('已新增当天行');
  }
  log('=== 完成 ===');
})().catch(e => { log('❌ ' + (e && e.message || e)); process.exit(1); });
