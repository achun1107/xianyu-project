﻿# wecom-send.ps1 -- reusable WeCom sender.
#
# WHY this exists: calling wecom-cli.cmd straight from Node's execFileSync does NOT work in this
# environment (no output, exit status null -> silent failure). PowerShell's `& $cli ... --set
# "markdown.content=$content"` with $content read from a UTF-8 file IS the proven path
# (ad-balance-duty.ps1 has been using it successfully).
#
# ASCII-only on purpose: .ps1 with Chinese needs UTF-8 BOM, which the editor strips.
#
# Usage:
#   powershell -File wecom-send.ps1 -File <utf8-md-path> [-Chat <chat-id>] [-DryRun]
# Exit: 0 = sent ok, 2 = file missing, 3 = send failed.

param(
  [Parameter(Mandatory=$true)][string]$File,
  [string]$Chat = '',
  [switch]$DryRun
)

$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'lib\ps\Config.ps1')
# param() defaults run before the script body, where Get-XyPath is not defined yet,
# so an explicit -Chat wins and everything else falls back to config.
if (-not $PSBoundParameters.ContainsKey('Chat')) { $Chat = Get-XyPath 'wecom.chatId' }
# 【2026-10-08 改】原来这里兜底到老板的企微群 id 字面量。分发版绝不能带 ——
# 学员机器上没配 wecom.chatId 时，绝不能把消息发进老板的群。读不到就直接失败退出。
if (-not $Chat) { Write-Host '[wecom-send] config.local.json 里没有 wecom.chatId，无法发送。'; exit 2 }
$marker = Join-Path (Get-XyPath 'paths.work') '!企微发送失败.txt'
$cli = Get-XyPath 'node.wecomCli'

if (-not (Test-Path $File)) { Write-Host "wecom-send: file not found: $File"; exit 2 }
$content = Get-Content $File -Raw -Encoding UTF8
if (-not $content -or $content.Trim().Length -eq 0) { Write-Host "wecom-send: empty content"; exit 2 }

if ($DryRun) { Write-Host ("wecom-send: DRY RUN, " + $content.Length + " chars -> " + $Chat); exit 0 }

$out = & $cli message aibot send --chat-id $Chat --msg-type markdown --set "markdown.content=$content" 2>&1 | Out-String
$out = $out.Trim()

if ($out -match '"success"\s*:\s*true' -or $out -match '"errcode"\s*:\s*0') {
  # Clear the Desktop fallback as well (2026-10-14) - its existence means "sending is broken".
  $deskAlert = Join-Path ([Environment]::GetFolderPath('Desktop')) '!XIANYU-ALERT-ACTION-NEEDED.txt'
  if (Test-Path $deskAlert) { Remove-Item $deskAlert -Force -ErrorAction SilentlyContinue }
  if (Test-Path $marker) {
    Remove-Item $marker -Force -ErrorAction SilentlyContinue
    Write-Host 'wecom-send: OK (cleared failure marker)'
  } else {
    Write-Host 'wecom-send: OK'
  }
  exit 0
}

# ---- failure path ----
# Rationale (2026-09-27): WeCom cannot report its own outage. ad-balance-duty.ps1 alerts on
# READ failures via WeCom -- useless when the SEND path is dead. That outage ran silently for
# ~10 hours (08:00-18:00, four missed broadcasts) because nothing outside WeCom noticed.
# So: leave a marker file whose EXISTENCE means "sending is currently broken".
$stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
$errcode = ''
if ($out -match '"errcode"\s*:\s*(\d+)') { $errcode = $Matches[1] }
# 【2026-10-08 改】这里原来把 $Chat 原文写进标记文件 —— 而那个文件【没被 gitignore 挡住】
# （.gitignore 那行以 `!` 开头，被 git 当成"反忽略"语法，匹配不到这个文件名），
# 于是每次发送失败都在往仓库里写一条群 id。聊天 id 不该出现在任何可能被提交的文件里。
Add-Content -Path $marker -Value ("$stamp  send failed  errcode=$errcode  chat=已脱敏") -Encoding UTF8
Write-Host ('wecom-send: FAILED :: errcode=' + $errcode + '  (marker written: ' + $marker + ')')

# ---- Desktop fallback FILE, added 2026-10-14 ----
# WHY: the toast below lasts 6 seconds and only helps if someone happens to be looking at the
# screen. The 850003 outage ran 2026-10-08 -> 2026-10-14 (a full week, ~30 failed broadcasts)
# with ZERO human notice, and on 2026-10-14 the ad account hit a zero balance while the
# breakers kept firing into that dead channel. A file that stays on the Desktop until a send
# succeeds is the version a human cannot miss. Existence of the file == sending is broken.
# ASCII-only CODE on purpose - the payload is the already-UTF-8 alert body, echoed verbatim.
try {
  $deskAlert = Join-Path ([Environment]::GetFolderPath('Desktop')) '!XIANYU-ALERT-ACTION-NEEDED.txt'
  if ($deskAlert -and (Test-Path (Split-Path $deskAlert))) {
    $head = "WeCom push FAILED at $stamp (errcode=$errcode)." + "`r`n" +
            "The alert below was NOT delivered - the WeCom robot authorization has expired." + "`r`n" +
            "This file deletes itself automatically once a send succeeds." + "`r`n" +
            "-------------------------------------------------------------" + "`r`n"
    Set-Content -Path $deskAlert -Value ($head + $content) -Encoding UTF8
    Write-Host ('wecom-send: desktop fallback written: ' + $deskAlert)
  }
} catch {
  Write-Host 'wecom-send: (desktop fallback file unavailable)'
}

# Desktop balloon so a human notices without opening any file. Best-effort only.
try {
  Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
  $ni = New-Object System.Windows.Forms.NotifyIcon
  $ni.Icon = [System.Drawing.SystemIcons]::Warning
  $ni.BalloonTipTitle = 'WeCom send FAILED'
  $ni.BalloonTipText = ('errcode ' + $errcode + ' - broadcasts are NOT being delivered.')
  $ni.Visible = $true
  $ni.ShowBalloonTip(15000)
  Start-Sleep -Seconds 6
  $ni.Dispose()
} catch {
  Write-Host 'wecom-send: (desktop toast unavailable, marker file is the signal)'
}

Write-Host ('wecom-send: raw :: ' + $out.Substring(0, [Math]::Min(900, $out.Length)))
exit 3
