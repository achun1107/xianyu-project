/**
 * ad-editor-run.js —— 批量「给已存在的擦亮计划增加宝贝」（驱动 ad-editor.js）
 *
 * 为什么需要它：ad-editor.js 只会干活，cfg 要从 window.__ECFG 注入，
 *   而在此之前没有对应的运行器（run-cfgs.js 是给【新建】计划用的 ad-driver.js）。
 *
 * 用法:
 *   EDIT_CFGS_JSON=<配置文件> node ad-editor-run.js [from] [to]
 *
 * 配置文件（数组），每项：
 *   { planName, searchKey, addItems:["itemId"], keepImprove:120, submit:false }
 *   · planName 必须能在计划列表里唯一匹配到（脚本按行文本包含匹配）
 *   · keepImprove 是「保持这个预计提升%」，所以不会动现有出价
 *   · submit:false 先干跑，确认找到宝贝、选的个数对，再改 true 真提交
 *
 * 与 run-cfgs.js 一样先干跑后真跑：ad-editor 打开编辑抽屉会【提交全部字段】，
 * 所以提交前必须把 目标/出价/预算 读回来核对（脚本内部有回读，见 ad-editor.js）。
 *
 * 【2026-10-09 修·真实事故】原来这里跳转是 `location.href=...` + 盲睡 17 秒。
 *   当**另一个会话**同时在用同一个浏览器时（实测：另一会话在跑 tools/preset-export.js，
 *   它会反复把店页导航到 /publish?itemId=xxx 读真实字段），两次运行都报
 *   "Execution context was destroyed, most likely because of a navigation"，重试也一样 ——
 *   因为盲睡结束时页面可能正好在导航中。
 *   修法两条：
 *     ① 不再盲睡，改成【轮询等到位】：href 含 dayu.goofish.com 且计划表渲染出行数 > 0；
 *     ② driver 失败且是「上下文被销毁」这类可恢复错误时，重新导航 + 重注入 cfg 再试，
 *        最多 3 次 —— 抢浏览器是外部状态，重试是唯一正确的应对。
 */
const http = require('http');
const fs = require('fs');
const { SVC, STORE } = require('./lib/env');

const KEY = SVC.apiKey;
const URL = 'https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage';

const CFGS = process.env.EDIT_CFGS_JSON
  ? JSON.parse(fs.readFileSync(process.env.EDIT_CFGS_JSON, 'utf8'))
  : [];
if (!CFGS.length) { console.log('用法: EDIT_CFGS_JSON=<配置文件> node ad-editor-run.js [from] [to]'); process.exit(2); }
const LOG = process.env.EDIT_CFGS_LOG || 'D:\\DSH\\achun\\ad-editor-log.ndjson';
const MAX_TRY = Number(process.env.EDIT_TRIES || 3);

function ev(code, timeoutMs) {
  return new Promise((resolve) => {
    const payload = JSON.stringify({ store: STORE, code });
    const req = http.request({ host: '127.0.0.1', port: SVC.port, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: b.slice(0, 300) }); } }); });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.setTimeout(timeoutMs || 240000, () => req.destroy(new Error('超时')));
    req.write(payload); req.end();
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function log(o) { fs.appendFileSync(LOG, JSON.stringify({ ts: new Date().toISOString(), ...o }) + '\n', 'utf8'); }

/** 可恢复错误：页面在我们眼皮底下被导航走了（通常是并发会话干的），重试就行 */
const RECOVERABLE = /Execution context was destroyed|Execution context is not available|Target closed|Navigation failed|Cannot find context/i;

const STATE = `JSON.stringify({href:location.href, rows:document.querySelectorAll('tbody tr').length, ready:document.readyState})`;

/** 导航到广告后台，并轮询等到「真的在那儿且表格渲染出来了」 */
async function enterAdConsole(label) {
  for (let i = 0; i < 6; i++) {
    await ev(`(function(){location.href=${JSON.stringify(URL)};return 'nav'})()`, 90000).catch(() => {});
    for (let k = 0; k < 14; k++) {
      await sleep(2500);
      const r = await ev(STATE, 30000);
      if (!r.ok) continue;                       // 正在导航 → 下一轮
      let s; try { s = typeof r.result === 'string' ? JSON.parse(r.result) : r.result; } catch (e) { continue; }
      if (s && String(s.href).indexOf('dayu.goofish.com') >= 0 && s.rows > 0) {
        console.log(`  已到广告后台（${s.rows} 行，第 ${i + 1} 次尝试）`);
        return true;
      }
    }
    console.log(`  第 ${i + 1} 次导航没到位（页面可能被并发会话抢走），重来`);
    await sleep(4000);
  }
  return false;
}

(async () => {
  const from = Number(process.argv[2] || 0), to = Number(process.argv[3] || CFGS.length);
  // 驱动器可换：添加用 ad-editor.js（__ECFG），移除用 ad-editor-remove.js（__RCFG_REMOVE）
  const DRIVER_FILE = process.env.EDIT_DRIVER || 'ad-editor.js';
  const GLOBAL_NAME = process.env.EDIT_GLOBAL || 'window.__ECFG';
  const DRIVER = fs.readFileSync(__dirname + '\\' + DRIVER_FILE, 'utf8');
  console.log('驱动器: ' + DRIVER_FILE + '   注入到: ' + GLOBAL_NAME);
  for (let i = from; i < to; i++) {
    const c = CFGS[i];
    console.log(`\n───── [${i + 1}/${CFGS.length}] ${c.planName}  加 ${(c.addItems || []).length} 个宝贝  提交=${!!c.submit} ─────`);

    let j = null;
    for (let attempt = 1; attempt <= MAX_TRY && !j; attempt++) {
      if (!(await enterAdConsole(c.planName))) {
        console.log('  ❌ 进不去广告后台（页面一直被占），放弃本项');
        log({ i, name: c.planName, step: 'nav', err: '进不去广告后台' });
        break;
      }
      const rc = await ev(`${GLOBAL_NAME}=${JSON.stringify(c)}; 'set'`);
      if (!rc.ok) {
        console.log('  cfg 失败 ' + rc.error + (RECOVERABLE.test(String(rc.error)) ? ' → 重试' : ''));
        if (!RECOVERABLE.test(String(rc.error))) { log({ i, name: c.planName, step: 'cfg', err: rc.error }); break; }
        continue;
      }
      const rd = await ev(DRIVER);
      if (!rd.ok) {
        const e = String(rd.error || '');
        if (RECOVERABLE.test(e) && attempt < MAX_TRY) { console.log(`  driver 被导航打断（第 ${attempt} 次），重试`); await sleep(6000); continue; }
        console.log('  driver 失败 ' + e);
        log({ i, name: c.planName, step: 'driver', err: e, attempt });
        break;
      }
      try { j = typeof rd.result === 'string' ? JSON.parse(rd.result) : rd.result; } catch (e) {
        console.log('  解析失败: ' + String(rd.result).slice(0, 300)); log({ i, name: c.planName, step: 'parse', raw: String(rd.result).slice(0, 400) }); break;
      }
    }
    if (!j) continue;

    console.log('  编辑前: 宝贝 ' + (j.beforeBadge || '?') + '，预计提升 ' + (j.beforeImprove || '?') + '%');
    console.log('  已加: ' + JSON.stringify(j.added || []) + '   没找到: ' + JSON.stringify(j.notFound || []));
    console.log('  编辑后: 宝贝 ' + (j.afterBadge || '?') + '，预计提升 ' + (j.afterImprove || '?') + '%');
    if (j.readback) console.log('  回读: ' + JSON.stringify(j.readback));
    // 注意：ad-editor*.js 落的是 R.saved，不是 R.submitted —— 早先这里只读 submitted，
    // 结果真保存了也显示「提交 —」，会让人以为没存（差点据此重复提交）。
    if (j.selfCheckPassed !== undefined) console.log('  自检 ' + (j.selfCheckPassed ? '✅' : '❌') + '   保存 ' + ((j.saved || j.submitted) ? '✅' : '—'));
    (j.steps || []).forEach((s) => console.log('    · ' + s));
    (j.errors || []).forEach((s) => console.log('    ❌ ' + s));
    if (j.fatal) console.log('  FATAL: ' + j.fatal);
    if (j.aborted) console.log('  ABORTED: ' + j.aborted);
    if (j.afterSubmit && j.afterSubmit.toast) console.log('  提示: ' + JSON.stringify(j.afterSubmit.toast));
    log({ i, name: c.planName, addItems: c.addItems, added: j.added || null, notFound: j.notFound || null,
      before: j.beforeBadge || null, after: j.afterBadge || null,
      impBefore: j.beforeImprove || null, impAfter: j.afterImprove || null,
      submitted: !!j.submitted, saved: !!j.saved, check: !!j.selfCheckPassed, fatal: j.fatal || null, aborted: j.aborted || null });
    await sleep(2000);
  }
  console.log('\n本批完成，日志: ' + LOG);
})().catch((e) => { console.error('FAIL ' + (e && e.stack || e)); process.exit(1); });
