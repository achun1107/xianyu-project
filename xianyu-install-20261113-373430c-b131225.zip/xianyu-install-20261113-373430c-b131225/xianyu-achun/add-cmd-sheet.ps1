﻿# add-cmd-sheet.ps1 -- 给已建的智能表格加一个「指令」子表
$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'lib\ps\Config.ps1')
$cli = Get-XyPath 'node.wecomCli'
$doc = 's3_AFkAkHiaACACNSDqvaudRQO00Ay4z_a'
$outFile = Join-Path (Get-XyPath 'paths.work') 'ss-addcmd-out.txt'

$title = [System.IO.File]::ReadAllText((Join-Path (Get-XyPath 'paths.work') 'ss-cmdsheet.txt'), [Text.Encoding]::UTF8).Trim()
$raw = [System.IO.File]::ReadAllText((Join-Path (Get-XyPath 'paths.work') 'ss-fields-cmd-min.json'), [Text.Encoding]::UTF8).Trim()
$f1 = $raw -replace '"', '\"'

$log = @()
$log += 'sheet-title=' + $title
$o = & $cli smartsheet sheets add --docid $doc --type add --sheet-title $title --fields $f1 2>&1 | Out-String
$log += $o.Trim()
[System.IO.File]::WriteAllText($outFile, ($log -join "`r`n"), [Text.Encoding]::UTF8)
Write-Host ('written: ' + $outFile)
