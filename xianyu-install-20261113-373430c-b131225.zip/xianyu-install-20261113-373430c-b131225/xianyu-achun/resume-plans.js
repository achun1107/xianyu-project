/**
 * resume-plans.js — 按 campaignId 精确恢复（对称于 pause-plans.js，用于「客服上班时恢复推广」）
 *
 * 为什么需要它：现有的 ad-resume-all.js 是【恢复全部暂停的】，
 *   会把 PAUSE-ADS 暂停的那 6 个计划一起恢复 —— 不是我们要的。
 *
 * 安全护栏（与 pause-plans.js 一致）：目标里只要有名字以「擦亮宝贝」开头的
 *   （主/副集合计划），整体中止 —— 主/副集合永不由脚本自动恢复。
 *
 * 用法: node resume-plans.js <id> [<id>...]
 */
const http = require('http'), fs = require('fs');
const { STORE, SVC } = require('./lib/env');
const KEY = SVC.apiKey;
const IDS = process.argv.slice(2).filter((a) => /^\d+$/.test(a));
if (!IDS.length) { console.log('用法: node resume-plans.js <id...>'); process.exit(2); }

function ev(code) {
  return new Promise((r) => {
    const p = JSON.stringify({ store: STORE, code });
    const q = http.request({ host: '127.0.0.1', port: SVC.port, path: '/api/agent/eval-on-store', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(p), 'x-api-key': KEY } },
      (res) => { let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => { try { r(JSON.parse(b)); } catch (e) { r({ ok: false, error: b.slice(0, 300) }); } }); });
    q.on('error', (e) => r({ ok: false, error: e.message })); q.write(p); q.end();
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const inner = `(async () => {
  const mtop = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const TARGETS = ${JSON.stringify(IDS)};
  const search = async () => {
    const r = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
    return (r.data || {}).result || [];
  };
  const out = { 时刻: new Date().toLocaleString('zh-CN'), 动作: '恢复' };
  const before = await search();
  const found = TARGETS.map(id => before.find(c => String(c.campaignId) === String(id))).filter(Boolean);
  out.找到 = found.length;
  out.未找到 = TARGETS.filter(id => !before.some(c => String(c.campaignId) === String(id)));

  // 🚫 护栏：主/副集合（擦亮宝贝*）一律不动
  const coll = found.filter(c => /^擦亮宝贝/.test(c.title || ''));
  if (coll.length) {
    out.中止 = '目标里含主/副集合计划，已整体中止';
    out.集合计划 = coll.map(c => c.campaignId + ' ' + c.title);
    return JSON.stringify(out, null, 1);
  }

  out.目标明细 = found.map(c => ({
    id: c.campaignId, name: c.title, 目标: c.bidTarget, 出价: n(c.cpm) / 100, 预算: n(c.maxDayBudget) / 100,
    商品: (c.entityList || []).map(e => e.entityId).join(','),
    恢复前状态: c.pauseStatus, 创意优化: String(c.creativeOptSwitch),
  }));
  const ids = found.filter(c => String(c.pauseStatus) === '1').map(c => String(c.campaignId));
  out.将恢复 = ids.length;
  if (!ids.length) { out.结果 = '本来就都在跑'; return JSON.stringify(out, null, 1); }

  const pr = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.pause', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ campaignIds: ids, pauseStatus: 0 }) } });
  out.平台返回 = (pr.ret || [])[0];
  let ok = 0;
  Object.keys(pr.data || {}).forEach(k => { if ((pr.data[k] || {}).pauseStatus === 0) ok++; });
  out.平台确认恢复数 = ok;

  await sleep(7000);
  const after = await search();
  out.恢复后校验 = TARGETS.map(id => {
    const c = after.find(x => String(x.campaignId) === String(id));
    return c ? { id, name: c.title, pauseStatus: c.pauseStatus, 已恢复: String(c.pauseStatus) === '0' } : { id, 不存在: true };
  });
  out.全店 = { 计划数: after.length, 在跑: after.filter(c => c.statusGroup === 'online').length };
  out.结果 = out.恢复后校验.every(x => x.已恢复 || x.不存在) ? '✅ 目标计划已全部恢复' : '⚠ 仍有未恢复的';
  return JSON.stringify(out, null, 1);
})()`;

(async () => {
  console.log('目标(恢复): ' + IDS.join(', ') + '\n');
  await ev(`(function(){location.href='https://dayu.goofish.com/?site=FISHAD#/ad/polish/campaign-manage';return 'n'})()`);
  await sleep(16000);
  const r = await ev(inner);
  if (!r.ok) { console.log('ERR ' + r.error); process.exit(1); }
  const d = typeof r.result === 'string' ? JSON.parse(r.result) : r.result;
  console.log(JSON.stringify(d, null, 1));
  fs.writeFileSync('D:\\DSH\\achun\\resume-result-' + Date.now() + '.json', JSON.stringify(d, null, 1), 'utf8');
})();
