# 中台（MUSE AV）账号 与 Key 对照

> 记录时间：2026-09-28 凌晨
> 起因：查「我的闲鱼出图模板怎么上传到中台」时，发现本机存在**两把不同的 key、两个账号**，
> 且过去一直混用，导致「共享版式到中台」按钮静默失效。

## 一、两个账号（都是本人的）

| | 邮箱 | 昵称 | 账号 id | 角色 | credits | brand |
|---|---|---|---|---|---|---|
| **管理员号** | `<见 playwright-service/service.local.json: hymUser>` | 潘春兴 | `b48164c7-6a1d-4c58-9150-39d65af3f4bb` | **admin** | 1361 | — |
| **租户号** | `achun0511@gmail.com` | 阿春 | `39c89b90-bd59-4aaf-9b64-6a8fcd65ae02` | user | 105 | **好易美** |

两个账号在**同一个租户** `<见 config.local.json: middle.tenant>` 里。

## 二、两把 key 分别在哪儿用

| 位置 | 文件 | 是哪把 | 说明 |
|---|---|---|---|
| 发布台服务端 | `…\playwright-service\server.js` → `HYM_KEY` | **租户号** `sk-studio-0e6c…0113e` | 2026-09-28 换的（原来那把 401） |
| 本机 museav CLI | `~/.museav.json` → `apiKey` | **租户号** `sk-studio-0e6c…0113e` | 2026-09-28 换的；备份在 `.museav.json.bak-*` |

> 曾经：CLI 用**管理员号**的 key。那把 key **「未识别租户身份」**，
> 读版式库直接报错，导致发布台「☁️ 共享版式到好易美后台」按钮**一直是坏的**。

## 三、两把 key 的能力差异（实测）

| 调用 | 管理员 key | 租户 key |
|---|---|---|
| `/api/me` | ✅ 200 | ✅ 200 |
| `/api/poster-templates`（版式库） | ❌ **401** | ✅ 200 |
| `museav poster-templates` | ❌ 未识别租户身份 | ✅ 列出 5 个 |
| `museav templates` | ✅ 114 | ✅ 114 |
| `museav projects` | ✅ 2 个工作区 | ⚠️ **一个都没有** |

**结论：凡是跟「版式 / 工作区」有关的，必须用租户 key。**

## 四、中台的两套模板机制（别再混）

| | 版式模板 `poster-templates` | 图片/文字模板 `templates` |
|---|---|---|
| 本质 | **封面底图（焊死）+ 固定 prompt** | 带**字段**的可复用模板 |
| 中台现有 | **6 个**（见下） | **114 个** = 98 平台 + **16 租户** |
| 变量 | 只有 `{城市}` `{明星}` | 任意，如 `artist, theme, city, style` |
| 在你的中台 UI 里 | 菜单大概叫【版式 / 版式模板】 | 【我的模板】← **就是这里，你点的地方** |
| 你名下 | — | **0 条**（所以「我的模板」是空的，不是你没建对） |

**当前 6 个版式**：

| id | 名称 | created_by |
|---|---|---|
| `396f670d-d969-422a-afdb-f72844126aac` | **白底红字版**（2026-09-28 推，见 §八） | ★ **租户号（你本人）** |
| `4edcf6ba-6b3a-4194-ac06-0d835c28614c` | 三黄块+一紫块版式 | 管理员号 |
| `19263c7a-2a9c-4d1e-b332-923bedbfa788` | 版式3 |
| `ad5213c5-d633-4ee0-99e0-b2b59f80c386` | 四横幅紫块（**图生模板逆向**出来的） |
| `52ed80e3-7c09-47e2-bb2a-45d770bceab2` | 首开紫块 |
| `e450904d-c199-44c5-b458-5c65b67a7c54` | 徐良版式 |

**16 个租户级图片模板**（字段都是 `artist, theme, city, style`，演唱会/代拍场景）：
拉群1~4、【侧脸/正脸+话筒】【贴图】右下-【人名主题】左上-【城市日期】左下、
粉丝见面会、明星宣讲会/发布会、品牌活动官宣海报、电影路演海报、招抢手招聘海报(+生图)、
演唱会巡演海报、小红书模板、高端时尚编辑海报、东方电影感·临窗回眸、真人感·纪实人像、高端护肤品商品图。

## 五、已知的中台 CLI bug

- `museav templates --tenant`（本租户）→ 返回「没有可用模板」，但列表里明明有 16 条标 `[租户]`。**过滤器坏了**，不是操作问题。
- `museav poster-templates` **只有 `add`，没有 `list`/`delete`**。所以：
  - 想看版式 → 直接跑 `museav poster-templates`（不带子命令）
  - **推上去就删不掉**（网页端能不能删没验证）→ 别拿真名做测试

## 六、常用命令

```bash
museav whoami                  # 当前身份（注意看是哪个账号）
museav poster-templates        # 列版式库（5 个）
museav templates               # 列图片/文字模板（114 个）
museav projects                # 列工作区（租户号下没有）

# 推一个版式到中台（这是「上传」的正解）
museav poster-templates add "底图.jpg" --name "版式名" --prompt "竖版{城市}{明星}演唱会..."

# 用字段化模板出图
museav gen --template <模板id> --fields '{"artist":"刘宪华","city":"北京"}'
```

## 七、还没解决的

- 5 个版式里**没有一个带「底图来源逻辑」**——中台的数据结构（8 个字段：`id/tenant_id/name/r2_key/prompt/created_by/created_at/url`）**根本放不下**这种逻辑，只能把来源写成 prompt 里的自然语言（「背景为{明星}{城市}演唱会官方海报」）。抓图/级联/兜底那套代码只存在于本机 `server.js`。
- ~~本地版式 `tpl_redtext`（白底红字版）没有底图文件，推不上中台~~ → **已解决，见 §八**。
- 底图目录 `assets/templates/` 里有 4 张**孤儿图**：`shoukai-v1.jpg`、`yikai-v1.jpg`、`tpl_mt7fdi08.jpg`、`tpl_mt8rix1n.jpg` —— 有图但 `poster-templates.json` 里没条目，发布台下拉里看不到。

## 八、「白底红字版」推送记录（2026-09-28）

**需求**：底图走「底图来源」逻辑，用户只填城市+明星就出图 → 做成中台版式。

**脚本**：`D:\DSH\achun\push-redtext.js`（`--check` 只查不推）

**四步**：

1. **生成封面** —— `gen-redtext-cover.js` → `make-covers.js`（杭州/那英）
   调 `/api/poster/make` 走**底图来源级联**（大麦→其他城市→猫眼/微博→AI兜底），拿到**大麦官方海报**当垫图，
   再用发布台同款 `_iwApplyText` 把 `tpl_redtext` 的 5 个文字层烧上去
   → `主图筛选-那英杭州/01-tpl_redtext-白底红字版.png`（1020×1360，`baseOrigin=damai`）
2. **封面固定** —— 复制到 `中台版式/tpl_redtext-封面.png`
3. **推送** —— `museav poster-templates add <封面> --name 白底红字版 --prompt "<来源+版式描述>"`
4. **回验** —— 封面 SHA256 `202002DB692EDFC7` 本地/中台**完全一致**；`{城市}`/`{明星}` 占位符未丢（描述 205 字）

**结果**：id `396f670d-d969-422a-afdb-f72844126aac`，`created_by` = **租户号（你本人）**
→ 这条**会出现在你自己的名下**（前 5 条都是管理员号建的）。

**为什么封面用「带字成品图」**：中台已有的「三黄块+一紫块版式」封面就是徐良官方海报 + 黄紫块烧字，
「成品图当封面」是本租户的既定约定，不是我自己定的。

### ⚠️ 必须知道的限制

中台版式**只有一张封面底图，没有抓取逻辑**。用这个版式出图时，中台是拿封面当**垫图**让 AI 重画，
**不会真去大麦搜海报**。prompt 里那句「背景为{明星}{城市}演唱会官方海报」是**给 AI 的提示词**，
不是可执行的抓取。

**要「真官方海报 + 白底红字」，必须走发布台的 `/api/poster/make` + `tpl_redtext`** —— 那条路才会真的搜。

### 踩过的坑

- **给 museav 传中文+空格，不要走 PowerShell**（会拆参数、吃引号）。正解是
  `execFileSync(node, [cliJs, 'poster-templates', 'add', 封面, '--name', 名称, '--prompt', 描述])`
  —— **数组参数直调 node，完全绕开 shell**。
  - node：`C:\Users\43462\.workbuddy\binaries\node\versions\22.22.2-3\node.exe`
  - cli ：`C:\Users\43462\.workbuddy\binaries\node\workspace\node_modules\museav-cli\dist\index.js`
- **`museav` 把成功消息写 stderr**，PowerShell 因此报 `exit code 1` —— **假报警**，看复核输出。
- **推之前必须查同名**：`poster-templates` 只有 `add`，没有 `delete`，重复推会产生重复项。

## 九、中台版式的正确用法（2026-09-28 实测跑通）

### 结论一：`gen --template` 不认版式

| 尝试 | 结果 |
|---|---|
| `museav gen --template <版式id>` | ❌ `模板不存在或已停用: 396f670d-…` |
| `museav gen --ref <图>` | ✅ 垫图上传成功（`图片1 就绪: …/refs/…`） |
| `museav gen --prompt <版式prompt替换占位符> --ref <底图>` | ✅ **出图成功**（30.6s，1 credit） |

`gen --template` 只认 `museav templates`（图片模板，114 个）的 id；
**版式模板（poster-templates）没有这个入口**，必须走 `--prompt`。

### 结论二：中台网页端干的事，手动复刻就三步

```bash
# 1. 取版式 prompt
GET https://manager.museav.top/api/poster-templates   → 找到目标 id 的 prompt
# 2. 把 {城市} {明星} 替换成实际值
# 3. 出图（--ref 就是底图）
museav gen --prompt "<替换后的 prompt>" --ref "<底图文件>" --ratio 3:4
```

脚本：`D:\DSH\achun\gen-with-poster-prompt.js <底图路径>`

**实测产物**：`https://img.webkubor.online/hym/generated/custom/2ad293dd-82d4-4312-b256-2af9390479bf.png`
（出图在 `/hym/generated/custom/` 下，垫图在 `/refs/` 下，两条路径别搞混）

### 结论三：三类底图来源 = 只换 `--ref`

| 来源 | `--ref` 传什么 |
|---|---|
| 搜索大麦 | 发布台 `/api/poster/make` 搜到的官方海报文件 |
| **用户中台出的图** | 中台出图 url → 下载成文件 |
| **用户上传的图** | 本地文件直接传 |

**这就解开了「底图来源逻辑传不进中台」的死结**：
逻辑（搜索/级联/兜底）**留在发布台**，搜到的图**当垫图送进中台**，中台用版式 prompt 排版。
不需要把逻辑塞进中台，中台只要能收垫图就够了。

### 结论四：发布台那条路是另一回事（别混）

`server.js` L2409-2418：当 `templateId` 在本地版式库里找不到时，发布台会去中台查同 id 版式，
**下载它的封面 url 当固定底图 —— prompt 被完全忽略**。

| | 底图 | prompt | 用途 |
|---|---|---|---|
| **发布台** `/api/poster/make` | 中台版式的**封面**（固定） | ❌ 忽略 | 把中台版式当"固定底图"用 |
| **中台** `gen --prompt --ref` | **任意垫图**（三类来源） | ✅ 用 | 真正按版式排版出图 |

### 已知问题

- prompt 里「⬆千好评」被 AI 画成了「**个**千好评」。建议改成「**3千+好评**」（跟「三黄块+一紫块版式」的写法一致）。
- 但版式**改不了也删不掉**（CLI 只有 add；条目级 API 落回 SPA HTML；网页端无删除按钮），
  要改只能**推一个新名字的条目**，旧的会一直留着。
- 单次出图成本 **1 credit**（租户号 105 → 104）。
