// ad-creative-toggle.js —— 在「计划详情」页把指定计划的「宝贝创意优化」关掉
// cfg = { planName }  ；window.__CTCFG
(async () => {
  const cfg = window.__CTCFG || {};
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const R = { plan: cfg.planName };
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const switches = () => [].slice.call(document.querySelectorAll('[role=switch], .ant-switch, button[class*=switch]'))
    .filter(e => e.getBoundingClientRect().height > 0);
  const stateOf = sw => String(sw.className).indexOf('checked') >= 0 || sw.getAttribute('aria-checked') === 'true';

  try {
    // 表格可能只渲染了一部分，且目标行可能不在第 1 页 → 先等渲染，再翻页找
    const findRow = () => [].slice.call(document.querySelectorAll('tbody tr'))
      .find(r => (r.innerText || '').indexOf(cfg.planName) >= 0);
    let row = null;
    for (let i = 0; i < 10 && !row; i++) { await sleep(1000); row = findRow(); }
    if (!row) {
      for (let p = 2; p <= 6 && !row; p++) {
        const pg = document.querySelector('.ant-pagination');
        const btn = pg && [].slice.call(pg.querySelectorAll('.ant-pagination-item'))
          .find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === String(p));
        if (!btn) break;
        click1(btn); await sleep(3500);
        row = findRow();
        R['翻到第' + p + '页'] = !!row;
      }
    }
    if (!row) {
      R.样例 = [].slice.call(document.querySelectorAll('tbody tr')).slice(0, 3).map(r => (r.innerText || '').replace(/\s+/g, ' ').slice(0, 50));
      throw new Error('找不到计划行');
    }
    const det = [].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '详情');
    if (!det) throw new Error('该行没有「详情」');
    click1(det);
    // 等详情页/抽屉出现「创意优化」
    let sw = null;
    for (let i = 0; i < 18; i++) {
      await sleep(1000);
      const body = document.body.innerText || '';
      if (!/创意优化/.test(body)) continue;
      const cands = switches().filter(s => {
        let p = s;
        for (let k = 0; k < 6 && p; k++) { p = p.parentElement; if (p && /创意优化/.test(p.innerText || '')) return true; }
        return false;
      });
      if (cands.length) { sw = cands[0]; R.等待秒数 = i + 1; break; }
    }
    R.url = location.href;
    R.找到开关 = !!sw;
    R.页面有创意优化字样 = /创意优化/.test(document.body.innerText || '');
    R.所有开关 = switches().map(s => ({ cls: String(s.className).slice(0, 70), checked: stateOf(s), 附近文本: (() => { let p = s; for (let k = 0; k < 5 && p; k++) { p = p.parentElement; if (p && (p.innerText || '').length < 60) return (p.innerText || '').replace(/\s+/g, ' ').trim(); } return ''; })() })).slice(0, 8);
    if (!sw) return JSON.stringify(R, null, 1);

    R.当前状态 = stateOf(sw) ? '已开启' : '未开启';
    if (stateOf(sw)) {
      click1(sw);
      await sleep(2500);
      // 确认弹窗
      const modal = [].slice.call(document.querySelectorAll('.ant-modal-content')).filter(m => m.getBoundingClientRect().width > 50).pop();
      R.弹窗文本 = modal ? (modal.innerText || '').replace(/\s+/g, ' ').slice(0, 160) : null;
      if (modal) {
        const ok = [].slice.call(modal.querySelectorAll('button,div,span'))
          .find(e => /确认关闭|确\s*定|确认/.test((e.innerText || '').trim()));
        R.点确认 = !!ok;
        if (ok) { click1(ok); await sleep(4000); }
      }
      await sleep(2500);
      const sw2 = switches().filter(s => { let p = s; for (let k = 0; k < 6 && p; k++) { p = p.parentElement; if (p && /创意优化/.test(p.innerText || '')) return true; } return false; })[0];
      R.关闭后状态 = sw2 ? (stateOf(sw2) ? '已开启' : '未开启') : '找不到开关';
      R.成功 = R.关闭后状态 === '未开启';
    } else { R.成功 = true; R.说明 = '本来就是关的'; }
    return JSON.stringify(R, null, 1);
  } catch (e) { R.fatal = e.message; return JSON.stringify(R, null, 1); }
})()
