﻿# 登录 WorkBuddy (CodeBuddy) CLI —— 登录完自动复测，窗口里直接出结论
#
# 为什么需要这个脚本：CLI 的登录只有交互式 /login 一条路（完整 --help 里没有任何
# API key / token 参数），而交互式 TUI 必须在【真实终端】里跑。
# 之前失败了两次，都是"窗口关了但不知道登录成没成"，所以这里加自动复测。

$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
try { $OutputEncoding = [Text.Encoding]::UTF8 } catch { }

# 不写死 node 版本号：CodeBuddy 自动升级会把 versions\<ver> 改名成 .<ver>.deleting.*
# （2026-10-02 和 2026-10-08 各踩过一次，表现是"脚本直接找不到路径"）。
# 靠 versions\current 这个装着版本号的普通文本文件解析，与 run-node.cmd 同一套规则。
$versionsDir = if ($env:XY_NODE_VERSIONS) { $env:XY_NODE_VERSIONS }
               else { Join-Path $env:USERPROFILE '.workbuddy\binaries\node\versions' }
$ver = $null
$curFile = Join-Path $versionsDir 'current'
if (Test-Path $curFile) {
    try {
        $v = ([System.IO.File]::ReadAllText($curFile)).Trim()
        if ($v -and (Test-Path (Join-Path $versionsDir "$v\node.exe"))) { $ver = $v }
    } catch { }
}
if (-not $ver) {
    $hit = Get-ChildItem $versionsDir -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -notlike '.*' -and $_.Name -ne 'locks' } |
        Sort-Object LastWriteTime -Descending |
        Where-Object { Test-Path (Join-Path $_.FullName 'node.exe') } |
        Select-Object -First 1
    if ($hit) { $ver = $hit.Name }
}
if (-not $ver) { Write-Host "❌ 找不到可用的 node 版本目录：$versionsDir"; exit 1 }

$node = Join-Path $versionsDir "$ver\node.exe"
$cli  = Join-Path $versionsDir "$ver\node_modules\@tencent-ai\codebuddy-code\bin\codebuddy"
# 本脚本所在仓库根（不再写死盘符）
$work = Split-Path -Parent $PSScriptRoot
$cfg  = Join-Path $env:USERPROFILE '.codebuddy'

Write-Host ''
Write-Host '============================================================'
Write-Host '  WorkBuddy (CodeBuddy) CLI  登录'
Write-Host '============================================================'
Write-Host ''
Write-Host '  接下来在这个窗口里操作：'
Write-Host ''
Write-Host '    1) 等出现 CodeBuddy 的横幅或输入框'
Write-Host '    2) 输入        /login        然后回车'
Write-Host '    3) 按提示在浏览器里授权（用你的 CodeBuddy 账号）'
Write-Host '    4) 登录成功后退出 CLI：输入 /exit，或按 Ctrl+C'
Write-Host ''
Write-Host '  退出后本脚本会自动复测一次登录态，结论打在下面。'
Write-Host ''
Write-Host '------------------------------------------------------------'
Write-Host ''

Set-Location $work
& $node $cli
$cliCode = $LASTEXITCODE

Write-Host ''
Write-Host '------------------------------------------------------------'
Write-Host ("  CLI 已退出（退出码 {0}）—— 正在复测登录态，请稍候…" -f $cliCode)
Write-Host ''

$before = @(Get-ChildItem $cfg -Recurse -File -Force -ErrorAction SilentlyContinue).Count
$out = & $node $cli -p "Reply with exactly: AUTH-OK" --permission-mode acceptEdits --output-format text 2>&1 | Out-String
$after = @(Get-ChildItem $cfg -Recurse -File -Force -ErrorAction SilentlyContinue).Count

Write-Host '================= 复测结果 ================='
if ($out -match 'AUTH-OK') {
    Write-Host '  [成功] 登录已生效，WorkBuddy 现在可以被调用了。'
    Write-Host '         回去跟 AI 说一声「登录好了」，它会立刻开始派活。'
} elseif ($out -match 'Authentication required') {
    Write-Host '  [失败] 仍是 Authentication required，登录没落盘。'
    Write-Host ''
    Write-Host '  请把上面 CLI 窗口里的内容（尤其是 /login 之后的报错）'
    Write-Host '  复制或截图给 AI —— 它需要错误原文才能判断卡在哪。'
} else {
    Write-Host '  [不确定] 复测输出不认识，原文如下：'
    Write-Host ''
    Write-Host $out
}
Write-Host ''
Write-Host ("  .codebuddy 文件数：{0} -> {1}（有变化说明确实写了东西）" -f $before, $after)
Write-Host '============================================'
Write-Host ''
Write-Host '  这个窗口先别关，方便复制上面的内容。'
Write-Host ''
