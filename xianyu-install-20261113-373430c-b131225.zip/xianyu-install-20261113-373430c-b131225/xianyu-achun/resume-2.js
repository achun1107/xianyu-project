// resume-2.js —— 试着恢复卡在「部分商品因状态异常」的两个计划
(async () => {
  const m = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const IDS = ['97154637', '97388704'];   // 北京陈都灵-咨询120 / 成都熊艺文-咨询120

  const search = async () => {
    const r = await m.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
    return (r.data || {}).result || [];
  };
  const before = await search();
  const out = {
    时刻: new Date().toLocaleString('zh-CN'),
    恢复前: before.filter(c => IDS.indexOf(String(c.campaignId)) >= 0).map(c => ({
      id: c.campaignId, name: c.title, pause: c.pauseStatus, group: c.statusGroup,
      说明: c.statusDescTitle || '-', 宝贝: (c.entityList || []).map(e => String(e.entityId)),
    })),
  };

  const pr = await m.request({ api: 'mtop.taobao.idle.ad.campaign.pause', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ campaignIds: IDS, pauseStatus: 0 }) } });
  out.平台返回 = (pr.ret || [])[0];
  out.返回明细 = {};
  Object.keys(pr.data || {}).forEach(k => {
    const v = pr.data[k] || {};
    out.返回明细[k] = { pauseStatus: v.pauseStatus, group: v.statusGroup, 说明: v.statusDescTitle || '-' };
  });

  for (const w of [8, 20, 40]) {
    await sleep(w * 1000);
    const a = await search();
    const cur = a.filter(c => IDS.indexOf(String(c.campaignId)) >= 0);
    out['等待' + w + '秒后'] = cur.map(c => ({ id: c.campaignId, name: c.title, pause: c.pauseStatus, group: c.statusGroup, 说明: c.statusDescTitle || '-' }));
    if (cur.every(c => String(c.pauseStatus) !== '1')) { out.结果 = '✅ 恢复成功'; break; }
  }
  if (!out.结果) out.结果 = '⚠ 仍被平台按回暂停（该状态只能等平台同步完成，手动恢复无效）';

  const after = await search();
  out.全店 = {
    计划数: after.length,
    在跑: after.filter(c => c.statusGroup === 'online').length,
    暂停: after.filter(c => String(c.pauseStatus) === '1').length,
  };
  return JSON.stringify(out, null, 1);
})()
