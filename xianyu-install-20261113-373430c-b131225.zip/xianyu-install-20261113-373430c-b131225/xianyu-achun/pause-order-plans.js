// pause-order-plans.js —— 暂停【所有】目标=订单量 且 在跑 的计划
// 护栏：任何名字以「擦亮宝贝」开头的计划一律不动（主/副集合）
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const mtop = window.lib.mtop;
  const TGT = { exposure: '曝光量', click: '浏览量', follow_collect: '关注收藏量', chat: '咨询量', order: '订单量' };
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const out = { 时刻: new Date().toLocaleString('zh-CN') };

  const search = async () => {
    const r = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
    return r;
  };

  let r;
  try { r = await search(); }
  catch (e) { out.session = (e && (e.ret || e.message)) || String(e); return JSON.stringify(out, null, 1); }
  if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0)) { out.session = r && r.ret; return JSON.stringify(out, null, 1); }

  const all = ((r.data || {}).result) || [];
  out.全店计划数 = all.length;

  const orderRunning = all.filter(c => c.bidTarget === 'order' && String(c.pauseStatus) !== '1');
  const coll = orderRunning.filter(c => /^擦亮宝贝/.test(c.title || ''));
  out.订单量且在跑 = orderRunning.map(c => ({
    id: c.campaignId, name: c.title, bid: n(c.cpm) / 100, budget: n(c.maxDayBudget) / 100,
    goods: (c.entityList || []).length, code: c.statusDescCode, group: c.statusGroup,
    今日花费: n((c.infoTab || {}).todayCost) / 100,
  }));

  if (coll.length) {
    out.中止 = '订单量在跑的计划里含主/副集合（擦亮宝贝*），为安全整体中止';
    out.集合计划 = coll.map(c => c.campaignId + ' ' + c.title);
    return JSON.stringify(out, null, 1);
  }
  if (!orderRunning.length) { out.结果 = '已经没有在跑的订单量计划了'; return JSON.stringify(out, null, 1); }

  const ids = orderRunning.map(c => String(c.campaignId));
  out.将暂停 = ids;
  const pr = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.pause', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ campaignIds: ids, pauseStatus: 1 }) } });
  out.平台返回 = (pr.ret || [])[0];
  let ok = 0;
  Object.keys(pr.data || {}).forEach(k => { if ((pr.data[k] || {}).pauseStatus === 1) ok++; });
  out.平台确认暂停数 = ok;

  await sleep(8000);
  const r2 = await search();
  const after = ((r2.data || {}).result) || [];
  const still = after.filter(c => c.bidTarget === 'order' && String(c.pauseStatus) !== '1');
  out.复查仍在跑的订单量 = still.map(c => c.campaignId + ' ' + c.title);
  out.复查全店 = {
    计划数: after.length,
    在跑: after.filter(c => String(c.pauseStatus) !== '1').length,
    主副集合在跑: after.filter(c => /^擦亮宝贝/.test(c.title || '') && String(c.pauseStatus) !== '1').map(c => c.title),
    订单量在跑: still.length,
    咨询量在跑: after.filter(c => c.bidTarget === 'chat' && String(c.pauseStatus) !== '1').length,
  };
  out.结果 = still.length === 0 ? '✅ 所有订单量计划已暂停' : '⚠ 仍有未暂停';
  return JSON.stringify(out, null, 1);
})()
