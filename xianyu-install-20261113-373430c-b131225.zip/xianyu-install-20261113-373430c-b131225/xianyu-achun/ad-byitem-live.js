// ad-byitem-live.js —— 只读：把「计划管理」表里每个计划的【宝贝信息】子表摊开，读**按链接**的花费/曝光/点击/咨询
//
// 为什么需要它：老板问「你能检查到每条链接分别来的咨询吗？」
//   计划级的数据（lib/mtop.js adPlans）是按【计划】汇总的，而一个计划可能挂多条链接，
//   所以计划级咨询数回答不了「哪条链接带来的」。
//   平台其实给了：计划行展开后是「宝贝信息」子表，列序（表头第二行）为
//     0擦亮状态 1宝贝信息 2宝贝ID 3擦亮花费(元) 4曝光数 5点击数 6咨询数
//     7下单笔数 8交易额(元) 9关注收藏数 10投产比
//   子表行是 11 个 td，计划行是 36 个 td —— 靠 td 数区分，这个形状是 2026-10-10 用
//   ad-table-dump.js 实测出来的，不是猜的。
//
// 由 ad-creative-run.js 驱动（CREATIVE_DRIVER=ad-byitem-live.js），返回 JSON 字符串。
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();

  for (let i = 0; i < 12; i++) {
    if (document.querySelectorAll('tbody tr').length) break;
    await sleep(1000);
  }

  const click1 = (el) => {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  };

  // 展开控件：Ant Design 的行展开图标有好几个类名，全试一遍，别只认一个
  const toggles = () => [].slice.call(document.querySelectorAll(
    '.ant-table-row-expand-icon, [class*=expand-icon], [class*=ExpandIcon], [class*=expandIcon]'));
  const collapsed = () => toggles().filter(e => !/expanded/.test(String(e.className)));
  const 控件总数 = toggles().length;

  let 点了 = 0;
  for (let round = 0; round < 4; round++) {
    const list = collapsed();
    if (!list.length) break;
    list.forEach(el => { click1(el); 点了++; });
    await sleep(1800);
  }

  // 顺序走一遍：大 td 数的行是计划行，10~16 td 的行是宝贝行。
  // 【2026-10-10 修】不能靠「上一个计划行」推归属 —— 实测子表行并不紧跟在自己的计划行后面，
  //   按 DOM 顺序推的结果是 10 条宝贝行全被记到同一个计划 ID 上（明显错）。
  //   可靠办法：子表行的行文本里【自带】「计划ID：xxxxxxxx计划名称：yyyy」，直接从行文本取。
  const seen = {};
  const collect = () => {
    const rows = [].slice.call(document.querySelectorAll('tbody tr'));
    rows.forEach(tr => {
      const tds = [].slice.call(tr.querySelectorAll('td'));
      if (tds.length < 10 || tds.length > 16) return;
      const tx = (i) => (tds[i] ? norm(tds[i].innerText) : '');
      const itemId = tx(2);
      if (!/^\d{10,}$/.test(itemId)) return;
      const all = norm(tr.innerText);
      const pid = (all.match(/计划ID[：:]\s*(\d{6,})/) || [])[1] || '';
      // 计划名后面紧跟着下一个宝贝ID，没有分隔符，所以用【非贪婪 + 前瞻】截断，
      //   否则会把下一个宝贝ID粘进计划名里（实测：「深圳王者荣耀嘉年华-咨询1201089630…」）。
      const pname = (all.match(/计划名称[：:]\s*(.{2,40}?)(?=\d{10,}|$)/) || [])[1] || '';
      seen[itemId] = {
        计划ID: pid, 计划名: pname,
        宝贝ID: itemId, 宝贝标题: tx(1).slice(0, 40),
        擦亮花费: tx(3), 曝光数: tx(4), 点击数: tx(5), 咨询数: tx(6),
        下单笔数: tx(7), 交易额: tx(8),
      };
    });
    return rows.length;
  };

  // 【2026-10-10 加】表格是虚拟滚动：DOM 里只挂了一部分行，所以要【边滚边收】，
  //   否则只能读到恰好渲染出来的那几条（实测第一次只读到 10 条，只覆盖 5 个计划）。
  const scrollers = () => {
    const out = [document.scrollingElement].filter(Boolean);
    ['.ant-table-body', '[class*=tableBody]', '[class*=virtual]', '[class*=scroll]']
      .forEach(sel => [].slice.call(document.querySelectorAll(sel)).forEach(e => {
        if (e.scrollHeight > e.clientHeight + 20) out.push(e);
      }));
    return out;
  };
  let 滚动次数 = 0, 行数峰值 = 0;
  for (const el of scrollers()) {
    try {
      el.scrollTop = 0;
      for (let k = 0; k < 40; k++) {
        const before = el.scrollTop;
        el.scrollTop = before + Math.max(200, Math.floor((el.clientHeight || 400) * 0.8));
        await sleep(320);
        滚动次数++;
        行数峰值 = Math.max(行数峰值, collect());
        if (el.scrollTop === before) break;
      }
    } catch (e) {}
  }
  const rowCount = collect();

  return JSON.stringify({
    时刻: new Date().toLocaleString('zh-CN'),
    展开控件总数: 控件总数,
    点了展开: 点了,
    tbody行数: rowCount,
    滚动次数: 滚动次数,
    行数峰值: 行数峰值,
    宝贝行数: Object.keys(seen).length,
    // 诊断：按类名（ant-table-row-expand-icon / *expand*）一个都没找到，
    //   说明这个表不是 Ant Design 的展开行实现，宝贝行是平台自己挂的。
    展开控件探查: {
      含expan类元素: [].slice.call(document.querySelectorAll('[class*=expan],[class*=Expan]'))
        .slice(0, 8).map(e => String(e.className).slice(0, 60)),
    },
    按宝贝: Object.keys(seen).map(k => seen[k]),
  }, null, 1);
})()
