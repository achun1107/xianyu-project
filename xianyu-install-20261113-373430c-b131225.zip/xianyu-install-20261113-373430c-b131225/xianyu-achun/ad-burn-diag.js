// ad-burn-diag.js —— 为什么烧不动：把「计划级消耗」和「宝贝级基础数据」对起来看
(async () => {
  const mtop = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };

  const cr = await mtop.request({
    api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) },
  });
  const plans = (cr.data || {}).result || [];

  const ir = await mtop.request({
    api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, tab: 'all', needTabs: true }) },
  });
  const items = ((ir.data || {}).result || {}).itemList || [];
  const byId = {};
  items.forEach(it => byId[String(it.itemId)] = it);

  const rows = plans.map(c => {
    const t = c.todayAdDataDetail || {};
    const ids = (c.entityList || []).map(e => String(e.entityId));
    const tags = ids.map(i => ((byId[i] || {}).tags || []).join('/') || '-');
    const sales = ids.map(i => n((byId[i] || {}).saleCnt));
    const pubDays = ids.map(i => {
      const p = (byId[i] || {}).publishTime;
      return p ? Math.round((Date.now() - Number(p)) / 86400000) : null;
    });
    return {
      id: String(c.campaignId), name: c.title, target: c.bidTarget,
      cpm: n(c.cpm) / 100, budget: n(c.maxDayBudget) / 100,
      宝贝数: ids.length, 宝贝: ids,
      tags: tags, 有tag的宝贝数: tags.filter(t => t !== '-').length,
      成交合计: sales.reduce((a, b) => a + b, 0), 上架天数: pubDays,
      花费: n(t.cost) / 100, 曝光: n(t.showPv), 点击: n(t.clickPv), 咨询: n(t.chatPv), 下单: n(t.payPv),
      paused: String(c.pauseStatus) === '1',
    };
  });

  // 分组聚合
  const grp = (key, f) => {
    const g = {};
    rows.forEach(r => { const k = f(r); (g[k] = g[k] || []).push(r); });
    return Object.keys(g).map(k => {
      const a = g[k];
      return {
        组: k, 计划数: a.length,
        总日预算: +a.reduce((s, r) => s + r.budget, 0).toFixed(0),
        今日花费: +a.reduce((s, r) => s + r.花费, 0).toFixed(2),
        今日曝光: a.reduce((s, r) => s + r.曝光, 0),
        今日咨询: a.reduce((s, r) => s + r.咨询, 0),
        有曝光计划数: a.filter(r => r.曝光 > 0).length,
      };
    }).sort((x, y) => y.今日花费 - x.今日花费);
  };

  const out = {
    时刻: new Date().toLocaleString('zh-CN'),
    总计划: rows.length,
    在跑: rows.filter(r => !r.paused).length,
    按_宝贝是否有定向tag: grp('tag', r => r.有tag的宝贝数 > 0 ? '有tag' : '无tag(全空)'),
    按_宝贝数: grp('cnt', r => r.宝贝数 + '个宝贝'),
    按_目标: grp('tg', r => r.target),
    按_出价档: grp('bid', r => r.target === 'order' ? (r.cpm >= 30 ? '订单≥¥30' : '订单<¥30') : (r.cpm >= 3 ? '咨询≥¥3' : '咨询<¥3')),
    明细_在跑的: rows.filter(r => !r.paused).sort((a, b) => b.花费 - a.花费).map(r =>
      `${r.id} ${r.name.slice(0, 22).padEnd(22)} ${r.target.padEnd(5)} ¥${String(r.cpm).padEnd(6)} 预算¥${String(r.budget).padEnd(4)} ${r.宝贝数}宝 tag=${r.tags.join('|')} 成交${r.成交合计} | 花¥${String(r.花费).padEnd(7)} 曝光${String(r.曝光).padStart(5)} 咨询${r.咨询}`),
  };
  return JSON.stringify(out, null, 1);
})()
