/**
 * ad-pending.js —— 建好超级擦亮计划但【今天不开】，并保证第二天 08:00 一起开
 *
 * 老板 2026-10-10：「建好超级擦亮计划，今天不开，明天再一起开。」
 *
 * 为什么需要它（三个坑，一个都不能漏）：
 *   ① run-cfgs.js 建完计划平台会提示「擦亮任务已开启」—— 也就是建完就在跑，得立刻暂停。
 *   ② 光暂停不够：每 30 分钟的 ad-watch-stuck.ps1 专门把 statusDescCode=16 的暂停计划【恢复】，
 *      新建计划恰好长时间处于该状态 → 会在今晚被无声开回来。所以要进 AD-EXCLUDE.json。
 *   ③ 但进了 AD-EXCLUDE 就【永远不会被 08:00 的 ad-window --on 开起来】——
 *      所以第二天 07:45 必须再把它从名单里删掉，08:00 才会「一起开」。
 *
 * 用法:
 *   node ad-pending.js create    # 建两组计划（各 2 条链接）→ 立即暂停 → 写进 AD-EXCLUDE
 *   node ad-pending.js release   # 把 create 记下的计划从 AD-EXCLUDE 删掉（07:45 跑）
 */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
process.chdir(__dirname);

const mtop = require('./lib/mtop');
const ROOT = __dirname;
const PENDING = path.join(ROOT, 'ad-pending-state.json');
const EXCLUDE = path.join(ROOT, 'AD-EXCLUDE.json');
const LOGF = path.join(ROOT, 'ad-pending.log');
const log = (s) => { const l = '[' + new Date().toLocaleString('zh-CN') + '] ' + s; console.log(l); try { fs.appendFileSync(LOGF, l + '\n'); } catch (e) {} };
const jload = (p, d) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { return d; } };

const GROUPS = [
  { city: '澳门', star: '梓渝', searchKey: '梓渝', planName: '澳门梓渝-咨询120' },
  { city: '南京', star: '华晨宇', searchKey: '华晨宇', planName: '南京华晨宇-咨询120' },
];

const MODE = String(process.argv[2] || '');
if (!['create', 'release'].includes(MODE)) { console.log('用法: node ad-pending.js create|release'); process.exit(2); }

// 计划规格：与 run-cfgs.js 的老规矩一致（咨询量 · 提升120% · 预算¥50 · 8:00-23:00）
//   ⚠ endHour 是 22 不是 23：ad-driver 是 h <= endHour 闭区间，格 h = h:00-(h+1):00，
//     所以窗口 8:00-23:00 对应 endHour 22（见 tools/ad-hours-check.js）。
const SPEC = { target: 'chat', improvePct: 120, expectedBid: '2.5', budget: 50, startHour: 8, endHour: 22, submit: true };

async function create() {
  const led = jload(path.join(ROOT, '上架台账.json'), []);
  const plans = await mtop.adPlans();
  const state = { ids: [], plans: [], at: new Date().toISOString() };

  for (const g of GROUPS) {
    if (plans.some((p) => p.name === g.planName)) { log('⏭ 计划「' + g.planName + '」已存在，跳过'); continue; }
    const items = led.filter((r) => r.city === g.city && r.star === g.star && !(String(r.状态 || '').includes('已下架')))
      .map((r) => String(r.itemId)).filter(Boolean);
    if (!items.length) { log('❌ ' + g.city + g.star + ' 在台账里找不到在售链接，跳过'); continue; }

    const cfg = Object.assign({ searchKey: g.searchKey, items: items, planName: g.planName }, SPEC);
    const cf = path.join(ROOT, 'ad-pending-' + g.city + '.cfg.json');
    fs.writeFileSync(cf, JSON.stringify([cfg], null, 2), 'utf8');
    log('建计划「' + g.planName + '」 宝贝 ' + items.length + ' 条: ' + items.join(', '));
    const r = spawnSync(process.execPath, [path.join(ROOT, 'run-cfgs.js')],
      { stdio: 'inherit', cwd: ROOT, env: Object.assign({}, process.env, { CFGS_JSON: cf, CFGS_LOG: path.join(ROOT, 'run-cfgs-log-pending.ndjson') }) });
    log('  run-cfgs 退出码 ' + r.status);
  }

  // 建完立刻暂停（平台建完就在跑），并核对
  await new Promise((s) => setTimeout(s, 5000));
  const after = await mtop.adPlans();
  for (const g of GROUPS) {
    const p = after.find((x) => x.name === g.planName);
    if (!p) { log('⚠️ 回读不到计划「' + g.planName + '」'); continue; }
    log('  回读: ' + p.id + ' 状态=' + p.verdictCn + ' 出价¥' + p.bidYuan + ' 预算¥' + p.budgetYuan + ' 宝贝 ' + p.itemCount + ' 条');
    state.ids.push(String(p.id));
    state.plans.push({ id: String(p.id), name: p.name, items: p.items, bid: p.bidYuan, budget: p.budgetYuan });
  }
  if (state.ids.length) {
    const r = await mtop.adPause(state.ids, { pauseStatus: 1 });
    log('暂停平台返回: ' + (r.ret || []).join(' | '));
  }
  fs.writeFileSync(PENDING, JSON.stringify(state, null, 2), 'utf8');

  // 进 AD-EXCLUDE，防今晚被 ad-watch-stuck 开回来
  if (state.ids.length) {
    const ex = jload(EXCLUDE, { ids: [] });
    ex.ids = ex.ids || [];
    state.ids.forEach((id) => { if (!ex.ids.includes(id)) ex.ids.push(id); });
    ex._计划明细 = ex._计划明细 || {};
    state.plans.forEach((p) => { ex._计划明细[p.id] = p.name + ' · 出价¥' + p.bid + ' · 预算¥' + p.budget + ' · 绑 ' + p.items + '。老板 2026-10-10「今天不开，明天再一起开」→ 建后即暂停并进本名单；07:45 由 ad-pending.js release 移出，08:00 随全店一起开。'; });
    fs.writeFileSync(EXCLUDE, JSON.stringify(ex, null, 2) + '\n', 'utf8');
    log('已写 AD-EXCLUDE，当前名单 ' + ex.ids.length + ' 个: ' + ex.ids.join(','));

    await new Promise((s) => setTimeout(s, 9000));
    const chk = await mtop.adPlans();
    state.ids.forEach((id) => { const p = chk.find((x) => x.id === id); log('  暂停校验 ' + id + ' → ' + (p ? p.verdictCn : '(找不到)')); });
  }
  log('create 完成');
}

async function release() {
  const st = jload(PENDING, { ids: [] });
  if (!st.ids || !st.ids.length) { log('没有待放行的计划（ad-pending-state.json 为空），无需处理'); return; }
  const ex = jload(EXCLUDE, { ids: [] });
  const before = (ex.ids || []).length;
  ex.ids = (ex.ids || []).filter((id) => !st.ids.includes(id));
  fs.writeFileSync(EXCLUDE, JSON.stringify(ex, null, 2) + '\n', 'utf8');
  log('已把 ' + st.ids.join(',') + ' 从 AD-EXCLUDE 移出（' + before + ' → ' + ex.ids.length + '）');
  log('它们仍是暂停态，08:00 的 ad-window --on 会把全店暂停计划一起开起来');
}

(MODE === 'create' ? create() : release()).catch((e) => { log('❌ FAIL ' + ((e && e.stack) || e)); process.exit(1); });
