// ad-target-probe2.js —— 对比三个计划里「订单量」是否可用
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const targets = ['凤凰传奇北京-咨询120', '李大奔广州-咨询120', '孙燕姿广州-咨询120', '热销-汪苏泷广州-咨询130'];
  const out = {};
  const findRow = name => [].slice.call(document.querySelectorAll('tbody tr')).find(r => (r.innerText || '').indexOf(name) >= 0);
  for (const name of targets) {
    let row = findRow(name);
    if (!row) {
      for (let p = 2; p <= 5 && !row; p++) {
        const pg = document.querySelector('.ant-pagination');
        const b = pg && [].slice.call(pg.querySelectorAll('.ant-pagination-item')).find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === String(p));
        if (!b) break;
        click1(b); await sleep(3200); row = findRow(name);
      }
    }
    if (!row) { out[name] = '找不到行'; continue; }
    click1([].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑'));
    let od = null;
    for (let i = 0; i < 15; i++) { await sleep(1000); od = document.querySelector('.ant-drawer-content'); if (od && /更想获得/.test(od.innerText || '')) break; }
    await sleep(2000);
    const rs = [].slice.call(document.querySelectorAll('input[type=radio]'))
      .filter(r => ['exposure', 'click', 'follow_collect', 'chat', 'order'].indexOf(r.value) >= 0);
    out[name] = rs.map(r => r.value + (r.disabled ? '(禁用)' : '') + (r.checked ? '(选中)' : ''));
    // 宝贝列表
    out[name + '_宝贝'] = [].slice.call(document.querySelectorAll('[class*=goodsTitle]')).map(e => (e.innerText || '').trim().slice(0, 26));
    // 关掉抽屉
    const wrap = od && od.closest('.ant-drawer');
    const cancel = wrap && [].slice.call(wrap.querySelectorAll('div,span,button')).find(e => e.children.length === 0 && /^取\s*消$/.test((e.innerText || '').trim()));
    if (cancel) click1(cancel);
    await sleep(2500);
  }
  return JSON.stringify(out, null, 1);
})()
