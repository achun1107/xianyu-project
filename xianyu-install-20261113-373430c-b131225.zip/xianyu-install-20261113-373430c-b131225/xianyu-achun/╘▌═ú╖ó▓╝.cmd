@echo off
REM Double-click to PAUSE auto-publishing.
REM Creates D:\DSH\achun\PAUSE-PUBLISH ; wake-publish-sleep.ps1 will keep the
REM service alive but publish nothing while this file exists.
cd /d "%~dp0"
echo paused %date% %time% > "PAUSE-PUBLISH"
echo.
echo   Auto-publish PAUSED.
echo   (file created: %~dp0PAUSE-PUBLISH)
echo   Double-click "continue-publish.cmd" to resume.
echo.
timeout /t 6 >nul
