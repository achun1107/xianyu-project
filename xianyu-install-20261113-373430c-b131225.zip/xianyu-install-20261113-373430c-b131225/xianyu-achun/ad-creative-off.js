// ad-creative-off.js —— 在「编辑计划」抽屉里关掉「创意优化」，并锁住日预算不被冲掉
// cfg = window.__COCFG = { planName, budget }   budget 传该计划当前的日预算值，用于保存前重设
(async () => {
  const cfg = window.__COCFG || {};
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const R = {};
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  function setNative(el, val) {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    d.set.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const drawers = () => [].slice.call(document.querySelectorAll('.ant-drawer-content')).filter(d => d.getBoundingClientRect().width > 200);
  const outer = () => drawers().find(d => /编辑计划/.test(d.innerText || ''));
  const swState = sw => String(sw.className).indexOf('checked') >= 0 || sw.getAttribute('aria-checked') === 'true';
  // 抽屉里含「创意优化」字样的那个开关
  const coSwitch = od => [].slice.call(od.querySelectorAll('[role=switch], .ant-switch, button[class*=switch]'))
    .find(s => { let p = s; for (let k = 0; k < 6 && p; k++) { p = p.parentElement; if (p && /创意优化/.test(p.innerText || '')) return true; } return false; });

  try {
    const findRow = () => [].slice.call(document.querySelectorAll('tbody tr')).find(r => (r.innerText || '').indexOf(cfg.planName) >= 0);
    let row = null;
    for (let i = 0; i < 10 && !row; i++) { await sleep(1000); row = findRow(); }
    for (let p = 2; p <= 6 && !row; p++) {
      const pg = document.querySelector('.ant-pagination');
      const btn = pg && [].slice.call(pg.querySelectorAll('.ant-pagination-item')).find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === String(p));
      if (!btn) break;
      click1(btn); await sleep(3500); row = findRow();
    }
    if (!row) throw new Error('找不到计划行');
    click1([].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑'));
    let od = null;
    for (let i = 0; i < 15; i++) { await sleep(1000); od = outer(); if (od && /创意优化/.test(od.innerText || '')) break; }
    if (!od) throw new Error('编辑抽屉没打开 / 里面没有创意优化');
    R.处理前 = /创意优化[^]{0,6}已开启/.test((od.innerText || '').replace(/\s+/g, '')) ? '已开启' : '未开启/未知';

    // ---- 关创意优化 ----
    let sw = coSwitch(od);
    R.找到开关 = !!sw;
    if (sw && swState(sw)) {
      click1(sw); await sleep(2500);
      const modal = [].slice.call(document.querySelectorAll('.ant-modal-content')).filter(m => m.getBoundingClientRect().width > 50).pop();
      R.弹窗 = modal ? (modal.innerText || '').replace(/\s+/g, ' ').slice(0, 120) : null;
      if (modal) {
        const ok = [].slice.call(modal.querySelectorAll('button,div,span')).filter(e => e.children.length === 0)
          .find(e => /确认关闭|确\s*定|确认|继\s*续/.test((e.innerText || '').trim()));
        R.点确认 = !!ok;
        if (ok) { click1(ok); await sleep(3000); }
      }
      await sleep(2000);
      od = outer() || od;
      sw = coSwitch(od);
      R.处理后 = sw ? (swState(sw) ? '仍开启❌' : '未开启✅') : '找不到开关';
    } else if (sw) { R.处理后 = '本来就是未开启'; }
    else throw new Error('抽屉里找不到创意优化开关');
    if (R.处理后.indexOf('未开启') < 0) throw new Error('没能关上，未保存（' + R.处理后 + '）');

    // ---- 锁预算（保存会提交所有字段，预算会回落默认档）----
    if (cfg.budget) {
      // ⚠️ 选择器不能写松：`[class*=radioGroup--]` 会先命中「更想获得」那组单选
      //（曝光量/浏览量/…），预算组反而抓不到。用已知可用的类名，再兜底按「自定义」文本找。
      let grp = od.querySelector('[class*=radioGroup--eEugUXoZ]');
      if (!grp) {
        const cand = [].slice.call(od.querySelectorAll('div')).filter(d =>
          /自定义/.test(d.innerText || '') && d.querySelectorAll('input').length <= 2 && d.querySelectorAll('[class*=radio--]').length >= 2);
        grp = cand.sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length)[0];
      }
      if (!grp) throw new Error('找不到日花费上限控件');
      const box = [].slice.call(grp.querySelectorAll('[class*=radio--]'));
      R.预算档位 = box.map(e => (e.innerText || '').trim());
      const custom = box[box.length - 1];
      const customTxt = (custom.innerText || '').trim();
      const preset = box.slice(0, -1).find(e => (e.innerText || '').trim() === '¥' + cfg.budget);
      if (preset) { click1(preset); await sleep(1600); R.预算回读 = '¥' + cfg.budget; R.预算走预设 = true; }
      else if (customTxt === '¥' + cfg.budget) { R.预算回读 = customTxt; R.预算已是目标值 = true; }
      else {
        click1(custom); await sleep(1800);
        let bi = grp.querySelector('input');
        if (!bi) throw new Error('自定义预算槽没有输入框');
        setNative(bi, cfg.budget); await sleep(700);
        bi.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
        bi.dispatchEvent(new Event('blur', { bubbles: true }));
        await sleep(1800);
        bi = grp.querySelector('input');
        R.预算回读 = bi ? String(bi.value || '').trim() : '';
      }
      // ⚠️ 数字比较：输入框里是 "300"，不是 "¥300"
      if (Number(String(R.预算回读).replace(/[^\d.]/g, '')) !== Number(cfg.budget)) {
        throw new Error('预算回读=' + R.预算回读 + ' 期望 ' + cfg.budget + '，未保存');
      }
    }

    // ---- 保存 ----
    const wrap = od.closest('.ant-drawer');
    const foot = wrap && wrap.querySelector('.ant-drawer-footer');
    const ok = foot && [].slice.call(foot.querySelectorAll('div,span,button'))
      .find(e => e.children.length === 0 && /^确\s*定$/.test((e.innerText || '').trim()));
    if (!ok) throw new Error('找不到外层确定');
    click1(ok);
    R.已保存 = true;
    await sleep(6000);
    R.提示 = ((document.body.innerText || '').match(/[^\n]*(成功|失败|错误|不能)[^\n]*/g) || []).slice(0, 3);
    return JSON.stringify(R, null, 1);
  } catch (e) { R.fatal = e.message; return JSON.stringify(R, null, 1); }
})()
