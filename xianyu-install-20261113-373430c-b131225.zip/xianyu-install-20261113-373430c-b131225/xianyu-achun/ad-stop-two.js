// ad-stop-two.js —— 停掉 刘宪华深圳 + 华晨宇南京 的所有推广（含被主/副集合带上的）
// 4 个宝贝：华晨宇南京 1079180581679 / 1077256903447；刘宪华深圳 1072030678297 / 1074445430045
(async () => {
  const mtop = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const ITEMS = {
    '1079180581679': '华晨宇南京①',
    '1077256903447': '华晨宇南京②',
    '1072030678297': '刘宪华深圳①',
    '1074445430045': '刘宪华深圳②',
  };
  const search = async () => {
    const r = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
    return (r.data || {}).result || [];
  };
  const before = await search();

  // 找出所有含这 4 个宝贝的计划
  const hits = before.filter(c => (c.entityList || []).some(e => ITEMS[String(e.entityId)]));
  const out = {
    待停计划: hits.map(c => ({
      id: c.campaignId, name: c.title, 目标: c.bidTarget, 暂停态: c.pauseStatus,
      实时花费: n((c.infoTab || {}).todayCost) / 100,
      命中宝贝: (c.entityList || []).map(e => ITEMS[String(e.entityId)]).filter(Boolean),
      全部宝贝: (c.entityList || []).map(e => String(e.entityId)),
    })),
  };
  const 主副 = hits.filter(c => /^擦亮宝贝/.test(c.title));
  out['被主副集合带着推的'] = 主副.map(c => c.campaignId + ' ' + c.title);

  const ids = hits.filter(c => String(c.pauseStatus) !== '1').map(c => String(c.campaignId));
  out.实际要停 = ids;
  if (!ids.length) { out.结果 = '目标计划本来就是暂停状态'; return JSON.stringify(out, null, 1); }

  const pr = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.pause', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ campaignIds: ids, pauseStatus: 1 }) } });
  out.平台返回 = (pr.ret || [])[0];
  out.平台确认 = {};
  Object.keys(pr.data || {}).forEach(k => {
    const v = pr.data[k] || {};
    out.平台确认[k] = { pauseStatus: v.pauseStatus, group: v.statusGroup, desc: v.statusDescTitle };
  });

  await sleep(6000);
  const after = await search();
  out.停后复核 = after.filter(c => ids.indexOf(String(c.campaignId)) >= 0)
    .map(c => ({ id: c.campaignId, name: c.title, pause: c.pauseStatus, group: c.statusGroup }));
  out.全店 = { 计划数: after.length, 在跑: after.filter(c => c.statusGroup === 'online').length, 暂停: after.filter(c => String(c.pauseStatus) === '1').length };
  out.主副集合还在跑 = after.filter(c => /^擦亮宝贝/.test(c.title) && c.statusGroup === 'online').length;
  out.结果 = out.停后复核.every(x => x.pause === '1') ? '✅ 已全部停止' : '⚠ 仍有未停';
  return JSON.stringify(out, null, 1);
})()
