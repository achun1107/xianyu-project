// ad-rebid.js —— 只改一个已存在计划的「自定义出价」，不碰宝贝/预算/时段
// cfg = { planName, targetImprove, submit }
//
// 两个必须处理的坑（2026-09-21 实测）：
//   1. 编辑 drawer 打开时默认选中的是「建议出价」行，不是「自定义」行。
//      不先点自定义行，读到的是**建议价**（如 22.2），不是计划的真实出价（26.66），
//      然后拿它去反解会越解越远。
//   2. 出价一律保留一位小数（用户约定）；控制台本身也只显示一位。
(async () => {
  const cfg = window.__RCFG || {};
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const R = { steps: [], errors: [] };
  const step = s => R.steps.push(s);

  // ══ 出价上限 · 永久规则（2026-09-27，见 出价上限规则-永久.md）══
  // 咨询量 ≤ ¥4、订单量 ≤ ¥35。超限一律不保存（fail-closed）。
  // 临时放宽：注入前设 window.__BID_CAPS = { chat: 6, order: 40 }。
  const BID_CAPS = Object.assign({ chat: 4, order: 35 }, (typeof window !== 'undefined' && window.__BID_CAPS) || {});
  const TARGET_NAMES = { '曝光量': 'exposure', '浏览量': 'click', '关注收藏量': 'follow_collect', '咨询量': 'chat', '订单量': 'order' };
  // 从编辑抽屉读「更想获得」选中的是哪一档（多策略，读不到返回 null）
  function readTarget() {
    const od = outer(); if (!od) return null;
    // 策略1：label 里带 checked 的 radio
    const labels = [].slice.call(od.querySelectorAll('label'));
    for (const l of labels) {
      const t = (l.innerText || '').trim();
      if (!TARGET_NAMES[t]) continue;
      const r = l.querySelector('input[type=radio]');
      if (r && r.checked) return { name: t, key: TARGET_NAMES[t] };
    }
    // 策略2：radio 的兄弟 label（Ant Design 两种写法都有）
    const radios = [].slice.call(od.querySelectorAll('input[type=radio]'));
    for (const r of radios) {
      if (!r.checked) continue;
      const wrap = r.closest('label') || r.parentElement;
      const t = wrap ? (wrap.innerText || '').trim() : '';
      if (TARGET_NAMES[t]) return { name: t, key: TARGET_NAMES[t] };
    }
    // 策略3：高亮容器（radioActive / checked）
    const act = [].slice.call(od.querySelectorAll('[class*=radioActive],[class*=active],[class*=checked]'));
    for (const a of act) {
      const t = (a.innerText || '').trim();
      if (TARGET_NAMES[t]) return { name: t, key: TARGET_NAMES[t] };
    }
    return null;
  }
  // 返回 { targetName, key, cap } —— 读不到目标时 cap 为 undefined，由调用处决定是否放行
  function resolveCap() {
    const t = readTarget();
    if (t) return { targetName: t.name, key: t.key, cap: BID_CAPS[t.key] };
    if (cfg.target && TARGET_NAMES[cfg.target]) return { targetName: cfg.target, key: cfg.target, cap: BID_CAPS[cfg.target], fromCfg: true };
    if (typeof cfg.maxBid === 'number') return { targetName: '(未知)', key: null, cap: cfg.maxBid, fromCfg: true };
    return { targetName: null, key: null, cap: undefined };
  }

  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;   // 绝不追加 el.click()
  }
  function setNative(el, val) {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    d.set.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const drawers = () => [].slice.call(document.querySelectorAll('.ant-drawer-content')).filter(d => d.getBoundingClientRect().width > 200);
  const outer = () => drawers().find(d => /编辑计划/.test(d.innerText || ''));
  const bidInput = () => {
    const od = outer(); if (!od) return null;
    return od.querySelector('input[placeholder*="出价"]') || null;
  };
  const readImp = () => {
    const od = outer(); if (!od) return null;
    const m = od.innerText.match(/预计提升\s*(\d+)%/);
    return m ? parseInt(m[1], 10) : null;
  };
  async function probe(v) {
    const el = bidInput();
    if (!el) throw new Error('出价输入框消失');
    const b4 = readImp();
    const s = (Math.round(v * 10) / 10).toFixed(1);
    el.focus(); setNative(el, s);
    await sleep(350);
    el.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    for (let i = 0; i < 12; i++) {
      await sleep(650);
      const cur = readImp();
      if (cur !== null && cur !== b4) { await sleep(800); return readImp(); }
    }
    return readImp();
  }

  try {
    // ---------- -2. 先关掉可能残留的编辑抽屉 ----------
    // 坑（2026-09-21）：上一次运行如果中途抛错，抽屉会**留在打开状态**；而计划管理页是 hash 路由，
    // 再跳同一个 URL 不一定会重新渲染，于是下一次运行读到的是**上一个计划的陈旧抽屉**
    //（实测：给一个咨询计划读出了 34/150%，而它自己的出价是 ¥3.2）。开工先关。
    if (outer()) {
      const wrap0 = outer().closest('.ant-drawer');
      const cancel0 = wrap0 && [].slice.call(wrap0.querySelectorAll('div,span,button'))
        .find(e => e.children.length === 0 && /^(取\s*消|关\s*闭)$/.test((e.innerText || '').trim()));
      const close0 = wrap0 && wrap0.querySelector('.ant-drawer-close');
      if (cancel0) { click1(cancel0); R.closedStaleDrawer = '取消'; }
      else if (close0) { click1(close0); R.closedStaleDrawer = 'X'; }
      else { R.closedStaleDrawer = '关不掉'; }
      await sleep(2500);
    }

    // ---------- -1. 清掉「计划ID」搜索框里的残留值 ----------
    // 这个框的筛选是**粘住的**：一旦填过，翻页/刷新都会保留，导致计划表只显示 1 行
    // （实测：页面显示「计划(1)」而接口其实是 40 个计划）。每次开工先清空。
    const idFilter = [].slice.call(document.querySelectorAll('input'))
      .find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
    if (idFilter && String(idFilter.value || '').trim() !== '') {
      R.hadIdFilter = idFilter.value;
      setNative(idFilter, '');
      await sleep(500);
      idFilter.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
      idFilter.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
      await sleep(3200);
    }

    // ---------- 0. 先确保停在「计划」tab ----------
    // 管理页有两个 tab：计划(N) 和 宝贝(N)。之前点过「宝贝」tab 后状态会被保留，
    // 于是表格里全是宝贝行，按计划名找行必然「找不到计划行」（实测踩过）。
    const planTab = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn'))
      .find(e => /^计划\(\d+\)$/.test((e.innerText || '').trim()));
    if (planTab) { click1(planTab); await sleep(3500); R.clickedPlanTab = true; }

    // ---------- 0.5 分页找行 ----------
    // 40 个计划不会全渲染在一页；顶部那个「请输入计划ID」框实测回车不过滤，
    // 所以改成翻页找（最多 8 页）。
    const findRow = () => [].slice.call(document.querySelectorAll('tbody tr'))
      .find(r => (r.innerText || '').indexOf(cfg.planName) >= 0)
      || [].slice.call(document.querySelectorAll('tbody tr'))
        .find(r => cfg.planId && (r.innerText || '').indexOf(String(cfg.planId)) >= 0);
    let row = findRow();
    R.pageTries = [];
    if (!row) {
      for (const n of [1, 2, 3, 4, 5, 6, 7, 8]) {
        const items = [].slice.call(document.querySelectorAll('.ant-pagination-item, li[title]'));
        const it = items.find(e => ((e.getAttribute && e.getAttribute('title')) || e.innerText || '').trim() === String(n));
        if (!it) { R.pageTries.push({ n, noBtn: true }); continue; }
        click1(it);
        await sleep(2600);
        row = findRow();
        R.pageTries.push({ n, found: !!row, rows: document.querySelectorAll('tbody tr').length });
        if (row) break;
      }
    }
    if (!row) {
      const sample = [].slice.call(document.querySelectorAll('tbody tr')).slice(0, 5).map(r => (r.innerText || '').replace(/\s+/g, ' ').slice(0, 40));
      throw new Error('找不到计划行：' + cfg.planName + '（翻页 ' + JSON.stringify(R.pageTries) + ' 样例 ' + JSON.stringify(sample) + '）');
    }
    const edit = [].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑');
    if (!edit) throw new Error('该行没有「编辑」');
    click1(edit);
    // 固定 4s 不够：多宝贝计划（3 件的「一组」）抽屉要拉 3 个宝贝的数据，渲染明显更慢。
    // 实测刘宪华北京-订单120 读出 bid=0 / imp=null，就是读在空气里。改成轮询等就绪。
    let od = null;
    for (let i = 0; i < 15; i++) {
      await sleep(1000);
      od = outer();
      if (od && bidInput() && readImp() !== null) { R.drawerReadyIn = (i + 1) + 's'; break; }
    }
    if (!od) throw new Error('编辑 drawer 没打开');

    // ---------- 2. 先切到「自定义」出价行！ ----------
    const imps = [].slice.call(od.querySelectorAll('[class*=improveNum]'));
    R.improveRows = imps.length;
    if (imps.length >= 2) {
      let r2 = imps[1];
      for (let i = 0; i < 10 && r2 && !r2.querySelector('input[type=radio]'); i++) r2 = r2.parentElement;
      const lab = r2 && r2.querySelector('label');
      if (lab) { click1(lab); await sleep(1800); }
      R.customRadioClicked = !!lab;
    }
    // 切换出价方式会再触发一轮重渲染，读到 0 就再等等
    for (let i = 0; i < 10; i++) {
      const v = parseFloat((bidInput() || {}).value || '0');
      if (v > 0 && readImp() !== null) break;
      await sleep(800);
    }
    const curBid = parseFloat((bidInput() || {}).value || '0');
    const curImp = readImp();
    R.beforeBid = curBid; R.beforeImprove = curImp;
    step('打开：出价 ¥' + curBid + ' / ' + curImp + '%（已切自定义行）');
    if (!curBid || !curImp) throw new Error('读不到当前出价或提升（bid=' + curBid + ', imp=' + curImp + '，抽屉就绪=' + (R.drawerReadyIn || '超时') + '）');

    // ---------- 3. 从当前出价按 0.1 网格扫描到目标 ----------
    const target = cfg.targetImprove;
    const curve = {};
    let bid = Math.round(curBid * 10) / 10;
    let imp = (bid === curBid) ? curImp : await probe(bid);
    curve[bid] = imp;
    let guard = 0;
    while (imp < target && guard++ < 60) {
      const gap = target - imp;
      // 离目标远用大步，近了用 0.1
      const st = gap > 12 ? Math.max(0.5, Math.round(curBid * 0.06 * 10) / 10) : 0.1;
      bid = Math.round((bid + st) * 10) / 10;
      imp = await probe(bid); curve[bid] = imp;
    }
    if (imp < target) throw new Error('加到 ¥' + bid + ' 仍达不到 ' + target + '%（当前 ' + imp + '%）');
    // 往下回退到最小的、仍 >= 目标的 0.1 网格值
    for (let k = 0; k < 40; k++) {
      const lower = Math.round((bid - 0.1) * 10) / 10;
      if (lower <= 0) break;
      const p = await probe(lower);
      curve[lower] = p;
      if (p >= target) { bid = lower; imp = p; } else break;
    }
    R.finalBid = bid; R.finalImprove = imp; R.curve = curve;
    step('反解出价 ¥' + bid.toFixed(1) + ' → ' + imp + '%');

    // ---------- 3.5 【必须】把输入框写回 bid ----------
    // 坑（2026-09-21 抓到，20 个计划全部中招）：回退循环是靠「探测 bid-0.1、不合格就 break」
    // 退出的，退出时**输入框里留着的正是那个被否决的值**，而 bid/imp 变量是上一个通过的值。
    // 保存提交的是输入框的实际内容 → 实存出价比 finalBid 整整低一档：
    //   报 34.0 实存 ¥33.90（149% 而非 150%）、报 3.3 实存 ¥3.20（约 148% 而非 153%）。
    // 自检也因此形同虚设——查的是变量，不是输入框。
    // 以后一律：保存前写回 bid，并且用**输入框实际内容**做自检。
    {
      const want = bid.toFixed(1);
      let el = bidInput();
      if (!el) throw new Error('回退后出价输入框消失');
      // ⚠️ 别比字符串：输入框显示的是 "34"，不是 "34.0"，比字符串会把好结果判成失败
      if (Math.abs(parseFloat(el.value) - bid) > 1e-6) {
        const p = await probe(bid);
        curve['restore@' + bid] = p;
        R.restored = { to: bid, imp: p, from: String(el.value).trim() };
        if (p < target) throw new Error('写回 ¥' + want + ' 后反而只有 ' + p + '%（目标 ' + target + '%）');
        imp = p;
      }
      el = bidInput();
      R.inputAtSave = el ? String(el.value).trim() : null;
      if (!(el && Math.abs(parseFloat(el.value) - bid) <= 1e-6)) throw new Error('保存前出价框=' + R.inputAtSave + '，期望 ' + want + '（写回失败）');
    }

    // ---------- 4. 自检 ----------
    R.checks = { 达成目标: imp >= target, 出价框已写回: !!R.inputAtSave && Math.abs(parseFloat(R.inputAtSave) - bid) <= 1e-6 };

    // ---------- 3.7 提价前置校验（2026-09-27 老板批准，fail-closed）----------
    // 起因：09-21 批量提价时把孙燕姿订单出价从 ¥26.66/¥28.94 一次抬到 ¥34（+27%/ +17%），
    //       随后该 campaign 烧掉 ¥300+ 只来 6 个咨询。从此提价必须先过两道闸。
    //   闸1 历史成本：过去 H 天单次转化成本 > 目标×2 的计划，不许再提价（先解决成本，再加价）
    //   闸2 幅度：单次提价不得超过 +MAX_RAISE%
    {
      const H = Number(cfg.historyDays || 3);
      const MAX_RAISE = Number(cfg.maxRaisePct != null ? cfg.maxRaisePct : 20) / 100;
      const MAX_CPC = Number(cfg.maxCostPerChat != null ? cfg.maxCostPerChat : 8);  // ¥4 目标 × 2
      const MIN_COST = Number(cfg.minHistoryCost != null ? cfg.minHistoryCost : 20); // 样本下限

      // 闸2：幅度（用抽屉里读到的真实当前出价 curBid 作分母）
      if (curBid > 0) {
        const raisePct = (bid - curBid) / curBid * 100;
        R.提价幅度 = +raisePct.toFixed(1) + '%';
        R.幅度上限 = (MAX_RAISE * 100) + '%';
        if (raisePct > MAX_RAISE * 100 + 1e-6) {
          throw new Error('提价幅度 ' + raisePct.toFixed(1) + '% > 上限 ' + (MAX_RAISE * 100) +
            '%（¥' + curBid + ' → ¥' + bid + '）—— 请分步提，拒绝一次跳太多');
        }
      }

      // 闸1：历史单次转化成本
      let h = null;
      try {
        const end = new Date(), start = new Date(end.getTime() - (H - 1) * 86400000);
        const ymd = d => d.getFullYear().toString() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
        const hr = await window.lib.mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
          data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, startDate: ymd(start), endDate: ymd(end), includeEndDate: true, campaignStatus: [], statusGroup: [] }) } });
        const list = ((hr && hr.data) || {}).result || [];
        const c = list.filter(x => String(x.campaignId) === String(cfg.planId))[0];
        if (c) {
          const d = c.adDataDetailVO || {};
          const cost = Number(d.cost || 0) / 100, chats = Number(d.chatPv || 0);
          h = { 花费: +cost.toFixed(2), 咨询: chats, 单次成本: chats > 0 ? +(cost / chats).toFixed(2) : (cost > 0 ? '∞' : 0) };
        }
      } catch (e) { h = { err: (e && (e.ret || e.message)) || String(e) }; }
      R.历史成本 = h;
      if (h && !h.err && h.花费 >= MIN_COST) {
        const cpc = h.咨询 > 0 ? h.花费 / h.咨询 : Infinity;
        if (cpc > MAX_CPC) {
          throw new Error('过去 ' + H + ' 天单次转化成本 ¥' + (cpc === Infinity ? '∞' : cpc.toFixed(2)) +
            ' > ¥' + MAX_CPC + '（目标×2，花费¥' + h.花费 + ' / ' + h.咨询 + '次）—— 先降成本，不许提价');
        }
      } else if (h && h.err) {
        R.历史成本警告 = '拉取失败，闸1未生效：' + h.err;
      } else if (h && h.花费 < MIN_COST) {
        R.历史成本警告 = '样本不足（花费¥' + h.花费 + ' < ¥' + MIN_COST + '），闸1跳过';
      }
    }

    // ---------- 3.8 出价上限校验（永久规则 2026-09-27，fail-closed）----------
    // 咨询量 ≤ ¥4 / 订单量 ≤ ¥35。见 出价上限规则-永久.md
    // 这是硬约束：宁可这笔不做，也不许把超限出价写进线上。
    {
      const capInfo = resolveCap();
      R.目标类型 = capInfo.targetName;
      R.目标判定来源 = capInfo.fromCfg ? 'cfg' : (capInfo.targetName === '(未知)' ? 'cfg.maxBid' : '抽屉');
      R.出价上限 = capInfo.cap === undefined ? '(无法判定)' : capInfo.cap;
      if (capInfo.cap === undefined) {
        throw new Error('读不到「更想获得」目标类型，且调用方未提供 target/maxBid —— 无法确认出价上限，拒绝保存');
      }
      R.checks.出价未超上限 = bid <= capInfo.cap + 1e-9;
      if (!R.checks.出价未超上限) {
        R.aborted = '出价 ¥' + bid.toFixed(2) + ' 超过「' + R.目标类型 + '」上限 ¥' + capInfo.cap + '（永久规则），未保存';
        R.selfCheckPassed = false;
        return JSON.stringify(R, null, 1);
      }
      step('上限校验 ' + R.目标类型 + '：¥' + bid.toFixed(2) + ' ≤ ¥' + capInfo.cap + ' ✅');
    }

    R.selfCheckPassed = Object.keys(R.checks).every(k => R.checks[k]);
    if (!R.selfCheckPassed) { R.aborted = '自检未通过，未保存：' + JSON.stringify(R.checks); return JSON.stringify(R, null, 1); }
    if (!cfg.submit) { R.aborted = 'dry run，未保存'; return JSON.stringify(R, null, 1); }

    // ---------- 4.5 顺带修正预算（可选） ----------
    // 坑：编辑 drawer 保存时会提交**所有**字段。drawer 打开时预算会回落到平台默认预设
    //（订单目标默认 ¥96/¥288），所以只改出价也可能把预算一起改掉。实测踩过：
    // AB-图A-订单120 的预算被从 ¥60 写成了 ¥96，破坏了三臂对称性。
    if (cfg.budget) {
      const grp = outer().querySelector('[class*=radioGroup--eEugUXoZ]');
      if (!grp) throw new Error('找不到日花费上限控件');
      const box = [].slice.call(grp.querySelectorAll('[class*=radio--]'));
      R.budgetOptions = box.map(e => (e.innerText || '').trim());
      // ⚠️ 最后一个选项是「自定义」槽位，输入后它自己的文字会变成 ¥60，
      // 所以**不能按文字匹配**，否则会把自定义槽当预设点，一点就把输入清空。
      // 正确做法：预设只看前 n-1 个，其余一律走自定义槽。
      const custom = box[box.length - 1];
      const preset = box.slice(0, -1).find(e => (e.innerText || '').trim() === '¥' + cfg.budget);
      let binp = null;
      if (preset) {
        click1(preset); await sleep(1600);
        R.budgetByPreset = true;
        // ⚠️ 预设档**没有输入框**，只有点了「自定义」槽才会渲染出 input。
        // 旧代码点完预设仍强制要 input，于是碰到 ¥150 这种预设档就直接抛错
        //（实测：刘宪华北京-咨询120 出价已经解到 153%，却卡在预算这步没保存）。
        // 预设档改用「选中态」当证据，拿不到就退回自定义槽重设一次。
        R.budgetPresetCls = (preset.className || '').toString().slice(0, 140);
        const parentCls = ((preset.parentElement || {}).className || '').toString().slice(0, 140);
        if (!/check|active|select/i.test(R.budgetPresetCls + ' ' + parentCls)) {
          click1(custom); await sleep(1600);
          binp = grp.querySelector('input');
          if (!binp) throw new Error('预算预设点击后没有选中证据，退回自定义槽又没有输入框（cls=' + R.budgetPresetCls + '）');
          setNative(binp, cfg.budget); await sleep(600);
          binp.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
          binp.dispatchEvent(new Event('blur', { bubbles: true }));
          await sleep(1600);
          R.budgetByPreset = false;
        }
        step('预算 ¥' + cfg.budget + (R.budgetByPreset ? '（预设）' : '（预设无选中证据→自定义槽）'));
      } else {
        click1(custom); await sleep(1800);
        step('预算 ¥' + cfg.budget + '（自定义槽）');
      }
      if (R.budgetByPreset) {
        R.budgetInputVal = String(cfg.budget);
        R.checks.预算对 = true;
      } else {
        if (!binp) binp = grp.querySelector('input');
        if (!binp) throw new Error('没出现预算输入框');
        R.budgetInputVal = String(binp.value).trim();
        R.checks.预算对 = R.budgetInputVal === String(cfg.budget);
      }
      R.selfCheckPassed = Object.keys(R.checks).every(k => R.checks[k]);
      if (!R.selfCheckPassed) { R.aborted = '自检未通过（预算输入框=' + R.budgetInputVal + '，目标 ¥' + cfg.budget + '），未保存'; return JSON.stringify(R, null, 1); }
    }

    // ---------- 5. 保存（外层 drawer 的确定在 .ant-drawer-footer 里，是个 div） ----------
    const wrap = outer().closest('.ant-drawer');
    const foot = wrap && wrap.querySelector('.ant-drawer-footer');
    R.footerHtml = foot ? (foot.innerHTML || '').replace(/\s+/g, ' ').slice(0, 200) : null;
    const ok = foot && [].slice.call(foot.querySelectorAll('div,span,button'))
      .find(e => e.children.length === 0 && /^确\s*定$/.test((e.innerText || '').trim()));
    if (!ok) throw new Error('找不到外层确定按钮（footer：' + (R.footerHtml || '无') + '）');
    click1(ok);
    R.saved = true;
    await sleep(5000);
    R.afterSave = { drawersLeft: drawers().length, toast: ((document.body.innerText || '').match(/[^\n]*(修改成功|成功|失败|错误|不能)[^\n]*/g) || []).slice(0, 4) };
    return JSON.stringify(R, null, 1);
  } catch (e) {
    R.fatal = e.message;
    return JSON.stringify(R, null, 1);
  }
})()
