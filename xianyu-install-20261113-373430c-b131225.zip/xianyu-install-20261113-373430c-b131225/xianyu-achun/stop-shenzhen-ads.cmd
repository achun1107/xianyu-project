@echo off
rem 10:00 -- boss 2026-10-12: Shenzhen HonourOfKings GONGCHUANG-ZHIYE + QIMIAOYE,
rem stop ALL promotion for those two events after 10am (that day only).
rem Adds the 4 plan ids to AD-EXCLUDE.json AND pauses them.
rem AD-EXCLUDE is the ONLY thing that survives the 08:00 open / 08:40 guard / 30-min stuck-recovery.
rem ASCII only in .cmd: non-ASCII bytes get mangled by the console codepage.
cd /d D:\DSH\achun
node tools\event-ads.js --ids=99921823,100284773,98904274,100129385 --why="boss 2026-10-12: Shenzhen GONGCHUANG-ZHIYE + QIMIAOYE (JIANIANHUA), all promotion paused after 10:00"
