// ad-editor-remove.js —— 从已存在的擦亮计划里【移除】宝贝，并按需重解出价
// cfg = { planName, searchKey, removeItems:[], keepImprove:120, submit:false }
//
// 为什么需要它：ad-editor.js 只能【添加】，没有移除路径。2026-10-08 出了一次事故 ——
//   给三亚计划加宝贝时，ad-editor.js 的行匹配把父容器当成了行，点「添加」点到了
//   别的行，把广州周杰伦的 1083554882086 加进了三亚计划（而那条正是老板要求停投的）。
//   修好匹配之后，还得能把加错的摘掉。
//
// 移除方式（2026-10-08 探明）：选品抽屉里，已选中的行按钮文字是「取消添加」，
//   未选中的是「添加」。所以移除 = 点那一行的「取消添加」。
//
// 沿用 ad-editor.js 的两条既有教训：
//   1. 外层 drawer 的「确定」不是 <button>，要从 .ant-drawer 包裹层的
//      .ant-drawer-footer 里找 div/span（querySelectorAll('button') 恒为空）。
//   2. 增删宝贝会改变系统建议出价，所以要用 UI 二分把「预计提升」重解回 keepImprove。
(async () => {
  const cfg = window.__RCFG_REMOVE || {};
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const R = { steps: [], errors: [] };
  const step = s => R.steps.push(s);

  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  function setNative(el, val) {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    d.set.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const bt = (t, root) => [].slice.call((root || document).querySelectorAll('div,span,button,a'))
    .find(e => e.children.length === 0 && (e.innerText || '').trim() === t);
  const drawers = () => [].slice.call(document.querySelectorAll('.ant-drawer-content'))
    .filter(d => d.getBoundingClientRect().width > 200);
  const outerDrawer = () => drawers().find(d => /编辑计划/.test(d.innerText || ''));
  const pickerDrawer = () => drawers().find(d => /编辑宝贝|新增宝贝/.test(d.innerText || '') && d.querySelector('input[placeholder="请输入宝贝标题"]'));

  try {
    // ---------- 1. 打开该计划的编辑 ----------
    const rows = [].slice.call(document.querySelectorAll('tr'));
    const row = rows.find(r => (r.innerText || '').indexOf(cfg.planName) >= 0);
    if (!row) throw new Error('列表里找不到计划行：' + cfg.planName);
    const edit = [].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑');
    if (!edit) throw new Error('该行没有「编辑」');
    click1(edit); await sleep(4000);

    const od = outerDrawer();
    if (!od) throw new Error('编辑计划抽屉没打开');
    R.beforeBadge = ((od.innerText.match(/已选宝贝\(([^)]*)\)/) || [])[1]);
    R.beforeImprove = ((od.innerText.match(/预计提升\s*(\d+)%/) || [])[1]);
    step('打开编辑：' + R.beforeBadge + '，预计提升 ' + R.beforeImprove + '%');

    // ---------- 2. 点「编辑宝贝」 ----------
    const ei = bt('编辑宝贝', od) || [].slice.call(od.querySelectorAll('div,span,button,a'))
      .find(e => /编辑宝贝/.test(e.innerText || ''));
    if (!ei) throw new Error('找不到「编辑宝贝」入口');
    click1(ei); await sleep(4500);
    const pd = pickerDrawer();
    if (!pd) throw new Error('编辑宝贝抽屉没打开');

    // ---------- 3. 搜索 ----------
    const inp = pd.querySelector('input[placeholder="请输入宝贝标题"]');
    if (!inp) throw new Error('找不到宝贝搜索框');
    setNative(inp, cfg.searchKey || '');
    inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    inp.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    await sleep(4500);

    // ---------- 4. 逐条移除（=== 点那一行的「取消添加」）----------
    // 【关键】行匹配用打分：真行元素(TR) 优先，同档取文字最短的。
    //   原来 ad-editor.js 取"第一个匹配"，父容器会抢先命中 → 点到别的行（真实事故）。
    const pdNow = pickerDrawer();
    const cand = {};
    [].slice.call(pdNow.querySelectorAll('tr,li,div')).forEach(e => {
      const t = (e.innerText || '').replace(/\s+/g, ' ').trim();
      const m = t.match(/宝贝ID:(\d{10,})/);
      if (!m || t.length >= 500) return;
      const id = m[1];
      const score = (e.tagName === 'TR' ? 0 : 100000) + t.length;
      if (!cand[id] || score < cand[id].score) cand[id] = { score: score, el: e, text: t };
    });
    R.rowsAvailable = Object.keys(cand);
    R.removed = []; R.notFound = [];
    for (const id of (cfg.removeItems || [])) {
      const c = cand[String(id)];
      if (!c) { R.notFound.push(String(id)); continue; }
      // 【2026-10-08 修·真实事故】绝不能向上找祖先容器。
      //   上一版写成「从行往上找 6 层，第一个文字是『取消添加』的元素」——
      //   当目标行【已经不是选中态】时（按钮是「添加」），它会往上爬到含多行的容器，
      //   命中【邻居行】的「取消添加」并点掉，把一条正确的宝贝误删了
      //   （实际把 1090140297900 从三亚计划删掉了）。
      //   正确做法：只在【这一行内部】找；找不到就报错，不猜。
      const b = [].slice.call(c.el.querySelectorAll('button,a,span'))
        .find(x => (x.innerText || '').trim() === '取消添加');
      if (b) { click1(b); R.removed.push(String(id)); }
      else { R.errors.push('这一行没有「取消添加」（说明它本来就不在计划里）：' + id + '（行文字：' + c.text.slice(0, 60) + '）'); }
      await sleep(900);
    }
    await sleep(1400);
    step('已点取消添加：' + R.removed.join(',') + (R.notFound.length ? ' | 没找到：' + R.notFound.join(',') : ''));

    // ---------- 5. 确定（弹层）----------
    const pd2 = pickerDrawer();
    const pdBtns = [].slice.call(pd2.querySelectorAll('button'));
    const ok1 = pdBtns.find(b => /^确\s*定$/.test((b.innerText || '').trim()));
    if (!ok1) throw new Error('编辑宝贝弹层里没有确定按钮，按钮：' + pdBtns.map(b => b.innerText.trim()).join('|'));
    click1(ok1); await sleep(4000);

    const od2 = outerDrawer();
    R.afterBadge = od2 ? ((od2.innerText.match(/已选宝贝\(([^)]*)\)/) || [])[1]) : null;
    R.afterImprove = od2 ? ((od2.innerText.match(/预计提升\s*(\d+)%/) || [])[1]) : null;
    step('移完：' + R.afterBadge + '，预计提升 ' + R.afterImprove + '%');

    // ---------- 6. 出价重解回 keepImprove ----------
    if (cfg.keepImprove && String(R.afterImprove) !== String(cfg.keepImprove)) {
      const bidInp = od2.querySelector('input[placeholder="自定义出价"]');
      R.hasBidInput = !!bidInp;
      if (bidInp) {
        const readImp = () => {
          const odx = outerDrawer();
          const m = odx && odx.innerText.match(/预计提升\s*(\d+)%/);
          return m ? parseInt(m[1], 10) : null;
        };
        async function probe(v) {
          const el = outerDrawer().querySelector('input[placeholder="自定义出价"]');
          if (!el) throw new Error('出价框消失');
          el.focus(); setNative(el, (Math.round(v * 100) / 100).toFixed(2));
          await sleep(400);
          el.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
          el.dispatchEvent(new Event('blur', { bubbles: true }));
          await sleep(2600);
          return readImp();
        }
        const suggest = parseFloat(((od2.innerText.match(/出价\s*¥\s*([0-9.]+)/) || [])[1]) || '0') || null;
        R.suggestYuan = suggest;
        let lo = suggest || 1, hi = Math.max((suggest || 1) * 1.5, 2);
        const curve = {};
        curve[lo] = await probe(lo); curve[hi] = await probe(hi);
        let g = 0;
        while (curve[hi] < cfg.keepImprove && g++ < 8) { lo = hi; hi = hi * 1.5; curve[hi] = await probe(hi); }
        for (let i = 0; i < 14 && hi - lo > 0.011; i++) {
          const mid = Math.round((lo + hi) / 2 * 100) / 100;
          if (mid === lo || mid === hi) break;
          curve[mid] = await probe(mid);
          if (curve[mid] >= cfg.keepImprove) hi = mid; else lo = mid;
        }
        R.finalBid = Math.round(hi * 100) / 100;
        curve[R.finalBid] = await probe(R.finalBid);
        R.curve = curve;
        R.finalImprove = curve[R.finalBid];
        step('重解出价 ¥' + R.finalBid.toFixed(2) + ' → ' + R.finalImprove + '%');
      }
    }

    // ---------- 7. 保存 ----------
    R.selfCheck = {
      宝贝数对: String(R.afterBadge) === String((parseInt(R.beforeBadge, 10) - (cfg.removeItems || []).length)) + '/10',
      提升对: !cfg.keepImprove || String(R.finalImprove || R.afterImprove) === String(cfg.keepImprove),
    };
    R.selfCheckPassed = Object.keys(R.selfCheck).every(k => R.selfCheck[k]);
    if (!R.selfCheckPassed) { R.aborted = '自检未通过，未保存'; return JSON.stringify(R, null, 1); }
    if (!cfg.submit) { R.aborted = 'dry run，未保存'; return JSON.stringify(R, null, 1); }

    const wrap = outerDrawer().closest('.ant-drawer');
    const foot = wrap && wrap.querySelector('.ant-drawer-footer');
    R.footerHtml = foot ? (foot.innerHTML || '').replace(/\s+/g, ' ').slice(0, 300) : null;
    const ok2 = foot && [].slice.call(foot.querySelectorAll('div,span,button'))
      .find(e => e.children.length === 0 && /^确\s*定$/.test((e.innerText || '').trim()));
    if (!ok2) throw new Error('找不到外层 drawer 的确定按钮（footer 内容：' + (R.footerHtml || '无 footer') + '）');
    click1(ok2);
    R.saved = true;
    await sleep(5000);
    R.afterSave = {
      url: location.href,
      drawersLeft: drawers().length,
      toast: ((document.body.innerText || '').match(/[^\n]*(成功|失败|错误|不能|超出)[^\n]*/g) || []).slice(0, 4),
    };
    return JSON.stringify(R, null, 1);
  } catch (e) {
    R.fatal = e.message;
    return JSON.stringify(R, null, 1);
  }
})()
