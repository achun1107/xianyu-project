// ad-read-now.js —— 快速读今日擦亮：实时花费 + 缓存明细 + 宝贝标签（纯 API，不爬表格）
(async () => {
  const mtop = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const cr = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
  const plans = (cr.data || {}).result || [];
  const ir = await mtop.request({ api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, tab: 'all', needTabs: true }) } });
  const items = ((ir.data || {}).result || {}).itemList || [];
  const byId = {}; items.forEach(it => byId[String(it.itemId)] = it);

  const rows = plans.map(c => {
    const t = c.todayAdDataDetail || {}, it = c.infoTab || {};
    const ids = (c.entityList || []).map(e => String(e.entityId));
    return {
      id: String(c.campaignId), name: c.title, target: c.bidTarget,
      bid: n(c.cpm) / 100, budget: n(c.maxDayBudget) / 100,
      实时花费: n(it.todayCost) / 100,
      缓存花费: n(t.cost) / 100, 缓存时间: t.time, 曝光: n(t.showPv), 点击: n(t.clickPv),
      询单量: n(t.chatPv), 下单: n(t.payPv), 交易额: n(t.payAmount) / 100, 投产比: n(t.returnOnInvestment),
      ctr: n(t.ctr), 宝贝数: ids.length,
      tags: ids.map(i => ((byId[i] || {}).tags || []).join('/') || '-').join('|'),
      成交: ids.reduce((s, i) => s + n((byId[i] || {}).saleCnt), 0),
      pause: String(c.pauseStatus),
    };
  });
  return JSON.stringify({ 时刻: new Date().toLocaleString('zh-CN'), 缓存时间: rows[0] && rows[0].缓存时间, 计划: rows });
})()
