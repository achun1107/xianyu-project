// ad-live-rows2.js —— 翻页抓表格实时列（按内容定位，不猜列序）
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const raw = () => [].slice.call(document.querySelectorAll('tbody tr')).map(tr =>
    [].slice.call(tr.querySelectorAll('td')).map(x => (x.innerText || '').replace(/\s+/g, ' ').trim()));

  const diag = { tr: document.querySelectorAll('tbody tr').length };
  const r0 = raw();
  diag.首行单元格数 = r0[0] ? r0[0].length : 0;
  diag.首行 = r0[0] ? r0[0].slice(0, 20) : null;

  const all = {};
  const grab = () => raw().forEach(c => {
    const idc = c.find(x => /^\d{7,9}$/.test(x));
    if (idc) all[idc] = c;
  });
  grab();
  const pages = [].slice.call(document.querySelectorAll('.ant-pagination-item'))
    .map(e => (e.getAttribute('title') || e.innerText || '').trim()).filter(t => /^\d+$/.test(t));
  diag.页码 = pages;
  for (const p of pages) {
    if (p === '1') continue;
    const it = [].slice.call(document.querySelectorAll('.ant-pagination-item'))
      .find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === p);
    if (!it) continue;
    click1(it);
    await sleep(3000);
    grab();
  }
  const ids = Object.keys(all);
  return JSON.stringify({
    诊断: diag,
    时刻: new Date().toLocaleString('zh-CN'),
    抓到: ids.length,
    行: ids.map(id => all[id]),
  });
})()
