@echo off
rem XianyuPublish4Groups -- every 5 min: publish the group that is due, then open its ads 10 min later.
rem ASCII only: .cmd with non-ASCII bytes gets mangled by the console codepage.
cd /d D:\DSH\achun
node tools\publish-4groups.js
