// ad-target-probe.js —— 看「更想获得」5 个选项的真实状态
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const out = { url: location.href, 阶段: '打开页面即读' };
  const dump = tag => {
    const rs = [].slice.call(document.querySelectorAll('input[type=radio]'))
      .filter(r => ['exposure', 'click', 'follow_collect', 'chat', 'order', 'lead'].indexOf(r.value) >= 0);
    return rs.map(r => {
      const lab = r.closest('label') || r.parentElement;
      const box = lab && lab.parentElement;
      return {
        value: r.value, checked: r.checked, disabled: r.disabled,
        标签: ((lab && lab.innerText) || '').replace(/\s+/g, ' ').trim().slice(0, 24),
        附近文本: ((box && box.innerText) || '').replace(/\s+/g, ' ').trim().slice(0, 40),
        cls: String(lab && lab.className || '').slice(0, 50),
      };
    });
  };
  out.页面加载时 = dump();

  // 打开一个已存在的凤凰传奇计划看「更想获得」
  const rows = [].slice.call(document.querySelectorAll('tbody tr'));
  const row = rows.find(r => /凤凰传奇北京-咨询120/.test(r.innerText || ''));
  out.找到计划行 = !!row;
  if (row) {
    const ed = [].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑');
    click1(ed);
    for (let i = 0; i < 15; i++) { await sleep(1000); if (/编辑计划/.test(document.body.innerText || '')) break; }
    await sleep(2500);
    out.编辑抽屉里的 = dump();
    out.抽屉文本片段 = ((document.querySelector('.ant-drawer-content') || {}).innerText || '').replace(/\s+/g, ' ').match(/.{0,40}更想获得.{0,180}/);
  }
  return JSON.stringify(out, null, 1);
})()
