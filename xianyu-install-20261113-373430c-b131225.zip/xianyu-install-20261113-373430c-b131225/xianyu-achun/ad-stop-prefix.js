// ad-stop-prefix.js —— 按计划名前缀批量暂停（本次：单明星-*）
(async () => {
  const mtop = window.lib.mtop;
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const PREFIX = /^单明星/;

  const search = async () => {
    const r = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 100, campaignStatus: [], statusGroup: [] }) } });
    return (r.data || {}).result || [];
  };
  const before = await search();
  const hits = before.filter(c => PREFIX.test(c.title || ''));
  const out = {
    时刻: new Date().toLocaleString('zh-CN'),
    命中: hits.map(c => ({
      id: c.campaignId, name: c.title, 目标: c.bidTarget, 出价: n(c.cpm) / 100, 预算: n(c.maxDayBudget) / 100,
      暂停态: c.pauseStatus, 实时花费: n((c.infoTab || {}).todayCost) / 100,
      今日询单: n((c.todayAdDataDetail || {}).chatPv), 今日下单: n((c.todayAdDataDetail || {}).payPv),
    })),
  };
  const ids = hits.filter(c => String(c.pauseStatus) !== '1').map(c => String(c.campaignId));
  out.将暂停 = ids.length;
  if (!ids.length) { out.结果 = '本来就都停着'; return JSON.stringify(out, null, 1); }

  const pr = await mtop.request({ api: 'mtop.taobao.idle.ad.campaign.pause', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ campaignIds: ids, pauseStatus: 1 }) } });
  out.平台返回 = (pr.ret || [])[0];
  let ok = 0;
  Object.keys(pr.data || {}).forEach(k => { if ((pr.data[k] || {}).pauseStatus === 1) ok++; });
  out.平台确认暂停数 = ok;

  await sleep(6000);
  const after = await search();
  out.停后 = {
    仍在跑的单明星: after.filter(c => PREFIX.test(c.title || '') && String(c.pauseStatus) !== '1').map(c => c.campaignId + ' ' + c.title),
    全店: {
      计划数: after.length,
      在跑: after.filter(c => c.statusGroup === 'online').length,
      暂停: after.filter(c => String(c.pauseStatus) === '1').length,
      主副集合在跑: after.filter(c => /^擦亮宝贝/.test(c.title) && c.statusGroup === 'online').length,
    },
  };
  out.结果 = out.停后.仍在跑的单明星.length === 0 ? '✅ 单明星已全部暂停' : '⚠ 还有没停的';
  return JSON.stringify(out, null, 1);
})()
