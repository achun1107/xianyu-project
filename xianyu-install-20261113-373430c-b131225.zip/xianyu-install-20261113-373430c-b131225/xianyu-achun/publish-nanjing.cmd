@echo off
cd /d D:\DSH\achun
node publish-stagger.js 2
