// ad-fix-dangling.js —— 从计划里摘掉"不在商品列表"的宝贝，并锁住预算
// cfg = window.__RBCFG = [{ planName, removeTitles:[], budget }]
(async () => {
  const PLANS = window.__RBCFG || [];
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  function setNative(el, val) {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    d.set.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const drawers = () => [].slice.call(document.querySelectorAll('.ant-drawer-content')).filter(d => d.getBoundingClientRect().width > 200);
  const outer = () => drawers().find(d => /编辑计划/.test(d.innerText || ''));
  const titles = od => [].slice.call(od.querySelectorAll('[class*=goodsTitle]')).map(e => (e.innerText || '').trim());
  const out = [];

  for (const cfg of PLANS) {
    const R = { plan: cfg.planName };
    try {
      // 清掉「计划ID」筛选框的残留值：这个框的筛选是**粘住的**，一旦填过，
      // 翻页/刷新都会保留，表格里只剩 1 行 → 按计划名找不到行（实测踩过）
      const idFilter = [].slice.call(document.querySelectorAll('input'))
        .find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
      if (idFilter && String(idFilter.value || '').trim() !== '') {
        R.hadIdFilter = idFilter.value;
        setNative(idFilter, '');
        await sleep(500);
        idFilter.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
        idFilter.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
        await sleep(3200);
      }

      // 先确保停在「计划」tab：管理页有两个 tab（计划N / 宝贝N），
      // 之前点过「宝贝」后状态会保留，表格里全是宝贝行 → 按计划名必然找不到行
      const planTab = [].slice.call(document.querySelectorAll('.ant-tabs-tab,.ant-tabs-tab-btn'))
        .find(e => /^计划\(\d+\)$/.test((e.innerText || '').trim()));
      if (planTab) { click1(planTab); await sleep(3500); R.clickedPlanTab = true; }

      // ★ 用「请输入计划ID」框精确筛选（2026-09-26 实测**有效**；之前笔记记成"回车不过滤"是错的）。
      //   25 条计划分 3 页，靠翻页找行会被「宝贝」表的分页组抢走点击，得不偿失。
      if (cfg.planId) {
        const box = [].slice.call(document.querySelectorAll('input'))
          .find(e => (e.placeholder || '').indexOf('计划ID') >= 0);
        if (box) {
          setNative(box, String(cfg.planId));
          await sleep(600);
          box.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
          box.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
          await sleep(4000);
          R.已按ID筛选 = String(cfg.planId);
        }
      }

      const findRow = () => [].slice.call(document.querySelectorAll('tbody tr')).find(r => (r.innerText || '').indexOf(cfg.planName) >= 0);
      let row = null;
      for (let i = 0; i < 10 && !row; i++) { await sleep(1000); row = findRow(); }
      for (let p = 2; p <= 6 && !row; p++) {
        const pg = document.querySelector('.ant-pagination');
        const b = pg && [].slice.call(pg.querySelectorAll('.ant-pagination-item')).find(e => ((e.getAttribute('title') || e.innerText || '').trim()) === String(p));
        if (!b) break;
        click1(b); await sleep(3500); row = findRow();
      }
      if (!row) throw new Error('找不到计划行');
      click1([].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑'));
      let od = null;
      for (let i = 0; i < 15; i++) { await sleep(1000); od = outer(); if (od && od.querySelector('[class*=goodsTitle]')) break; }
      if (!od) throw new Error('编辑抽屉没打开');
      R.修改前 = titles(od);

      let removed = 0;
      for (let pass = 0; pass < 6; pass++) {
        const items = [].slice.call(od.querySelectorAll('[class*=goodsItem]'));
        let hit = null;
        for (const it of items) {
          const t = ((it.querySelector('[class*=goodsTitle]') || {}).innerText || '').trim();
          if (cfg.removeTitles.indexOf(t) >= 0) { hit = it.querySelector('[class*=clearItemBtn]'); break; }
        }
        if (!hit) break;
        click1(hit); removed++; await sleep(2500);
        od = outer() || od;
      }
      R.已摘掉 = removed;
      od = outer() || od;
      R.修改后 = titles(od);
      R.badge = ((od.innerText || '').match(/已选宝贝\(([^)]*)\)/) || [])[1];
      if (removed === 0) throw new Error('没摘到任何宝贝（抽屉里没有匹配的标题）');

      // 锁预算
      if (cfg.budget) {
        let grp = od.querySelector('[class*=radioGroup--eEugUXoZ]');
        if (!grp) {
          const cand = [].slice.call(od.querySelectorAll('div')).filter(d => /自定义/.test(d.innerText || '') && d.querySelectorAll('[class*=radio--]').length >= 2);
          grp = cand.sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length)[0];
        }
        if (!grp) throw new Error('找不到日花费上限控件');
        let box = [].slice.call(grp.querySelectorAll('[class*=radio--]'));
        // ★ 抽屉刚打开时预算还没渲染出当前值，末槽显示的是**占位文案「自定义」**，
        //   于是"预设匹配"失配、"自定义槽"又被当空值 → 保存被 fail-closed 拦下。
        //   实测：等 1~8 秒后末槽会变成「¥90」且为选中态。先等它渲染出来再判断。
        for (let w = 0; w < 12; w++) {
          const last = box[box.length - 1];
          if (last && /^¥\s*\d/.test((last.innerText || '').trim())) break;
          await sleep(800);
          od = outer() || od;
          const g2 = od.querySelector('[class*=radioGroup--eEugUXoZ]');
          if (g2) { grp = g2; box = [].slice.call(grp.querySelectorAll('[class*=radio--]')); }
        }
        R.预算档位 = box.map(e => (e.innerText || '').trim());
        const want = '¥' + cfg.budget;
        const custom = box[box.length - 1];
        const preset = box.slice(0, -1).find(e => (e.innerText || '').trim() === want);
        if (preset) { click1(preset); await sleep(1600); R.预算回读 = want; }
        else if ((custom.innerText || '').trim() === want) { R.预算回读 = want; R.预算本就是目标值 = true; }
        else {
          click1(custom); await sleep(1800);
          // ⚠️ 必须取「自定义槽自己内部」的 input：grp.querySelector('input') 会先命中别的槽，
          // 而且 React 在输入后会重建节点，所以写之前和读之前都要重新取。
          let bi = custom.querySelector('input') || grp.querySelector('input');
          if (!bi) throw new Error('自定义预算槽没有输入框');
          setNative(bi, cfg.budget); await sleep(800);
          bi.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
          bi.dispatchEvent(new Event('blur', { bubbles: true }));
          await sleep(2000);
          bi = custom.querySelector('input') || grp.querySelector('input');
          R.预算回读 = bi ? String(bi.value || '').trim() : '';
        }
        if (Number(String(R.预算回读).replace(/[^\d.]/g, '')) !== Number(cfg.budget)) throw new Error('预算回读=' + R.预算回读 + ' 期望 ' + cfg.budget + '，未保存');
      }

      const wrap = od.closest('.ant-drawer');
      const foot = wrap && wrap.querySelector('.ant-drawer-footer');
      const ok = foot && [].slice.call(foot.querySelectorAll('div,span,button')).find(e => e.children.length === 0 && /^确\s*定$/.test((e.innerText || '').trim()));
      if (!ok) throw new Error('找不到外层确定');
      click1(ok);
      R.已保存 = true;
      await sleep(6000);
      R.提示 = ((document.body.innerText || '').match(/[^\n]*(成功|失败|错误|不能|至少)[^\n]*/g) || []).slice(0, 3);
    } catch (e) { R.fatal = e.message; }
    out.push(R);
    await sleep(2000);
  }
  return JSON.stringify(out, null, 1);
})()
