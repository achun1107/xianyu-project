(async () => {
  const mtop = window.lib.mtop;
  const out = { hasLib: !!(window.lib && window.lib.mtop) };
  if (!out.hasLib) return JSON.stringify(out);

  // 1) 全部可擦亮商品（tab=all 也是 38，与 platReco 一致）
  const sr = await mtop.request({
    api: 'mtop.taobao.idle.ad.item.searchV2', v: '1.0', type: 'POST',
    data: { requestJson: JSON.stringify({ pageNum: 1, pageSize: 50, tab: 'all', needTabs: false, searchKey: '' }) },
  });
  const items = (((sr.data || {}).result) || {}).itemList || [];
  out.可擦亮商品数 = items.length;
  out.可擦亮商品 = items.map(x => ({
    itemId: String(x.itemId), catId: x.catId, price: x.price, saleCnt: x.saleCnt,
    tags: (x.tags || []).join('/'), title: (x.title || '').split('\n')[0].slice(0, 46),
    publishTime: x.publishTime,
  }));

  // 2) 全部计划及其商品
  const plans = [];
  for (let p = 1; p <= 8; p++) {
    const r = await mtop.request({
      api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: p, pageSize: 50, campaignStatus: [-6, -5, -4, -3, -2, 1, 2, 3, 4, 6, 99], statusGroup: [] }) },
    });
    if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0)) break;
    const d = r.data || {}, list = d.result || [];
    list.forEach(c => plans.push({
      id: c.campaignId, name: c.campaignName || c.title || '', target: c.bidTarget,
      cpm: c.cpm, budget: c.maxDayBudget, status: c.status,
      items: (c.entityList || []).map(e => String(e.entityId)),
    }));
    if (list.length < 50 || String(d.nextPage) === 'false') break;
  }
  out.计划数 = plans.length;
  out.计划 = plans;

  // 3) 覆盖集合
  const covered = {};
  plans.forEach(p => p.items.forEach(id => { (covered[id] = covered[id] || []).push(p.name); }));
  out.已覆盖商品数 = Object.keys(covered).length;
  out.覆盖明细 = covered;

  return JSON.stringify(out, null, 1);
})()
