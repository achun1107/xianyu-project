// ad-fix-babies.js —— 把超出「一个宝贝最多绑 3 个计划」的旧宝贝从新建计划里摘掉
// 背景：2026-09-21 建 孙燕姿广州/侯明昊郑州 4 个计划时，把已经绑满的旧宝贝又塞了进去，
//       平台判「部分商品因状态异常无法擦亮」并自动暂停，且恢复无效（必须先把宝贝改对）。
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;
  }
  const drawers = () => [].slice.call(document.querySelectorAll('.ant-drawer-content')).filter(d => d.getBoundingClientRect().width > 200);
  const outer = () => drawers().find(d => /编辑计划/.test(d.innerText || ''));
  const rowTitles = od => [].slice.call(od.querySelectorAll('[class*=goodsTitle]')).map(e => (e.innerText || '').trim());

  const PLANS = [
    { name: '孙燕姿广州-咨询120', remove: ['【代拍必中】孙燕姿广州站演唱会接代拍首开代抢孙燕姿演唱会代抢'] },
    { name: '孙燕姿广州-订单120', remove: ['【代拍必中】孙燕姿广州站演唱会接代拍首开代抢孙燕姿演唱会代抢'] },
    { name: '侯明昊郑州-咨询120', remove: ['【百分百中代拍】郑州侯明昊演唱会接抢票侯明昊演唱会代拍首开一'] },
    { name: '侯明昊郑州-订单120', remove: ['【百分百中代拍】郑州侯明昊演唱会接抢票侯明昊演唱会代拍首开一'] },
  ];
  const out = [];

  for (const p of PLANS) {
    const R = { plan: p.name };
    try {
      const rows = [].slice.call(document.querySelectorAll('tbody tr'));
      const row = rows.find(r => (r.innerText || '').indexOf(p.name) >= 0);
      if (!row) throw new Error('找不到计划行');
      const ed = [].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑');
      if (!ed) throw new Error('该行没有编辑');
      click1(ed);
      let od = null;
      for (let i = 0; i < 15; i++) { await sleep(1000); od = outer(); if (od && od.querySelector('[class*=goodsTitle]')) break; }
      if (!od) throw new Error('编辑抽屉没打开');
      R.修改前 = rowTitles(od);

      // 逐个点掉要删的宝贝（每次点完 DOM 会重渲染，必须重新查询）
      let removed = 0;
      for (let pass = 0; pass < 6; pass++) {
        const items = [].slice.call(od.querySelectorAll('[class*=goodsItem]'));
        let hit = null;
        for (const it of items) {
          const t = ((it.querySelector('[class*=goodsTitle]') || {}).innerText || '').trim();
          if (p.remove.indexOf(t) >= 0) { hit = it.querySelector('[class*=clearItemBtn]'); break; }
        }
        if (!hit) break;
        click1(hit);
        removed++;
        await sleep(2200);
        od = outer() || od;
      }
      R.已摘掉 = removed;
      await sleep(1500);
      od = outer() || od;
      R.修改后 = rowTitles(od);
      R.badge = ((od.innerText || '').match(/已选宝贝\(([^)]*)\)/) || [])[1];

      // 保存
      const wrap = od.closest('.ant-drawer');
      const foot = wrap && wrap.querySelector('.ant-drawer-footer');
      const ok = foot && [].slice.call(foot.querySelectorAll('div,span,button'))
        .find(e => e.children.length === 0 && /^确\s*定$/.test((e.innerText || '').trim()));
      if (!ok) throw new Error('找不到确定按钮');
      click1(ok);
      R.已提交 = true;
      await sleep(6000);
      const txt = (document.body.innerText || '');
      R.提示 = (txt.match(/[^\n]*(成功|失败|错误|不能|至少)[^\n]*/g) || []).slice(0, 3);
      R.抽屉还开着 = drawers().length;
    } catch (e) { R.fatal = e.message; }
    out.push(R);
    await sleep(1500);
  }
  return JSON.stringify(out, null, 1);
})()
