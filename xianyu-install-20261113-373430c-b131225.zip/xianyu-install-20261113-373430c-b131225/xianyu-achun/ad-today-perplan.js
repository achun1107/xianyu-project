(async () => {
  const mtop = window.lib.mtop;
  let all = [], p = 1;
  while (p <= 5) {
    const r = await mtop.request({
      api: 'mtop.taobao.idle.ad.campaign.search', v: '1.0', type: 'GET',
      data: { requestJson: JSON.stringify({ pageNum: p, pageSize: 100, campaignStatus: [], statusGroup: [] }) },
    });
    if (!(r && r.ret && String(r.ret[0]).indexOf('SUCCESS') === 0)) return JSON.stringify({ err: r.ret });
    const list = (r.data || {}).result || [];
    all = all.concat(list);
    if (list.length < 100) break;
    p++;
  }
  const n = v => { const x = Number(v); return isFinite(x) ? x : 0; };
  const rows = all.map(c => {
    const t = c.todayAdDataDetail || {};
    const it = c.infoTab || {};
    return {
      id: c.campaignId,
      name: c.title || '',
      target: c.bidTarget,
      cpm: n(c.cpm) / 100,
      budget: n(c.maxDayBudget) / 100,
      start: c.startTime,
      时段: (it.budgetScheduleDurations || []).length ? ((it.budgetScheduleDurations[0]) + '-' + (Number(it.budgetScheduleDurations[it.budgetScheduleDurations.length - 1]) + 1) + '点') : '全天',
      商品数: (c.entityList || []).length,
      商品: (c.entityList || []).map(e => e.entityId).join(','),
      成本: n(t.cost) / 100,
      曝光: n(t.showPv),
      点击: n(t.clickPv),
      咨询: n(t.chatPv),
      询单: n(t.inquiries),
      下单: n(t.payPv),
      支付额: n(t.payAmount) / 100,
      咨询成本: n(t.chatPv) > 0 ? +(n(t.cost) / n(t.chatPv) / 100).toFixed(2) : null,
      点击成本: n(t.clickPv) > 0 ? +(n(t.cost) / n(t.clickPv) / 100).toFixed(2) : null,
      下单成本: n(t.payPv) > 0 ? +(n(t.cost) / n(t.payPv) / 100).toFixed(2) : null,
      ROI: n(t.returnOnInvestment),
      点击率: n(t.ctr),
    };
  });
  // 类别
  const cat = r => /^热销/.test(r.name) ? '热销' : /^单明星/.test(r.name) ? '单明星' : /^近期开抢/.test(r.name) ? '近期开抢' : '主/副集合';
  rows.forEach(r => r.类别 = cat(r));
  return JSON.stringify({ 时刻: new Date().toLocaleString('zh-CN'), 计划数: rows.length, 计划: rows }, null, 1);
})()
