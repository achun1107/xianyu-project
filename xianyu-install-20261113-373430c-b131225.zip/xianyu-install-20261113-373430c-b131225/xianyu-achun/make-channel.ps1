﻿# make-channel.ps1 -- 创建企微智能表格（广告日报 + 指令 双向通道）
# 写成文件执行 + 结果落盘，避免 PowerShell 内联中文/引号的编码问题。
# ASCII 注释为主；中文只出现在读取的 JSON 文件和变量里。

$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'lib\ps\Config.ps1')
$cli = Get-XyPath 'node.wecomCli'
$outFile = Join-Path (Get-XyPath 'paths.work') 'ss-create-out.txt'

$name = [System.IO.File]::ReadAllText((Join-Path (Get-XyPath 'paths.work') 'ss-name.txt'), [Text.Encoding]::UTF8).Trim()
$sheet = [System.IO.File]::ReadAllText((Join-Path (Get-XyPath 'paths.work') 'ss-sheet.txt'), [Text.Encoding]::UTF8).Trim()
$raw = [System.IO.File]::ReadAllText((Join-Path (Get-XyPath 'paths.work') 'ss-fields-report-min.json'), [Text.Encoding]::UTF8).Trim()

$log = @()
$log += 'name=' + $name
$log += 'sheet=' + $sheet

# --- attempt 1: escape double quotes for the native command line ---
$f1 = $raw -replace '"', '\"'
$o1 = & $cli smartsheet create --name $name --sheet-title $sheet --fields $f1 2>&1 | Out-String
$log += ''
$log += '=== attempt1 (escaped quotes) ==='
$log += $o1.Trim()
$success = $o1 -match 'docid|doc_id'

# --- attempt 2: --set deep paths (no quotes at all) ---
if (-not $success) {
  $log += ''
  $log += '=== attempt2 (--set deep paths) ==='
  $args2 = @('smartsheet','create','--name',$name,'--sheet-title',$sheet)
  $cols = @(
    @('日期','text'), @('花费','number'), @('咨询','number'), @('单次咨询成本','number'),
    @('下单','number'), @('支付额','number'), @('状态','text'), @('明细','text')
  )
  for ($i = 0; $i -lt $cols.Count; $i++) {
    $args2 += '--set'; $args2 += ('fields.' + $i + '.field_title=' + $cols[$i][0])
    $args2 += '--set'; $args2 += ('fields.' + $i + '.field_type=' + $cols[$i][1])
  }
  $o2 = & $cli @args2 2>&1 | Out-String
  $log += $o2.Trim()
}

[System.IO.File]::WriteAllText($outFile, ($log -join "`r`n"), [Text.Encoding]::UTF8)
Write-Host ('written: ' + $outFile)
