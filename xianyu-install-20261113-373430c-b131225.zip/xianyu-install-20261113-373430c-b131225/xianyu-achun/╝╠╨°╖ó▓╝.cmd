@echo off
REM Double-click to RESUME auto-publishing.
REM Deletes D:\DSH\achun\PAUSE-PUBLISH so the next 30-min round publishes again.
cd /d "%~dp0"
if exist "PAUSE-PUBLISH" del /q "PAUSE-PUBLISH"
echo.
echo   Auto-publish RESUMED.
echo   Next round (every 30 min) will publish 1 listing.
echo.
timeout /t 6 >nul
