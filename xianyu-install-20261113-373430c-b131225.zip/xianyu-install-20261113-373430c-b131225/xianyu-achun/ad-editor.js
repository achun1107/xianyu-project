// ad-editor.js —— 给已存在的擦亮计划增加宝贝，并按需重解出价
// cfg = { planName, searchKey, addItems:[], keepImprove:120, submit:false }
(async () => {
  const cfg = window.__ECFG || {};
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const R = { steps: [], errors: [] };
  const step = s => R.steps.push(s);

  function click1(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { }
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
      const E = (t.startsWith('pointer') && window.PointerEvent) ? PointerEvent : MouseEvent;
      el.dispatchEvent(new E(t, o));
    });
    return true;   // 绝不追加 el.click()：展开/格子是 toggle，会双击抵消
  }
  function setNative(el, val) {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    d.set.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const bt = (t, root) => [].slice.call((root || document).querySelectorAll('div,span,button,a'))
    .find(e => e.children.length === 0 && (e.innerText || '').trim() === t);
  const drawers = () => [].slice.call(document.querySelectorAll('.ant-drawer-content'))
    .filter(d => d.getBoundingClientRect().width > 200);
  const outerDrawer = () => drawers().find(d => /编辑计划/.test(d.innerText || ''));
  const pickerDrawer = () => drawers().find(d => /编辑宝贝|新增宝贝/.test(d.innerText || '') && d.querySelector('input[placeholder="请输入宝贝标题"]'));

  try {
    // ---------- 1. 打开该计划的编辑 ----------
    const rows = [].slice.call(document.querySelectorAll('tr'));
    const row = rows.find(r => (r.innerText || '').indexOf(cfg.planName) >= 0);
    if (!row) throw new Error('列表里找不到计划行：' + cfg.planName);
    const edit = [].slice.call(row.querySelectorAll('span,a,button')).find(e => (e.innerText || '').trim() === '编辑');
    if (!edit) throw new Error('该行没有「编辑」');
    click1(edit); await sleep(4000);
    const od = outerDrawer();
    if (!od) throw new Error('编辑 drawer 没打开');
    R.beforeBadge = ((od.innerText.match(/已选宝贝\(([^)]*)\)/) || [])[1]);
    R.beforeImprove = ((od.innerText.match(/预计提升\s*(\d+)%/) || [])[1]);
    step('打开编辑：' + R.beforeBadge + '，预计提升 ' + R.beforeImprove + '%');

    // ---------- 2. 点「编辑宝贝」 ----------
    const eb = bt('编辑宝贝', od);
    if (!eb) throw new Error('找不到「编辑宝贝」');
    click1(eb); await sleep(4500);
    const pd = pickerDrawer();
    if (!pd) throw new Error('编辑宝贝弹层没打开');

    // ---------- 3. 搜索 + Enter ----------
    const search = pd.querySelector('input[placeholder="请输入宝贝标题"]');
    setNative(search, cfg.searchKey);
    search.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
    search.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
    await sleep(3500);

    // ---------- 4. 逐条添加 ----------
    // 【2026-10-08 修·真实事故】原来遍历 'tr,li,div' 并取【第一个】匹配的元素：
    //   父容器（div）的 innerText 也包含子行的「宝贝ID:xxx」，而父容器在文档顺序里
    //   排在前面；搜索结果少的时候父容器文字 < 500 字就通过了长度过滤，
    //   于是 rowsMap[id] 指向【一整块含多行的容器】，再向上找第一个「添加」就点到了别的行。
    //   实际后果：给三亚计划加 1090139217580，结果把广州周杰伦的 1083554882086 加了进去
    //   —— 而那条链接正是老板刚要求停投的。
    //   修法：给候选打分 —— 真行元素(TR) 优先，同一档里取【文字最短】的
    //   （最短的那个才是这一行本身，不是它的祖先）。
    const rowsMap = {};
    const _cand = {};
    [].slice.call(pd.querySelectorAll('tr,li,div')).forEach(e => {
      const t = (e.innerText || '').replace(/\s+/g, ' ').trim();
      const m = t.match(/宝贝ID:(\d{10,})/);
      if (!m || t.length >= 500) return;
      const id = m[1];
      const score = (e.tagName === 'TR' ? 0 : 100000) + t.length;
      if (!_cand[id] || score < _cand[id].score) _cand[id] = { score: score, el: e };
    });
    Object.keys(_cand).forEach(id => { rowsMap[id] = _cand[id].el; });
    R.rowsAvailable = Object.keys(rowsMap);
    R.added = []; R.notFound = [];
    for (const id of cfg.addItems) {
      const rr = rowsMap[String(id)];
      if (!rr) { R.notFound.push(String(id)); continue; }
      let scope = rr, hit = false;
      for (let i = 0; i < 6 && scope && !hit; i++) {
        const b = [].slice.call(scope.querySelectorAll('button,a,span')).find(x => (x.innerText || '').trim() === '添加');
        if (b) { click1(b); hit = true; }
        scope = scope.parentElement;
      }
      if (hit) R.added.push(String(id)); else R.errors.push('点不到添加 ' + id);
      await sleep(800);
    }
    await sleep(1200);
    const pd2 = pickerDrawer();
    R.pickerText = pd2 ? (pd2.innerText || '').replace(/\s+/g, ' ').slice(-260) : null;
    step('已点添加：' + R.added.join(',') + (R.notFound.length ? ' | 没找到：' + R.notFound.join(',') : ''));

    // ---------- 5. 确定（弹层） ----------
    const pdBtns = [].slice.call(pd2.querySelectorAll('button'));
    const ok1 = pdBtns.find(b => /^确\s*定$/.test((b.innerText || '').trim()));
    if (!ok1) throw new Error('编辑宝贝弹层里没有确定按钮，按钮：' + pdBtns.map(b => b.innerText.trim()).join('|'));
    click1(ok1); await sleep(3500);

    const od2 = outerDrawer();
    R.afterBadge = od2 ? ((od2.innerText.match(/已选宝贝\(([^)]*)\)/) || [])[1]) : null;
    R.afterImprove = od2 ? ((od2.innerText.match(/预计提升\s*(\d+)%/) || [])[1]) : null;
    step('加完：' + R.afterBadge + '，预计提升 ' + R.afterImprove + '%');

    // ---------- 6. 出价是否还命中目标？不命中就用 UI 二分重解 ----------
    if (cfg.keepImprove && String(R.afterImprove) !== String(cfg.keepImprove)) {
      const bidInp = od2.querySelector('input[placeholder="自定义出价"]');
      R.hasBidInput = !!bidInp;
      if (bidInp) {
        const readImp = () => {
          const odx = outerDrawer();
          const m = odx && odx.innerText.match(/预计提升\s*(\d+)%/);
          return m ? parseInt(m[1], 10) : null;
        };
        async function probe(v) {
          const el = outerDrawer().querySelector('input[placeholder="自定义出价"]');
          if (!el) throw new Error('出价框消失');
          el.focus(); setNative(el, (Math.round(v * 100) / 100).toFixed(2));
          await sleep(400);
          el.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
          el.dispatchEvent(new Event('blur', { bubbles: true }));
          await sleep(2600);
          return readImp();
        }
        const suggest = parseFloat(((od2.innerText.match(/出价\s*¥\s*([0-9.]+)/) || [])[1]) || '0') || null;
        R.suggestYuan = suggest;
        let lo = suggest || 1, hi = Math.max((suggest || 1) * 1.5, 2);
        const curve = {};
        curve[lo] = await probe(lo); curve[hi] = await probe(hi);
        let g = 0;
        while (curve[hi] < cfg.keepImprove && g++ < 8) { lo = hi; hi = hi * 1.5; curve[hi] = await probe(hi); }
        for (let i = 0; i < 14 && hi - lo > 0.011; i++) {
          const mid = Math.round((lo + hi) / 2 * 100) / 100;
          if (mid === lo || mid === hi) break;
          curve[mid] = await probe(mid);
          if (curve[mid] >= cfg.keepImprove) hi = mid; else lo = mid;
        }
        R.finalBid = Math.round(hi * 100) / 100;
        curve[R.finalBid] = await probe(R.finalBid);
        R.curve = curve;
        R.finalImprove = curve[R.finalBid];
        step('重解出价 ¥' + R.finalBid.toFixed(2) + ' → ' + R.finalImprove + '%');
      }
    }

    // ---------- 7. 保存 ----------
    R.selfCheck = {
      宝贝数对: String(R.afterBadge) === String((parseInt(R.beforeBadge, 10) + cfg.addItems.length)) + '/10',
      提升对: !cfg.keepImprove || String(R.finalImprove || R.afterImprove) === String(cfg.keepImprove),
    };
    R.selfCheckPassed = Object.keys(R.selfCheck).every(k => R.selfCheck[k]);
    if (!R.selfCheckPassed) { R.aborted = '自检未通过，未保存'; return JSON.stringify(R, null, 1); }
    if (!cfg.submit) { R.aborted = 'dry run，未保存'; return JSON.stringify(R, null, 1); }

    // 外层 drawer 的「确定」不是 <button>，是 .ant-drawer-footer 里的
    // <div class="footerBtn--buYXG2eq">确定</div>；而 footer 是 .ant-drawer-content 的兄弟，
    // 所以必须从 .ant-drawer 包裹层往里找（实测：querySelectorAll('button') 恒为空）
    const wrap = outerDrawer().closest('.ant-drawer');
    const foot = wrap && wrap.querySelector('.ant-drawer-footer');
    R.footerHtml = foot ? (foot.innerHTML || '').replace(/\s+/g, ' ').slice(0, 300) : null;
    const ok2 = foot && [].slice.call(foot.querySelectorAll('div,span,button'))
      .find(e => e.children.length === 0 && /^确\s*定$/.test((e.innerText || '').trim()));
    if (!ok2) throw new Error('找不到外层 drawer 的确定按钮（footer 内容：' + (R.footerHtml || '无 footer') + '）');
    click1(ok2);
    R.saved = true;
    await sleep(5000);
    R.afterSave = {
      url: location.href,
      drawersLeft: drawers().length,
      toast: ((document.body.innerText || '').match(/[^\n]*(成功|失败|错误|不能|超出)[^\n]*/g) || []).slice(0, 4),
    };
    return JSON.stringify(R, null, 1);
  } catch (e) {
    R.fatal = e.message;
    return JSON.stringify(R, null, 1);
  }
})()
