@echo off
setlocal
cd /d "%~dp0"
echo.
echo  ==============================================
echo    Xianyu automation - installer
echo  ==============================================
echo.
if not exist "xianyu-achun\install.ps1" (
  echo  [x] xianyu-achun\install.ps1 not found.
  echo      Unzip the WHOLE bundle (keep the three folders side by side) and retry.
  pause & exit /b 1
)
if not exist "xianyu-playwright-service\server.js" (
  echo  [x] xianyu-playwright-service\server.js not found.
  echo      Unzip the WHOLE bundle and retry.
  pause & exit /b 1
)
if not exist "xianyu-monitor\publish.js" (
  echo  [x] xianyu-monitor\publish.js not found.
  echo      Unzip the WHOLE bundle and retry.
  pause & exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo  [x] Node.js not found. Install Node 18+ from https://nodejs.org (LTS),
  echo      then CLOSE this window, open a new one and run this again.
  pause & exit /b 1
)
if not exist "xianyu-playwright-service\service.local.json" (
  echo  [!] xianyu-playwright-service\service.local.json is missing.
  echo      1^) copy xianyu-achun\service.local.json.example to xianyu-playwright-service\service.local.json
  echo      2^) fill in id / name (see install-guide.html section 2)
  echo      3^) double-click xianyu-playwright-service\start.bat, then run this again
  pause & exit /b 1
)
cd xianyu-achun
echo.
echo  ---- step 1/2: DRY RUN (changes nothing) ----
powershell -ExecutionPolicy Bypass -File install.ps1 -DryRun
echo.
echo  Check these two lines above point at:
echo    xianyu-playwright-service  and  xianyu-monitor
echo  If not, stop: the three folders are not side by side.
echo.
pause
echo  ---- step 2/2: REAL INSTALL ----
powershell -ExecutionPolicy Bypass -File install.ps1
echo.
echo  ---- done. next: scan the QR code ----
echo    node tools\store-ready.js "your-store-name"
echo    node tools\store-login.js "your-store-name" --wait=15
pause
