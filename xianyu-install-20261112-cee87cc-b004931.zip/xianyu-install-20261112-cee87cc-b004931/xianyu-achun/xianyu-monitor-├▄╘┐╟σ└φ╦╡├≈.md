# xianyu-monitor 密钥清理（2026-10-10，为分发做准备）

## 为什么要动这个仓

吴卫龙的 agent 发来：「找发件人要 **xianyu-monitor**（zip 或 gitlab 只读 token）」。
打这个包时**凭证扫描器直接拦下了**：老板本机 8093 的 `apiKey` **明文散在 16 个被跟踪文件里，共 22 处**。

| 文件 | 处数 |
|---|---|
| `publish.js` | 2 |
| `publish.js.bak_20260913` / `.bak_20260914` / `.bak_addrfix_*` / `.bak_cityfallback_*` / `.bak_fixtasks_*` | 各 2（共 10） |
| `api.js` / `bridge_direct.js` / `dashboard.js` / `publish_dashboard.js` | 各 1 |
| `console-tools/eval-store.js` / `preview-poster.js` / `trigger-publish.js` | 各 1 |
| `ad_ledger.py` | 1（`os.environ.get("XY_KEY", "<真key>")`） |
| `CODE_REVIEW.md` / `闲鱼项目合体研究-完整报告.md` | 各 1（这两份是在**记录**这个泄漏） |

**发出去 = 把驱动着你已登录闲鱼浏览器的那个本地服务的密钥，交到学员手上。**

## 改了什么（只改工作树，**没在该仓提交**）

1. **9 个代码文件、11 处** → 明文 key 换成**空串**
2. **`ad_ledger.py`** → 改成 `os.environ.get("XY_KEY", "")`（它本来就有 env 兜底，只是默认值是真 key）
3. **2 份文档** → 打码成 `xy_78****`
4. **5 个被跟踪的 `.bak_*`** → `git rm --cached` 取消跟踪（**文件留在磁盘，没删数据**）
5. **`.gitignore`**：`*.bak` → **`*.bak*`**
   —— 这是那 5 个备份一直被跟踪的根因：`*.bak` 匹配不到 `publish.js.bak_20260913` 这种带日期的后缀

结果：**被跟踪文件里 0 处**（51 个文件全查过）。

## ⚠️ 这处改动有一个必须记住的耦合

**换成空串之所以"行为等价"，是因为 8093 的 auth 对 `127.0.0.1` 来源直接放行**
（`server.js` 的 `isLocal` 分支）。key 是空、是错、是老板的，三种情况在学员机上表现**完全一样** ——
这也是它一直没被发现的原因。

**所以：等我们把 `isLocal` 免密钥放行堵掉（P0 那条安全洞）时，这些调用必须同步改成「读本机 key」，否则桌面发布台会全线 401。**

两件事必须一起做，别只做一半。

顺带说明：这些硬编码的 key **在学员机上本来就是错的**（每台机器的 8093 自己生成随机 key），
只是因为那个旁路才"能用"。所以这一步不但没削弱功能，反而是把一个本来就不对的写法清掉了。

## 现在的分发包

```
D:\xianyu-release\
  xianyu-achun-<版本>.zip                    1.8 MB   712 文件
  xianyu-playwright-service-<版本>.zip       0.1 MB    12 文件
  xianyu-monitor-<版本>.zip                  0.3 MB    48 文件   ← 这次新增
```

三个包都过了凭证扫描（拿本机 11 个真实凭证逐个文件查过）。
monitor 包里确认**包含** playwright-service 运行时要读的文件：
`publish.js` / `publish_ui.js` / `address_db.js` / `native_host.py` / `publish_dashboard.js` / `dashboard.js` / `manifest.json`。

## 建议你做一次

改的是你**正在用的桌面发布台**（`publish.js` / `publish_dashboard.js` / `dashboard.js` 都动了）。
因为旁路还在，理论上行为不变，但**建议你打开发布台随便看一眼**（面板能不能开、能不能读到店铺）。
有问题我立刻回滚 —— 这些改动都还没提交。
