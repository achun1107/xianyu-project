#!/usr/bin/env node
/**
 * tools/verify-student-view.js —— 用「学员的目录结构」验一遍安装流程
 *
 * 为什么需要它（2026-11-13）：
 *   这台开发机上 Node / museav / git 全都装好了，很多问题在本机【永远不会出现】。
 *   前几轮踩到的坑（文案模板没人生成、museav 装不上、store.active 指向老板的店、
 *   装完提示要自己替换占位符）都是靠"假装自己是学员"才发现的。
 *   而假装的方法每次都得手打一遍命令、还得盯输出——很容易漏。
 *   这个脚本把那一套固化下来：解压最新包 → 造一份假 service.local.json →
 *   跑 install.ps1 -DryRun → 逐项断言。
 *
 * ⚠️ 它只验【安装器这一侧】能验的东西。真机上才有的差异（没装 Node、
 *    Chromium 首次下载、真扫码、真发布）这里验不了，见 真机首装验证清单.md。
 *
 * 用法:
 *   node tools/verify-student-view.js                  # 用 D:\xianyu-release 里最新的包
 *   node tools/verify-student-view.js --zip=<路径>      # 指定包
 *   node tools/verify-student-view.js --store=我的测试店 # 指定假店名
 *   node tools/verify-student-view.js --keep            # 保留临时目录便于排查
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const A = {};
process.argv.slice(2).forEach((a, i, arr) => {
  if (!a.startsWith('--')) return;
  const eq = a.indexOf('=');
  if (eq > 2) { A[a.slice(2, eq)] = a.slice(eq + 1); return; }
  A[a.slice(2)] = (arr[i + 1] && !arr[i + 1].startsWith('--')) ? arr[i + 1] : true;
});

const STORE = String(A.store || '验证用测试店');
const KEEP = !!A.keep;

function findZip() {
  if (A.zip) return A.zip;
  const dir = 'D:\\xianyu-release';
  if (!fs.existsSync(dir)) return '';
  const zips = fs.readdirSync(dir).filter(f => /^xianyu-install-.*\.zip$/.test(f));
  if (!zips.length) return '';
  // 按【修改时间】取最新（按字母序会选错：f4f4968 排在 7ed762d 后面）
  zips.sort((a, b) => fs.statSync(path.join(dir, a)).mtimeMs - fs.statSync(path.join(dir, b)).mtimeMs);
  return path.join(dir, zips[zips.length - 1]);
}

const ZIP = findZip();
if (!ZIP || !fs.existsSync(ZIP)) {
  console.log('❌ 找不到分发包。先跑：');
  console.log('   node tools/make-release.js      （打三个仓）');
  console.log('   node tools/_build-install-bundle.js   （合成学员包）');
  process.exit(2);
}

const results = [];
const check = (name, ok, detail) => {
  results.push({ name, ok, detail: detail || '' });
  console.log('  ' + (ok ? '✅' : '❌') + ' ' + name + (detail ? '   ' + detail : ''));
};

(async () => {
  console.log('\n════ 学员视角验证 ════');
  console.log('包     : ' + path.basename(ZIP));
  console.log('假店名 : ' + STORE);

  const stage = path.join(os.tmpdir(), 'xy-verify-' + Date.now());
  fs.mkdirSync(stage, { recursive: true });

  // ── ① 解压 ──
  console.log('\n① 解压');
  try {
    execFileSync('tar', ['-xf', ZIP, '-C', stage], { encoding: 'utf8', timeout: 180000 });
  } catch (e) {
    check('解压成功', false, String(e.message).slice(0, 80));
    process.exit(1);
  }
  const roots = fs.readdirSync(stage, { withFileTypes: true }).filter(d => d.isDirectory());
  if (!roots.length) { check('找到解压后的目录', false); process.exit(1); }
  const root = path.join(stage, roots[0].name);
  const achun = path.join(root, 'xianyu-achun');
  check('解压后能定位到 xianyu-achun', fs.existsSync(achun));

  // ── ② 三目录并排 ──
  console.log('\n② 目录结构（学员最容易搞错的地方）');
  ['xianyu-achun', 'xianyu-playwright-service', 'xianyu-monitor'].forEach(d => {
    check(d + ' 并排存在', fs.existsSync(path.join(root, d)));
  });
  check('install.cmd 在根层', fs.existsSync(path.join(root, 'install.cmd')));
  check('install-guide.html 在根层', fs.existsSync(path.join(root, 'install-guide.html')));

  // ── ③ 造一份学员的 service.local.json ──
  console.log('\n③ 造学员的账号配置');
  const svcLocal = path.join(root, 'xianyu-playwright-service', 'service.local.json');
  const fakeId = '00000000-1111-2222-3333-444444444444';
  fs.writeFileSync(svcLocal, JSON.stringify({
    _说明: 'verify-student-view.js 造的假配置，只用于验证',
    localAccounts: [{ id: fakeId, name: STORE, username: '', password: '' }],
  }, null, 2), 'utf8');
  check('service.local.json 已写入', fs.existsSync(svcLocal), 'id=' + fakeId.slice(0, 8) + '… name=' + STORE);

  // ── ④ 跑 install.ps1 -DryRun ──
  console.log('\n④ 跑安装预演（-DryRun，什么都不改）');
  let out = '';
  try {
    out = execFileSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', 'install.ps1', '-DryRun'],
      { cwd: achun, encoding: 'utf8', timeout: 600000 });
  } catch (e) {
    out = (e.stdout || '') + (e.stderr || '');
  }

  // ── ⑤ 逐项断言 ──
  console.log('\n⑤ 断言');

  check('node 被识别', /\[ok\]\s+node:/.test(out), (out.match(/\[ok\]\s+node:.*/) || [''])[0].trim().slice(0, 70));

  // npm 必须和 node 同源（2026-11-12 修过的坑）
  const npmLine = (out.match(/\[DryRun\]\s+(\S*npm(?:\.cmd|\.exe|\.ps1))\s+install/) || [])[1] || '';
  const nodePath = (out.match(/\[ok\]\s+node:\s*(\S+)/) || [])[1] || '';
  const nodeDir = nodePath ? path.dirname(nodePath).toLowerCase() : '';
  check('npm 与 node 同源', !!npmLine && (!nodeDir || npmLine.toLowerCase().includes(nodeDir.slice(-30))),
    npmLine ? path.basename(npmLine.split(/\s+/)[0]) : '(没找到 npm install 行)');

  check('两个依赖仓都就位', /xianyu-playwright-service 已就位/.test(out) && /xianyu-monitor 已就位/.test(out));

  check('文案模板库这一步跑到了', /文案模板库/.test(out),
    (out.match(/已生成: .*xianyu-templates\.json|已存在，不覆盖: .*xianyu-templates\.json/) || [''])[0].trim().slice(0, 60));

  check('出图客户端这一步跑到了', /出图客户端/.test(out),
    (out.match(/museav 已装: .*|\[DryRun\] .*museav-cli@latest/) || [''])[0].trim().slice(0, 60));

  check('没有缺失项', /没有缺失项/.test(out));
  check('没有 FAIL', !/\[FAIL\]/.test(out));

  // 最关键的：装完提示必须用学员的店名，不能是占位符
  const tail = out.slice(out.indexOf('剩下必须人工做的三件事'));
  check('装完提示用了学员店名', tail.includes(STORE), tail.includes(STORE) ? '✓ 含 "' + STORE + '"' : '⚠️ 还是占位符');
  check('装完提示没有残留占位符', !/<你的店铺名>|<店铺名>/.test(tail),
    /<你的店铺名>|<店铺名>/.test(tail) ? '出现了 <你的店铺名>' : '');

  // ── ⑥ 汇总 ──
  const bad = results.filter(r => !r.ok);
  console.log('\n════ 结果 ════');
  console.log('  ' + (results.length - bad.length) + '/' + results.length + ' 通过');
  if (bad.length) {
    console.log('\n  ❌ 没过的：');
    bad.forEach(r => console.log('     · ' + r.name + (r.detail ? '  ' + r.detail : '')));
  } else {
    console.log('  ✅ 安装器这一侧没问题。真机上才有的差异见 真机首装验证清单.md');
  }

  if (!KEEP) {
    try { fs.rmSync(stage, { recursive: true, force: true }); } catch (e) {}
  } else {
    console.log('\n  临时目录保留在: ' + stage);
  }
  process.exit(bad.length ? 1 : 0);
})().catch(e => { console.log('❌ ' + (e && e.message || e)); process.exit(1); });
